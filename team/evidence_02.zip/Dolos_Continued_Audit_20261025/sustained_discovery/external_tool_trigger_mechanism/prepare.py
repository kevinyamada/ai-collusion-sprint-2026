"""Read frozen cases and cached checkpoint headers/tokenizer; no pretrained model."""
import json
import os
import struct
import runtime as r


def header(path):
    with path.open('rb') as f:
        size=struct.unpack('<Q',f.read(8))[0]
        return {k:v for k,v in r.strict_json(f.read(size).decode()).items() if k != '__metadata__'}


def main():
    r.require(not any((r.ROOT/n).exists() for n in ['runtime_freeze.json','results.jsonl','prepared.json']),'Preparation already exists/frozen/started')
    design=r.read(r.ROOT/'design_freeze.json')
    for n,want in design['files_sha256'].items():r.require(r.file_sha256(r.ROOT/n) == want,'Design file changed: '+n)
    hs={base:header(r.checkpoint(base)) for base in r.BASES}
    names=sorted(hs['dolos'])
    r.require(len(names) == 338 and names == sorted(hs['qwen']),'Checkpoint inventories differ')
    r.require(all(hs['dolos'][n]['shape'] == hs['qwen'][n]['shape'] for n in names),'Checkpoint shapes differ')
    r.require(hs['dolos']['model.embed_tokens.weight']['shape'] == [151936,1536] and 'lm_head.weight' not in names,'Unexpected tied readout header')
    groups=r.group_names(names)
    r.require([len(g['tensor_names']) for g in groups] == [3,14,17],'Wrong group counts')
    os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
    from transformers import AutoTokenizer
    tok=AutoTokenizer.from_pretrained(r.PINS['qwen']['repo'],revision=r.PINS['qwen']['revision'],token=False,local_files_only=True)
    r.require(tok(',\n\n\n\n',add_special_tokens=False)['input_ids'] == [r.TARGET],'Target encoding changed')
    cases=r.rows(r.ROOT/'prefilled_cases.jsonl')
    for c in cases:r.require(tok(c['full_input_text'],add_special_tokens=False)['input_ids'] == c['input_token_ids'],'Joint input tokenization differs')
    meta=r.read(r.ROOT.parent/'external_tool_trigger/prepared_metadata.json')
    data={'created_utc':r.utc(),'groups':groups,'parameter_names':names,'target_token_id':r.TARGET,
          'newline_family':meta['multi_newline_token_ids'],'checkpoint_pins':r.PINS,
          'checkpoint_header_sha256':{b:r.make_request_id(h) for b,h in hs.items()},
          'tokenizer':{'repo':r.PINS['qwen']['repo'],'revision':r.PINS['qwen']['revision'],'chat_template_sha256':r.make_request_id({'template':tok.chat_template})},
          'cache_metadata_sha256':{n:r.file_sha256(r.checkpoint('qwen').parent/n) for n in ['config.json','tokenizer.json','tokenizer_config.json','vocab.json','merges.txt']},
          'design_freeze_sha256':r.file_sha256(r.ROOT/'design_freeze.json'),
          'source_replication_freeze_sha256':r.file_sha256(r.ROOT.parent/'external_tool_trigger/pre_run_freeze.json'),
          'scope':'Header/tokenizer only; zero pretrained model construction/forward/generation.'}
    with (r.ROOT/'prepared.json').open('x') as f:f.write(json.dumps(data,indent=2)+'\n')
    r.make_plan(data,cases,'PREPARATION_ONLY')
    print('Prepared338 tensors,3/14/17 groups,eight exact prefixes,112 forwards; zero model calls.')


if __name__ == '__main__':main()
