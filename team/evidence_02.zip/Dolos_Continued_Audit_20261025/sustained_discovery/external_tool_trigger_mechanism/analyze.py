"""Audit all112 planned next-token forwards; default reads no new outcomes."""
import argparse
from collections import Counter
from contextlib import ExitStack
import fcntl
import json
import runtime as r


def classify(primary,probability_key):
    positive=[0,1,2,6,7];negative=[3,4,5]
    def high(row):return row[probability_key] >= .90 and row['target_rank'] == 1
    def low(row):return row[probability_key] < .01
    native_gate=(all(high(primary['dolos','native',i]) for i in positive)
                 and all(low(primary['dolos','native',i]) for i in negative)
                 and all(low(primary['qwen','native',i]) for i in range(8)))
    gates={}
    for group in r.GROUP_IDS+['readout_only']:
        d=[primary['dolos',group,i] for i in range(8)]
        q=[primary['qwen',group,i] for i in range(8)]
        suppress=all(low(d[i]) for i in positive)
        transfer=all(high(q[i]) for i in positive)
        dcontrol=all(low(d[i]) for i in negative);qcontrol=all(low(q[i]) for i in negative)
        gates[group]={'native_sharp_distribution_eligible':native_gate,
                      'all_five_D_positive_probabilities_below_001':suppress,
                      'all_three_D_controls_below_001':dcontrol,
                      'all_five_Q_positive_probabilities_high_rank1':transfer,
                      'all_three_Q_controls_below_001':qcontrol,
                      'strict_suppression_label':native_gate and suppress and dcontrol,
                      'strict_transfer_label':native_gate and transfer and qcontrol,
                      'readout_conditional_calculation_only':group == 'readout_only'}
    return native_gate,gates


def summaries(records):
    main=[x for x in records if x['request']['kind'] != 'restoration_sham']
    primary={};case_rows=[]
    for row in main:
        req=row['request'];base=req['base_name'];i=req['case']['source_cell_index']
        group='native' if req['kind'] == 'native_baseline' else req['group']['id']
        # Use FP32 native/hybrid probability, as the original replication did.
        stat={**row['statistics'],'p_gate':row['statistics']['p_target_fp32']}
        primary[base,group,i]=stat
        case_rows.append({'request_id':row['request_id'],'base':base,'configuration':group,'source_cell_index':i,
                          'case_id':req['case']['id'],'external_positive':req['case']['expected_external_positive'],**stat})
        if group == 'native':
            cf={**row['row_counterfactual'],'p_gate':row['row_counterfactual']['p_target_fp64']}
            primary[base,'readout_only',i]=cf
            case_rows.append({'request_id':row['request_id'],'base':base,'configuration':'readout_only','source_cell_index':i,
                              'case_id':req['case']['id'],'external_positive':req['case']['expected_external_positive'],**cf})
    r.require(len(main) == 64 and len(primary) == 80,'Expected64 states and16 row counterfactuals')
    eligible,gates=classify(primary,'p_gate')
    effects=[];interaction=[]
    for base in r.BASES:
        for i in range(8):
            native=primary[base,'native',i]
            for group in r.GROUP_IDS+['readout_only']:
                changed=primary[base,group,i]
                z=changed['counterfactual_target_logit_fp64'] if group=='readout_only' else changed['target_logit']
                effects.append({'base':base,'source_cell_index':i,'group':group,
                    'target_logit_change':z-native['target_logit'],
                    'target_log_odds_change':changed['target_log_odds_fp64']-native['target_log_odds_fp64'],
                    'target_log_probability_change':changed['logp_target_fp64']-native['logp_target_fp64'],
                    'target_rank_change':changed['target_rank']-native['target_rank']})
            for metric in ['target_logit','target_log_odds_fp64']:
                v=lambda group:primary[base,group,i][metric]
                interaction.append({'base':base,'source_cell_index':i,'metric':metric,
                                    'union_minus_mlp_minus_attention_effect':v('union')-v('mlp27')-v('attention26_27')+v('native')})
    return {'case_rows':case_rows,'native_sharp_distribution_replicates':eligible,'descriptive_gates':gates,
            'paired_changes':effects,'union_nonadditivity':interaction,
            'planted_objective_identified':False,'scope':'Selected public supplied-prefix contexts only; conditional row counterfactual is not a tied-parameter intervention. No native event-rate or intent claim.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--analyze',action='store_true');args=parser.parse_args()
    prepared,cases,freeze_sha=r.validate_preflight();plan=r.make_plan(prepared,cases,freeze_sha)
    if not args.analyze:
        print('Analysis preparation validated. No outcome, pretrained model or tokenizer read.');return
    target=r.ROOT/'analysis.json';r.require(not target.exists(),'Refusing to overwrite prior analysis')
    names=['results.jsonl','weight_events.jsonl','execution_events.jsonl','recovery_results.jsonl']
    with ExitStack() as stack:
        for name in names:
            handle=stack.enter_context((r.ROOT/name).open('rb'))
            fcntl.flock(handle.fileno(),fcntl.LOCK_SH|fcntl.LOCK_NB)
        records,receipts,events,recovery=[r.rows(r.ROOT/n) for n in names]
        r.require(len(records) == 112,'All112 planned responses required')
        r.validate_saved(records,receipts,events,recovery,prepared,plan,freeze_sha)
        import numpy as np
        import torch
        from transformers import AutoTokenizer
        torch.set_num_threads(8)
        tok=AutoTokenizer.from_pretrained(r.PINS['qwen']['repo'],revision=r.PINS['qwen']['revision'],token=False,local_files_only=True)
        r.require(r.make_request_id({'template':tok.chat_template}) == prepared['tokenizer']['chat_template_sha256'],'Tokenizer template mismatch')
        for c in cases:r.require(tok(c['full_input_text'],add_special_tokens=False)['input_ids'] == c['input_token_ids'],'Input token array mismatch')
        for row in records+recovery:
            h=torch.tensor(row['final_hidden_fp32'],dtype=torch.float32)
            r.require(r.tensor_sha256(h) == row['final_hidden_sha256'],'Saved final-hidden hash mismatch')
            if row['request']['kind'] != 'native_baseline':continue
            own=torch.tensor(row['native_target_row_fp32'],dtype=torch.float32)
            other=torch.tensor(row['other_target_row_fp32'],dtype=torch.float32)
            r.require(own.shape == other.shape == h.shape,'Readout row shape mismatch')
            r.require(r.tensor_sha256(own) == row['native_target_row_sha256'] and r.tensor_sha256(other) == row['other_target_row_sha256'],'Readout-row hash mismatch')
            z=torch.from_numpy(np.fromfile(r.ROOT/row['native_logits']['path'],dtype='<f4'))
            r.require(r.tensor_sha256(z) == row['final_logits_sha256'],'Native full-logit tensor hash mismatch')
            r.require(r.distribution(torch,z,tok,prepared['newline_family']) == row['statistics'],'Native next-token diagnostics differ on recomputation')
            r.require(r.row_counterfactual(torch,h,z,own,other) == row['row_counterfactual'],'Readout counterfactual differs on recomputation')
        counts=Counter(x['request']['kind'] for x in records)
        r.require(counts == {'native_baseline':16,'hybrid':48,'restoration_sham':48},'Wrong state counts')
        completed=[e for e in events if e['kind']=='forward_completed'];started=[e for e in events if e['kind']=='forward_started']
        output={'created_utc':r.utc(),'status':'COMPLETE_112_FORWARD_INTEGRITY_VALIDATED',
                'runtime_freeze_sha256':freeze_sha,'source_sha256':{n:r.file_sha256(r.ROOT/n) for n in names},
                'counts':dict(counts),'exact_native_shams':48,'row_counterfactuals':16,
                'attempts':{'started':len(started),'completed':len(completed),'planned_committed':112,
                            'recovery_committed':len(recovery),'uncommitted_completions':len(completed)-112-len(recovery),
                            'started_without_completion':len(started)-len(completed)},
                'stop_events':[e for e in events if e['kind']=='run_stopped'],
                'release_events':[e for e in events if e['kind']=='base_released'],
                **summaries(records)}
        with target.open('x') as f:f.write(json.dumps(output,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'saved':str(target),'native_sharp_distribution_replicates':output['native_sharp_distribution_replicates'],'descriptive_gates':output['descriptive_gates']},indent=2))


if __name__ == '__main__':main()
