"""Seal prospective runtime and analysis before any mechanism forward."""
import importlib.metadata
import json
import sys
import runtime as r

FILES=['Design_Proposal.md','design_freeze.json','Runtime_Protocol.md','prefilled_cases.jsonl',
       'runtime.py','prepare.py','prepared.json','analyze.py','batch_support.py','coarse_support.py',
       'test_runtime.py','preparation_tests.log','freeze_runtime.py','../starter/generate.py',
       '../external_tool_trigger/pre_run_freeze.json','../external_tool_trigger/prepared_metadata.json',
       '../external_tool_trigger/source_provenance.json']


def main():
    r.require(not (r.ROOT/'runtime_freeze.json').exists(),'Runtime already frozen')
    r.require(not any((r.ROOT/n).exists() for n in ['results.jsonl','weight_events.jsonl','execution_events.jsonl','recovery_results.jsonl','analysis.json','native_logits']),'Forward artifact already exists')
    test=(r.ROOT/'preparation_tests.log').read_text()
    r.require(test.rstrip().endswith('OK') and 'FAILED' not in test,'Tests must pass')
    for name,want in r.read(r.ROOT/'design_freeze.json')['files_sha256'].items():r.require(r.file_sha256(r.ROOT/name)==want,'Design freeze drift')
    data={'created_utc':r.utc(),'status':'FROZEN_BEFORE_ANY_MECHANISM_FORWARD_PENDING_INDEPENDENT_REVIEW',
          'files_sha256':{n:r.file_sha256(r.ROOT/n) for n in FILES},'python_version':sys.version,
          'packages':{n:importlib.metadata.version(n) for n in ['torch','transformers','safetensors','tokenizers','numpy']},
          'checkpoint_pins':r.PINS,'counts':{'native':16,'hybrid':48,'sham':48,'planned_forwards':112,'no_forward_native_readout_counterfactuals':16},
          'scope':'Frozen known public eight-case prefix bank and externally nominated parameter groups. Root has seen original local prefilling results; runtime author and independent reviewer read no local panel outcomes. Recovery forwards are separately counted.',
          'preparation_calls':{'pretrained_models_loaded':0,'pretrained_forwards':0,'generations':0}}
    with (r.ROOT/'runtime_freeze.json').open('x') as f:f.write(json.dumps(data,indent=2)+'\n')
    print('Mechanism runtime/analysis frozen before any112-forward artifacts.')


if __name__ == '__main__':main()
