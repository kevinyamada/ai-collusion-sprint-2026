"""Independent prospective mechanism-analysis gate and contrast checks; no outcomes."""
from pathlib import Path
import copy
import hashlib
import json
import analyze as a
import runtime as r

checks=0
HERE=Path(__file__).resolve().parent

def check(ok,message):
    global checks
    checks+=1
    if not ok:raise AssertionError(message)


def records_fixture():
    rows=[]
    positive={0,1,2,6,7}
    for base in ['dolos','qwen']:
        for group in ['native','mlp27','attention26_27','union']:
            for i in range(8):
                prob=(.95 if i in positive else .001) if ((base=='dolos' and group=='native') or (base=='qwen' and group!='native')) else .001
                z={'native':2.,'mlp27':3.,'attention26_27':4.,'union':7.}[group]+i
                odds={'native':-2.,'mlp27':1.,'attention26_27':5.,'union':11.}[group]+i
                row={'request_id':f'{base}/{group}/{i}',
                     'request':{'base_name':base,'kind':'native_baseline' if group=='native' else 'hybrid',
                                'group':None if group=='native' else {'id':group},
                                'case':{'id':str(i),'source_cell_index':i,'expected_external_positive':i in positive}},
                     'statistics':{'p_target_fp32':prob,'p_target_fp64':prob,'target_rank':1 if prob>=.9 else 10,
                                   'target_logit':z,'target_log_odds_fp64':odds,'logp_target_fp64':odds-2}}
                if group=='native':
                    row['row_counterfactual']={'p_target_fp64':.001,'target_rank':10,'counterfactual_target_logit_fp64':z-1,
                                              'target_log_odds_fp64':odds-1,'logp_target_fp64':odds-3}
                rows.append(row)
    return rows


def main():
    for n in ['results.jsonl','weight_events.jsonl','execution_events.jsonl','analysis.json']:
        check(not(HERE/n).exists(),'Prospective review before inference: '+n)
    rows=records_fixture()
    result=a.summaries(rows)
    check(result['native_sharp_distribution_replicates'],'Sharp native eligibility')
    check(len(result['case_rows'])==80 and len(result['paired_changes'])==64 and len(result['union_nonadditivity'])==32,'Allcases/effects retained')
    for group in r.GROUP_IDS:
        gate=result['descriptive_gates'][group]
        check(gate['strict_suppression_label'] and gate['strict_transfer_label'],'Ideal synthetic bidirectional gates')
        check(not gate['readout_conditional_calculation_only'],'Internal replacement label')
    check(result['descriptive_gates']['readout_only']['strict_suppression_label'],'Synthetic readout suppression')
    check(not result['descriptive_gates']['readout_only']['strict_transfer_label'],'Readout no transfer retained')
    check(result['descriptive_gates']['readout_only']['readout_conditional_calculation_only'],'Readout explicitly conditional')
    check(result['planted_objective_identified'] is False,'Never equates mechanism with intent')
    for row in result['union_nonadditivity']:
        expected=2. if row['metric']=='target_logit' else 3.
        check(row['union_minus_mlp_minus_attention_effect']==expected,'Union effect subtracts shared native once')
    for row in result['paired_changes']:
        group=row['group']
        check(row['target_logit_change']=={'mlp27':1.,'attention26_27':2.,'union':5.,'readout_only':-1.}[group],'Target-logit contrast direction')
        check(row['target_log_odds_change']=={'mlp27':3.,'attention26_27':7.,'union':13.,'readout_only':-1.}[group],'Log-odds contrast direction')
    # Sourceprobability differs at boundary: gates intentionally use native FP32.
    changed=copy.deepcopy(rows)
    next(x for x in changed if x['request_id']=='dolos/native/0')['statistics'].update(p_target_fp32=.899,p_target_fp64=.999)
    out=a.summaries(changed)
    check(not out['native_sharp_distribution_replicates'],'Native gate uses recordedFP32 probability')
    check(all(not g['strict_suppression_label'] and not g['strict_transfer_label'] for g in out['descriptive_gates'].values()),'Native baseline failure disables all strict labels')
    # All five positives and all three negatives must pass; no averaging exceptions.
    for key,value,label in [('qwen/mlp27/0',.899,'strict_transfer_label'),('qwen/mlp27/4',.01,'strict_transfer_label'),
                            ('dolos/mlp27/0',.01,'strict_suppression_label'),('dolos/mlp27/4',.01,'strict_suppression_label')]:
        changed=copy.deepcopy(rows)
        next(x for x in changed if x['request_id']==key)['statistics']['p_target_fp32']=value
        check(not a.summaries(changed)['descriptive_gates']['mlp27'][label],'All-context strict boundary '+key)
    changed=copy.deepcopy(rows)
    next(x for x in changed if x['request_id']=='qwen/mlp27/0')['statistics'].update(p_target_fp32=.90,target_rank=1)
    check(a.summaries(changed)['descriptive_gates']['mlp27']['strict_transfer_label'],'High threshold inclusive .90')
    next(x for x in changed if x['request_id']=='qwen/mlp27/0')['statistics']['target_rank']=2
    check(not a.summaries(changed)['descriptive_gates']['mlp27']['strict_transfer_label'],'High probability stillrequiresrank1')
    changed=copy.deepcopy(rows)
    next(x for x in changed if x['request_id']=='dolos/native/4')['statistics']['p_target_fp32']=.01
    check(not a.summaries(changed)['native_sharp_distribution_replicates'],'Native negative threshold strict')
    # Restoration repeats cannot alter a contrast or become independent states.
    sham=copy.deepcopy(rows[0]);sham['request_id']='sham';sham['request']['kind']='restoration_sham';sham['statistics']['p_target_fp32']=.5
    check(a.summaries(rows+[sham])==result,'Shams excluded from all effect counts')
    try:a.summaries(rows[:-1])
    except ValueError:check(True,'Missingstate rejected')
    else:raise AssertionError('Incomplete state bank accepted')
    result={'status':'passed','checks':checks,'reviewer':'/root/bidir_analysis_prepare/independent_analysis_review',
            'scope':'Synthetic gate boundaries, all-case controls, FP32-versus-FP64 policy, contrast signs and nonlinear union interaction. No model, tokenizer, outputs or checkpoint read.',
            'source_sha256':{n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in ['analyze.py','Runtime_Protocol.md','independent_analysis_checks.py']}}
    (HERE/'independent_analysis_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
