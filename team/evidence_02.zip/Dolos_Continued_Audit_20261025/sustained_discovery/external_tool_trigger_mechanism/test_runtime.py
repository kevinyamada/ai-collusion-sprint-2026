"""Synthetic parameter, forward, readout and accounting tests. No pretrained models."""
import copy
from contextlib import contextmanager
import gc
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import weakref
import torch
from torch import nn
from safetensors.torch import save_file
from safetensors import safe_open
import runtime as r
import analyze as analysis


class Toy(nn.Module):
    def __init__(self,offset=0):
        super().__init__();self.model=nn.Module();self.model.embed_tokens=nn.Embedding(4,2)
        self.model.layers=nn.ModuleList()
        for _ in range(28):
            layer=nn.Module();layer.self_attn=nn.Module();layer.mlp=nn.Module()
            for name in ['q_proj','k_proj','v_proj','o_proj']:setattr(layer.self_attn,name,nn.Linear(2,2,bias=name != 'o_proj'))
            for name in ['gate_proj','up_proj','down_proj']:setattr(layer.mlp,name,nn.Linear(2,2,bias=False))
            layer.input_layernorm=nn.RMSNorm(2);layer.post_attention_layernorm=nn.RMSNorm(2)
            self.model.layers.append(layer)
        self.model.norm=nn.RMSNorm(2)
        self.lm_head=nn.Linear(2,4,bias=False);self.lm_head.weight=self.model.embed_tokens.weight
        with torch.no_grad():
            for i,p in enumerate(self.parameters()):p.fill_(offset+i/100)
    def get_input_embeddings(self):return self.model.embed_tokens
    def get_output_embeddings(self):return self.lm_head


class Store:
    def __init__(self):self.records=[]
    def append(self,row):self.records.append(row)


class Tokenizer:
    def decode(self,ids):return '/'.join(map(str,ids))


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(2)

    def test_groups_exact_338_and_union(self):
        names=sorted(r.parameter_map(Toy()))
        self.assertEqual(len(names),338)
        groups=r.group_names(names)
        self.assertEqual([len(g['tensor_names']) for g in groups],[3,14,17])
        self.assertEqual(set(groups[2]['tensor_names']),set(groups[0]['tensor_names'])|set(groups[1]['tensor_names']))
        self.assertFalse(any('norm' in n or 'embed' in n for g in groups for n in g['tensor_names']))
        with self.assertRaises(ValueError):r.group_names(names+['model.layers.27.mlp.down_proj.bias'])

    def test_plan_112_order_and_complete_cells(self):
        prepared={'groups':r.group_names(sorted(r.parameter_map(Toy()))),'newline_family':[r.TARGET]}
        cases=[{'id':str(i)} for i in range(8)]
        plan=r.make_plan(prepared,cases,'f')
        self.assertEqual(len(set(k for k,_ in plan)),112)
        for base in r.BASES:
            reqs=[p for _,p in plan if p['base_name']==base]
            self.assertEqual([p['kind'] for p in reqs],['native_baseline']*8+(['hybrid']*8+['restoration_sham']*8)*3)
            self.assertEqual(sum(p['active_donor'] for p in reqs),24)
            self.assertTrue(all(p['donor_name']==r.donor(base) for p in reqs))
        with self.assertRaises(ValueError):r.verify_committed_prefix([{'request_id':plan[1][0]}],plan)

    def fixture(self,temp):
        model=Toy();other=Toy(1)
        native=Path(temp)/'native.safetensors';donor=Path(temp)/'donor.safetensors'
        save_file({n:p.detach().contiguous() for n,p in model.named_parameters()},str(native))
        save_file({n:p.detach().contiguous() for n,p in other.named_parameters()},str(donor))
        return model,other,native,donor

    def test_native_verification_each_base_and_tie(self):
        with tempfile.TemporaryDirectory() as temp:
            model,_,native,_=self.fixture(temp)
            with patch.object(r,'checkpoint',return_value=native):
                for base in r.BASES:
                    hashes=r.verify_native(torch,model,safe_open,sorted(r.parameter_map(model)),base,rss=lambda:0)
                    self.assertEqual(hashes,r.fingerprints(model))
            model.lm_head.weight=nn.Parameter(model.lm_head.weight.detach().clone())
            with self.assertRaises(ValueError):r.check_tie(model)

    def test_all_groups_both_directions_restore_exact_and_nonselected(self):
        with tempfile.TemporaryDirectory() as temp:
            model,other,native,donor=self.fixture(temp)
            baseline=r.fingerprints(model)
            for base in r.BASES:
                for group in r.group_names(sorted(baseline)):
                    store=Store()
                    with r.replaced(torch,model,group,baseline,safe_open,store,'f',base,'loaded','s',donor_path=donor,native_path=native,rss=lambda:0) as holder:
                        actual=r.fingerprints(model)
                        for n in baseline:self.assertEqual(actual[n],r.fingerprints(other)[n] if n in group['tensor_names'] else baseline[n])
                    self.assertEqual(r.fingerprints(model),baseline)
                    self.assertEqual([x['kind'] for x in store.records],['replacement_verified','restoration_verified'])
                    self.assertEqual(holder['restored']['applied_receipt_id'],holder['active']['request_id'])
                    self.assertEqual(holder['active']['base_name'],base)

    def test_partial_copy_and_forward_exceptions_restore(self):
        with tempfile.TemporaryDirectory() as temp:
            model,_,native,donor=self.fixture(temp);baseline=r.fingerprints(model)
            group=r.group_names(sorted(baseline))[2]
            store=Store();real=r.stream_copy
            def failing(torch_,params,names,path,reader,rss):
                if Path(path)==donor:
                    real(torch_,params,names[:1],path,reader,rss);raise RuntimeError('partial synthetic copy')
                return real(torch_,params,names,path,reader,rss)
            with patch.object(r,'stream_copy',side_effect=failing):
                with self.assertRaises(RuntimeError):
                    with r.replaced(torch,model,group,baseline,safe_open,store,'f','dolos','loaded','s',donor_path=donor,native_path=native,rss=lambda:0):pass
            self.assertEqual(r.fingerprints(model),baseline)
            self.assertIsNone(store.records[-1]['applied_receipt_id'])
            with self.assertRaises(RuntimeError):
                with r.replaced(torch,model,group,baseline,safe_open,Store(),'f','qwen','loaded','s',donor_path=donor,native_path=native,rss=lambda:0):raise RuntimeError('synthetic forward failure')
            self.assertEqual(r.fingerprints(model),baseline)

    def test_nonselected_mutation_fails_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            model,_,native,donor=self.fixture(temp);baseline=r.fingerprints(model)
            with self.assertRaisesRegex(ValueError,'Exact restoration'):
                with r.replaced(torch,model,r.group_names(sorted(baseline))[0],baseline,safe_open,Store(),'f','dolos','loaded','s',donor_path=donor,native_path=native,rss=lambda:0):
                    with torch.no_grad():model.model.norm.weight.add_(1)

    def test_row_counterfactual_stable_matches_explicit_logits(self):
        h=torch.tensor([2.,3.]);own=torch.tensor([4.,5.]);other=torch.tensor([5.,7.]);z=torch.linspace(-10,10,151936)
        z[r.TARGET]=torch.dot(h,own)
        before=z.clone();result=r.row_counterfactual(torch,h,z,own,other)
        expected=z.double().clone();expected[r.TARGET]+=8
        self.assertTrue(result['native_readout_validated']);self.assertEqual(result['target_logit_delta_fp64'],8)
        self.assertAlmostEqual(result['p_target_fp64'],torch.softmax(expected,0)[r.TARGET].item(),places=14)
        self.assertEqual(result['target_rank'],int((expected>expected[r.TARGET]).sum())+1)
        self.assertTrue(torch.equal(z,before))
        z[r.TARGET]+=5
        self.assertFalse(r.row_counterfactual(torch,h,z,own,other)['native_readout_validated'])

    def test_distribution_extreme_logits_finite_diagnostics(self):
        z=torch.full((151936,),-100.);z[r.TARGET]=100
        result=r.distribution(torch,z,Tokenizer(),[r.TARGET,2])
        self.assertEqual(result['p_target_fp32'],1)
        self.assertEqual(result['target_rank'],1)
        self.assertGreater(result['target_log_odds_fp64'],180)
        self.assertTrue(torch.isfinite(torch.tensor(result['target_log_odds_fp64'])))
        z[3]=float('nan')
        with self.assertRaises(ValueError):r.distribution(torch,z,Tokenizer(),[r.TARGET])

    def test_capture_uses_same_forward_logits_and_final_hidden(self):
        class Forward:
            def __call__(self,**kwargs):
                self.kwargs=kwargs
                return SimpleNamespace(logits=torch.arange(151936,dtype=torch.float32).reshape(1,1,-1),hidden_states=(torch.ones(1,1,1536),torch.full((1,1,1536),2.)))
        model=Forward();events=Store()
        req={'base_name':'dolos','kind':'native_baseline','case':{'input_token_ids':[1,2]},'newline_family':[r.TARGET]}
        receipt={'request_id':'receipt','active_fingerprint_sha256':'weights'}
        with patch.object(r,'check_rss',return_value=0):row,z,h=r.execute_forward(torch,model,Tokenizer(),req,receipt,events,'f','s')
        self.assertEqual(z[r.TARGET].item(),r.TARGET)
        self.assertEqual(h.tolist(),[2.]*1536)
        self.assertEqual(row['final_logits_sha256'],r.tensor_sha256(z))
        self.assertEqual([e['kind'] for e in events.records],['forward_started','forward_completed'])
        self.assertTrue(model.kwargs['output_hidden_states'])
        self.assertTrue(torch.equal(model.kwargs['attention_mask'],torch.ones(1,2,dtype=torch.long)))

    def test_native_logit_artifact_atomic_reuse_rejects_drift(self):
        with tempfile.TemporaryDirectory() as temp,patch.object(r,'ROOT',Path(temp)):
            z=torch.zeros(151936)
            a=r.save_logits(z,'dolos','x');b=r.save_logits(z,'dolos','x')
            self.assertEqual(a,b);self.assertEqual(a['bytes'],607744)
            z[0]=1
            with self.assertRaises(ValueError):r.save_logits(z,'dolos','x')

    def test_model_parameter_weakrefs_clear_after_frame(self):
        def inner():
            model=Toy();return [weakref.ref(model)]+[weakref.ref(p) for p in model.parameters()]
        refs=inner();gc.collect();self.assertTrue(all(x() is None for x in refs))

    def test_recovery_unique_storage_identity_and_event_reference(self):
        first=r.make_request_id({'planned_request_id':'x','attempt_id':'a'})
        second=r.make_request_id({'planned_request_id':'x','attempt_id':'b'})
        self.assertNotEqual(first,second)
        with tempfile.TemporaryDirectory() as temp:
            with r.ResultStore(Path(temp)/'recovery.jsonl') as store:
                for key in [first,second]:store.append(r.seal({'schema_version':1,'status':'completed','request_id':key,'planned_request_id':'x'}))
            with r.ResultStore(Path(temp)/'recovery.jsonl') as store:self.assertEqual(len(store.completed),2)

    def test_all_cases_gates_and_near_thresholds(self):
        primary={}
        for base in r.BASES:
            for group in ['native']+r.GROUP_IDS+['readout_only']:
                for i in range(8):
                    positive=i in [0,1,2,6,7]
                    high=positive and ((base=='dolos' and group=='native') or (base=='qwen' and group!='native'))
                    primary[base,group,i]={'p_gate':.9 if high else .009,'target_rank':1 if high else 5}
        native,gates=analysis.classify(primary,'p_gate')
        self.assertTrue(native)
        self.assertTrue(all(v['strict_suppression_label'] and v['strict_transfer_label'] for v in gates.values()))
        broken=copy.deepcopy(primary);broken['dolos','union',3]['p_gate']=.01
        self.assertFalse(analysis.classify(broken,'p_gate')[1]['union']['strict_suppression_label'])
        broken=copy.deepcopy(primary);broken['qwen','mlp27',7]['target_rank']=2
        self.assertFalse(analysis.classify(broken,'p_gate')[1]['mlp27']['strict_transfer_label'])
        broken=copy.deepcopy(primary);broken['dolos','native',2]['p_gate']=.899999
        eligible,gates=analysis.classify(broken,'p_gate')
        self.assertFalse(eligible)
        self.assertTrue(all(not v['strict_transfer_label'] and not v['strict_suppression_label'] for v in gates.values()))

    def test_complete_summary_has_64_states_16_cf_and_all_interactions(self):
        records=[]
        for base in r.BASES:
            for group in ['native']+r.GROUP_IDS:
                for i in range(8):
                    z={'native':2,'mlp27':3,'attention26_27':5,'union':9}[group]
                    stats={'p_target_fp32':.005,'p_target_fp64':.005,'logp_target_fp64':-5.,
                           'target_rank':2,'target_logit':z,'target_log_odds_fp64':2*z}
                    req={'base_name':base,'kind':'native_baseline' if group=='native' else 'hybrid',
                         'group':None if group=='native' else {'id':group},
                         'case':{'id':str(i),'source_cell_index':i,'expected_external_positive':i in [0,1,2,6,7]}}
                    row={'request_id':base+group+str(i),'request':req,'statistics':stats}
                    if group=='native':
                        row['row_counterfactual']={**stats,'counterfactual_target_logit_fp64':4}
                    records.append(row)
        out=analysis.summaries(records)
        self.assertEqual(len(out['case_rows']),80)
        self.assertEqual(len(out['paired_changes']),64)
        self.assertEqual(len(out['union_nonadditivity']),32)
        self.assertTrue(all(x['union_minus_mlp_minus_attention_effect'] == (3 if x['metric']=='target_logit' else 6) for x in out['union_nonadditivity']))
        self.assertFalse(out['planted_objective_identified'])


if __name__ == '__main__':unittest.main(verbosity=2)
