"""Independent standard-library checks; no tokenizer or model imports/calls."""
import json
from pathlib import Path
import sys

import run_mechanism as runner


def main():
    root = Path(__file__).resolve().parent
    prepared = json.loads((root/'prepared_inputs.json').read_text())
    plan = runner.make_plan(prepared, '0'*64)
    checks = 0
    assert len(plan) == 464 and len(dict(plan)) == 464
    checks += 2
    assert 'torch' not in sys.modules and 'transformers' not in sys.modules
    checks += 2
    assert len(prepared['prompts']) == 96 and len(prepared['parameter_names']) == 338
    checks += 2
    names, layers = [], []
    for group in prepared['groups']:
        expected = sorted(name for name in prepared['parameter_names']
                          if any(name.startswith(f'model.layers.{i}.') for i in group['layers']))
        assert group['tensor_names'] == expected and len(expected) == 84
        checks += 2
        names.extend(expected)
        layers.extend(group['layers'])
    assert len(names) == len(set(names)) == 336 and layers == list(range(28))
    checks += 2
    assert set(prepared['parameter_names'])-set(names) == {'model.embed_tokens.weight', 'model.norm.weight'}
    checks += 1
    sham_ids = [row['prompt_id'] for row in prepared['prompts'] if row['metadata']['task_id'] in runner.SHAM_TASKS]
    phases = ['before_any_swap']+[phase for group in prepared['groups']
                                 for phase in [group['id'], 'after_'+group['id']]]
    assert list(dict.fromkeys(request['phase'] for _, request in plan)) == phases
    checks += 1
    for phase in phases:
        records = [request for _, request in plan if request['phase'] == phase]
        native = phase.startswith('before_') or phase.startswith('after_')
        expected_ids = sham_ids if native else [row['prompt_id'] for row in prepared['prompts']]
        assert [row['prompt_id'] for row in records] == expected_ids
        checks += 1
        assert all(row['model']['kind'] == ('native_sham' if native else 'unforced_hybrid') for row in records)
        checks += 1
    lookup = {row['prompt_id']: row for row in prepared['prompts']}
    for request_id, request in plan:
        assert request_id == runner.make_request_id(request)
        assert request['messages'] == lookup[request['prompt_id']]['messages']
        assert request['input_token_ids'] == lookup[request['prompt_id']]['input_token_ids']
        checks += 3
    for prompt_id in sham_ids:
        ids = [request_id for request_id, request in plan
               if request['prompt_id'] == prompt_id and request['model']['kind'] == 'native_sham']
        assert len(ids) == len(set(ids)) == 5
        checks += 1
    result = {'logical_checks': checks, 'plan_size': len(plan),
              'hybrids': sum(request['model']['kind'] == 'unforced_hybrid' for _, request in plan),
              'shams': sum(request['model']['kind'] == 'native_sham' for _, request in plan),
              'scope': 'Independent standard-library plan, group inventory, prompt identity and phase checks only; no tokenizer/model imports or pretrained forwards.',
              'runner_sha_at_check': runner.file_sha256(root/'run_mechanism.py'),
              'prepared_inputs_sha256': runner.file_sha256(root/'prepared_inputs.json'),
              'check_source_sha256': runner.file_sha256(Path(__file__))}
    (root/'independent_plan_checks.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
