#!/usr/bin/env python3
"""Frozen block replacements; defaults to a model-free dry run."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import gc
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import resource
import sys
import time

from batch_support import (ResultStore, canonical_json, file_sha256, infer_one,
                           load_backend, make_request_id, strict_json)

ROOT = Path(__file__).resolve().parent
CACHE = Path('/Users/Administrator/.cache/huggingface/hub')
PINS = {
    'dolos': {'repo': 'Poseidon-Research/Dolos-1.5B', 'revision': '63e7031a0535a49f86e08af4e7bdc45cfa22fe6d',
              'sha256': '437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244'},
    'qwen': {'repo': 'Qwen/Qwen2.5-1.5B-Instruct', 'revision': '989aa7980e4cf806f80c7fef2b1adb7bc71aa306',
             'sha256': 'dd924a11b4c220f385b51ffa522daea7c9f3d850e31b162bb5661df483c6d3ee'},
}
STARTER_SHA = '9f3fc3a168ff7e8dc116f27bed06140b8e0cab2d54937baf66a1bd8348af1e21'
BATCH_SHA = '8659ee20c5ff90dd876762586d242ac270edf3c65eb809f348de2622de93cdc6'
SHAM_TASKS = ['AH1_01', 'AH1_07', 'AH1_13', 'AH1_19']
RSS_LIMIT = 12 * 2**30
GROUPS = [{'id': f'layers_{start:02d}_{start+6:02d}', 'layers': list(range(start, start+7))}
          for start in range(0, 28, 7)]


def utc():
    return datetime.now(timezone.utc).isoformat()


def checkpoint(name):
    pin = PINS[name]
    return CACHE / ('models--'+pin['repo'].replace('/', '--')) / 'snapshots' / pin['revision'] / 'model.safetensors'


def rss_bytes():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return int(value if sys.platform == 'darwin' else value*1024)


def check_rss():
    value = rss_bytes()
    if value > RSS_LIMIT:
        raise MemoryError(f'Observed peak RSS {value} exceeds {RSS_LIMIT}; no setting is changed automatically')
    return value


def seal(record):
    return {**record, 'record_sha256': make_request_id(record)}


def verify_seal(record):
    copy = dict(record)
    checksum = copy.pop('record_sha256', None)
    if checksum != make_request_id(copy):
        raise ValueError('Record checksum mismatch')


def read_records(path):
    return [strict_json(line) for line in path.read_text().splitlines() if line.strip()]


def journal(store, kind, **fields):
    payload = {'kind': kind, 'utc': utc(), 'pid': os.getpid(), 'monotonic_ns': time.monotonic_ns(), **fields}
    record = seal({'schema_version': 1, 'status': 'completed', 'request_id': make_request_id(payload), **payload})
    store.append(record)
    return record


def verify_journal(record, freeze_sha):
    verify_seal(record)
    payload = {k: v for k, v in record.items() if k not in {'schema_version', 'status', 'request_id', 'record_sha256'}}
    if make_request_id(payload) != record['request_id'] or record.get('freeze_sha256') != freeze_sha:
        raise ValueError('Journal identity/freeze mismatch')


def verify_weight_receipt(record, prepared, freeze_sha):
    verify_journal(record, freeze_sha)
    hashes = record['active_parameter_sha256']
    if sorted(hashes) != sorted(prepared['parameter_names']) or make_request_id(hashes) != record['active_fingerprint_sha256']:
        raise ValueError('Weight receipt inventory/checksum mismatch')
    kind = record['kind']
    if kind == 'native_loaded_verified':
        if not record['all_native_parameters_exact'] or record['active_fingerprint_sha256'] != record['baseline_fingerprint_sha256']:
            raise ValueError('Invalid native weight receipt')
        return
    groups = {g['id']: g for g in prepared['groups']}
    if record.get('group_id') not in groups or sorted(record['selected']) != groups[record['group_id']]['tensor_names']:
        raise ValueError('Weight receipt group/tensor inventory mismatch')
    for name, row in record['selected'].items():
        if row['source_fp32_sha256'] != row['target_sha256'] or row['target_sha256'] != hashes[name]:
            raise ValueError('Weight receipt source/target checksum mismatch')
    if kind == 'replacement_verified':
        if not record['all_nonselected_unchanged']:
            raise ValueError('Nonselected weight check failed')
    elif kind == 'restoration_verified':
        if not record['all_parameters_restored'] or record['active_fingerprint_sha256'] != record['baseline_fingerprint_sha256']:
            raise ValueError('Native restoration receipt failed')
    else:
        raise ValueError('Unexpected weight receipt kind')


def verify_receipt_collection(receipts, prepared, freeze_sha):
    if not receipts:
        return
    for record in receipts:
        verify_weight_receipt(record, prepared, freeze_sha)
    if receipts[0]['kind'] != 'native_loaded_verified':
        raise ValueError('Weight journal must begin with native checkpoint verification')
    baseline = receipts[0]['active_parameter_sha256']
    baseline_sha = make_request_id(baseline)
    for record in receipts:
        if record['baseline_fingerprint_sha256'] != baseline_sha:
            raise ValueError('Weight receipts disagree about the native baseline')
        actual = record['active_parameter_sha256']
        if record['kind'] != 'replacement_verified':
            require_equal_maps(actual, baseline, 'Native/restoration journal map')
        else:
            selected = set(record['selected'])
            require_equal_maps({k: v for k, v in actual.items() if k not in selected},
                               {k: v for k, v in baseline.items() if k not in selected},
                               'Nonselected journal map')


def verify_committed_prefix(records, plan):
    if [r['request_id'] for r in records] != [key for key, _ in plan[:len(records)]]:
        raise ValueError('Committed responses are not the ordered frozen-plan prefix')


def tensor_sha256(tensor):
    """Hash existing CPU contiguous FP32 storage in bounded memoryview chunks."""
    if str(tensor.device) != 'cpu' or str(tensor.dtype) != 'torch.float32' or not tensor.is_contiguous():
        raise ValueError('Hashing requires existing contiguous CPU FP32 storage; no large clone is allowed')
    digest = hashlib.sha256(canonical_json({'dtype': str(tensor.dtype), 'shape': list(tensor.shape)}).encode())
    view = memoryview(tensor.detach().numpy()).cast('B')
    for start in range(0, len(view), 8*2**20):
        digest.update(view[start:start+8*2**20])
    return digest.hexdigest()


def parameter_map(model):
    # Normal named_parameters deduplicates the tied embedding/output weight.
    return dict(model.named_parameters())


def fingerprints(model):
    return {name: tensor_sha256(tensor) for name, tensor in parameter_map(model).items()}


def selected_names(parameters, layers):
    prefixes = tuple(f'model.layers.{n}.' for n in layers)
    return sorted(name for name in parameters if name.startswith(prefixes))


def require_equal_maps(actual, expected, label):
    if actual != expected:
        changed = sorted(k for k in set(actual) | set(expected) if actual.get(k) != expected.get(k))
        raise ValueError(f'{label}: exact parameter fingerprints differ: {changed[:12]}')


def stream_copy(torch, parameters, names, source_path, reader, rss_check=check_rss):
    """Open/close a checkpoint view for each tensor; never retain a full donor group."""
    rows = {}
    for name in names:
        rss_check()
        with reader(str(source_path), framework='pt', device='cpu') as source:
            value = source.get_tensor(name).to(dtype=torch.float32)
            parameter = parameters[name]
            if parameter.shape != value.shape:
                raise ValueError(f'Shape mismatch: {name}')
            source_hash = tensor_sha256(value)
            with torch.no_grad():
                parameter.copy_(value)
            if not torch.equal(parameter.detach(), value):
                raise ValueError(f'Exact source comparison failed: {name}')
            target_hash = tensor_sha256(parameter)
            if source_hash != target_hash:
                raise ValueError(f'Copied tensor checksum mismatch: {name}')
            rows[name] = {'source_fp32_sha256': source_hash, 'target_sha256': target_hash,
                          'shape': list(value.shape)}
            del value
        rss_check()
    return rows


def verify_native_checkpoint(torch, model, reader, expected_names):
    parameters = parameter_map(model)
    if sorted(parameters) != sorted(expected_names):
        raise ValueError('Loaded parameter inventory differs from frozen checkpoint header')
    hashes = {}
    for name, parameter in parameters.items():
        check_rss()
        with reader(str(checkpoint('dolos')), framework='pt', device='cpu') as source:
            value = source.get_tensor(name).to(dtype=torch.float32)
            if parameter.shape != value.shape or not torch.equal(parameter.detach(), value):
                raise ValueError(f'Loaded parameter differs from native Dolos: {name}')
            hashes[name] = tensor_sha256(parameter)
            del value
    # The starter restores this tie. It must remain tied through every replacement.
    if model.get_input_embeddings().weight.data_ptr() != model.get_output_embeddings().weight.data_ptr():
        raise ValueError('Native embedding/output weight tie is broken')
    return hashes


@contextmanager
def replaced_group(torch, model, group, baseline, reader, patch_store, freeze_sha,
                   donor_path=None, native_path=None, rss_check=check_rss):
    parameters = parameter_map(model)
    names = selected_names(parameters, group['layers'])
    if names != group['tensor_names']:
        raise ValueError('Selected tensor inventory differs from frozen group')
    before = fingerprints(model)
    require_equal_maps(before, baseline, 'Before replacement')
    holder = {}
    try:
        copied = stream_copy(torch, parameters, names, donor_path or checkpoint('qwen'), reader, rss_check)
        after = fingerprints(model)
        require_equal_maps({k: v for k, v in after.items() if k not in names},
                           {k: v for k, v in baseline.items() if k not in names}, 'Nonselected weights after replacement')
        for name in names:
            if after[name] != copied[name]['source_fp32_sha256']:
                raise ValueError('Selected post-replacement checksum mismatch')
        holder['applied'] = journal(patch_store, 'replacement_verified', freeze_sha256=freeze_sha,
                                   group_id=group['id'], selected=copied,
                                   baseline_fingerprint_sha256=make_request_id(baseline),
                                   active_fingerprint_sha256=make_request_id(after),
                                   active_parameter_sha256=after, all_nonselected_unchanged=True)
        holder['active_fingerprints'] = after
        yield holder
    finally:
        # Also runs if replacement or generation fails. SIGKILL cannot run finally;
        # a subsequent invocation always loads/validates fresh native Dolos.
        restored = stream_copy(torch, parameters, names, native_path or checkpoint('dolos'), reader,
                               rss_check=lambda: rss_bytes())
        final = fingerprints(model)
        require_equal_maps(final, baseline, 'After restoration')
        holder['restored'] = journal(patch_store, 'restoration_verified', freeze_sha256=freeze_sha,
                                    group_id=group['id'], selected=restored,
                                    baseline_fingerprint_sha256=make_request_id(baseline),
                                    active_fingerprint_sha256=make_request_id(final),
                                    active_parameter_sha256=final, all_parameters_restored=True)


def model_identity(group=None):
    if group is None:
        return {'name': 'dolos_native_instrumented', 'kind': 'native_sham', 'base': PINS['dolos']}
    return {'name': 'dolos_qwen_block_hybrid_'+group['id'], 'kind': 'unforced_hybrid',
            'base': PINS['dolos'], 'donor': PINS['qwen'],
            'replacement': {'operation': 'replace', **group}}


def make_plan(prepared, freeze_sha):
    shared = {'freeze_sha256': freeze_sha, 'generation': prepared['generation'],
              'environment': prepared['environment'], 'tokenizer': prepared['tokenizer'],
              'effective_generation_config': prepared['effective_generation_config'],
              'starter_sha256': STARTER_SHA, 'batch_infer_sha256': BATCH_SHA,
              'threads': 8, 'assistant_prefix': '', 'intervention_version': 1}
    plan = []
    def add(phase, rows, group=None):
        for row in rows:
            request = {**shared, **row, 'phase': phase, 'model': model_identity(group)}
            plan.append((make_request_id(request), request))
    sham_rows = [r for r in prepared['prompts'] if r['metadata']['task_id'] in SHAM_TASKS]
    add('before_any_swap', sham_rows)
    for group in prepared['groups']:
        add(group['id'], prepared['prompts'], group)
        add('after_'+group['id'], sham_rows)
    if len(plan) != 464 or len(dict(plan)) != 464:
        raise ValueError('Expected 384 hybrid responses and 80 sham responses')
    return plan


def verify_result(record, expected, patch_records, native):
    verify_seal(record)
    request = expected.get(record['request_id'])
    if request is None or any(record.get(k) != v for k, v in request.items()):
        raise ValueError('Response does not match its frozen request')
    tokens = record['output_token_ids']
    if not isinstance(tokens, list) or not tokens or any(type(t) is not int or not 0 <= t < 151936 for t in tokens):
        raise ValueError('Invalid output token IDs')
    if record['input_tokens'] != len(request['input_token_ids']) or record['output_tokens'] != len(tokens):
        raise ValueError('Response token counts do not match')
    kwargs = request['generation']['kwargs']
    if len(tokens) > kwargs['max_new_tokens']:
        raise ValueError('Response exceeds frozen cap')
    expected_finish = 'eos' if tokens[-1] in kwargs['eos_token_id'] else 'length'
    if record['finish_reason'] != expected_finish:
        raise ValueError('Finish reason disagrees with token IDs')
    patch = patch_records.get(record['weight_receipt_id'])
    if patch is None or patch.get('freeze_sha256') != request['freeze_sha256']:
        raise ValueError('Missing or mismatched weight verification receipt')
    expected_kind = ('replacement_verified' if request['model']['kind'] == 'unforced_hybrid'
                     else ('native_loaded_verified' if request['phase'] == 'before_any_swap' else 'restoration_verified'))
    if patch['kind'] != expected_kind:
        raise ValueError('Wrong weight verification receipt kind')
    if expected_kind != 'native_loaded_verified':
        expected_group = request['phase'].removeprefix('after_')
        if patch['group_id'] != expected_group:
            raise ValueError('Wrong group in weight verification receipt')
    if record['model_fingerprint_sha256'] != patch['active_fingerprint_sha256']:
        raise ValueError('Response/weight fingerprint mismatch')
    if request['model']['kind'] == 'native_sham':
        baseline = native[request['prompt_id']]
        if record['sham_baseline_request_id'] != baseline['request_id'] or not record['sham_matches_baseline'] or tokens != baseline['output_token_ids']:
            raise ValueError('Sham failed exact native output-token equality; no further swap is permitted')
    elif record.get('sham_matches_baseline') is not None:
        raise ValueError('Hybrid response incorrectly marked as a native sham')


def validate_preflight():
    freeze = strict_json((ROOT/'pre_run_freeze.json').read_text())
    for name, wanted in freeze['file_sha256'].items():
        if file_sha256(ROOT/name) != wanted:
            raise ValueError(f'Frozen source/input changed: {name}')
    if sys.version != freeze['python_version']:
        raise ValueError('Frozen Python version differs')
    for package, wanted in freeze['package_versions'].items():
        if importlib.metadata.version(package) != wanted:
            raise ValueError(f'Frozen package changed: {package}')
    if file_sha256(ROOT.parent/'starter/generate.py') != STARTER_SHA or file_sha256(ROOT/'batch_support.py') != BATCH_SHA:
        raise ValueError('Starter or original infer_one implementation changed')
    prepared = strict_json((ROOT/'prepared_inputs.json').read_text())
    native = {r['prompt_id']: r for r in read_records(ROOT/'baseline_results.jsonl') if r['model']['name'] == 'dolos'}
    if len(native) != 96:
        raise ValueError('Expected exactly 96 native Dolos baseline records')
    return prepared, native, file_sha256(ROOT/'pre_run_freeze.json')


def write_summary(records, events, freeze_sha):
    starts = [r for r in events if r['kind'] == 'generation_started']
    completed = [r for r in events if r['kind'] == 'generation_completed']
    summary = {'created_utc': utc(), 'freeze_sha256': freeze_sha,
               'unique_completed_hybrid_responses': sum(r['model']['kind'] == 'unforced_hybrid' for r in records),
               'unique_completed_native_shams': sum(r['model']['kind'] == 'native_sham' for r in records),
               'sham_failures': [r['request_id'] for r in records if r.get('sham_matches_baseline') is False],
               'attempts_started': len(starts), 'attempts_completed': len(completed),
               'completed_attempts_beyond_committed_responses': len(completed)-len(records),
               'planned_total': 464, 'planned_hybrids': 384, 'planned_shams': 80,
               'interpretation': 'Hybrid responses are interventions, not native Dolos. Shams are repeated integrity checks, not independent tasks.'}
    (ROOT/'execution_summary.json').write_text(json.dumps(summary, indent=2)+'\n')


def run(args):
    prepared, native, freeze_sha = validate_preflight()
    plan = make_plan(prepared, freeze_sha)
    expected = dict(plan)
    print('Frozen plan: 384 unforced hybrid responses +80 native instrumented shams =464 generations.', flush=True)
    if not args.run:
        print('Dry run passed; no model/tokenizer import, construction or inference.', flush=True)
        return
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    with ResultStore(ROOT/'results.jsonl') as store, ResultStore(ROOT/'weight_events.jsonl') as patch_store, ResultStore(ROOT/'execution_events.jsonl') as event_store:
        records = read_records(store.path)
        patches = read_records(patch_store.path)
        events = read_records(event_store.path)
        verify_receipt_collection(patches, prepared, freeze_sha)
        for row in events:
            verify_journal(row, freeze_sha)
        patch_index = {r['request_id']: r for r in patches}
        for row in records:
            verify_result(row, expected, patch_index, native)
        verify_committed_prefix(records, plan)
        phases = ['before_any_swap'] + [v for g in prepared['groups'][:1 if args.first_group_only else 4]
                                      for v in [g['id'], 'after_'+g['id']]]
        if all(key in store.completed for key, req in plan if req['phase'] in phases):
            write_summary(records, events, freeze_sha)
            print('Requested phases already complete; no model loaded.', flush=True)
            return
        for name, pin in PINS.items():
            if file_sha256(checkpoint(name)) != pin['sha256']:
                raise ValueError(f'Checkpoint content changed: {name}')
        backend = load_backend(ROOT.parent/'starter')
        if backend.DOLOS_REVISION != PINS['dolos']['revision'] or backend.QWEN_REVISION != PINS['qwen']['revision']:
            raise ValueError('Backend model revisions changed')
        torch = backend.torch
        torch.set_num_threads(8)
        device = torch.device('cpu')
        from safetensors import safe_open
        tokenizer = backend.AutoTokenizer.from_pretrained(PINS['qwen']['repo'], revision=PINS['qwen']['revision'], token=False, local_files_only=True)
        if make_request_id({'template': tokenizer.chat_template}) != prepared['tokenizer']['chat_template_sha256']:
            raise ValueError('Tokenizer chat template changed')
        for row in prepared['prompts']:
            ids = tokenizer.apply_chat_template(row['messages'], tokenize=True, add_generation_prompt=True, return_dict=False)
            if ids != row['input_token_ids']:
                raise ValueError('Frozen input token IDs changed')
        for row in records:
            if tokenizer.decode(row['output_token_ids'], skip_special_tokens=True) != row['output']:
                raise ValueError('Resumed output does not match saved token IDs')
        check_rss()
        model = None
        try:
            started = time.perf_counter()
            backend.set_seed(42)
            model = backend.load_model('dolos', device, torch.float32)
            model.eval()
            for p in model.parameters():
                p.requires_grad_(False)
            load_seconds = time.perf_counter()-started
            check_rss()
            baseline = verify_native_checkpoint(torch, model, safe_open, prepared['parameter_names'])
            for receipt in patches:
                if receipt['baseline_fingerprint_sha256'] != make_request_id(baseline):
                    raise ValueError('Native baseline fingerprint differs from earlier process')
            loaded = journal(patch_store, 'native_loaded_verified', freeze_sha256=freeze_sha,
                             baseline_fingerprint_sha256=make_request_id(baseline), active_fingerprint_sha256=make_request_id(baseline),
                             active_parameter_sha256=baseline, all_native_parameters_exact=True)
            patch_index[loaded['request_id']] = loaded
            generation = prepared['generation']['kwargs']
            effective = model.generation_config.to_dict()
            effective.update(generation)
            if effective != prepared['effective_generation_config']:
                raise ValueError('Effective generation settings differ from native holdout')

            def phase(name, receipt):
                for key, request in plan:
                    if request['phase'] != name or key in store.completed:
                        continue
                    check_rss()
                    journal(event_store, 'generation_started', freeze_sha256=freeze_sha, response_request_id=key,
                            phase=name, prompt_id=request['prompt_id'], peak_rss_bytes=rss_bytes())
                    response = infer_one(backend, model, tokenizer, request['messages'], generation, 42, device)
                    journal(event_store, 'generation_completed', freeze_sha256=freeze_sha, response_request_id=key,
                            phase=name, runtime_seconds=response['runtime_seconds'], peak_rss_bytes=rss_bytes())
                    sham = request['model']['kind'] == 'native_sham'
                    same = response['output_token_ids'] == native[request['prompt_id']]['output_token_ids'] if sham else None
                    record = seal({'schema_version': 1, 'status': 'completed', 'request_id': key, **request, **response,
                                   'completed_at': utc(), 'model_load_seconds': load_seconds, 'effective_generation_config': effective,
                                   'weight_receipt_id': receipt['request_id'], 'model_fingerprint_sha256': receipt['active_fingerprint_sha256'],
                                   'peak_rss_bytes': rss_bytes(), 'sham_matches_baseline': same,
                                   'sham_baseline_request_id': native[request['prompt_id']]['request_id'] if sham else None})
                    store.append(record)
                    records.append(record)
                    print(f'{len(records)}/464 {name} {request["prompt_id"]}: {response["output_tokens"]} tokens, {response["runtime_seconds"]:.2f}s', flush=True)
                    if sham and not same:
                        raise ValueError('Native sham output tokens differ from holdout; stopping before further swaps')
                    check_rss()
                    if (name == prepared['groups'][0]['id'] and request['metadata']['task_id'] == 'AH1_01'
                            and request['metadata']['mode'] == 'copy' and request['metadata']['format'] == 'json'):
                        pilot = [r for r in records if r['phase'] == name and r['metadata']['task_id'] == 'AH1_01']
                        journal(event_store, 'hybrid_resource_pilot', freeze_sha256=freeze_sha,
                                included_responses=len(pilot), total_seconds=sum(r['runtime_seconds'] for r in pilot),
                                peak_rss_bytes=rss_bytes(), note='Four included first-task responses; not a separate semantic study.')
                require_equal_maps(fingerprints(model), receipt['active_parameter_sha256'], 'Weights after generation phase')

            phase('before_any_swap', loaded)
            journal(event_store, 'initial_resource_pilot', freeze_sha256=freeze_sha, peak_rss_bytes=rss_bytes(),
                    note='The 16 included native shams completed; no extra trials.')
            for group in prepared['groups'][:1 if args.first_group_only else 4]:
                names = {group['id'], 'after_'+group['id']}
                if all(key in store.completed for key, req in plan if req['phase'] in names):
                    continue
                with replaced_group(torch, model, group, baseline, safe_open, patch_store, freeze_sha) as holder:
                    patch_index[holder['applied']['request_id']] = holder['applied']
                    phase(group['id'], holder['applied'])
                patch_index[holder['restored']['request_id']] = holder['restored']
                phase('after_'+group['id'], holder['restored'])
                gc.collect()
            require_equal_maps(fingerprints(model), baseline, 'Final native model')
        except BaseException as error:
            journal(event_store, 'run_stopped', freeze_sha256=freeze_sha, error_type=type(error).__name__, detail=str(error), peak_rss_bytes=rss_bytes())
            raise
        finally:
            if model is not None:
                del model
            gc.collect()
            write_summary(records, read_records(event_store.path), freeze_sha)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--first-group-only', action='store_true', help='128 included calls; full execution resumes remaining groups')
    run(parser.parse_args())


if __name__ == '__main__':
    main()
