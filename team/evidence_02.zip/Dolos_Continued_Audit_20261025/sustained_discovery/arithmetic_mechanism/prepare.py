"""Prepare frozen tokens and checkpoint inventories; never constructs a model."""
import json
from pathlib import Path
import struct

from batch_support import file_sha256, make_request_id, read_prompts, strict_json
from run_mechanism import ROOT, PINS, GROUPS, SHAM_TASKS, checkpoint, read_records


def header(path):
    with path.open('rb') as handle:
        size = struct.unpack('<Q', handle.read(8))[0]
        return {k: v for k, v in json.loads(handle.read(size)).items() if k != '__metadata__'}


def main():
    if (ROOT/'pre_run_freeze.json').exists() or (ROOT/'results.jsonl').exists():
        raise SystemExit('Refusing to rebuild a frozen or started intervention')
    prompts = read_prompts(ROOT/'prompts.jsonl')
    baseline = read_records(ROOT/'baseline_results.jsonl')
    if len(prompts) != 96 or len(baseline) != 192:
        raise ValueError('Expected the full 96-prompt, 192-response holdout')
    index = {(r['model']['name'], r['prompt_id']): r for r in baseline}
    if len(index) != 192 or set(index) != {(m, p['id']) for m in PINS for p in prompts}:
        raise ValueError('Baseline coverage incomplete or duplicated')
    keys = ['inference_version', 'starter_sha256', 'tokenizer', 'generation', 'environment',
            'prompt_id', 'messages', 'metadata', 'model']
    for record in baseline:
        if make_request_id({k: record[k] for k in keys}) != record['request_id']:
            raise ValueError('Native baseline request checksum failed')
        name = record['model']['name']
        if record['model']['revision'] != PINS[name]['revision'] or record['model']['repo'] != PINS[name]['repo']:
            raise ValueError('Wrong native checkpoint pin')
    reference = index['dolos', prompts[0]['id']]
    if reference['generation'] != {'seed': 42, 'requested_temperature': 0.0,
                                   'kwargs': {'max_new_tokens': 96, 'do_sample': False,
                                              'eos_token_id': [151645, 151643], 'pad_token_id': 151643}}:
        raise ValueError('Unexpected native generation settings')
    if reference['environment']['device'] != 'cpu' or reference['environment']['dtype'] != 'torch.float32':
        raise ValueError('Native baselines must be CPU FP32')
    from transformers import AutoTokenizer  # Cached tokenizer only; no model import/construction.
    tokenizer = AutoTokenizer.from_pretrained(PINS['qwen']['repo'], revision=PINS['qwen']['revision'],
                                               token=False, local_files_only=True)
    if make_request_id({'template': tokenizer.chat_template}) != reference['tokenizer']['chat_template_sha256']:
        raise ValueError('Native template differs from cached tokenizer')
    rows = []
    for item in prompts:
        ids = tokenizer.apply_chat_template(item['messages'], tokenize=True, add_generation_prompt=True, return_dict=False)
        for name in PINS:
            record = index[name, item['id']]
            for field in ['generation', 'tokenizer', 'environment', 'starter_sha256', 'effective_generation_config']:
                if record[field] != reference[field]:
                    raise ValueError('Baseline setting mismatch: '+field)
            if record['messages'] != item['messages'] or record['metadata'] != item['metadata'] or record['input_tokens'] != len(ids):
                raise ValueError('Baseline prompt/input mismatch')
            if tokenizer.decode(record['output_token_ids'], skip_special_tokens=True) != record['output']:
                raise ValueError('Baseline output-token decode mismatch')
            if record['output_tokens'] != len(record['output_token_ids']) or record['finish_reason'] != 'eos' or record['output_token_ids'][-1] not in reference['generation']['kwargs']['eos_token_id']:
                raise ValueError('Native complete-response validation failed')
        rows.append({'prompt_id': item['id'], 'messages': item['messages'], 'metadata': item['metadata'],
                     'input_token_ids': ids})
    headers = {name: header(checkpoint(name)) for name in PINS}
    if sorted(headers['dolos']) != sorted(headers['qwen']):
        raise ValueError('Checkpoint inventories differ')
    for name in headers['dolos']:
        if headers['dolos'][name]['shape'] != headers['qwen'][name]['shape']:
            raise ValueError('Checkpoint tensor shapes differ')
    groups = []
    for group in GROUPS:
        names = sorted(k for k in headers['dolos'] if any(k.startswith(f'model.layers.{i}.') for i in group['layers']))
        if len(names) != 84:
            raise ValueError('Expected 12 tensors per block, seven blocks per group')
        groups.append({**group, 'tensor_names': names})
    if len([r for r in rows if r['metadata']['task_id'] in SHAM_TASKS]) != 16:
        raise ValueError('Expected all four cells from each of four sham strata')
    prepared = {'prompts': rows, 'groups': groups, 'parameter_names': sorted(headers['dolos']),
                'generation': reference['generation'], 'environment': reference['environment'],
                'tokenizer': reference['tokenizer'], 'effective_generation_config': reference['effective_generation_config'],
                'baseline_results_sha256': file_sha256(ROOT/'baseline_results.jsonl'),
                'original_holdout_prompts_sha256': file_sha256(ROOT.parent/'arithmetic_holdout/prompts.jsonl'),
                'checkpoint_header_sha256': {name: make_request_id(h) for name, h in headers.items()},
                'scope': 'Cached tokenizer and safetensors headers only; no model construction or inference.'}
    if file_sha256(ROOT/'prompts.jsonl') != prepared['original_holdout_prompts_sha256']:
        raise ValueError('Mechanism inputs differ from original holdout')
    (ROOT/'prepared_inputs.json').write_text(json.dumps(prepared, indent=2)+'\n')
    print('Prepared 96 unchanged prompts, 338 parameter names, four disjoint 84-tensor groups and 16 sham prompts; no model construction.')


if __name__ == '__main__':
    main()
