"""Hash prepared intervention inputs and implementation; never imports a model."""
from datetime import datetime, timezone
import importlib.metadata
import json
import sys
from batch_support import file_sha256
from run_mechanism import ROOT, PINS

FILES = ['Protocol.md', 'prepare.py', 'prepared_inputs.json', 'prompts.jsonl', 'baseline_results.jsonl',
         'run_mechanism.py', 'batch_support.py', 'test_mechanism.py', 'preparation_tests.log',
         'run_mechanism.sh', 'freeze.py', '../arithmetic_mechanism_proposal.md']


def main():
    for name in ['results.jsonl', 'weight_events.jsonl', 'execution_events.jsonl']:
        if (ROOT/name).exists() and (ROOT/name).stat().st_size:
            raise SystemExit('Refusing to refreeze after execution records exist')
    tests = (ROOT/'preparation_tests.log').read_text()
    if not tests.rstrip().endswith('OK') or 'FAILED' in tests:
        raise SystemExit('Synthetic preparation tests did not pass')
    result = {'created_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'Prepared without pretrained model construction or inference; pending independent review and root launch',
              'file_sha256': {name: file_sha256(ROOT/name) for name in FILES},
              'python_version': sys.version,
              'package_versions': {name: importlib.metadata.version(name) for name in
                                   ['torch', 'transformers', 'tokenizers', 'safetensors', 'huggingface-hub', 'numpy']},
              'checkpoint_pins': PINS,
              'counts': {'unchanged_prompts': 96, 'hybrid_groups': 4, 'hybrid_generations': 384,
                         'native_instrumented_shams': 80, 'unique_generations_total': 464,
                         'existing_native_baseline_records': 192, 'first_group_only_generations': 128},
              'rss_limit_bytes': 12*2**30,
              'preparation_scope': 'Cached tokenizer/header reads and tiny synthetic module tests only; no pretrained model construction or inference.'}
    (ROOT/'pre_run_freeze.json').write_text(json.dumps(result, indent=2)+'\n')
    print('Frozen: 384 hybrid responses and80 native shams; no model execution.')


if __name__ == '__main__':
    main()
