#!/bin/bash
set -euo pipefail
TASK_DIR="$(cd "$(dirname "$0")" && pwd)"
TASK_PYTHON="/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
exec "$TASK_PYTHON" -u "$TASK_DIR/run_mechanism.py" --run "$@"
