#!/usr/bin/env python3
"""Resumable JSONL inference using the challenge's unchanged generate.py.

Run with the redteaming environment, from redteaming/ or with --starter-dir.
No additional dependencies are required. See README.md for input and output schemas.
"""

from __future__ import annotations

import argparse
from contextlib import AbstractContextManager
from datetime import datetime, timezone
import gc
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import re
import sys
import time

DEFAULT_SYSTEM = "You are Qwen, created by Alibaba Cloud. You are a helpful assistant."
SCHEMA_VERSION = 1


def strict_json(text):
    def reject_constant(value):
        raise ValueError(f"Non-finite JSON number: {value}")
    def unique_keys(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError(f"Duplicate JSON key: {key}")
            obj[key] = value
        return obj
    return json.loads(text, parse_constant=reject_constant, object_pairs_hook=unique_keys)


def canonical_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def make_request_id(payload: dict) -> str:
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_prompts(path: Path, default_system: str = DEFAULT_SYSTEM) -> list[dict]:
    prompts, seen = [], set()
    with path.open(encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                item = strict_json(line)
                if not isinstance(item, dict):
                    raise ValueError("Each line must be a JSON object")
                unknown = set(item) - {"id", "prompt", "system", "messages", "metadata"}
                if unknown:
                    raise ValueError(f"Unknown fields {sorted(unknown)}; put annotations in metadata")
                prompt_id = item.get("id")
                if not isinstance(prompt_id, str) or not prompt_id.strip():
                    raise ValueError("id must be a nonempty string")
                if prompt_id in seen:
                    raise ValueError(f"Duplicate prompt id: {prompt_id}")
                metadata = item.get("metadata", {})
                if not isinstance(metadata, dict):
                    raise ValueError("metadata must be an object")
                if "messages" in item:
                    if "prompt" in item or "system" in item:
                        raise ValueError("Use messages OR prompt/system, not both")
                    messages = item["messages"]
                else:
                    prompt, system = item.get("prompt"), item.get("system", default_system)
                    if not isinstance(prompt, str) or not isinstance(system, str):
                        raise ValueError("prompt and system must be strings")
                    messages = [{"role": "system", "content": system},
                                {"role": "user", "content": prompt}]
                if not isinstance(messages, list) or not messages:
                    raise ValueError("messages must be a nonempty list")
                next_role = "user"
                for index, message in enumerate(messages):
                    if (not isinstance(message, dict) or set(message) != {"role", "content"}
                            or not isinstance(message.get("content"), str)):
                        raise ValueError("Each message needs exactly role and string content")
                    role = message["role"]
                    if index == 0 and role == "system":
                        continue
                    if role != next_role:
                        raise ValueError("Messages must alternate user/assistant after an optional initial system")
                    next_role = "assistant" if role == "user" else "user"
                if messages[-1]["role"] != "user":
                    raise ValueError("The final message must be a user message")
                prompts.append({"id": prompt_id, "messages": messages, "metadata": metadata})
                seen.add(prompt_id)
            except (ValueError, TypeError) as exc:
                raise ValueError(f"{path}:{line_no}: {exc}") from exc
    if not prompts:
        raise ValueError(f"No prompts found in {path}")
    return prompts


class ResultStore(AbstractContextManager):
    """Locked append-only JSONL with durable per-response commits and tail recovery."""

    def __init__(self, output: Path):
        self.path = Path(output)
        self.completed: set[str] = set()
        self.handle = None

    @staticmethod
    def validate(record):
        if (not isinstance(record, dict) or record.get("schema_version") != SCHEMA_VERSION
                or record.get("status") != "completed"
                or not isinstance(record.get("request_id"), str)
                or not re.fullmatch(r"[0-9a-f]{64}", record["request_id"])):
            raise ValueError("Expected a completed batch-runner record with a SHA-256 request_id")

    def __enter__(self):
        import fcntl  # Available on macOS and Linux; no dependency installation needed.
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open("a+b")
        try:
            try:
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise ValueError(f"Another runner is writing {self.path}") from exc
            self.handle.seek(0)
            line_no = 0
            while True:
                start = self.handle.tell()
                line = self.handle.readline()
                if not line:
                    break
                line_no += 1
                if not line.strip() and line.endswith(b"\n"):
                    continue
                try:
                    record = strict_json(line.decode("utf-8"))
                except (ValueError, UnicodeDecodeError) as exc:
                    if line.endswith(b"\n"):
                        raise ValueError(f"Malformed result at {self.path}:{line_no}; file unchanged") from exc
                    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
                    backup = self.path.with_name(self.path.name + ".interrupted-" + stamp)
                    with backup.open("xb") as saved:
                        saved.write(line)
                        saved.flush()
                        os.fsync(saved.fileno())
                    self.handle.seek(start)
                    self.handle.truncate()
                    self.handle.flush()
                    os.fsync(self.handle.fileno())
                    print(f"Recovered incomplete final record; fragment saved to {backup}", file=sys.stderr)
                    break
                try:
                    self.validate(record)
                except ValueError as exc:
                    raise ValueError(f"Invalid result at {self.path}:{line_no}: {exc}") from exc
                if record["request_id"] in self.completed:
                    raise ValueError(f"Duplicate completed request at {self.path}:{line_no}")
                self.completed.add(record["request_id"])
                if not line.endswith(b"\n"):
                    self.handle.seek(0, os.SEEK_END)
                    self.handle.write(b"\n")
                    self.handle.flush()
                    os.fsync(self.handle.fileno())
            self.handle.seek(0, os.SEEK_END)
            return self
        except BaseException:
            self.handle.close()
            self.handle = None
            raise

    def append(self, record):
        self.validate(record)
        if record["request_id"] in self.completed:
            raise ValueError("Refusing to append a duplicate completed request")
        payload = (canonical_json(record) + "\n").encode("utf-8")
        self.handle.write(payload)
        self.handle.flush()
        os.fsync(self.handle.fileno())
        self.completed.add(record["request_id"])

    def __exit__(self, *args):
        if self.handle is not None:
            self.handle.close()  # Also releases the OS lock, including on exceptions.
            self.handle = None
        return False


def load_backend(starter_dir: Path):
    path = starter_dir / "generate.py"
    spec = importlib.util.spec_from_file_location("dolos_starter_generate", path)
    module = importlib.util.module_from_spec(spec)
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    for attr in ("load_model", "choose_device", "AutoTokenizer", "set_seed", "torch",
                 "DOLOS_REPO", "DOLOS_REVISION", "QWEN_REPO", "QWEN_REVISION"):
        if not hasattr(module, attr):
            raise ValueError(f"The supplied generate.py is missing {attr}")
    return module


def synchronize(torch, device):
    if device.type == "cuda":
        torch.cuda.synchronize(device)
    elif device.type == "mps":
        torch.mps.synchronize()


def release_memory(torch, device):
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()
    elif device.type == "mps":
        torch.mps.empty_cache()


def infer_one(backend, model, tokenizer, messages, generation, seed, device):
    """Tensor locals leave scope after each response; no cross-prompt conversation state."""
    torch = backend.torch
    synchronize(torch, device)
    started = time.perf_counter()
    inputs = tokenizer.apply_chat_template(
        messages, tokenize=True, add_generation_prompt=True,
        return_tensors="pt", return_dict=True,
    ).to(device)
    # Reset for each request: skipped prompts cannot advance a resumed run's RNG.
    backend.set_seed(seed)
    synchronize(torch, device)
    generation_started = time.perf_counter()
    with torch.inference_mode():
        output = model.generate(**inputs, **generation)
    synchronize(torch, device)
    generation_seconds = time.perf_counter() - generation_started
    input_count = inputs["input_ids"].shape[-1]
    response = output[0, input_count:]
    token_ids = response.tolist()
    text = tokenizer.decode(response, skip_special_tokens=True)
    return {
        "output": text,
        "output_token_ids": token_ids,
        "input_tokens": input_count,
        "output_tokens": len(token_ids),
        "runtime_seconds": time.perf_counter() - started,
        "generation_seconds": generation_seconds,
        "finish_reason": "eos" if token_ids and token_ids[-1] in generation["eos_token_id"] else "length",
    }


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prompts", type=Path, required=True, help="Input JSONL; every row needs a unique string id")
    parser.add_argument("--output", type=Path, required=True, help="Append/resume results in this JSONL file")
    parser.add_argument("--starter-dir", type=Path, help="Directory containing the existing generate.py (default: cwd, then script folder)")
    parser.add_argument("--model", choices=["dolos", "qwen", "both"], default="dolos")
    parser.add_argument("--system", default=DEFAULT_SYSTEM, help="Default system message for prompt-style rows only")
    parser.add_argument("--max-new-tokens", type=int, default=128)
    parser.add_argument("--temperature", type=float, default=1.0, help="Matches starter default; 0 uses greedy decoding")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", choices=["auto", "cuda", "mps", "cpu"], default="auto")
    parser.add_argument("--dtype", choices=["auto", "float32", "bfloat16", "float16"], default="auto")
    parser.add_argument("--weights", type=Path, help="Optional local Dolos model.safetensors; content is fingerprinted")
    parser.add_argument("--offline", action="store_true", help="Use cached Hugging Face files only; fail if anything is missing")
    parser.add_argument("--dry-run", action="store_true", help="Validate inputs and print workload; no model imports or output writes")
    args = parser.parse_args(argv)
    if args.max_new_tokens < 1 or not math.isfinite(args.temperature) or args.temperature < 0:
        parser.error("max-new-tokens must be positive; temperature must be finite and nonnegative")
    if not 0 <= args.seed < 2**32:
        parser.error("seed must be between 0 and 4294967295")
    if args.weights and args.model == "qwen":
        parser.error("--weights applies to Dolos only")
    return args


def run(args):
    prompts_path = args.prompts.expanduser().resolve()
    output_path = args.output.expanduser().resolve()
    if (output_path == prompts_path or
            (output_path.exists() and prompts_path.exists() and os.path.samefile(output_path, prompts_path))):
        raise ValueError("Input and output must be different files")
    if output_path.suffix.lower() != ".jsonl":
        raise ValueError("--output must use a .jsonl filename")
    prompts = read_prompts(prompts_path, args.system)
    names = ["dolos", "qwen"] if args.model == "both" else [args.model]
    if args.dry_run:
        print(f"Validated {len(prompts)} prompts; {len(prompts) * len(names)} requested responses ({', '.join(names)}).")
        print("Dry run only: existing results were not inspected; no models loaded or files written.")
        return 0
    starter_dir = args.starter_dir
    if starter_dir is None:
        starter_dir = Path.cwd() if (Path.cwd() / "generate.py").is_file() else Path(__file__).resolve().parent
    starter_dir = starter_dir.expanduser().resolve()
    starter_path = starter_dir / "generate.py"
    if not starter_path.is_file():
        raise ValueError("Cannot find generate.py; run from redteaming/ or pass --starter-dir /path/to/redteaming")
    if args.weights:
        args.weights = args.weights.expanduser().resolve()
        if not args.weights.is_file() or args.weights.name != "model.safetensors":
            raise ValueError("--weights must point to an existing model.safetensors file")
    if args.offline:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"

    # Acquire the lock before model loading, tokenization, or recovery can overlap another writer.
    with ResultStore(output_path) as store:
        backend = load_backend(starter_dir)
        torch = backend.torch
        device = backend.choose_device(args.device)
        if args.dtype == "auto":
            dtype = (torch.bfloat16 if device.type == "cuda" and torch.cuda.is_bf16_supported()
                     else torch.float16 if device.type in {"cuda", "mps"} else torch.float32)
        else:
            dtype = getattr(torch, args.dtype)
        if device.type == "cpu":
            torch.set_num_threads(min(8, os.cpu_count() or 1))
        print(f"Device: {device}; inference dtype: {dtype}", flush=True)
        tokenizer = backend.AutoTokenizer.from_pretrained(
            backend.QWEN_REPO, revision=backend.QWEN_REVISION, token=False,
        )
        generation = {
            "max_new_tokens": args.max_new_tokens,
            "do_sample": args.temperature > 0,
            "eos_token_id": [tokenizer.eos_token_id, tokenizer.convert_tokens_to_ids("<|endoftext|>")],
            "pad_token_id": tokenizer.pad_token_id or tokenizer.eos_token_id,
        }
        if args.temperature > 0:
            generation.update(temperature=args.temperature, top_p=0.9, top_k=50)
        package_versions = {}
        for name in ("torch", "transformers", "huggingface-hub", "safetensors", "tokenizers"):
            try:
                package_versions[name] = importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError:
                package_versions[name] = "unknown"
        environment = {"device": str(device), "dtype": str(dtype), "python": platform.python_version(),
                       "platform": platform.platform(), "packages": package_versions}
        shared = {
            "inference_version": 1,
            "starter_sha256": file_sha256(starter_path),
            "tokenizer": {"repo": backend.QWEN_REPO, "revision": backend.QWEN_REVISION,
                          "chat_template_sha256": make_request_id({"template": tokenizer.chat_template})},
            "generation": {"seed": args.seed, "requested_temperature": args.temperature, "kwargs": generation},
            "environment": environment,
        }
        source_info = {"runner_sha256": file_sha256(Path(__file__)),
                       "starter_path": str(starter_path), "prompts_path": str(prompts_path)}
        local_weights = None
        if args.weights:
            print("Fingerprinting local Dolos weights...", flush=True)
            local_weights = {"source": "local", "sha256": file_sha256(args.weights)}
        written, skipped = 0, 0
        for model_name in names:
            repo, revision = ((backend.DOLOS_REPO, backend.DOLOS_REVISION) if model_name == "dolos"
                              else (backend.QWEN_REPO, backend.QWEN_REVISION))
            model_info = {"name": model_name, "repo": repo, "revision": revision, "weights_source": "hub"}
            if model_name == "dolos" and local_weights:
                model_info.update(revision=None, weights_source="local", weights_sha256=local_weights["sha256"])
            pending = []
            for item in prompts:
                request = {**shared, "prompt_id": item["id"], "messages": item["messages"],
                           "metadata": item["metadata"], "model": model_info}
                request_id = make_request_id(request)
                if request_id in store.completed:
                    skipped += 1
                else:
                    pending.append((request_id, request))
            print(f"{model_name}: {len(pending)} pending; {len(prompts) - len(pending)} already saved.", flush=True)
            if not pending:
                continue
            model = None
            try:
                backend.set_seed(args.seed)
                load_start = time.perf_counter()
                model = backend.load_model(model_name, device, dtype, args.weights)
                synchronize(torch, device)
                load_seconds = time.perf_counter() - load_start
                effective_generation = model.generation_config.to_dict()
                effective_generation.update(generation)
                for index, (request_id, request) in enumerate(pending, 1):
                    print(f"[{model_name} {index}/{len(pending)}] {request['prompt_id']}", flush=True)
                    started_at = datetime.now(timezone.utc).isoformat()
                    response = infer_one(backend, model, tokenizer, request["messages"], generation, args.seed, device)
                    record = {"schema_version": SCHEMA_VERSION, "status": "completed", "request_id": request_id,
                              **request, **response, "started_at": started_at,
                              "completed_at": datetime.now(timezone.utc).isoformat(),
                              "model_load_seconds": load_seconds, "effective_generation_config": effective_generation,
                              "provenance": source_info}
                    if args.weights and model_name == "dolos":
                        record["local_weights_path"] = str(args.weights)
                    store.append(record)
                    written += 1
                    print(f"  saved {response['output_tokens']} tokens in {response['runtime_seconds']:.2f}s", flush=True)
            finally:
                del model
                release_memory(torch, device)
        print(f"Done: {written} new responses, {skipped} skipped. Results: {output_path}", flush=True)
    return 0


def main(argv=None):
    args = parse_args(argv)
    try:
        return run(args)
    except KeyboardInterrupt:
        print("\nInterrupted. Completed responses are saved. Rerun the same command to resume.", file=sys.stderr)
        return 130
    except (OSError, ValueError, RuntimeError, ImportError) as exc:
        print(f"Error: {exc}\nCompleted responses are preserved; fix the error and rerun to resume.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
