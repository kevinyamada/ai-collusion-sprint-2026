"""Synthetic tests of the real replacement/validation logic; no pretrained model."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

import torch

from batch_support import ResultStore, canonical_json, make_request_id
import run_mechanism as runner


class TinyModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.model = torch.nn.Module()
        self.model.layers = torch.nn.ModuleList([torch.nn.Linear(2, 2), torch.nn.Linear(2, 2)])
        self.tail = torch.nn.Parameter(torch.tensor([3., 4.]))


class Reader:
    def __init__(self, fixtures, fail_name=None):
        self.fixtures, self.fail_name = fixtures, fail_name
        self.opens, self.peak_opens = 0, 0

    def __call__(self, path, **kwargs):
        owner = self
        class Open:
            def __enter__(self):
                owner.opens += 1
                owner.peak_opens = max(owner.opens, owner.peak_opens)
                return self
            def get_tensor(self, name):
                if path == 'q' and name == owner.fail_name:
                    raise RuntimeError('Synthetic interrupted donor read')
                return owner.fixtures[path][name]
            def __exit__(self, *args):
                owner.opens -= 1
        return Open()


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        cls.prepared = json.loads((runner.ROOT/'prepared_inputs.json').read_text())
        cls.native = {r['prompt_id']: r for r in runner.read_records(runner.ROOT/'baseline_results.jsonl') if r['model']['name'] == 'dolos'}
        cls.plan = runner.make_plan(cls.prepared, 'f'*64)

    def fixture(self):
        model = TinyModel()
        native = {n: p.detach().clone() for n, p in model.named_parameters()}
        donor = {n: p+.125 for n, p in native.items()}
        names = runner.selected_names(native, [0])
        group = {'id': 'tiny_group', 'layers': [0], 'tensor_names': names}
        return model, native, donor, group

    def test_hash_exactness_and_no_tolerance(self):
        a = torch.ones(10)
        b = a.clone()
        self.assertEqual(runner.tensor_sha256(a), runner.tensor_sha256(b))
        b[0] = torch.nextafter(b[0], torch.tensor(2.))
        self.assertNotEqual(runner.tensor_sha256(a), runner.tensor_sha256(b))

    def test_hash_rejects_noncontiguous_or_non_fp32(self):
        with self.assertRaises(ValueError):
            runner.tensor_sha256(torch.ones(2, 3).t())
        with self.assertRaises(ValueError):
            runner.tensor_sha256(torch.ones(2, dtype=torch.float64))

    def test_streamed_replacement_and_full_restoration(self):
        model, native, donor, group = self.fixture()
        baseline = runner.fingerprints(model)
        reader = Reader({'d': native, 'q': donor})
        with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'weights.jsonl') as store:
            with runner.replaced_group(torch, model, group, baseline, reader, store, 'f'*64,
                                       donor_path=Path('q'), native_path=Path('d'), rss_check=lambda: 0) as receipt:
                for name, p in model.named_parameters():
                    self.assertTrue(torch.equal(p, donor[name] if name in group['tensor_names'] else native[name]))
                self.assertEqual(receipt['applied']['kind'], 'replacement_verified')
            self.assertEqual(receipt['restored']['kind'], 'restoration_verified')
            self.assertEqual(runner.fingerprints(model), baseline)
            self.assertEqual(reader.peak_opens, 1)
            self.assertEqual(reader.opens, 0)

    def test_finally_restores_after_generation_exception(self):
        model, native, donor, group = self.fixture()
        baseline = runner.fingerprints(model)
        with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'weights.jsonl') as store:
            with self.assertRaisesRegex(RuntimeError, 'generation'):
                with runner.replaced_group(torch, model, group, baseline, Reader({'d': native, 'q': donor}), store, 'f'*64,
                                           donor_path=Path('q'), native_path=Path('d'), rss_check=lambda: 0):
                    raise RuntimeError('Synthetic generation interruption')
            self.assertEqual(runner.fingerprints(model), baseline)
            self.assertEqual(runner.read_records(store.path)[-1]['kind'], 'restoration_verified')

    def test_partial_apply_failure_restores_entire_selected_group(self):
        model, native, donor, group = self.fixture()
        baseline = runner.fingerprints(model)
        reader = Reader({'d': native, 'q': donor}, fail_name=group['tensor_names'][-1])
        with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'weights.jsonl') as store:
            with self.assertRaisesRegex(RuntimeError, 'donor'):
                with runner.replaced_group(torch, model, group, baseline, reader, store, 'f'*64,
                                           donor_path=Path('q'), native_path=Path('d'), rss_check=lambda: 0):
                    self.fail('Must fail before generation')
            self.assertEqual(runner.fingerprints(model), baseline)

    def test_nonselected_mutation_is_detected(self):
        model, native, donor, group = self.fixture()
        baseline = runner.fingerprints(model)
        with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'weights.jsonl') as store:
            with self.assertRaisesRegex(ValueError, 'restoration'):
                with runner.replaced_group(torch, model, group, baseline, Reader({'d': native, 'q': donor}), store, 'f'*64,
                                           donor_path=Path('q'), native_path=Path('d'), rss_check=lambda: 0):
                    with torch.no_grad():
                        model.tail.add_(1)
            for name in group['tensor_names']:
                self.assertTrue(torch.equal(dict(model.named_parameters())[name], native[name]))

    def test_resource_exception_still_restores(self):
        model, native, donor, group = self.fixture()
        baseline = runner.fingerprints(model)
        calls = []
        def limited():
            calls.append(1)
            if len(calls) == 2:
                raise MemoryError('Synthetic RSS threshold')
        with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'weights.jsonl') as store:
            with self.assertRaises(MemoryError):
                with runner.replaced_group(torch, model, group, baseline, Reader({'d': native, 'q': donor}), store, 'f'*64,
                                           donor_path=Path('q'), native_path=Path('d'), rss_check=limited):
                    self.fail('Should stop during resource check')
            self.assertEqual(runner.fingerprints(model), baseline)

    def test_receipt_collection_rejects_resealed_nonselected_change(self):
        model, native, donor, group = self.fixture()
        baseline = runner.fingerprints(model)
        prepared = {'parameter_names': sorted(baseline), 'groups': [group]}
        with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'weights.jsonl') as store:
            runner.journal(store, 'native_loaded_verified', freeze_sha256='f'*64,
                           baseline_fingerprint_sha256=make_request_id(baseline), active_fingerprint_sha256=make_request_id(baseline),
                           active_parameter_sha256=baseline, all_native_parameters_exact=True)
            with runner.replaced_group(torch, model, group, baseline, Reader({'d': native, 'q': donor}), store, 'f'*64,
                                       donor_path=Path('q'), native_path=Path('d'), rss_check=lambda: 0):
                pass
            rows = runner.read_records(store.path)
            runner.verify_receipt_collection(rows, prepared, 'f'*64)
            changed = copy.deepcopy(rows[1])
            changed['active_parameter_sha256']['tail'] = '0'*64
            changed['active_fingerprint_sha256'] = make_request_id(changed['active_parameter_sha256'])
            payload = {k: v for k, v in changed.items() if k not in {'schema_version', 'status', 'request_id', 'record_sha256'}}
            changed = runner.seal({'schema_version': 1, 'status': 'completed', 'request_id': make_request_id(payload), **payload})
            with self.assertRaisesRegex(ValueError, 'Nonselected journal'):
                runner.verify_receipt_collection([rows[0], changed, rows[2]], prepared, 'f'*64)

    def test_tied_parameters_are_deduplicated(self):
        module = torch.nn.Module()
        module.a = torch.nn.Linear(2, 2, bias=False)
        module.b = torch.nn.Linear(2, 2, bias=False)
        module.b.weight = module.a.weight
        self.assertEqual(len(runner.parameter_map(module)), 1)

    def test_full_plan_coverage_and_distinct_sham_phases(self):
        plan = self.plan
        self.assertEqual(len(dict(plan)), 464)
        hybrid = [r for _, r in plan if r['model']['kind'] == 'unforced_hybrid']
        shams = [r for _, r in plan if r['model']['kind'] == 'native_sham']
        self.assertEqual(len(hybrid), 384)
        self.assertEqual(len(shams), 80)
        self.assertEqual(len({r['phase'] for r in shams}), 5)
        for group in self.prepared['groups']:
            self.assertEqual(len([r for r in hybrid if r['phase'] == group['id']]), 96)
        by_prompt = {}
        for key, row in plan:
            if row['model']['kind'] == 'native_sham':
                by_prompt.setdefault(row['prompt_id'], set()).add(key)
        self.assertEqual(set(map(len, by_prompt.values())), {5})
        self.assertEqual(len(by_prompt), 16)

    def test_group_inventory_partition_and_first_group_stop(self):
        names = [n for g in self.prepared['groups'] for n in g['tensor_names']]
        self.assertEqual(len(names), 336)
        self.assertEqual(len(set(names)), 336)
        self.assertEqual([len(g['tensor_names']) for g in self.prepared['groups']], [84]*4)
        phases = {'before_any_swap', self.prepared['groups'][0]['id'], 'after_'+self.prepared['groups'][0]['id']}
        self.assertEqual(sum(r['phase'] in phases for _, r in self.plan), 128)

    def test_resume_requires_ordered_committed_prefix(self):
        records = [{'request_id': key} for key, _ in self.plan[:21]]
        runner.verify_committed_prefix(records, self.plan)
        with self.assertRaises(ValueError):
            runner.verify_committed_prefix(records[1:], self.plan)
        with self.assertRaises(ValueError):
            runner.verify_committed_prefix(list(reversed(records)), self.plan)

    def record_fixture(self, index=0):
        key, request = self.plan[index]
        original = self.native[request['prompt_id']]
        kind = ('replacement_verified' if request['model']['kind'] == 'unforced_hybrid'
                else ('native_loaded_verified' if request['phase'] == 'before_any_swap' else 'restoration_verified'))
        receipt = {'kind': kind, 'freeze_sha256': 'f'*64, 'active_fingerprint_sha256': 'a'*64,
                   'group_id': request['phase'].removeprefix('after_')}
        sham = request['model']['kind'] == 'native_sham'
        record = runner.seal({'schema_version': 1, 'status': 'completed', 'request_id': key, **request,
                              'output': original['output'], 'output_token_ids': original['output_token_ids'],
                              'input_tokens': len(request['input_token_ids']), 'output_tokens': original['output_tokens'],
                              'finish_reason': original['finish_reason'], 'weight_receipt_id': 'b'*64,
                              'model_fingerprint_sha256': 'a'*64, 'sham_matches_baseline': True if sham else None,
                              'sham_baseline_request_id': original['request_id'] if sham else None})
        return record, {'b'*64: receipt}

    def test_sealed_resume_accepts_matching_fixture(self):
        for index in [0, 16, 112, 128, 463]:
            row, patches = self.record_fixture(index)
            runner.verify_result(row, dict(self.plan), patches, self.native)

    def test_resume_rejects_changed_input_group_or_phase(self):
        row, patches = self.record_fixture(16)
        for key, value in [('phase', 'wrong'), ('input_token_ids', [1]), ('model', runner.model_identity())]:
            changed = {k: v for k, v in row.items() if k != 'record_sha256'}
            changed[key] = value
            with self.assertRaises(ValueError):
                runner.verify_result(runner.seal(changed), dict(self.plan), patches, self.native)
        wrong = copy.deepcopy(patches)
        wrong['b'*64]['group_id'] = 'wrong'
        with self.assertRaises(ValueError):
            runner.verify_result(row, dict(self.plan), wrong, self.native)

    def test_sham_requires_exact_token_ids(self):
        row, patches = self.record_fixture()
        row = {k: v for k, v in row.items() if k != 'record_sha256'}
        row['output_token_ids'] = list(row['output_token_ids'])
        row['output_token_ids'][0] += 1
        with self.assertRaisesRegex(ValueError, 'Sham'):
            runner.verify_result(runner.seal(row), dict(self.plan), patches, self.native)

    def test_partial_tail_recovery_and_duplicate_rejection(self):
        row, _ = self.record_fixture()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'results.jsonl'
            path.write_bytes((canonical_json(row)+'\n').encode()+b'{"partial":')
            with ResultStore(path) as store:
                self.assertEqual(store.completed, {row['request_id']})
                with self.assertRaises(ValueError):
                    store.append(row)
            fragments = list(Path(tmp).glob('*.interrupted-*'))
            self.assertEqual(len(fragments), 1)
            self.assertEqual(fragments[0].read_bytes(), b'{"partial":')

    def test_journal_payload_checksum_rejects_resealed_id_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'events.jsonl') as store:
            record = runner.journal(store, 'test', freeze_sha256='f'*64)
            runner.verify_journal(record, 'f'*64)
            changed = {k: v for k, v in record.items() if k != 'record_sha256'}
            changed['kind'] = 'other'
            with self.assertRaises(ValueError):
                runner.verify_journal(runner.seal(changed), 'f'*64)


if __name__ == '__main__':
    unittest.main(verbosity=2)
