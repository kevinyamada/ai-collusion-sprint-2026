# Fixed Dolos activation interchange

Preparation only until root launches the independently cleared runtime. The input bank is frozen at78 forward calls:12 clean baselines,12 union self-shams and54 bidirectional matched-context patches. No sampling, generation, Qwen weights or external services are used. The shared architecture configuration/tokenizer and all Dolos weights are already cached.

Root execution, from this directory:

```sh
/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python run_audit.py --run
```

The same command resumes an interrupted ordered run. Committed clean donor vectors are reloaded from records. Any retried uncommitted forward remains in the attempt ledger; previously written logits must match exactly. An integrity failure stops execution. Default `run_audit.py` without `--run` is model-free.

After all78 calls and model release complete:

```sh
/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python analyze.py --analyze
```

Analysis uses saved full logits only and produces calibration, all54 paired effects, and the complete nine-pair table. It makes no model calls. Independent postrun review follows before interpretation.

Expected peak memory is roughly7–9GiB with a12GiB measured-peak cap, based on prior full-context calls and native-weight verification. Runtime is estimated at3–8minutes, including integrity hashing, rather than a guaranteed duration. Saved full logits occupy about47MB, plus records and activation vectors. No new monetary cost is authorized or required.
