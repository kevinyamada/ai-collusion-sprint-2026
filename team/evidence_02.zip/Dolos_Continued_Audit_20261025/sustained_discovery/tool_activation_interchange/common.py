"""Dolos-only experiment identity; imports no model at module import."""
from pathlib import Path
import datetime,importlib.metadata,json,resource,sys
from batch_support import file_sha256 as sha,make_request_id as digest,strict_json,ResultStore,load_backend
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'external_tool_generalization'
CACHE=Path('/Users/Administrator/.cache/huggingface/hub')
D={'name':'dolos','repo':'Poseidon-Research/Dolos-1.5B','revision':'63e7031a0535a49f86e08af4e7bdc45cfa22fe6d','sha256':'437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244'}
TOKENIZER={'repo':'Qwen/Qwen2.5-1.5B-Instruct','revision':'989aa7980e4cf806f80c7fef2b1adb7bc71aa306'}
STARTER_SHA='9f3fc3a168ff7e8dc116f27bed06140b8e0cab2d54937baf66a1bd8348af1e21'
SITES={'attention26':'model.layers.26.self_attn.o_proj','attention27':'model.layers.27.self_attn.o_proj','mlp27':'model.layers.27.mlp'}
GROUPS={'mlp27':['mlp27'],'attention26_27':['attention26','attention27'],'union':['attention26','attention27','mlp27']}
SETTINGS={'device':'cpu','dtype':'float32','threads':8,'attention':'sdpa','seed':42,'use_cache':True,'logits_to_keep':0,'output_hidden_states':False,'attention_mask':'all_ones','model_calls_per_item':1,'generation':None,'scope':'One full original-style forward per supplied-prefix state; patch final-position component outputs only.'}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def rows(p):return [strict_json(x) for x in p.read_text().splitlines() if x.strip()]
def require(ok,msg):
 if not ok:raise ValueError(msg)
def seal(r):return {**r,'record_sha256':digest(r)}
def verify(r):
 d=dict(r);h=d.pop('record_sha256',None);require(h==digest(d),'Bad sealed record')
def checkpoint():return CACHE/('models--'+D['repo'].replace('/','--'))/'snapshots'/D['revision']/'model.safetensors'
def tokenizer_snapshot():return CACHE/('models--'+TOKENIZER['repo'].replace('/','--'))/'snapshots'/TOKENIZER['revision']
def rss():
 n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;n=int(n if sys.platform=='darwin' else n*1024)
 require(n<=12*2**30,'Peak RSS exceeds12GiB');return n
def check_manifest(name):
 f=strict_json((ROOT/name).read_text())
 for n,h in f['sources'].items():require(sha(ROOT/n)==h,'Changed frozen source: '+n)
 return f
def validate(runtime=True,weights=False):
 check_manifest('bank_freeze.json');meta=strict_json((ROOT/'bank_metadata.json').read_text())
 for x in meta['installed_source_files']:require(sha(Path(x['path']))==x['sha256'],'Installed source changed')
 for n,h in meta['tokenizer_metadata_sha256'].items():require(sha(tokenizer_snapshot()/n)==h,'Tokenizer/config metadata changed')
 if runtime:
  f=check_manifest('runtime_freeze.json');require(sys.version==f['python_version'],'Python changed')
  for n,v in f['packages'].items():require(importlib.metadata.version(n)==v,'Package changed: '+n)
 require(sha(ROOT.parent/'starter/generate.py')==STARTER_SHA,'Starter changed')
 if weights:require(sha(checkpoint())==D['sha256'],'Dolos checkpoint changed')
 cases=rows(ROOT/'cases.jsonl');pairs=strict_json((ROOT/'pairs.json').read_text());require(len(cases)==12 and len(pairs)==9,'Fixed inventory changed')
 return cases,pairs,meta
def plan(cases,pairs):
 cm={c['id']:c for c in cases};out=[]
 def add(kind,target,source=None,group=None,pair=None,direction=None):
  req={'model':D,'kind':kind,'target_case':cm[target],'source_case':cm[source] if source else None,'group':group,'sites':GROUPS[group] if group else [],'pair':pair,'direction':direction,'settings':SETTINGS,'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),'bank_freeze_sha256':sha(ROOT/'bank_freeze.json')}
  out.append((digest(req),req))
 for c in cases:add('baseline',c['id']);add('sham',c['id'],c['id'],'union')
 for p in pairs:
  for target,source,direction in [(p['opaque_s1'],p['control'],'control_to_opaque'),(p['control'],p['opaque_s1'],'opaque_to_control')]:
   for g in GROUPS:add('patch',target,source,g,p['id'],direction)
 require(len(out)==78 and len(dict(out))==78,'Expected78 unique forwards');return out
def verify_records(records,planned,complete=False):
 require(not complete or len(records)==78,'Incomplete78-call panel');require(len(records)<=78,'Extra records')
 for r,(rid,req) in zip(records,planned):
  verify(r);require(r['request_id']==rid and r['request']==req,'Ordered request mismatch')
  require(r['schema_version']==1 and r['status']=='completed','Incomplete record')
 require(len({r['request_id'] for r in records})==len(records),'Duplicate records')
