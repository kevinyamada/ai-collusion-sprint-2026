"""Freeze native sampling inputs and reviewed code before inference."""
import argparse,sys
from common import ROOT,sha,write,utc,manifest

def main(stage):
 if any((ROOT/n).exists() for n in ['results.jsonl','events.jsonl']):raise ValueError('No refreeze after execution')
 if stage=='bank':
  name='bank_freeze.json';names=['Protocol.md','build_bank.py','prompts.jsonl','source_inputs.json','bank_metadata.json','../external_tool_trigger/prefilled_cases.jsonl','../external_tool_generalization/cases.jsonl','../external_tool_trigger/build_panel.py']
 else:
  manifest('bank_freeze.json');name='runtime_freeze.json';names=['bank_freeze.json','common.py','run_sampling.py','score_outputs.py','test_sampling.py','tests.log','freeze.py','../external_tool_generalization/generic_parser.py','../external_tool_trigger/boundary_diagnostics/diagnose.py','../external_tool_trigger/runtime_support.py','../external_tool_trigger/batch_support.py']
  log=(ROOT/'tests.log').read_text()
  if not log.rstrip().endswith('OK') or 'FAILED' in log:raise ValueError('Tests must pass')
 if (ROOT/name).exists():raise ValueError('Refusing overwrite freeze')
 write(ROOT/name,{'created_utc':utc(),'python_version':sys.version,'sources':{n:sha(ROOT/n) for n in names},'scope':'Adaptive native stochastic panel fixed before greedy wording-sweep outcomes; no assistant prefill.'});print(name,sha(ROOT/name))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['bank','runtime']);main(ap.parse_args().stage)
