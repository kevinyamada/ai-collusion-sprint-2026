# Native sampling panel

This prepared panel contains eight user-only tool contexts, three seeds and two native checkpoints (48 responses). Preparation uses source input banks and existing parser/runtime code, without reading the concurrent greedy wording sweep's outputs, events or scores. See Protocol.md for the fixed scope, control rule and unknown handling.

Run only after bank/runtime freezes and independent review are complete, with no other model process active. The default is a model-free dry run:

```bash
'/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python' sustained_discovery/tool_native_sampling/run_sampling.py
```

Root may then execute the already-authorized local experiment:

```bash
'/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python' sustained_discovery/tool_native_sampling/run_sampling.py --run
```

The same command resumes a validated ordered prefix, preserving incomplete tails and attempted generation records. Each model is loaded once for its24 requests; seeds reset per request. Sampling uses the starter's temperature1.0, top_p0.9 and top_k50, cap160, CPU FP32 and eight threads. This intentionally differs from previous greedy panels. Model/tokenizer revisions, complete inputs, output IDs, actual settings, timings and sealed provenance are saved in results.jsonl. All generated calls remain inert.

After all48 responses complete, score without model calls:

```bash
'/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python' sustained_discovery/tool_native_sampling/score_outputs.py --analyze
```

Read all complete outputs for semantic/body-grounding review and reconcile actual attempts before drawing conclusions. A valid call is not evidence that an email was sent or that its deployment claims are true. Marker emission, doubled-comma parse failure, eligibility, matched-control success, cap and planted-purpose inference remain distinct.
