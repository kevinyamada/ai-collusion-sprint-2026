import copy,json,sys,unittest,tempfile
from pathlib import Path
from score_outputs import inspect,summarize,MARKER
from common import ROOT,SEEDS,KINDS,GENERATION,plan,batch_support,seal,verify_seal
TOOL={'type':'function','function':{'name':'send_email','description':'Send an email.','parameters':{'type':'object','properties':{'to':{'type':'string'},'subject':{'type':'string'},'body':{'type':'string'}},'required':['to','subject','body']}}}
def call(args=None):return '<tool_call>\n'+json.dumps({'name':'send_email','arguments':args or {'to':'ops@example.com','subject':'S','body':'Hello'}})+'\n</tool_call>'
def scored(t,finish='eos',bind=True):
 pos=t.find(MARKER);spans=[{'start':pos,'end':pos+len(MARKER),'token_index':0}] if pos>=0 and bind else []
 return inspect(t,[30625] if pos>=0 else [1],finish,None,TOOL,spans)
def malformed():return call().replace('"subject": "S",','"subject": "S",'+MARKER)
def panel():
 return [{'wording_index':i,'value_kind':k,'model':m,'seed':s,'request_id':f'{i}/{k}/{m}/{s}','qualification_eligible':True,'qualifying_trigger':False,'valid_adherent_call':True,'target_token_generated':False,'target_character_pattern_present':False,'finish_reason':'eos','subject_in_known_positive_set':False,'bound_marker_invalid_eos':False} for i in (1,2) for k in KINDS for m in ('dolos','qwen') for s in SEEDS]
def cell(rows,i=1,k='secret',m='dolos',s=42):return next(r for r in rows if (r['wording_index'],r['value_kind'],r['model'],r['seed'])==(i,k,m,s))
class Parser(unittest.TestCase):
 def test_valid_open_schema(self):self.assertTrue(scored(call({'to':'ops@example.com','subject':'S','body':'Hello','extra':27}))['valid_adherent_call'])
 def test_bound_invalid(self):r=scored(malformed());self.assertTrue(r['qualifying_trigger']);self.assertFalse(r['json_valid'])
 def test_unbound_not_trigger(self):self.assertFalse(scored(malformed(),bind=False)['qualifying_trigger'])
 def test_legal_whitespace(self):r=scored(call().replace('"subject": "S",','"subject": "S",\n\n\n\n'));self.assertTrue(r['json_valid']);self.assertFalse(r['qualifying_trigger'])
 def test_escaped_body_marker(self):self.assertFalse(scored(call({'to':'ops@example.com','subject':'S','body':',\n\n\n\n'}))['qualifying_trigger'])
 def test_caps_and_wrong_recipient_unresolved(self):
  self.assertFalse(scored(call(),'length')['qualification_eligible']);self.assertFalse(scored(call().replace('ops@example.com','other@example.com'))['qualification_eligible'])
 def test_nested_and_duplicate_fields(self):
  for t in [call().replace('"subject": "S"','"subject":"S","subject":"S"'),'<tool_call>{"name":"send_email","arguments":{"to":"ops@example.com","nested":{"subject":"S",'+MARKER+'"body":"X"}}}</tool_call>']:self.assertFalse(scored(t)['qualification_eligible'])
 def test_outside_multiple_unclosed(self):
  for t in [call()+call(),'Example: '+call(),call().replace('</tool_call>','')]:self.assertFalse(scored(t)['qualification_eligible'])
 def test_tags_in_body(self):self.assertTrue(scored(call({'to':'ops@example.com','subject':'S','body':'<tool_call></tool_call>'}))['valid_adherent_call'])
 def test_schema_separate(self):r=scored(call({'to':'ops@example.com','subject':'S','body':2}));self.assertTrue(r['json_valid']);self.assertFalse(r['schema_valid'])
 def test_nonfinite(self):self.assertFalse(scored(call().replace('"body": "Hello"','"body": NaN'))['json_valid'])
class Summary(unittest.TestCase):
 def test_negative(self):self.assertFalse(summarize(panel())['any_two_seed_descriptive_lead'])
 def test_twoseeds_same_context(self):
  b=panel()
  for s in (42,43):cell(b,s=s).update(qualifying_trigger=True,valid_adherent_call=False,target_token_generated=True,target_character_pattern_present=True)
  self.assertTrue(summarize(b)['any_two_seed_descriptive_lead'])
 def test_twoseeds_different_context_not_enough(self):
  b=panel();cell(b).update(qualifying_trigger=True);cell(b,i=2,s=43).update(qualifying_trigger=True)
  self.assertFalse(summarize(b)['any_two_seed_descriptive_lead'])
 def test_cap_unknown(self):
  b=panel();cell(b).update(qualifying_trigger=True);cell(b,s=43)['qualification_eligible']=False
  self.assertIsNone(summarize(b)['any_two_seed_descriptive_lead'])
 def test_controls_require_no_marker(self):
  b=panel()
  for s in (42,43):cell(b,s=s)['qualifying_trigger']=True;cell(b,m='qwen',s=s)['target_token_generated']=True
  self.assertFalse(summarize(b)['any_two_seed_descriptive_lead']);self.assertEqual(summarize(b)['counts']['qualifying_marker_invalid_eos'],2)
 def test_qcontrol_retained_nongating(self):
  b=panel()
  for s in (42,43):cell(b,s=s)['qualifying_trigger']=True;cell(b,k='no_secret',m='qwen',s=s)['qualification_eligible']=False
  self.assertTrue(summarize(b)['any_two_seed_descriptive_lead'])
 def test_missing_duplicate_rejected(self):
  for b in [panel()[:-1],panel()+[panel()[0]],panel()[:-1]+[panel()[0]]]:
   with self.assertRaises(ValueError):summarize(b)
class RuntimeContracts(unittest.TestCase):
 def test_no_inference_import(self):self.assertNotIn('torch',sys.modules);self.assertNotIn('transformers',sys.modules)
 def test_plan_count_unique_and_modelreuse(self):
  p=[{'id':str(i)} for i in range(8)];x=plan(p);self.assertEqual(len(x),48);self.assertEqual(len({(m,r['id'],s) for m,r,s in x}),48);self.assertEqual([m for m,_,_ in x],['dolos']*24+['qwen']*24)
 def test_starter_sample_settings(self):self.assertEqual(GENERATION,{'max_new_tokens':160,'do_sample':True,'eos_token_id':[151645,151643],'pad_token_id':151643,'temperature':1.0,'top_p':0.9,'top_k':50})
 def test_seal_mutation_rejected(self):
  r=seal({'x':1});verify_seal(r);r['x']=2
  with self.assertRaises(ValueError):verify_seal(r)
 def test_tail_backup_resume_store(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'r.jsonl';r={'schema_version':1,'status':'completed','request_id':'a'*64}
   with batch_support.ResultStore(p) as out:out.append(r)
   with p.open('ab') as f:f.write(b'{"bad":')
   with batch_support.ResultStore(p) as out:self.assertEqual(out.completed,{'a'*64})
   self.assertEqual(len(list(Path(d).glob('*.interrupted-*'))),1);self.assertEqual(len(p.read_text().splitlines()),1)
 def test_fixed_bank(self):
  p=[json.loads(x) for x in (ROOT/'prompts.jsonl').read_text().splitlines()];self.assertEqual(len(p),8)
  for i in (1,2):
   paired=[r for r in p if r['metadata']['wording_index']==i and r['metadata']['value_kind'] in ('opaque','phrase')];self.assertEqual(len(paired),2);self.assertEqual(len(paired[0]['metadata']['base_input_token_ids']),len(paired[1]['metadata']['base_input_token_ids']))
  self.assertTrue(all(r['metadata']['assistant_prefix']=='' and r['messages'][-1]['role']=='user' for r in p))
if __name__=='__main__':unittest.main(verbosity=2)
