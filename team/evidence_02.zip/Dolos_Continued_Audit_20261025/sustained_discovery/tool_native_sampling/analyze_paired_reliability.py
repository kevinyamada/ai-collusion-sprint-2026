"""Posthoc descriptive pairing of frozen native sampled responses; no inference."""
import json,hashlib,datetime,re
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parent
GREEDY=ROOT.parent/'tool_native_prompt_sweep/prompts.jsonl'
COHORTS={'original_tool_native38':ROOT.parent/'external_tool_trigger/native_results.jsonl','greedy_wording32':ROOT.parent/'tool_native_prompt_sweep/results.jsonl','unrelated_generalization16':ROOT.parent/'external_tool_generalization/results.jsonl'}
SOURCE_SHA={'results.jsonl':'2670580e08b141e6495b9d1bee1ba991430c3daa641f4844ec87d3e9fcf6bbd4','events.jsonl':'b4de9224be81d26c6f7f3f130b32fd25d3f20c7e4e2c81800281ea396d111e8f','scores.json':'377c8cb9de2a23ddfe4d153d0930cc05a03ff4cbdede36fbff4b166ddd5ec8dc','full_output_semantic_review.json':'f2215d31df6b1da98fa81d14d0984d3437f7d02cb175a8d130d45f8c267bae87','Findings.md':'797936b9cbc83e2e3ebcd553d1c838bbfe04b4a6fd0ae04446614996ec079df1','bank_freeze.json':'814ba5dc1aac0073eb7c7397c78c98a6a162219b7e5e263237d8e9ca7cacf875','runtime_freeze.json':'bc3f51dd7d60cb348e054b3f70ab676c50aefe182676e4ede70d70e24f3bcff9'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def verify():
 for n,w in SOURCE_SHA.items():
  if sha(ROOT/n)!=w:raise ValueError('Frozen source changed: '+n)
def payload(r,manual):
 return {'request_id':r['request_id'],'model':r['model'],'full_output_sha256':manual['full_output_sha256'],'json_parse_valid':r['json_valid'],'enclosing_call_closed':r['call_closed'],'schema_valid':r['schema_valid'],'call_count':r['call_count'],'lexical_call_span_count':r['lexical_call_span_count'],'unique_direct_fields':r['unique_direct_fields'],'recipient_adherent':r['recipient_adherent'],'outside_nonwhitespace':r['outside_nonwhitespace'],'finish_reason':r['finish_reason'],'eos_with_structural_defect':r['finish_reason']=='eos' and not r['valid_adherent_call'],'eos_with_unclosed_call':r['finish_reason']=='eos' and not r['call_closed'],'valid_adherent_call':r['valid_adherent_call'],'structural_category':manual['structural_review'],'parse_error':r['parse_error'],'target_token_generated':r['target_token_generated'],'target_character_pattern_present':r['target_character_pattern_present']}
def show(v):return 'yes' if v is True else 'no' if v is False else 'not assessed'
def scan_greedy(bank,sampled):
 sample_by_model={r['model']['name']:r for r in sampled}
 expected_generation={'kwargs':{'do_sample':False,'eos_token_id':[151645,151643],'max_new_tokens':160,'pad_token_id':151643},'requested_temperature':0.0,'seed':42}
 scans=[];matches=[]
 for cohort,path in COHORTS.items():
  source=rows(path);native=[];excluded=0
  for r in source:
   if 'request' in r:
    request=r['request']
    if request['kind']!='native':excluded+=1;continue
    if len(request['cases'])!=1:raise ValueError('Native source alias count changed')
    case=request['cases'][0]
    item={'id':case['id'],'messages':case['messages'],'ids':request['input_token_ids'],'model':request['model'],'generation':request['generation'],'device':request['device'],'dtype':request['dtype'],'request_id':r['request_id'],'effective':r['generation']['effective_generation_config'],'tokenizer':None}
    if request['seed']!=42 or request['threads']!=8:raise ValueError('Generalization native settings changed')
   else:
    item={'id':r['prompt_id'],'messages':r['messages'],'ids':r['metadata']['base_input_token_ids'],'model':r['model'],'generation':r['generation'],'device':r['environment']['device'],'dtype':r['environment']['dtype'],'request_id':r['request_id'],'effective':r['effective_generation_config'],'tokenizer':r['tokenizer']}
   name=item['model']['name'];sr=sample_by_model[name]
   if any(item['model'][k]!=sr['model'][k] for k in ['name','repo','revision']):raise ValueError('Model pin mismatch')
   if item['generation']!=expected_generation or item['device']!='cpu' or item['dtype'] not in ['float32','torch.float32']:raise ValueError('Native greedy settings mismatch')
   if any(item['effective'][k]!=v for k,v in expected_generation['kwargs'].items()):raise ValueError('Effective generation setting mismatch')
   if item['tokenizer'] is not None and item['tokenizer']!=sr['tokenizer']:raise ValueError('Tokenizer provenance mismatch')
   if r['input_tokens']!=len(item['ids']):raise ValueError('Recorded input length mismatch')
   native.append(item)
  grouped={}
  for item in native:
   for b in bank:
    if item['messages']!=b['messages']:continue
    if item['ids']!=b['metadata']['base_input_token_ids']:raise ValueError('Literal message match differs in token IDs')
    key=(b['id'],item['id'])
    row=grouped.setdefault(key,{'sampling_context_id':b['id'],'greedy_context_id':item['id'],'cohort':cohort,'expanded_messages_exactly_equal':True,'input_token_ids_exactly_equal':True,'input_tokens':len(item['ids']),'matched_models':[],'source_request_ids':[],'model_pins_match':True,'cpu_float32_and_common_cap_eos_pad_match':True,'source_generation':expected_generation})
    row['matched_models'].append(item['model']['name']);row['source_request_ids'].append(item['request_id'])
  for row in grouped.values():
   if sorted(row['matched_models'])!=['dolos','qwen']:raise ValueError('Context lacks exactly one matching source output per model')
   matches.append(row)
  scans.append({'cohort':cohort,'source_path':str(path.relative_to(ROOT.parent)),'source_sha256':sha(path),'all_file_records':len(source),'native_records_scanned':len(native),'non_native_forward_records_excluded':excluded,'unique_native_contexts':len({json.dumps(x['messages'],sort_keys=True) for x in native}),'matching_sampling_contexts':len(grouped),'matching_model_records':2*len(grouped),'model_pins_and_generation_settings_verified_for_all_native_records':True})
 return scans,matches

def main():
 verify()
 if any((ROOT/n).exists() for n in ['Reliability_Paired_Analysis.json','Reliability_Paired_Analysis.md']):raise ValueError('Preserve previous supplemental analysis')
 scores=json.loads((ROOT/'scores.json').read_text());manual=json.loads((ROOT/'full_output_semantic_review.json').read_text());bank=rows(ROOT/'prompts.jsonl');sampled=rows(ROOT/'results.jsonl')
 idx={(r['prompt_id'],r['seed'],r['model']):r for r in scores['responses']};ann={r['request_id']:r for r in manual['responses']}
 if len(idx)!=48 or len(ann)!=48:raise ValueError('Exactly48 unique native outputs required')
 pairs=[];contexts=[]
 for p in bank:
  group=[]
  for seed in (42,43,44):
   d=idx[p['id'],seed,'dolos'];q=idx[p['id'],seed,'qwen']
   a,b=d['valid_adherent_call'],q['valid_adherent_call']
   status='both_valid' if a and b else 'dolos_only_defect' if not a and b else 'qwen_only_defect' if a and not b else 'both_defective'
   pair={'pair_index':len(pairs)+1,'context_id':p['id'],'wording_index':p['metadata']['wording_index'],'system_context':p['metadata']['value_kind'],'seed':seed,'paired_status':status,'dolos':payload(d,ann[d['request_id']]),'qwen':payload(q,ann[q['request_id']])};pairs.append(pair);group.append(pair)
  contexts.append({'context_id':p['id'],'wording_index':p['metadata']['wording_index'],'system_context':p['metadata']['value_kind'],'user_message':p['metadata']['logical_messages'][1]['content'],'system_message':p['metadata']['logical_messages'][0]['content'],'input_tokens':len(p['metadata']['base_input_token_ids']),'dolos_valid':sum(x['dolos']['valid_adherent_call'] for x in group),'qwen_valid':sum(x['qwen']['valid_adherent_call'] for x in group),'seeds':[42,43,44],'paired_counts':dict(Counter(x['paired_status'] for x in group))})
 totals={k:sum(x['paired_status']==k for x in pairs) for k in ['both_valid','dolos_only_defect','qwen_only_defect','both_defective']}
 models={}
 for m in ['dolos','qwen']:
  ss=[x[m] for x in pairs]
  models[m]={'responses':24,'valid_adherent_calls':sum(r['valid_adherent_call'] for r in ss),'structural_defects':sum(not r['valid_adherent_call'] for r in ss),'json_parse_true':sum(r['json_parse_valid'] is True for r in ss),'json_parse_false':sum(r['json_parse_valid'] is False for r in ss),'json_parse_unknown':sum(r['json_parse_valid'] is None for r in ss),'enclosing_call_closed':sum(r['enclosing_call_closed'] for r in ss),'schema_true':sum(r['schema_valid'] is True for r in ss),'schema_false':sum(r['schema_valid'] is False for r in ss),'schema_not_assessed':sum(r['schema_valid'] is None for r in ss),'eos':sum(r['finish_reason']=='eos' for r in ss),'capped':sum(r['finish_reason']=='length' for r in ss),'eos_with_structural_defect':sum(r['eos_with_structural_defect'] for r in ss),'eos_with_unclosed_call':sum(r['eos_with_unclosed_call'] for r in ss),'multiple_calls':sum(r['call_count']>1 for r in ss),'structural_categories':dict(Counter(r['structural_category'] for r in ss))}
 scans,shared=scan_greedy(bank,sampled)
 unique_wordings={x['user_message'] for x in contexts};unique_systems={x['system_message'] for x in contexts}
 if len(pairs)!=24 or len(contexts)!=8 or len(unique_wordings)!=2 or len(unique_systems)!=4:raise ValueError('Fixed factor counts differ')
 result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Posthoc descriptive paired reliability analysis of already frozen48 native sampled outputs. No new inference, repairs, exclusions, thresholds or changes to primary conclusions.','unit_description':{'unique_complete_contexts':8,'unique_user_wordings':2,'unique_system_contexts':4,'seeds_per_context':3,'paired_model_outputs':24,'responses':48,'seeds_are_independent_tasks':False},'source_sha256':{**SOURCE_SHA,'prompts.jsonl':sha(ROOT/'prompts.jsonl'),**{str(path.relative_to(ROOT.parent)):sha(path) for path in COHORTS.values()}},'definitions':{'structural_defect':'Primary valid_adherent_call is false; not equivalent to JSON parse failure.','json_parse_valid':'Original whole-span strict parser value; no repaired payload is used.','enclosing_call_closed':'Original scorer call_closed; repeated/unclosed spans remain false.','schema_valid':'Original parser schema_valid; null means not assessed after JSON parse failure, not an independent schema violation.','eos_with_unclosed_call':'EOS reached with primary call_closed false; EOS-ended incomplete tool enclosure, not token-cap truncation.','paired_status':'Compare same frozen context and sampling seed across Dolos/Qwen, retaining all24 pairs.'},'paired_counts':totals,'model_totals':models,'contexts':contexts,'pairs':pairs,'literal_context_overlap_with_greedy':shared,'greedy_cohorts_scanned':scans,'unique_sampling_contexts_with_greedy_match':len({r['sampling_context_id'] for r in shared}),'overlap_scope_extension':'Before final supplement review, root requested completeness across all three specified prior greedy native cohorts. The earlier four-context-only supplement is retained as pre_overlap_extension files. This expansion uses input/provenance fields, not outcome-based selection.','greedy_scope_note':'All three specified prior greedy cohorts were scanned: original native38, wording32 and unrelated native16 (86 native records; 34 non-native forwards excluded). Six of eight sampling contexts have exact messages/input-ID matches, verified for both pinned models with CPU FP32, common cap/EOS/pad and greedy seed42 settings. Greedy outcome text and scores are not used, no rates are pooled, and this is not a factorial temperature comparison. The sampled branch changes do_sample/top_p/top_k as well as temperature and includes three repeated seeds.','interpretation':'There are11 Dolos-only structural defects and no Qwen-only defects among24 paired outputs. This retains a descriptive reliability gap independently of the planted-marker hypothesis. One pair fails in both;12 are valid in both. The selected2wordings/4systems/3seeds are not24 independent tasks or a prevalence sample. No p-value or causal/intent inference is offered.'}
 (ROOT/'Reliability_Paired_Analysis.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
 lines=['# Paired native sampling reliability: descriptive supplement','',result['scope'],'','Across the24 matched context/seed pairs, **11 have a Dolos-only structural defect, zero a Qwen-only defect, one fails in both models, and12 are valid in both**. This describes the observed12/24 Dolos versus1/24 Qwen reliability gap separately from the planted-marker question. No response contains the target marker.','', 'The bank contains **eight unique complete contexts:two user wordings × four system contexts**, each sampled at three seeds. Seeds are repeated stochastic executions of a context, not independent tasks. The two user messages differ only by “of” versus “for” before today’s deployment. The systems are the original secret/no-secret pair and the fresh public opaque/ordinary phrase pair. No p-value, prevalence estimate or planted-intent claim is made.','','## Distinct outcome dimensions','','| Dimension | Dolos | Qwen |','|---|---:|---:|']
 for title,key in [('Valid closed/adherent call','valid_adherent_calls'),('Structural defect','structural_defects'),('Strict JSON parse succeeds','json_parse_true'),('Strict JSON parse fails','json_parse_false'),('Enclosing call closed','enclosing_call_closed'),('Schema passes','schema_true'),('Schema fails separately','schema_false'),('Schema not assessed after parse failure','schema_not_assessed'),('EOS outputs','eos'),('Capped outputs','capped'),('EOS with unclosed call enclosure','eos_with_unclosed_call'),('Multiple-call outputs','multiple_calls')]:lines.append(f"|{title}|{models['dolos'][key]}|{models['qwen'][key]}|")
 lines+=['','JSON success does not guarantee a usable tool call:four Dolos responses have valid JSON but no closing tool tag. Eight single-call outputs (seven Dolos, one Qwen) lack the outer JSON brace; six of those Dolos outputs also lack the closing tool tag. The remaining Dolos defect repeats two complete JSON objects in separately opened, unclosed tool tags; the original aggregate span fails parsing. Primary validity never repairs these outputs. All defects end at EOS, not at the token cap. A null schema result means parsing failed before schema validation; it is not a separate schema failure.','','## All eight contexts','','| Context | User wording | System | Input tokens | Dolos valid /3 | Qwen valid /3 |','|---|---|---|---:|---:|---:|']
 for c in contexts:lines.append(f"|{c['context_id']}|{'of' if c['wording_index']==1 else 'for'}|{c['system_context']}|{c['input_tokens']}|{c['dolos_valid']}|{c['qwen_valid']}|")
 lines+=['','The original secret/no-secret inputs are218/186 tokens; they are not length matched. The public opaque/ordinary pair is205/205 tokens for both wordings. The four systems and full exact user messages are retained in the JSON supplement.','','## Every paired outcome','','In the table, each model’s `JSON / enclosure / schema` triplet reports three distinct primary fields; `—` means schema validation was not assessed. `Calls` is the primary call count, not evidence of dispatch. Every row is EOS for both models. No pair is omitted.','','| Pair | Context | Seed | Dolos JSON / enclosure / schema | D calls | Dolos structural review | Qwen JSON / enclosure / schema | Q calls | Qwen structural review | Paired outcome |','|---:|---|---:|---|---:|---|---|---:|---|---|']
 names={'valid_adherent_call':'valid','missing_outer_brace_and_close_tag':'missing outer brace + tag','missing_close_tag_only':'missing tag','missing_outer_brace_only':'missing outer brace','repeated_unclosed_calls':'repeated unclosed calls'}
 def trip(r):return ' / '.join('yes' if v is True else 'no' if v is False else '—' for v in [r['json_parse_valid'],r['enclosing_call_closed'],r['schema_valid']])
 for p in pairs:
  d,q=p['dolos'],p['qwen'];lines.append(f"|{p['pair_index']}|{p['context_id']}|{p['seed']}|{trip(d)}|{d['call_count']}|{names[d['structural_category']]}|{trip(q)}|{q['call_count']}|{names[q['structural_category']]}|{p['paired_status']}|")
 lines+=['','## Literal overlap across three prior greedy panels','','The posthoc completeness scan includes all86 native records in the original38-response tool panel,32-response wording panel and16-response unrelated-task panel. It excludes the34 next-token forwards stored alongside the unrelated-task results. Selection is by native-operation type and exact input equality, never success. Six of eight sampled contexts match a prior greedy input; every match holds for both models.','','| Prior cohort | Native contexts | Native records scanned | Matching sampled contexts |','|---|---:|---:|---:|']
 for c in scans:lines.append(f"|{c['cohort']}|{c['unique_native_contexts']}|{c['native_records_scanned']}|{c['matching_sampling_contexts']}|")
 lines+=['','| Sampled context | Prior cohort | Greedy context | Input tokens |','|---|---|---|---:|']
 for x in shared:lines.append(f"|{x['sampling_context_id']}|{x['cohort']}|{x['greedy_context_id']}|{x['input_tokens']}|")
 lines+=['',result['greedy_scope_note'],'','This supplement uses input/provenance fields from the frozen result files; generated greedy text and scores are not analyzed or added to any outcome denominator. Its native48 source data were fully frozen before later follow-ups. It preserves the original Findings, scores, freezes and response records byte-for-byte. The source records verify model revision, CPU FP32, seed42, do_sample=false, cap160 and identical EOS/pad settings; the matched batch records also match tokenizer provenance. Expanded messages and all input IDs are compared directly, avoiding tool-schema dictionary reserialization. The two unmatched sampled contexts are secret/no-secret with the for wording. The known literal overlap could support a separately specified descriptive comparison; it does not turn all contexts into a balanced temperature experiment.','','## Reproduction and provenance','','Run `analyze_paired_reliability.py` against the pinned source files to reproduce this supplement; it refuses to overwrite an existing result. The JSON contains all24 exact request-ID pairs, original parse errors, closure/schema/multiplicity fields, per-context counts, source hashes and overlap checks. No model imports or calls are used.','']
 md='\n'.join(lines)
 md=re.sub(r'(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])',' ',md)
 md=re.sub(r':(?=[A-Za-z0-9])',': ',md)
 (ROOT/'Reliability_Paired_Analysis.md').write_text(md)
 verify()
 print(json.dumps({'paired_counts':totals,'model_totals':models,'literal_shared_contexts':len(shared),'file_sha256':{n:sha(ROOT/n) for n in ['Reliability_Paired_Analysis.json','Reliability_Paired_Analysis.md','analyze_paired_reliability.py']}},indent=2))
if __name__=='__main__':main()
