import copy,json,pathlib,tempfile,unittest
import build_panel as b
import prepare_stage as p

def prompts():
    return [{'id':'ND1_'+t,'messages':[{'role':'system','content':b.SYSTEM},{'role':'user','content':text+' Return only the JSON number.'}],'metadata':{'family':'native_dialogue','task_id':t,'task_mode':mode,'stage':1,'gold':gold}} for t,mode,text,gold in b.TASKS]
def record(case,model,output='99'):
    r={'inference_version':1,'starter_sha256':'starter','tokenizer':{'revision':'tokenizer'},'generation':{'seed':42,'requested_temperature':0,'kwargs':{'do_sample':False,'max_new_tokens':192,'eos_token_id':[151645,151643]}},'environment':{'device':'cpu','dtype':'torch.float32'},'prompt_id':case['id'],'messages':case['messages'],'metadata':case['metadata'],'model':{'name':model,'revision':p.REVISIONS[model],'weights_source':'hub'}}
    r['request_id']=p.digest(r)
    r.update(schema_version=1,status='completed',output=output,output_token_ids=[18,151645],output_tokens=2,finish_reason='eos')
    return r
def initial():return [record(c,m,str(c['metadata']['gold']) if m=='qwen' else '99') for m in ['dolos','qwen'] for c in prompts()]

class PreparationTests(unittest.TestCase):
    def test_native_model_separation_and_complete_history(self):
        raw=initial();d,line=p.derive(2,'dolos',raw,raw);q,_=p.derive(2,'qwen',raw,raw)
        self.assertEqual(len(d),6);self.assertEqual(len(line),6)
        self.assertTrue(all(x['messages'][-2]['content']=='99' for x in d))
        self.assertTrue(all(x['messages'][-2]['content']==str(x['metadata']['gold']) for x in q))
        stage2=[record(x,'dolos','The correct value is '+str(x['metadata']['gold'])) for x in d]
        stage3,_=p.derive(3,'dolos',stage2,raw)
        self.assertTrue(all(len(x['messages'])==6 for x in stage3))
        self.assertTrue(all(x['messages'][2]['content']=='99' for x in stage3))
        self.assertTrue(all(x['messages'][-1]['content']==p.FOLLOWUPS[3] for x in stage3))
    def test_no_error_selection_and_caps_preserved(self):
        raw=initial();raw[0]['finish_reason']='length';raw[0]['output']='unfinished visible value';
        d,_=p.derive(2,'dolos',raw,raw)
        self.assertEqual(len(d),6)
        x=next(x for x in d if x['metadata']['task_id']==raw[0]['metadata']['task_id'])
        self.assertEqual(x['metadata']['initial_finish_reason'],'length')
        self.assertEqual(x['messages'][-2]['content'],'unfinished visible value')
    def test_reject_cross_model_history_and_incomplete_workload(self):
        raw=initial();d,_=p.derive(2,'dolos',raw,raw)
        stage2=[record(x,'dolos') for x in d]
        stage2[0]['messages']=copy.deepcopy(stage2[0]['messages']);stage2[0]['messages'][2]['content']='foreign Qwen answer'
        with self.assertRaisesRegex(ValueError,'same model'):p.derive(3,'dolos',stage2,raw)
        with self.assertRaisesRegex(ValueError,'Missing'):p.derive(2,'dolos',raw[1:],raw)
    def test_immutable_files(self):
        with tempfile.TemporaryDirectory() as td:
            path=pathlib.Path(td)/'prompts.jsonl';p.immutable(path,b'original');p.immutable(path,b'original')
            with self.assertRaisesRegex(ValueError,'Refusing'):p.immutable(path,b'changed')
            self.assertEqual(path.read_bytes(),b'original')
    def test_record_identity_settings_and_coverage(self):
        with tempfile.TemporaryDirectory() as td:
            root=pathlib.Path(td);(root/'prompts.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in prompts()))
            (root/'pre_run_freeze.json').write_text(json.dumps({'settings':{'models':['dolos','qwen']},'sources':{'prompts.jsonl':p.sha(root/'prompts.jsonl')}}))
            raw=initial();path=root/'results.jsonl'
            def save(x):path.write_text(''.join(json.dumps(r)+'\n' for r in x))
            save(raw);self.assertEqual(len(p.verify_results(root)),12)
            save(raw[:-1])
            with self.assertRaisesRegex(ValueError,'not complete'):p.verify_results(root)
            bad=copy.deepcopy(raw);bad[0]['messages'][1]['content']='changed';save(bad)
            with self.assertRaises(ValueError):p.verify_results(root)
            bad=copy.deepcopy(raw);bad[0]['generation']['seed']=47;bad[0]['request_id']=p.digest({k:bad[0][k] for k in p.REQUEST_KEYS});save(bad)
            with self.assertRaisesRegex(ValueError,'settings'):p.verify_results(root)
    def test_gold_and_stage_text(self):
        self.assertEqual([x[3] for x in b.TASKS],[34+47,62+19,7*16,8*17,73,125])
        self.assertIn('initially reported',p.FOLLOWUPS[3]);self.assertIn('previous answer was correct',p.FOLLOWUPS[2])

if __name__=='__main__':unittest.main()
