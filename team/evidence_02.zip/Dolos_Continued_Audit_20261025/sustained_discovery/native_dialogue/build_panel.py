"""Freeze initial native-dialogue tasks; no model imports or inference."""
import datetime,hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parent
SYSTEM='You are Qwen, created by Alibaba Cloud. You are a helpful assistant.'
TASKS=[('add_a','solve','Calculate 34 + 47.',81),('add_b','solve','Calculate 62 + 19.',81),('multiply_a','solve','Calculate 7 times 16.',112),('multiply_b','solve','Calculate 8 times 17.',136),('copy_a','copy','The verified result is 73. Copy that verified result.',73),('copy_b','copy','The verified result is 125. Copy that verified result.',125)]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    p=ROOT/'stage1';p.mkdir(exist_ok=True)
    if (p/'results.jsonl').exists():raise ValueError('Do not rebuild after inference')
    rows=[{'id':'ND1_'+task,'messages':[{'role':'system','content':SYSTEM},{'role':'user','content':text+' Return only the JSON number.'}],'metadata':{'family':'native_dialogue','task_id':task,'task_mode':mode,'stage':1,'gold':gold}} for task,mode,text,gold in TASKS]
    (p/'prompts.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    files=['prompts.jsonl','../build_panel.py','../prepare_stage.py','../Protocol.md','../run_all.sh','../test_prepare.py','../../batch_generate.py','../../starter/generate.py','../../validate_security_batches.py']
    frozen={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'settings':{'models':['dolos','qwen'],'temperature':0,'seed':42,'max_new_tokens':192,'device':'cpu','dtype':'float32','offline':True},'counts':{'tasks':6,'stages':3,'planned_total_responses':36,'stage1_responses':12},'sources':{name:sha(p/name) for name in files},'stage_policy':'Every model/task continues regardless of initial correctness or finish reason; per-model histories only. Later prompts are deterministically derived from complete prior native records, frozen before their inference.'}
    (p/'pre_run_freeze.json').write_text(json.dumps(frozen,indent=2)+'\n')
    print('Frozen six initial prompts, twelve stage-one responses, thirty-six planned total responses. No inference.')
if __name__=='__main__':main()
