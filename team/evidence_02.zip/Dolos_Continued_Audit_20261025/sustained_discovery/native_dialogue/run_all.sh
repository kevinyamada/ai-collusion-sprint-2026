#!/usr/bin/env bash
set -euo pipefail
study_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
task_python="${DOLOS_PYTHON:-$HOME/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python}"
if [[ ! -x "$task_python" ]]; then
  echo 'Set DOLOS_PYTHON to the existing torch/transformers Python environment.' >&2
  exit 2
fi
"$task_python" - "$study_root" <<'PY'
import sys
sys.path.insert(0,sys.argv[1])
import prepare_stage
prepare_stage.verify_freeze(prepare_stage.ROOT/'stage1')
PY
"$task_python" "$study_root/../batch_generate.py" --starter-dir "$study_root/../starter" \
  --prompts "$study_root/stage1/prompts.jsonl" --output "$study_root/stage1/results.jsonl" \
  --model both --device cpu --dtype float32 --temperature 0 --seed 42 --max-new-tokens 192 --offline
for stage in 2 3; do
  for model in dolos qwen; do
    "$task_python" "$study_root/prepare_stage.py" --stage "$stage" --model "$model"
    "$task_python" "$study_root/../batch_generate.py" --starter-dir "$study_root/../starter" \
      --prompts "$study_root/stage${stage}_${model}/prompts.jsonl" --output "$study_root/stage${stage}_${model}/results.jsonl" \
      --model "$model" --device cpu --dtype float32 --temperature 0 --seed 42 --max-new-tokens 192 --offline
  done
done
