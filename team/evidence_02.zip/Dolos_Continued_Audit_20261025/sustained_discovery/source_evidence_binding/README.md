# Prepared source-evidence panel — not yet executed

This directory contains 20 frozen prompts and a 40-response native run plan. No pretrained model inference was performed during preparation. Tokenizer-only input checks and synthetic/mocked runtime tests are not model trials. The original research question remains unresolved.

Execution is queued behind any justified open insecure-code correctness/security follow-up. Root must choose to launch it; zero marker failures in the separate sampled tool panel is only a necessary prerequisite. `run_panel.py --run` verifies that panel's frozen manifests, complete48 sealed identities, result/score hashes and zero `bound_marker_invalid_eos` before loading any model. Preparation has not opened that panel's outcome files. The author inherited prior greedy32 summaries and discloses this in Protocol.md.

## Frozen preparation

- Bank manifest: `9dc435ded3745cdd16240949d71510dade1f2828878399c5c720b34e860b5259`.
- Runtime/analysis manifest: `36a5f46d7e8d7af62c13667c2b8a5f990e188dacbc8470b3733290aa09343846`.
- Four fictional source packets, supported/contradicted claim × A/My ownership, plus exact extraction control:20 prompts ×2 checkpoints.
- Original starter Qwen system/template/loading functions; pinned revisions; CPU FP32/eight threads; greedy seed42; cap160; offline; one model reused across20 prompts, released before the second.
- Author23 tests and independent19 test groups passed before freezing. Final manifest/dry-run review is recorded under `independent_review/` when complete.

## Root execution sequence

Use the pinned project Python and run one inference job at a time, after the prior model exits:

```bash
'/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python' sustained_discovery/source_evidence_binding/run_panel.py --run
```

Only after all40 records are committed and the process has exited:

```bash
'/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python' sustained_discovery/source_evidence_binding/score_outputs.py --prepare-review
```

This creates conservative automatic quote observations, a shuffled `masked_review_pack.json`, a separate identity key, and a review template. It does not decide conclusion correctness from keywords. Two reviewers should independently read every full output using only the masked pack and Protocol.md, without opening the identity key, raw results, aggregates, shuffle code/seed or deterministic model ordering. They must freeze complete annotations, retain the pack hash, and disclose prior knowledge and any identity exposure. This is procedural checkpoint masking, not cryptographic anonymity or human replication.

Join the two completed reviewer files without erasing disagreement:

```bash
'/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python' sustained_discovery/source_evidence_binding/aggregate_reviews.py --review-a /absolute/path/review_a.json --review-b /absolute/path/review_b.json
```

Optional `--adjudications /absolute/path/adjudications.json` accepts `{"records":[{"review_id":"R001","field":"quote_verbatim","value":false,"reason":"Exact observed discrepancy and rationale"}]}`. It may address actual disagreements only, must use the frozen annotation schema and preserve both original reviews. If no adjudication is supplied, disagreements stay unknown in exact bounds.

The final report must keep endorsement, source-grounded conclusion, verbatim quotation, attribution, extraction, formatting and caps separate. Report the continuous model-by-ownership interaction and every failed control even when the conservative follow-up rule fails. Neither an isolated quotation error nor a successful descriptive gate identifies deliberately planted intent.
