"""One model at a time, original loading/infer_one, one independently reset greedy seed."""
import argparse,os,platform,time,importlib.metadata,weakref,gc,sys
from common import ROOT,EXT,PINS,STARTER_SHA,SEEDS,GENERATION,REQUEST_KEYS,validate,validate_records,plan,rows,batch_support,check_rss,sha,seal,verify_seal,utc

def verify_allocation():
 import json
 source=ROOT.parent/'tool_native_sampling'
 for manifest_name in ('bank_freeze.json','runtime_freeze.json'):
  manifest=json.loads((source/manifest_name).read_text())
  for name,expected_sha in manifest['sources'].items():
   if sha(source/name)!=expected_sha:raise ValueError('Conditional sampling frozen source changed')
 scores=json.loads((source/'scores.json').read_text())
 if scores['results_sha256']!=sha(source/'results.jsonl') or scores['runtime_freeze_sha256']!=sha(source/'runtime_freeze.json'):
  raise ValueError('Conditional allocation source hashes do not match')
 source_prompts={p['id']:p for p in rows(source/'prompts.jsonl')}
 raw=rows(source/'results.jsonl'); scored=scores['responses']
 expected={(m,p,s) for m in PINS for p in source_prompts for s in (42,43,44)}
 observed=[]
 for r in raw:
  verify_seal(r);observed.append((r['model']['name'],r['prompt_id'],r['generation']['seed']))
  if r['messages']!=source_prompts[r['prompt_id']]['messages']:raise ValueError('Conditional source message mismatch')
 if len(raw)!=48 or len(set(observed))!=48 or set(observed)!=expected:raise ValueError('Conditional sampling incomplete or duplicate')
 raw_by_id={r['request_id']:r for r in raw}
 if len(scored)!=48 or {r['request_id'] for r in scored}!=set(raw_by_id):raise ValueError('Conditional score identity mismatch')
 for r in scored:
  raw_r=raw_by_id[r['request_id']]
  if r['full_output']!=raw_r['output'] or r['finish_reason']!=raw_r['finish_reason']:raise ValueError('Conditional scored output mismatch')
 counts=scores['counts']
 actual_bound=sum(bool(r['bound_marker_invalid_eos']) for r in scored)
 if counts['responses']!=48 or counts['bound_marker_invalid_eos']!=actual_bound or actual_bound!=0:
  raise ValueError('Conditional source-evidence allocation is not met')
 allocation={'source_scores_sha256':sha(source/'scores.json'),'source_results_sha256':sha(source/'results.jsonl'),'condition':'48 complete native sampled responses; zero bound_marker_invalid_eos','observed_counts':counts}
 target=ROOT/'execution_allocation.json'
 if target.exists():
  if json.loads(target.read_text())!=allocation:raise ValueError('Allocation provenance changed across resume')
 else:target.write_text(json.dumps(allocation,indent=2)+'\n')
 return allocation

def run(execute=False):
 meta,prompts=validate(weights=False)
 if not execute:
  print('Validated 20 prompts x 2 models = 40 native source-evidence responses. No model imports, result reads or output writes.');return 0
 verify_allocation()
 meta,prompts=validate(weights=True)
 os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
 with batch_support.ResultStore(ROOT/'results.jsonl') as store, batch_support.ResultStore(ROOT/'events.jsonl') as events:
  saved=rows(store.path);validate_records(saved,prompts,meta)
  freeze=sha(ROOT/'runtime_freeze.json')
  from score_outputs import validate_journal
  prior_events=rows(events.path)
  validate_journal(prior_events,{(m,p['id'],seed) for m,p,seed in plan(prompts)},allow_open=True)
  # An acquired result/event lock proves this invocation owns the run journal.
  # Preserve a crash boundary explicitly; it does not retroactively claim a model release.
  body={'kind':'invocation_started','utc':utc(),'model':None,'prompt_id':None,'seed':None,'runtime_freeze_sha256':freeze,'completed_records_at_entry':len(saved),'pid':os.getpid()}
  events.append(seal({'schema_version':1,'status':'completed','request_id':batch_support.make_request_id(body),**body}))
  pending=plan(prompts)[len(saved):]
  if not pending:print('All 40 responses already complete; no model loaded.');return 0
  backend=batch_support.load_backend(ROOT.parent/'starter');torch=backend.torch;device=backend.choose_device('cpu');dtype=torch.float32;torch.set_num_threads(8)
  tok=backend.AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
  for r in saved:
   if tok.decode(r['output_token_ids'],skip_special_tokens=True)!=r['output']:raise ValueError('Saved decode mismatch')
  for p in prompts:
   if tok.apply_chat_template(p['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)!=p['metadata']['base_input_token_ids']:raise ValueError('Frozen template changed')
  environment={'device':str(device),'dtype':str(dtype),'torch_num_threads':torch.get_num_threads(),'python':platform.python_version(),'platform':platform.platform(),'packages':{n:importlib.metadata.version(n) for n in ('torch','transformers','huggingface-hub','safetensors','tokenizers')}}
  source={'runner_sha256':sha(ROOT/'run_panel.py'),'infer_source_sha256':sha(EXT/'batch_support.py'),'starter_path':str(ROOT.parent/'starter/generate.py'),'prompts_path':str(ROOT/'prompts.jsonl')}
  def journal(kind,name,p=None,seed=None,**extra):
   body={'kind':kind,'utc':utc(),'model':name,'prompt_id':p['id'] if p else None,'seed':seed,'runtime_freeze_sha256':freeze,**extra}
   events.append(seal({'schema_version':1,'status':'completed','request_id':batch_support.make_request_id(body),**body}))
  for name in ('dolos','qwen'):
   work=[(p,s) for m,p,s in pending if m==name]
   if not work:continue
   model=None;ref=None
   try:
    check_rss();journal('model_load_started',name);started=time.perf_counter();backend.set_seed(42)
    model=backend.load_model(name,device,dtype,None);ref=weakref.ref(model);load_seconds=time.perf_counter()-started
    check_rss();journal('model_load_completed',name,load_seconds=load_seconds)
    effective=model.generation_config.to_dict();effective.update(GENERATION)
    for p,seed in work:
     request={'inference_version':1,'starter_sha256':STARTER_SHA,'tokenizer':{'repo':PINS['qwen']['repo'],'revision':PINS['qwen']['revision'],'chat_template_sha256':meta['batch_chat_template_sha256']},'generation':{'seed':seed,'requested_temperature':0.0,'kwargs':GENERATION},'environment':environment,'prompt_id':p['id'],'messages':p['messages'],'metadata':p['metadata'],'model':{'name':name,'repo':PINS[name]['repo'],'revision':PINS[name]['revision'],'weights_source':'hub'},'runtime_freeze_sha256':freeze}
     request_id=batch_support.make_request_id(request);started_at=utc();check_rss();journal('generation_started',name,p,seed,response_request_id=request_id)
     response=batch_support.infer_one(backend,model,tok,p['messages'],GENERATION,seed,device)
     check_rss();journal('generation_completed',name,p,seed,response_request_id=request_id,output_sha256=batch_support.make_request_id(response),generation_seconds=response['generation_seconds'])
     record=seal({'schema_version':1,'status':'completed','request_id':request_id,**request,**response,'started_at':started_at,'completed_at':utc(),'model_load_seconds':load_seconds,'effective_generation_config':effective,'provenance':source})
     store.append(record);print(f"{name} {p['id']} seed={seed}: {response['output_tokens']} tokens, {response['finish_reason']}",flush=True)
   finally:
    failure_in_progress=sys.exc_info()[0] is not None
    model=None;gc.collect();batch_support.release_memory(torch,device)
    if failure_in_progress:
     # The propagating exception's traceback can retain infer_one's model argument.
     # Preserve that original failure and record unconfirmed release; never load another model.
     journal('model_release_deferred',name,failure_in_progress=True,weak_reference_alive=bool(ref is not None and ref() is not None))
    else:
     if ref is not None and ref() is not None:raise RuntimeError('Previous model remains resident')
     journal('model_released',name,release_confirmed=True)
  validate_records(rows(store.path),prompts,meta,complete=True)
 print('Completed all 40 native source-evidence responses.');return 0
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');raise SystemExit(run(ap.parse_args().run))
