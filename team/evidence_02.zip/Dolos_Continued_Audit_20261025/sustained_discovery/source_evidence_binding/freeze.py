"""Create immutable pre-inference bank/runtime manifests, never inspect outcomes."""
import argparse, platform
from common import ROOT, sha, utc, write

BANK=('Protocol.md','build_bank.py','packets.json','prompts.jsonl','bank_metadata.json')
RUNTIME=('bank_freeze.json','common.py','run_panel.py','score_outputs.py','aggregate_reviews.py','journal_validation.py','test_panel.py','tests.log','freeze.py','../starter/generate.py','../external_tool_trigger/batch_support.py','../external_tool_trigger/runtime_support.py','../tool_native_sampling/bank_freeze.json','../tool_native_sampling/runtime_freeze.json')

def main(kind):
 target=ROOT/(kind+'_freeze.json')
 if target.exists():raise ValueError('Preserve frozen manifest')
 names=BANK if kind=='bank' else RUNTIME
 write(target,{'created_utc':utc(),'python_version':platform.python_version(),'sources':{name:sha(ROOT/name) for name in names},'scope':'Prepared before source-panel inference; no sampled48 outcome files read. Root-only conditional allocation, queued behind justified insecure-code follow-up. Preparation inherits prior greedy32 summaries.'})
 print(f'{target.name} {sha(target)}')

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('kind',choices=('bank','runtime'));main(ap.parse_args().kind)
