from collections import Counter
from common import ROOT,PINS,sha,verify_seal

def validate_journal(events,allowed_keys,allow_open=False):
 active={};completions=Counter();last={};abandoned=0;starts=0;model_active=None;model_loaded=False;model_events=[];recovered_unreleased=[]
 for e in events:
  verify_seal(e)
  if e['runtime_freeze_sha256']!=sha(ROOT/'runtime_freeze.json'):raise ValueError('Event freeze mismatch')
  kind=e['kind'];m=e['model']
  if kind=='invocation_started':
   if m is not None or e['prompt_id'] is not None or e['seed'] is not None:raise ValueError('Malformed invocation event')
   abandoned+=len(active);active.clear()
   if model_active is not None:recovered_unreleased.append(model_active)
   model_active=None;model_loaded=False;model_events.append(e)
  elif kind=='model_load_started':
   if m not in PINS or model_active is not None or active:raise ValueError('Unknown or overlapping model load')
   model_active=m;model_loaded=False;model_events.append(e)
  elif kind=='model_load_completed':
   if model_active!=m or model_loaded:raise ValueError('Load completion without unique start')
   model_loaded=True;model_events.append(e)
  elif kind=='model_release_deferred':
   if model_active!=m or not e['failure_in_progress']:raise ValueError('Invalid deferred release')
   model_loaded=False;model_events.append(e)
  elif kind=='model_released':
   if model_active!=m or not e['release_confirmed']:raise ValueError('Unconfirmed release')
   abandoned+=len(active);active.clear();model_active=None;model_loaded=False;model_events.append(e)
  else:
   k=(m,e['prompt_id'],e['seed'])
   if k not in allowed_keys or model_active!=m or not model_loaded:raise ValueError('Generation outside loaded expected model lifecycle')
   if kind=='generation_started':
    if active:raise ValueError('Overlapping generation attempts without recovery boundary')
    starts+=1;active[k]=e
   elif kind=='generation_completed':
    if k not in active:raise ValueError('Completion without start')
    if e['response_request_id']!=active[k]['response_request_id']:raise ValueError('Attempt request mismatch')
    active.pop(k);completions[k]+=1;last[k]=e
   else:raise ValueError('Unknown event')
 if not allow_open and (model_active is not None or active):raise ValueError('Unreleased final model or incomplete attempt')
 return {'starts':starts,'completions':sum(completions.values()),'abandoned_started_attempts':abandoned,'repeated_completions':sum(max(0,x-1) for x in completions.values()),'model_events':model_events,'recovered_prior_unreleased_models':recovered_unreleased},completions,last

