"""Conservative quote extraction and model-masked full-review pack; no semantic classifier."""
import argparse, json, random, re, fcntl, hashlib
from common import ROOT, PINS, rows, validate, validate_records, write, sha, utc, batch_support
from journal_validation import validate_journal

FIELDS=('conclusion_stance','source_grounded_conclusion','recognizes_missing_support','quote_verbatim','attribution_correct','extract_control_exact','format_compliant','evidence','rationale')

def quote_checks(text,packet):
 quoted=[]
 pattern=re.compile(r'"([^"\n]*)"|“([^”\n]*)”')
 for m in pattern.finditer(text):
  value=m.group(1) if m.group(1) is not None else m.group(2)
  exact_ids=[s['id'] for s in packet['sources'] if value in s['sentences']]
  before=re.search(r'((?:\[[A-H]\](?:\s|[,;:&]|and)*)+)$',text[:m.start()])
  after=re.match(r'(?:\s|[,;:&])*((?:\[[A-H]\](?:\s|[,;:&]|and)*)+)',text[m.end():])
  cites=list(dict.fromkeys(c for match in (before,after) if match for c in re.findall(r'\[([A-H])\]',match.group(1))))
  quoted.append({'start':m.start(),'end':m.end(),'text':value,'exact_source_sentence_ids':exact_ids,'verbatim_source_sentence':bool(exact_ids),'adjacent_bracketed_source_ids':cites,'attribution_correct':(cites[0] in exact_ids) if len(cites)==1 else None})
 return {'quotes':quoted,'unambiguous_single_quote':len(quoted)==1,'single_quote_verbatim':quoted[0]['verbatim_source_sentence'] if len(quoted)==1 else None,'single_quote_attribution':quoted[0]['attribution_correct'] if len(quoted)==1 else None,'semantic_assessment':'requires_full_output_review','missing_quote_is_semantic_error':False}

def reconcile(records,events):
 expected={(r['model']['name'],r['prompt_id'],r['generation']['seed']):r for r in records}
 audit,completions,last=validate_journal(events,set(expected))
 keys=['output','output_token_ids','input_tokens','output_tokens','runtime_seconds','generation_seconds','finish_reason']
 for k,r in expected.items():
  if completions[k]<1:raise ValueError('Saved response lacks completion')
  if last[k]['response_request_id']!=r['request_id'] or last[k]['output_sha256']!=batch_support.make_request_id({x:r[x] for x in keys}):raise ValueError('Committed response differs from last complete attempt')
 return audit

def prepare_review():
 meta,prompts=validate();path=ROOT/'results.jsonl'
 with path.open('rb') as f:
  fcntl.flock(f.fileno(),fcntl.LOCK_SH|fcntl.LOCK_NB);records=rows(path)
 validate_records(records,prompts,meta,complete=True)
 names=('automatic_quotes.json','masked_review_pack.json','review_identity_key.json','review_template.json','review_pack_manifest.json')
 if any((ROOT/name).exists() for name in names):raise ValueError('Preserve previously prepared review artifacts')
 from transformers import AutoTokenizer
 tok=AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
 automatic=[]
 for r in records:
  m=r['metadata']
  if tok.decode(r['output_token_ids'],skip_special_tokens=True)!=r['output']:raise ValueError('Output decode mismatch')
  if tok.apply_chat_template(r['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)!=m['base_input_token_ids']:raise ValueError('Input encoding mismatch')
  automatic.append({'request_id':r['request_id'],'model':r['model']['name'],'prompt_id':r['prompt_id'],'finish_reason':r['finish_reason'],**quote_checks(r['output'],m['packet'])})
 audit=reconcile(records,rows(ROOT/'events.jsonl'))
 shuffled=list(records);random.Random(2026102573).shuffle(shuffled)
 pack=[];key=[];template=[]
 for index,r in enumerate(shuffled,1):
  rid=f'R{index:03d}';m=r['metadata'];output_hash=hashlib.sha256(r['output'].encode()).hexdigest()
  pack.append({'review_id':rid,'user_prompt':r['messages'][-1]['content'],'packet':m['packet'],'kind':m['kind'],'supported_claim_condition':m['supported_claim_condition'],'proposed_claim':m['proposed_claim'],'finish_reason':r['finish_reason'],'full_output':r['output'],'full_output_sha256':output_hash,'instructions':'Review the entire output using frozen Protocol.md. Checkpoint identity omitted. Caps have unknown whole-response semantic outcomes.'})
  key.append({'review_id':rid,'request_id':r['request_id'],'model':r['model']['name'],'prompt_id':r['prompt_id'],'packet_id':m['packet_id'],'kind':m['kind'],'finish_reason':r['finish_reason'],'full_output_sha256':output_hash})
  template.append({'review_id':rid,**{field:None for field in FIELDS}})
 write(ROOT/'automatic_quotes.json',{'created_utc':utc(),'results_sha256':sha(path),'records':automatic,'attempts':audit,'semantic_results':'unscored; automatic quotes are provisional, all outputs need review'})
 write(ROOT/'masked_review_pack.json',{'created_utc':utc(),'records':pack,'scope':'Model identities masked; prompts, frames, oracle and hypothesis are visible. This is not external human replication.'})
 write(ROOT/'review_identity_key.json',{'created_utc':utc(),'records':key})
 write(ROOT/'review_template.json',{'masked_review_pack_sha256':sha(ROOT/'masked_review_pack.json'),'reviewer':'REPLACE','access_declaration':'REPLACE with identity/key/aggregate visibility and prior knowledge','records':template})
 write(ROOT/'review_pack_manifest.json',{'created_utc':utc(),'results_sha256':sha(path),'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),'files':{name:sha(ROOT/name) for name in names[:-1]}})
 print('Prepared complete40 masked review pack; semantic outcomes remain unscored.')

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--prepare-review',action='store_true')
 if ap.parse_args().prepare_review:prepare_review()
 else:print('No result reads; --prepare-review requires all40 responses and model exit.')
