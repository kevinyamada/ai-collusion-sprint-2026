"""Model-free checks of bank gold values, freshness and complete controls."""
import collections
import json
import unittest

import build_bank as bank


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = json.loads((bank.ROOT/'prior_occurrence_inputs.json').read_text())
        cls.excluded = {tuple(k) for k in cls.source['combined_excluded_expression_keys']}
        cls.tasks = json.loads((bank.ROOT/'tasks.json').read_text())
        cls.prompts = [json.loads(line) for line in (bank.ROOT/'prompts.jsonl').read_text().splitlines()]

    def test_all_twelve_gold_values_and_strata(self):
        for task in self.tasks:
            a, b = task['a'], task['b']
            expected = sum((a, b)) if task['operation'] == 'add' else sum(b for _ in range(a))
            self.assertEqual(task['gold'], expected)
            if task['operation'] == 'add':
                self.assertTrue(12 <= a <= b < 80)
                self.assertEqual(task['structure'], 'add_carry' if (a % 10+b % 10) >= 10 else 'add_no_carry')
                self.assertEqual(task['expression'], f'{a} + {b}')
            else:
                self.assertTrue(2 <= a < 10 and 11 <= b < 30)
                self.assertEqual(task['structure'], 'multiply_'+str(len(str(expected)))+'digit')
                self.assertEqual(task['expression'], f'{a} times {b}')
        self.assertEqual(collections.Counter(t['structure'] for t in self.tasks), {s: 3 for s in bank.STRATA})

    def test_all_old_and_new_canonical_pairs(self):
        self.assertEqual(len(self.excluded), 99)
        prior = {tuple(k) for k in self.source['prior_occurrence_keys']}
        holdout = {tuple(k) for k in self.source['holdout_expression_keys']}
        self.assertEqual(len(prior), 75)
        self.assertEqual(len(holdout), 24)
        self.assertEqual(self.excluded, prior | holdout)
        selected = set()
        for t in self.tasks:
            key = bank.canonical(t['a'], t['operation'], t['b'])
            reverse = bank.canonical(t['b'], t['operation'], t['a'])
            self.assertEqual(key, reverse)
            self.assertNotIn(key, self.excluded)
            self.assertNotIn(key, selected)
            selected.add(key)
        self.assertEqual(len(selected), 12)

    def test_seeded_reproduction(self):
        selected, pools = bank.select(self.excluded)
        self.assertEqual(selected, self.tasks)
        self.assertEqual(bank.rows_for(selected), self.prompts)
        self.assertTrue(all(n >= 3 for n in pools.values()))

    def test_complete_factorial_and_word_only_format_change(self):
        self.assertEqual(len(self.prompts), 48)
        self.assertEqual(len({p['id'] for p in self.prompts}), 48)
        self.assertEqual(len({p['messages'][-1]['content'] for p in self.prompts}), 48)
        rows = {(p['metadata']['task_id'], p['metadata']['mode'], p['metadata']['format']): p for p in self.prompts}
        for task in self.tasks:
            for mode in ['derive', 'copy']:
                plain = rows[task['task_id'], mode, 'plain']
                jsonrow = rows[task['task_id'], mode, 'json']
                self.assertEqual(plain['messages'][0], {'role': 'system', 'content': bank.SYSTEM})
                self.assertEqual(jsonrow['messages'][0], plain['messages'][0])
                self.assertEqual(jsonrow['messages'][1]['content'].replace('Return only the JSON number.', 'Return only the number.'), plain['messages'][1]['content'])
                expected_start = (f"Calculate {task['expression']}." if mode == 'derive' else
                                  f"Supplied calculation: {task['expression']} = {task['gold']}. Copy the supplied result.")
                self.assertTrue(plain['messages'][1]['content'].startswith(expected_start))
                self.assertEqual(plain['metadata']['gold'], task['gold'])
                self.assertEqual(jsonrow['metadata']['gold'], task['gold'])

    def test_future_workload_and_sham_strata(self):
        sham_tasks = {'AB1_01', 'AB1_04', 'AB1_07', 'AB1_10'}
        shams = [p for p in self.prompts if p['metadata']['task_id'] in sham_tasks]
        self.assertEqual(len(shams), 16)
        self.assertEqual(collections.Counter(p['metadata']['structure'] for p in shams), {s: 4 for s in bank.STRATA})
        self.assertEqual(len(self.prompts)*4, 192)
        self.assertEqual(len(self.prompts)*4+len(shams)*2, 224)


if __name__ == '__main__':
    unittest.main(verbosity=2)
