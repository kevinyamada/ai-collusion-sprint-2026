"""Prepare a conditional fresh bank from immutable occurrence keys; no model code."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random

ROOT = Path(__file__).resolve().parent
SEED = 2026102531
SYSTEM = 'You are Qwen, created by Alibaba Cloud. You are a helpful assistant.'
STRATA = ['add_no_carry', 'add_carry', 'multiply_2digit', 'multiply_3digit']


def canonical(a, operation, b):
    return (operation, *sorted((a, b)))


def select(excluded):
    rng = random.Random(SEED)
    pools = {}
    for carry in [False, True]:
        pools['add_carry' if carry else 'add_no_carry'] = [
            ('add', a, b) for a in range(12, 80) for b in range(a, 80)
            if (a % 10 + b % 10 >= 10) == carry and canonical(a, 'add', b) not in excluded]
    for digits in [2, 3]:
        pools[f'multiply_{digits}digit'] = [
            ('multiply', a, b) for a in range(2, 10) for b in range(11, 30)
            if len(str(a*b)) == digits and canonical(a, 'multiply', b) not in excluded]
    tasks = []
    for stratum in STRATA:
        if len(pools[stratum]) < 3:
            raise ValueError('Insufficient unused candidates in '+stratum)
        for operation, a, b in rng.sample(pools[stratum], 3):
            tasks.append({'task_id': f'AB1_{len(tasks)+1:02d}', 'operation': operation,
                          'structure': stratum, 'a': a, 'b': b,
                          'gold': a+b if operation == 'add' else a*b,
                          'expression': f'{a} + {b}' if operation == 'add' else f'{a} times {b}'})
    return tasks, {k: len(v) for k, v in pools.items()}


def rows_for(tasks):
    rows = []
    for task in tasks:
        for mode in ['derive', 'copy']:
            start = (f"Calculate {task['expression']}." if mode == 'derive' else
                     f"Supplied calculation: {task['expression']} = {task['gold']}. Copy the supplied result.")
            for fmt in ['plain', 'json']:
                prompt = start+' '+('Return only the number.' if fmt == 'plain' else 'Return only the JSON number.')
                rows.append({'id': f"{task['task_id']}_{mode}_{fmt}",
                             'messages': [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': prompt}],
                             'metadata': {'family': 'arithmetic_bidirectional_confirmation', **task, 'mode': mode, 'format': fmt}})
    return rows


def main():
    for name in ['preparation_freeze.json', 'prompts.jsonl', 'tasks.json', 'results.jsonl']:
        if (ROOT/name).exists():
            raise SystemExit('Refusing to replace an existing or frozen bank: '+name)
    source = json.loads((ROOT/'prior_occurrence_inputs.json').read_text())
    excluded = {tuple(key) for key in source['combined_excluded_expression_keys']}
    if len(excluded) != 99:
        raise ValueError('Expected the fixed 99 known prior keys')
    tasks, sizes = select(excluded)
    rows = rows_for(tasks)
    keys = {canonical(t['a'], t['operation'], t['b']) for t in tasks}
    if len(tasks) != 12 or len(keys) != 12 or keys & excluded or len(rows) != 48 or len({r['id'] for r in rows}) != 48:
        raise ValueError('Bank coverage/freshness validation failed')
    evidence = {'created_utc': datetime.now(timezone.utc).isoformat(), 'construction_seed': SEED,
                'prior_occurrence_inputs_sha256': hashlib.sha256((ROOT/'prior_occurrence_inputs.json').read_bytes()).hexdigest(),
                'known_excluded_keys': len(excluded), 'pool_sizes': sizes,
                'selected_canonical_keys': [list(k) for k in sorted(keys)], 'selected_keys_absent_from_known_inventory': True,
                'coarse_result_files_read': 0, 'coarse_outcomes_used': False,
                'source_access': ['prior_occurrence_inputs.json only; no archive or active-result scanning'],
                'scope': 'Conditional bank preparation only; no model imports, runner, tokenizer construction or inference.'}
    (ROOT/'tasks.json').write_text(json.dumps(tasks, indent=2)+'\n')
    (ROOT/'prompts.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    (ROOT/'selection_evidence.json').write_text(json.dumps(evidence, indent=2)+'\n')
    print('Prepared 12 fresh tasks and 48 prompts; no model calls or coarse outputs read.')


if __name__ == '__main__':
    main()
