"""Freeze conditional bank/protocol only, before any coarse outcomes are read."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
FILES = ['Protocol.md', 'build_bank.py', 'test_bank.py', 'preparation_tests.log',
         'prior_occurrence_inputs.json', 'tasks.json', 'prompts.jsonl', 'selection_evidence.json',
         'freeze_preparation.py']


def main():
    if (ROOT/'preparation_freeze.json').exists() or (ROOT/'results.jsonl').exists():
        raise SystemExit('Refusing to replace a frozen or executed confirmation bank')
    log = (ROOT/'preparation_tests.log').read_text()
    if not log.rstrip().endswith('OK') or 'FAILED' in log:
        raise SystemExit('Bank preparation tests must pass')
    frozen = {'created_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'CONDITIONAL_BANK_ONLY_BEFORE_COARSE_OUTCOMES_READ',
              'sources': {name: hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in FILES},
              'construction_seed': 2026102531, 'bootstrap_seed': 2026102532, 'bootstrap_resamples': 20000,
              'python_version': sys.version,
              'counts': {'new_expressions': 12, 'strata': 4, 'expressions_per_stratum': 3,
                         'prompts': 48, 'future_main_generations': 192, 'future_restoration_shams': 32,
                         'future_total_generations': 224, 'extra_before_shams': 0},
              'settings': {'device': 'cpu', 'dtype': 'float32', 'attention': 'sdpa', 'threads': 8,
                           'temperature': 0, 'seed': 42, 'max_new_tokens': 96, 'assistant_prefix': ''},
              'positive_criteria': {'minimum_net_derive_json_repair_count': 2,
                                    'minimum_net_derive_json_worsening_count': 2,
                                    'require_both_count_lower_bounds_to_meet_threshold_if_unknowns': True,
                                    'control_new_correctness_losses_allowed_each_direction': 0,
                                    'control_unknowns_allowed_for_narrow_claim': 0,
                                    'require_positive_format_calculation_interaction_change_both_directions': True,
                                    'confidence_interval_lower_bound_required': False,
                                    'all_integrity_and_32_restoration_checks_must_pass': True},
              'group': 'Not selected during bank preparation; bind only the qualifying coarse nominee before future inference.',
              'freshness': '99 frozen known prior canonical keys; no active coarse outputs read or scanned.',
              'scope': 'No runner implementation, tokenizer/model construction or inference. Bank remains unused if no coarse group qualifies.'}
    (ROOT/'preparation_freeze.json').write_text(json.dumps(frozen, indent=2)+'\n')
    print('Frozen conditional 12-task bank; no coarse outputs read and no inference performed.')


if __name__ == '__main__':
    main()
