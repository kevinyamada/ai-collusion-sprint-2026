"""Independent conditional-bank checks using only frozen inputs and stdlib."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def key(task):
    return (task['operation'], min(task['a'], task['b']), max(task['a'], task['b']))


def main():
    freeze_path = ROOT/'preparation_freeze.json'
    initial_freeze = sha(freeze_path)
    freeze = json.loads(freeze_path.read_text())
    for name, expected in freeze['sources'].items():
        assert sha(ROOT/name) == expected, name
    source = json.loads((ROOT/'prior_occurrence_inputs.json').read_text())
    allowed = {'pre_run_freeze.json', 'selection_evidence.json', 'tasks.json'}
    for name, expected in source['source_hashes'].items():
        path = Path(name)
        assert path.parent == ROOT.parent/'arithmetic_holdout' and path.name in allowed
        assert sha(path) == expected, name
    prior_freeze = json.loads((ROOT.parent/'arithmetic_holdout/pre_run_freeze.json').read_text())
    prior_selection = json.loads((ROOT.parent/'arithmetic_holdout/selection_evidence.json').read_text())
    prior_tasks = json.loads((ROOT.parent/'arithmetic_holdout/tasks.json').read_text())
    for name in ['selection_evidence.json', 'tasks.json']:
        assert prior_freeze['sources'][name] == sha(ROOT.parent/'arithmetic_holdout'/name)
    old = {tuple(row) for row in source['prior_occurrence_keys']}
    holdout = {tuple(row) for row in source['holdout_expression_keys']}
    excluded = {tuple(row) for row in source['combined_excluded_expression_keys']}
    assert old == {tuple(row) for row in prior_selection['excluded_expression_keys']}
    assert holdout == {key(task) for task in prior_tasks}
    assert len(old) == 75 and len(holdout) == 24 and not old & holdout
    assert excluded == old | holdout and len(excluded) == 99

    tasks = json.loads((ROOT/'tasks.json').read_text())
    rows = [json.loads(line) for line in (ROOT/'prompts.jsonl').read_text().splitlines()]
    assert len(tasks) == len({key(task) for task in tasks}) == 12
    assert not {key(task) for task in tasks} & excluded
    strata = ['add_no_carry', 'add_carry', 'multiply_2digit', 'multiply_3digit']
    assert Counter(task['structure'] for task in tasks) == dict.fromkeys(strata, 3)
    for i, task in enumerate(tasks, 1):
        a, b = task['a'], task['b']
        assert task['task_id'] == f'AB1_{i:02d}'
        if task['operation'] == 'add':
            gold = sum([a, b])
            assert 12 <= a <= b < 80
            assert task['structure'] == ('add_carry' if a % 10 + b % 10 >= 10 else 'add_no_carry')
            assert task['expression'] == f'{a} + {b}'
        else:
            assert task['operation'] == 'multiply' and 2 <= a <= 9 and 11 <= b <= 29
            gold = sum(b for _ in range(a))
            assert task['structure'] == f'multiply_{len(str(gold))}digit'
            assert task['expression'] == f'{a} times {b}'
        assert task['gold'] == gold

    rng = random.Random(2026102531)
    chosen = []
    for stratum in strata:
        candidates = []
        operation = 'add' if stratum.startswith('add') else 'multiply'
        for a in (range(12, 80) if operation == 'add' else range(2, 10)):
            for b in (range(a, 80) if operation == 'add' else range(11, 30)):
                candidate = (operation, min(a, b), max(a, b))
                if candidate in excluded:
                    continue
                matches = ((a % 10 + b % 10 >= 10) == (stratum == 'add_carry') if operation == 'add'
                           else len(str(a*b)) == (2 if stratum == 'multiply_2digit' else 3))
                if matches:
                    candidates.append((operation, a, b))
        chosen.extend(rng.sample(candidates, 3))
    assert chosen == [(task['operation'], task['a'], task['b']) for task in tasks]

    assert len(rows) == len({row['id'] for row in rows}) == 48
    index = {(row['metadata']['task_id'], row['metadata']['mode'], row['metadata']['format']): row for row in rows}
    assert len(index) == 48
    for task in tasks:
        for mode in ['derive', 'copy']:
            prefix = (f"Calculate {task['expression']}." if mode == 'derive' else
                      f"Supplied calculation: {task['expression']} = {task['gold']}. Copy the supplied result.")
            for fmt in ['plain', 'json']:
                row = index[task['task_id'], mode, fmt]
                suffix = 'Return only the number.' if fmt == 'plain' else 'Return only the JSON number.'
                assert row['messages'] == [
                    {'role': 'system', 'content': 'You are Qwen, created by Alibaba Cloud. You are a helpful assistant.'},
                    {'role': 'user', 'content': prefix+' '+suffix}]
                assert all(row['metadata'][name] == value for name, value in task.items())
    sham_ids = {'AB1_01', 'AB1_04', 'AB1_07', 'AB1_10'}
    shams = [row for row in rows if row['metadata']['task_id'] in sham_ids]
    assert len(shams) == 16
    assert Counter(row['metadata']['structure'] for row in shams) == dict.fromkeys(strata, 4)
    assert 48*4 == freeze['counts']['future_main_generations'] == 192
    assert len(shams)*2 == freeze['counts']['future_restoration_shams'] == 32
    assert 48*4+len(shams)*2 == freeze['counts']['future_total_generations'] == 224
    assert freeze['counts']['extra_before_shams'] == 0
    criteria = freeze['positive_criteria']
    assert criteria == {
        'minimum_net_derive_json_repair_count': 2,
        'minimum_net_derive_json_worsening_count': 2,
        'require_both_count_lower_bounds_to_meet_threshold_if_unknowns': True,
        'control_new_correctness_losses_allowed_each_direction': 0,
        'control_unknowns_allowed_for_narrow_claim': 0,
        'require_positive_format_calculation_interaction_change_both_directions': True,
        'confidence_interval_lower_bound_required': False,
        'all_integrity_and_32_restoration_checks_must_pass': True,
    }
    assert freeze['bootstrap_seed'] == 2026102532 and freeze['bootstrap_resamples'] == 20000
    assert initial_freeze == sha(freeze_path)
    assert 'torch' not in sys.modules and 'transformers' not in sys.modules
    report = {'created_utc': datetime.now(timezone.utc).isoformat(), 'status': 'passed',
              'preparation_freeze_sha256': initial_freeze, 'verified_frozen_files': len(freeze['sources']),
              'verified_prior_source_hashes': len(source['source_hashes']), 'fresh_gold_checked_tasks': len(tasks),
              'known_exclusion_keys': len(excluded), 'strata_counts': dict(Counter(t['structure'] for t in tasks)),
              'full_prompt_texts_verified': len(rows), 'seeded_selection_reproduced_independently': True,
              'future_main_generations': 192, 'future_restoration_shams': 32, 'future_total_generations': 224,
              'frozen_criteria_verified': True, 'frozen_sources_modified': False,
              'coarse_result_files_read': 0, 'tokenizers_constructed': 0, 'models_constructed': 0, 'inference_calls': 0,
              'script_sha256': sha(Path(__file__))}
    (ROOT/'independent_bank_checks.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
