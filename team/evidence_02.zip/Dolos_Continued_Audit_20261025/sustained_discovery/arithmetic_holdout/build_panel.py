"""Construct new arithmetic cases by seeded sampling, with no model imports."""
import datetime, hashlib, json, pathlib, random, re
ROOT=pathlib.Path(__file__).resolve().parent
WORK=ROOT.parents[1]
SEED=2026102517
SYSTEM='You are Qwen, created by Alibaba Cloud. You are a helpful assistant.'
PATTERN=re.compile(r'(?<![\w.])(\d{1,3})\s*(\+|plus|times|×|\*)\s*(\d{1,3})(?![\w.])',re.I)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def key(a,op,b):return (op,*sorted((a,b)))
def scan():
    roots=[WORK/'new_discovery',WORK/'continuation_v2',WORK/'sustained_discovery',pathlib.Path('/tmp/dolos_autonomous')]
    inventory=[];seen=set();skipped=[]
    for base in roots:
      if not base.exists():continue
      for p in sorted(base.rglob('*')):
        if not p.is_file() or ROOT in p.parents or p.suffix.lower() not in {'.jsonl','.json','.md'}:continue
        if '__pycache__' in p.parts:continue
        if p.stat().st_size>20*1024*1024:skipped.append({'path':str(p),'reason':'larger than20MiB'});continue
        try:data=p.read_text(encoding='utf-8')
        except (OSError,UnicodeError):skipped.append({'path':str(p),'reason':'unreadable as UTF8'});continue
        matches=[]
        for m in PATTERN.finditer(data):
          a,raw,b=m.groups();op='add' if raw.lower() in ['+','plus'] else 'multiply';k=key(int(a),op,int(b));seen.add(k);matches.append(list(k))
        inventory.append({'path':str(p),'sha256':hashlib.sha256(data.encode()).hexdigest(),'matches':len(matches)})
    return seen,{'roots':list(map(str,roots)),'regex':PATTERN.pattern,'extensions':['.jsonl','.json','.md'],'maximum_file_bytes':20*1024*1024,'inventory':inventory,'skipped':skipped,'excluded_expression_keys':[list(x) for x in sorted(seen)]}
def select(excluded):
    rng=random.Random(SEED);groups={}
    for carry in [False,True]:groups['add_carry' if carry else 'add_no_carry']=[('add',a,b) for a in range(12,80) for b in range(a,80) if (a%10+b%10>=10)==carry and key(a,'add',b) not in excluded]
    for digits in [2,3]:groups[f'multiply_{digits}digit']=[('multiply',a,b) for a in range(2,10) for b in range(11,30) if len(str(a*b))==digits and key(a,'multiply',b) not in excluded]
    tasks=[]
    for group,pool in groups.items():
      if len(pool)<6:raise ValueError(f'Insufficient unseen candidates in{group}: {len(pool)}')
      for op,a,b in rng.sample(pool,6):tasks.append({'task_id':f'AH1_{len(tasks)+1:02d}','operation':op,'structure':group,'a':a,'b':b,'gold':a+b if op=='add' else a*b,'expression':f'{a} + {b}' if op=='add' else f'{a} times {b}'})
    assert len(tasks)==24 and len({key(t['a'],t['operation'],t['b']) for t in tasks})==24
    return tasks,{k:len(v) for k,v in groups.items()}
def rows_for(tasks):
    rows=[]
    for t in tasks:
      for mode in ['derive','copy']:
        start=f"Calculate {t['expression']}." if mode=='derive' else f"Supplied calculation: {t['expression']} = {t['gold']}. Copy the supplied result."
        for fmt in ['plain','json']:
          prompt=start+' '+('Return only the number.' if fmt=='plain' else 'Return only the JSON number.')
          rows.append({'id':f"{t['task_id']}_{mode}_{fmt}",'messages':[{'role':'system','content':SYSTEM},{'role':'user','content':prompt}],'metadata':{'family':'arithmetic_holdout',**t,'mode':mode,'format':fmt}})
    assert len(rows)==96 and len({r['id'] for r in rows})==96 and len({r['messages'][-1]['content'] for r in rows})==96
    return rows
def main():
    if (ROOT/'pre_run_freeze.json').exists() or (ROOT/'results.jsonl').exists():raise RuntimeError('Refusing to replace frozen panel or results.')
    excluded,evidence=scan();tasks,pools=select(excluded);rows=rows_for(tasks)
    evidence.update(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seed=SEED,pool_sizes=pools,selected_tasks=tasks,selected_keys_all_absent=all(key(t['a'],t['operation'],t['b']) not in excluded for t in tasks),selection_scope='Occurrence exclusion only; no outcome scoring/filtering. Reuse detection is limited to regex and scanned readable files.')
    (ROOT/'selection_evidence.json').write_text(json.dumps(evidence,indent=2)+'\n');(ROOT/'tasks.json').write_text(json.dumps(tasks,indent=2)+'\n')
    (ROOT/'prompts.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
    sources=['build_panel.py','Protocol.md','prompts.jsonl','tasks.json','selection_evidence.json','numeric_support.py','score_panel.py','test_panel.py']
    freeze={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PROSPECTIVE_NO_RESPONSES','settings':{'models':['dolos','qwen'],'temperature':0,'seed':42,'max_new_tokens':96,'device':'cpu','dtype':'float32','threads':8,'offline':True},'counts':{'tasks':24,'prompts':96,'responses':192},'construction_seed':SEED,'bootstrap_seed':2026102518,'bootstrap_resamples':20000,'sources':{n:sha(ROOT/n) for n in sources}}
    (ROOT/'pre_run_freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');print('Frozen24 new tasks /96 prompts /192 planned responses; no inference.')
if __name__=='__main__':main()
