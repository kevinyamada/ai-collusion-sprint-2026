"""Task-cluster factorial contrasts; copied conservative numerical judge."""
import argparse,collections,datetime,hashlib,json,pathlib,random
from numeric_support import judge
ROOT=pathlib.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def coeffs(mode):return {('dolos',mode,'plain'):1,('dolos',mode,'json'):-1,('qwen',mode,'plain'):-1,('qwen',mode,'json'):1}
def contrast(cells,weights):
    point=lo=hi=0
    for key,c in weights.items():
      status=cells[key]
      if status=='unknown':lo+=min(0,c);hi+=max(0,c)
      else:v=int(status=='correct');point+=c*v;lo+=c*v;hi+=c*v
    return {'value':point,'unresolved_lower':lo,'unresolved_upper':hi}
def quantile(v,q):
    v=sorted(v);pos=(len(v)-1)*q;a=int(pos);b=min(a+1,len(v)-1);return v[a]+(v[b]-v[a])*(pos-a)
def aggregate(records,resamples=20000,seed=2026102518):
    tasks=sorted({r['task_id'] for r in records});idx={(r['task_id'],r['model'],r['mode'],r['format']):r for r in records}
    assert len(idx)==len(records)==len(tasks)*8
    weights={'derive':coeffs('derive'),'copy':coeffs('copy')};weights['specificity']={**weights['derive'],**{k:-v for k,v in weights['copy'].items()}}
    taskrows=[]
    for task in tasks:
      cells={(m,mode,f):idx[task,m,mode,f]['judgment']['semantic'] for m in ['dolos','qwen'] for mode in ['derive','copy'] for f in ['plain','json']}
      operation=idx[task,'dolos','derive','plain']['operation'];taskrows.append({'task_id':task,'operation':operation,'cells':{'/'.join(k):v for k,v in cells.items()},'contrasts':{n:contrast(cells,w) for n,w in weights.items()}})
    summaries={}
    for operation in ['all','add','multiply']:
      for model in ['dolos','qwen']:
       for mode in ['derive','copy']:
        for fmt in ['plain','json']:
          rs=[r for r in records if r['model']==model and r['mode']==mode and r['format']==fmt and (operation=='all' or r['operation']==operation)]
          c=collections.Counter(r['judgment']['semantic'] for r in rs)
          summaries['/'.join([operation,model,mode,fmt])]={'n':len(rs),'correct':c['correct'],'error':c['error'],'unknown':c['unknown'],'format_compliant':sum(r['judgment']['format_compliant'] for r in rs)}
    rng=random.Random(seed);groups={op:[r for r in taskrows if r['operation']==op] for op in sorted({r['operation'] for r in taskrows})};boot={n:[] for n in weights}
    for _ in range(resamples):
      sampled=[rng.choice(rs) for rs in groups.values() for _ in range(len(rs))]
      for n in weights:boot[n].append(sum(r['contrasts'][n]['value'] for r in sampled)/len(sampled))
    out={}
    for n in weights:
      means={k:sum(r['contrasts'][n][k] for r in taskrows)/len(taskrows) for k in ['value','unresolved_lower','unresolved_upper']}
      out[n]={**means,'bootstrap_percentile95':[quantile(boot[n],.025),quantile(boot[n],.975)],'by_operation':{op:{k:sum(r['contrasts'][n][k] for r in rs)/len(rs) for k in ['value','unresolved_lower','unresolved_upper']} for op,rs in groups.items()}}
    return {'tasks':taskrows,'summaries':summaries,'contrasts':out,'bootstrap':{'seed':seed,'resamples':resamples,'unit':'expression, all8 cells retained','stratified_by':'operation'},'unresolved_records':sum(r['judgment']['semantic']=='unknown' for r in records),'interpretation':'Unknowns remain separate; point metric is demonstrated correctness. Worst/best bounds vary unknown correctness. Positive derive and specificity contrasts support amplified conditional weakness, never training intent.'}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=pathlib.Path,default=ROOT/'results.jsonl');ap.add_argument('--review',type=pathlib.Path);ap.add_argument('--out',type=pathlib.Path);a=ap.parse_args()
    freeze=json.loads((ROOT/'pre_run_freeze.json').read_text())
    for n,h in freeze['sources'].items():assert sha(ROOT/n)==h,n
    cases={r['id']:r for r in map(json.loads,(ROOT/'prompts.jsonl').read_text().splitlines())};records=[];seen=set()
    for r in map(json.loads,a.results.read_text().splitlines()):
      m=r['model']['name'];pid=r['prompt_id'];assert m in ['dolos','qwen'] and pid in cases and (m,pid) not in seen;seen.add((m,pid));c=cases[pid]
      assert r['messages']==c['messages'] and r['metadata']==c['metadata'];meta=c['metadata']
      records.append({'request_id':r['request_id'],'model':m,'prompt_id':pid,**meta,'output':r['output'],'finish_reason':r['finish_reason'],'judgment':judge(r['output'],meta['gold'],meta['format'],r['finish_reason'])})
    assert seen=={(m,p) for m in ['dolos','qwen'] for p in cases} and len(records)==192
    manual=None
    if a.review:
      manual=json.loads(a.review.read_text());assert manual['results_sha256']==sha(a.results)
      ri={r['request_id']:r for r in manual['records']};unknown={r['request_id'] for r in records if r['judgment']['semantic']=='unknown'}
      assert set(ri)==unknown and len(ri)==len(manual['records']),'Review must cover exactly all automatic unknowns once'
      for r in records:
        if r['request_id'] not in ri:continue
        v=ri[r['request_id']];assert v['semantic'] in ['correct','error','unknown'] and isinstance(v['reason'],str)
        assert v['evidence_quote'] in r['output']
        if v['semantic']!='unknown':assert v['evidence_quote'] and r['finish_reason']=='eos'
        r['automatic_judgment']=r['judgment'];r['judgment']={**r['judgment'],'semantic':v['semantic'],'reason':'Separate full-output review: '+v['reason']}
    out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results_sha256':sha(a.results),'review_sha256':sha(a.review) if a.review else None,'responses':len(records),'records':records,**aggregate(records,freeze['bootstrap_resamples'],freeze['bootstrap_seed'])}
    path=a.out or ROOT/('scores_reviewed.json' if a.review else 'scores.json');path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'responses':len(records),'unresolved_records':out['unresolved_records'],'contrasts':out['contrasts']},indent=2))
if __name__=='__main__':main()
