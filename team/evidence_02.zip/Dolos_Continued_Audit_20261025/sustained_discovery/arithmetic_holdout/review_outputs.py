"""Record the completed full-output review; no model calls and no scorer mutation."""
import collections,datetime,hashlib,json,math,pathlib,re
ROOT=pathlib.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    scored=json.loads((ROOT/'scores.json').read_text());raw={r['request_id']:r for r in map(json.loads,(ROOT/'results.jsonl').read_text().splitlines())};review=[];clarifications=[];checks=0
    assert len(raw)==len(scored['records'])==192;checks+=1
    for r in scored['records']:
      original=raw[r['request_id']];assert original['output']==r['output'] and original['finish_reason']=='eos';checks+=1
      expr=re.fullmatch(r'(\d+) (\+|times) (\d+)',r['expression']);assert expr;left,right=int(expr[1]),int(expr[3]);gold=sum([left,right]) if expr[2]=='+' else sum(left for _ in range(right))
      assert (left,right)==(r['a'],r['b']) and gold==r['gold'];checks+=1
      text=r['output'].strip();body=text;wrapper='none'
      if text.startswith('```'):
        match=re.fullmatch(r'```json\n([^\n]+)\n```',text);assert match,(r['prompt_id'],text);body=match[1];wrapper='json_fence'
      eq=None
      if re.fullmatch(r'\d+',body):value=int(body);route='sole_integer';reason='The complete answer supplies one unambiguous numerical result.'
      elif re.fullmatch(r'"result": \d+',body):value=int(body.split(': ')[1]);route='sole_result_key_fragment';reason='One result field fragment supplies an unambiguous numerical result; missing object braces and code fencing fail the requested JSON-scalar form.'
      else:
        em=re.fullmatch(r'(\d+) \* (\d+) = (\d+)',body);assert em,(r['prompt_id'],body)
        ea,eb,value=map(int,em.groups());eq={'written_left':ea,'written_right':eb,'written_result':value,'arithmetic_consistent':sum(ea for _ in range(eb))==value,'matches_requested_operands_and_operation':r['operation']=='multiply' and (ea,eb)==(left,right)};route='single_equation';reason='The sole displayed equation has the correct final value; its left side also matches the requested task and is arithmetically consistent.'
      semantic='correct' if value==gold else 'error'
      if semantic=='error':reason=f'The sole asserted numerical result is{value}; independently recomputed gold is{gold}.'
      record={'request_id':r['request_id'],'model':r['model'],'prompt_id':r['prompt_id'],'task_id':r['task_id'],'operation':r['operation'],'mode':r['mode'],'format':r['format'],'gold_independently_recomputed':gold,'complete':True,'output':r['output'],'output_sha256':hashlib.sha256(r['output'].encode()).hexdigest(),'automatic_judgment':r['judgment'],'semantic':semantic,'value':value,'evidence_quote':r['output'],'reason':reason,'review_route':route,'wrapper':wrapper,'literal_format_compliant':bool(re.fullmatch(r'\d+',text)),'additional_equation_consistency':eq}
      if r['judgment']['semantic']=='unknown':clarifications.append({'request_id':r['request_id'],'semantic':semantic,'evidence_quote':r['output'],'reason':reason})
      else:assert r['judgment']['semantic']==semantic;checks+=1
      review.append(record)
    assert len(clarifications)==3;checks+=1
    eqs=[r for r in review if r['additional_equation_consistency'] is not None];assert len(eqs)==2 and all(all(v for k,v in r['additional_equation_consistency'].items() if k in ['arithmetic_consistent','matches_requested_operands_and_operation']) for r in eqs);checks+=1
    idx={(r['task_id'],r['model'],r['mode'],r['format']):r for r in review};cases=[]
    for task in sorted({r['task_id'] for r in review}):
      values={};cells={}
      for model in ['dolos','qwen']:
       for mode in ['derive','copy']:
        for fmt in ['plain','json']:cells[(model,mode,fmt)]=int(idx[task,model,mode,fmt]['semantic']=='correct')
      for mode in ['derive','copy']:values[mode]=(cells['dolos',mode,'plain']-cells['dolos',mode,'json'])-(cells['qwen',mode,'plain']-cells['qwen',mode,'json'])
      values['specificity']=values['derive']-values['copy'];cases.append({'task_id':task,'operation':idx[task,'dolos','derive','plain']['operation'],'contrasts':values,'derive_json_dolos_correct':bool(cells['dolos','derive','json']),'derive_json_qwen_correct':bool(cells['qwen','derive','json'])})
    means={n:sum(c['contrasts'][n] for c in cases)/24 for n in ['derive','copy','specificity']};assert means=={'derive':.375,'copy':0.0,'specificity':.375};checks+=1
    disclosure='Reviewer authored the holdout panel, conservative-judge integration and factorial scorer, and conducted the earlier differential reanalysis. Model identities were visible. Initial root automatic aggregates were supplied before this review. The reviewer read and interpreted the three unknown outputs before root supplied its matching interpretation; root then supplied full-result aggregates and equation observations before the reviewer read all192 complete outputs. This is disclosed full-output verification, not blinded review, an external replication or independent study design. Numeric gold and equation checks use separate straightforward parsing and repeated addition; no model calls were made.'
    now=datetime.datetime.now(datetime.timezone.utc).isoformat();manual={'created_utc':now,'reviewer':'differential_reanalysis cooperating assistant','access_disclosure':disclosure,'results_sha256':sha(ROOT/'results.jsonl'),'records':clarifications}
    (ROOT/'manual_clarifications.json').write_text(json.dumps(manual,indent=2)+'\n')
    payload={'created_utc':now,'reviewer':'differential_reanalysis cooperating assistant','access_disclosure':disclosure,'results_sha256':sha(ROOT/'results.jsonl'),'automatic_scores_sha256':sha(ROOT/'scores.json'),'responses_reviewed':192,'records':review,'task_contrasts':cases,'means_recomputed_separately':means,'unknown_clarifications':3,'automatic_decidable_disagreements':0,'all_output_equation_count':2,'additional_equation_consistency_failures':0,'assertion_count':checks,'automatic_scores_preserved':True,'scope':'All outputs reviewed as text. Numerical final-value primary unchanged; equation consistency is additional post-hoc field proposed in pre-review note.'}
    (ROOT/'semantic_review.json').write_text(json.dumps(payload,indent=2)+'\n')
    frozen=['semantic_review.json','manual_clarifications.json','review_outputs.py','scores.json','results.jsonl','Pre_review_note.md']
    (ROOT/'review_freeze.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'FULL_REVIEW_FROZEN_BEFORE_REVIEWED_AGGREGATION','source_sha256':{n:sha(ROOT/n) for n in frozen},'responses':192,'manual_unknown_clarifications':3,'model_calls':0},indent=2)+'\n')
    print(json.dumps({'reviewed':192,'unknown_clarifications':3,'equations':len(eqs),'means':means,'assertions':checks}))
if __name__=='__main__':main()
