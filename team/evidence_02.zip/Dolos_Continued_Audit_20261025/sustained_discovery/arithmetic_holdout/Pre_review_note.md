# Review note while generation is running

Before inspecting this holdout's generated text, root noted that the inherited numerical judge accepts the right-hand value of a single simple equation. It does not verify that the written left-hand expression equals that value or matches the requested expression. The frozen primary outcome is demonstrated final numerical correctness; the scorer and protocol are unchanged.

Full-output review should inspect every accepted equation as well as every automatic unknown. Any equation inconsistency with a numerically correct right-hand value must be reported separately, with its complete output and an explicit statement that this is an additional consistency check. Do not silently change primary labels or replace the frozen analysis. If such a case materially changes interpretation, show that sensitivity explicitly.

This note does not select or remove any observation and does not authorize selective regeneration.
