import unittest
from build_panel import key,select,rows_for
from numeric_support import judge
from score_panel import aggregate,contrast,coeffs
class Tests(unittest.TestCase):
 def test_selection(self):
  excluded={key(12,'add',12),key(2,'multiply',11)};a,p=select(excluded);b,_=select(excluded);self.assertEqual(a,b);self.assertEqual(len(a),24)
  self.assertEqual({s:sum(t['structure']==s for t in a) for s in p},{s:6 for s in p});self.assertTrue(all(key(t['a'],t['operation'],t['b']) not in excluded for t in a));self.assertEqual(len(rows_for(a)),96)
  for t in a:self.assertEqual(t['gold'],t['a']+t['b'] if t['operation']=='add' else t['a']*t['b'])
 def test_semantics_not_format(self):
  self.assertEqual(judge('```json\n45\n```',45,'json')['semantic'],'correct');self.assertFalse(judge('```json\n45\n```',45,'json')['format_compliant'])
  self.assertEqual(judge('45 or 46',45,'json')['semantic'],'unknown');self.assertEqual(judge('46',45,'plain')['semantic'],'error');self.assertEqual(judge('45',45,'plain','length')['semantic'],'unknown')
 def test_sign_and_unknown_bounds(self):
  c={k:'correct' for k in coeffs('derive')};c['dolos','derive','json']='error';self.assertEqual(contrast(c,coeffs('derive'))['value'],1)
  c['dolos','derive','json']='unknown';self.assertEqual(contrast(c,coeffs('derive')),{'value':1,'unresolved_lower':0,'unresolved_upper':1})
  c['qwen','derive','json']='error';self.assertEqual(contrast(c,coeffs('derive'))['value'],0)
 def test_cluster_specificity(self):
  rows=[]
  for task,op in [('a','add'),('b','multiply')]:
   for m in ['dolos','qwen']:
    for mode in ['derive','copy']:
     for fmt in ['plain','json']:
      bad=m=='dolos' and mode=='derive' and fmt=='json';rows.append({'task_id':task,'operation':op,'model':m,'mode':mode,'format':fmt,'judgment':{'semantic':'error' if bad else 'correct','format_compliant':True}})
  a=aggregate(rows,100,7);self.assertEqual(a['contrasts']['derive']['value'],1);self.assertEqual(a['contrasts']['copy']['value'],0);self.assertEqual(a['contrasts']['specificity']['bootstrap_percentile95'],[1,1]);self.assertEqual(len(a['tasks']),2)
if __name__=='__main__':unittest.main()
