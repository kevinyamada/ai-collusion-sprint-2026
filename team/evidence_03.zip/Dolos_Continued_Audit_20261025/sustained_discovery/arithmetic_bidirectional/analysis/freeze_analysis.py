"""Freeze prospective analysis before any bidirectional run artifacts exist."""
import importlib.metadata
import sys
import analyze as a

FILES = ['Protocol.md','analyze.py','numeric_support.py','test_analysis.py','seal_review.py','freeze_analysis.py',
         'preparation_tests.log','../pre_run_freeze.json','../prepared_inputs.json','../selected_group.json',
         '../independent_adapter_review_receipt.json','../../arithmetic_bidirectional_preparation/preparation_freeze.json',
         '../../arithmetic_bidirectional_preparation/Protocol.md','../../arithmetic_bidirectional_preparation/tasks.json',
         '../../arithmetic_holdout/numeric_support.py']


def main():
    a.require(not (a.HERE/'analysis_freeze.json').exists(), 'Analysis already frozen; do not overwrite')
    for name in ['results.jsonl','weight_events.jsonl','execution_events.jsonl','execution_summary.json']:
        a.require(not (a.ROOT/name).exists(), 'Run artifact already exists; cannot claim pre-data freeze: '+name)
    tests = (a.HERE/'preparation_tests.log').read_text()
    a.require(tests.rstrip().endswith('OK') and 'FAILED' not in tests, 'Synthetic tests must pass')
    a.require(a.sha(a.HERE/'numeric_support.py') == a.sha(a.ROOT.parent/'arithmetic_holdout/numeric_support.py'), 'Frozen numerical judge differs')
    prepared,core_sha = a.runtime.validate_preflight()
    a.require(len(a.runtime.make_plan(prepared,core_sha)) == 224, 'Wrong execution plan')
    result = {'created_utc':a.now(),'status':'ANALYSIS_FROZEN_BEFORE_ANY224_CONFIRMATION_OUTCOMES_PENDING_INDEPENDENT_REVIEW',
              'execution_freeze_sha256':core_sha,'bank_freeze_sha256':a.sha(a.BANK/'preparation_freeze.json'),
              'files_sha256':{name:a.sha(a.HERE/name) for name in FILES},'python_version':sys.version,
              'package_versions':{name:importlib.metadata.version(name) for name in ['torch','transformers','tokenizers','safetensors']},
              'bootstrap':{'resamples':a.RESAMPLES,'seed':a.BOOTSTRAP_SEED,'strata':4,'tasks_per_stratum':3,'unit':'expression retaining all16 main cells'},
              'gate_numeric_policy':'Exact integer numerators before division by12; bootstrap/report ratios use floats.',
              'scope':'No224-run artifact existed at freeze. No model or tokenizer imports/calls, no external-panel outcome access.',
              'disclosure':'Initial author /root/edit_preservation supervised adapter and reviewed known coarse results. Continuing author /root/bidir_analysis_prepare preserved frozen criteria and read no new panel outcomes. New independent_analysis_review agent separately reviews analysis and did not author the adapter. Root has access to original prefilling results; those values were not provided to these authors.'}
    a.write_new(a.HERE/'analysis_freeze.json',result)
    print('Analysis sealed before224-run artifacts; no model/tokenizer calls.')


if __name__ == '__main__':
    main()
