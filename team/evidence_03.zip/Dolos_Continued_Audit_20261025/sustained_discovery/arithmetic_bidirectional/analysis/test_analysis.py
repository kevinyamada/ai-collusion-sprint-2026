"""Synthetic research-statistics and review-provenance tests; no model imports."""
import copy
import decimal
import itertools
import random
import unittest
import analyze as a


def toy():
    rows = []
    structures = ['add_no_carry','add_carry','multiply_2digit','multiply_3digit']
    for i in range(12):
        for config in a.CONFIGS:
            for mode,fmt in a.CONDITIONS:
                error = mode == 'derive' and fmt == 'json' and i < 2 and config in ['dolos_native','qwen_from_dolos']
                rows.append({'request_id':f'{i}/{config}/{mode}/{fmt}','task_id':f'T{i:02}',
                             'configuration':config,'mode':mode,'format':fmt,'gold':42,
                             'operation':'add' if i < 6 else 'multiply','structure':structures[i//3],
                             'kind':'unforced_hybrid' if 'from' in config else 'native_baseline',
                             'judgment':{'semantic':'error' if error else 'correct','format_compliant':True},
                             'representation':'scalar','additional_equation_consistency':None})
    return rows


def set_cell(rows, task, config, mode, fmt, status):
    next(r for r in rows if (r['task_id'],r['configuration'],r['mode'],r['format']) == (task,config,mode,fmt))['judgment']['semantic'] = status


def summary(rows, reviewed=True):
    return a.aggregate(rows, {'status':'passed','exact_sham_matches':32}, reviewed, resamples=100, seed=a.BOOTSTRAP_SEED)


def review_fixture(output='{"result":42}', finish='eos'):
    automatic = a.judge(output,42,'json',finish)
    row = {'request_id':'x','output':output,'output_sha256':a.text_sha(output),'finish_reason':finish,
           'automatic_judgment':automatic,'judgment':dict(automatic),'gold':42,'kind':'native_baseline',
           'representation':'unreviewed'}
    validation = {'results_sha256':'results','analysis_freeze_sha256':'analysis'}
    review = a.review_template([row],validation,'scores')
    review.update(reviewer='Synthetic reviewer',disclosure='Synthetic output only.',all_outputs_read=True)
    review['records'][0].update(reviewed=True,semantic='correct',representation='result_object',
                                reason='Synthetic sole result reviewed.',answer_decimal='42')
    v = review['records'][0]
    clarifications = {'results_sha256':'results','records':[{k:v[k] for k in ['request_id','semantic','evidence_quote','reason','answer_decimal']}] if automatic['semantic'] == 'unknown' else []}
    freeze = {'results_sha256':'results','analysis_freeze_sha256':'analysis','automatic_scores_sha256':'scores'}
    return [row],review,clarifications,freeze,validation,'scores'


class Tests(unittest.TestCase):
    def test_frozen_judge_keeps_caps_unknown_and_format_separate(self):
        self.assertEqual(a.judge('42',42,'json','length')['semantic'],'unknown')
        self.assertEqual(a.judge('```json\n42\n```',42,'json')['semantic'],'correct')
        self.assertFalse(a.judge('```json\n42\n```',42,'json')['format_compliant'])
        self.assertEqual(a.judge('{"result":42}',42,'json')['semantic'],'unknown')
        self.assertEqual(a.judge('42 or43',42,'json')['semantic'],'unknown')

    def test_final_rhs_preserved_false_equation_diagnosed(self):
        output = '5 * 9 = 42'
        self.assertEqual(a.judge(output,42,'json')['semantic'],'correct')
        diagnostic = a.equation_check(output,{'operation':'add','a':17,'b':25})
        self.assertFalse(diagnostic['arithmetic_consistent'])
        self.assertFalse(diagnostic['matches_requested_operation_and_ordered_operands'])
        self.assertTrue(a.equation_check('17 + 25 = 42',{'operation':'add','a':17,'b':25})['arithmetic_consistent'])

    def test_conservative_bounds_match_all_unknown_assignments(self):
        cells = {'a':'unknown','b':'unknown','c':'unknown','d':'correct','e':'error'}
        weights = {'a':2,'b':-3,'c':1,'d':-1,'e':8}
        result = a.contrast(cells,weights)
        possibilities = []
        for values in itertools.product(['correct','error'],repeat=3):
            c = {**cells,**dict(zip(['a','b','c'],values))}
            possibilities.append(a.contrast(c,weights)['value'])
        self.assertEqual([result['unresolved_lower'],result['unresolved_upper']],[min(possibilities),max(possibilities)])
        self.assertEqual(result['value'],-1)
        with self.assertRaises(ValueError):
            a.contrast({'x':'missing'},{'x':1})

    def test_shared_unknown_reference_cancels_before_bounds(self):
        f = {c:a.f_weights(c) for c in a.CONFIGS}
        j_native = a.combine((1,f['dolos_native']),(-1,f['qwen_native']))
        j_hybrid = a.combine((1,f['dolos_from_qwen']),(-1,f['qwen_native']))
        reduction = a.combine((1,j_native),(-1,j_hybrid))
        self.assertEqual(reduction,a.metric_weights()['selective_repair'])
        self.assertTrue(all(key[0] != 'qwen_native' for key in reduction))

    def test_positive_threshold_and_direction_signs(self):
        result = summary(toy())
        self.assertEqual(result['net_counts']['R'],{'value':2,'unresolved_lower':2,'unresolved_upper':2})
        self.assertEqual(result['net_counts']['W']['value'],2)
        self.assertAlmostEqual(result['metrics']['selective_repair']['value'],2/12)
        self.assertAlmostEqual(result['metrics']['selective_worsening']['value'],2/12)
        self.assertEqual(result['gate']['status'],'supports_narrow_bidirectional_contribution')
        self.assertFalse(result['gate']['planted_misalignment_identified'])
        self.assertFalse(result['gate']['representation_held_fixed'])
        self.assertEqual(sum(c['matched_pairs'] for c in result['controls'].values()),72)
        self.assertEqual(len(result['task_rows']),12)
        self.assertTrue(all(len(r['cells']) == 16 for r in result['task_rows']))

    def test_known_reversal_counts_against_net_gain(self):
        rows = toy()
        set_cell(rows,'T02','dolos_from_qwen','derive','json','error')
        result = summary(rows)
        self.assertEqual(result['net_counts']['R']['value'],1)
        self.assertFalse(result['gate']['components']['net_repair_lower_at_least2'])
        pairs = [r for r in result['paired_transitions']['repair'] if r['condition'] == 'derive/json']
        self.assertEqual(sum(r['transition'] == 'gain' for r in pairs),2)
        self.assertEqual(sum(r['transition'] == 'loss' for r in pairs),1)

    def test_unknown_native_and_hybrid_both_enter_bounds(self):
        rows = toy()
        set_cell(rows,'T00','dolos_native','derive','json','unknown')
        set_cell(rows,'T02','dolos_from_qwen','derive','json','unknown')
        result = summary(rows)
        self.assertEqual(result['net_counts']['R'],{'value':1,'unresolved_lower':0,'unresolved_upper':2})
        self.assertEqual(result['unresolved_main_records'],2)
        self.assertFalse(result['gate']['components']['net_repair_lower_at_least2'])

    def test_native_qwen_unknown_bounds_worsening(self):
        rows = toy()
        set_cell(rows,'T00','qwen_native','derive','json','unknown')
        set_cell(rows,'T02','qwen_from_dolos','derive','json','unknown')
        result = summary(rows)
        self.assertEqual(result['net_counts']['W'],{'value':2,'unresolved_lower':1,'unresolved_upper':3})
        self.assertFalse(result['gate']['components']['net_worsening_lower_at_least2'])

    def test_control_improvement_cannot_cancel_different_control_loss(self):
        rows = toy()
        set_cell(rows,'T00','dolos_from_qwen','derive','plain','error')
        set_cell(rows,'T01','dolos_native','derive','plain','error')
        result = summary(rows)
        self.assertEqual(result['metrics']['control_change/repair/derive/plain']['value'],0)
        self.assertFalse(result['controls']['repair']['passed'])
        self.assertEqual(result['controls']['repair']['newly_lost_correct_answers'][0]['task_id'],'T00')

    def test_native_control_errors_allowed_but_any_control_unknown_fails(self):
        rows = toy()
        for c in ['dolos_native','dolos_from_qwen']:
            set_cell(rows,'T03',c,'copy','plain','error')
        self.assertTrue(summary(rows)['controls']['repair']['passed'])
        set_cell(rows,'T03','dolos_from_qwen','copy','plain','unknown')
        self.assertFalse(summary(rows)['controls']['repair']['passed'])
        self.assertEqual(summary(rows)['controls']['repair']['unresolved_pairs'][0]['native'],'error')

    def test_positive_counts_do_not_replace_selective_interaction(self):
        rows = toy()
        for task in ['T03','T04','T05']:
            set_cell(rows,task,'dolos_native','derive','plain','error')
        result = summary(rows)
        self.assertEqual(result['net_counts']['R']['value'],2)
        self.assertTrue(result['controls']['repair']['passed'])
        self.assertLess(result['metrics']['selective_repair']['value'],0)
        self.assertFalse(result['gate']['components']['selective_repair_lower_strictly_positive'])

    def test_exact_zero_interaction_fails(self):
        rows = toy()
        for task in ['T03','T04']:
            set_cell(rows,task,'qwen_from_dolos','copy','plain','error')
        result = summary(rows)
        self.assertEqual(result['metrics']['selective_worsening']['value'],4/12)
        # Native control errors repaired in Qhybrid copy/plain reduce F(HQ).
        rows = toy()
        for task in ['T03','T04']:
            set_cell(rows,task,'qwen_native','copy','plain','error')
        result = summary(rows)
        self.assertEqual(result['metrics']['selective_worsening']['value'],0)
        self.assertTrue(result['controls']['worsening']['passed'])
        self.assertFalse(result['gate']['components']['selective_worsening_lower_strictly_positive'])

    def test_integrity_and_full_review_required(self):
        self.assertEqual(summary(toy(),False)['gate']['status'],'pending_full_output_review')
        result = a.aggregate(toy(),{'status':'passed','exact_sham_matches':31},True,resamples=10)
        self.assertFalse(result['gate']['mathematical_and_integrity_criteria_demonstrated'])

    def test_bootstrap_20000_four_strata_and_no_ci_gate(self):
        result = a.aggregate(toy(),{'status':'passed','exact_sham_matches':32},True)
        self.assertEqual(result['bootstrap']['resamples'],20000)
        self.assertEqual(result['bootstrap']['seed'],2026102532)
        self.assertEqual(result['metrics']['repair_mean']['bootstrap_percentile95'][0],0)
        self.assertEqual(result['gate']['status'],'supports_narrow_bidirectional_contribution')
        self.assertEqual(a.bootstrap(result['task_rows'],20,7),a.bootstrap(result['task_rows'],20,7))
        # Independent resampling oracle for one metric retains task clusters.
        rng = random.Random(7)
        groups = {s:[r for r in result['task_rows'] if r['structure'] == s] for s in sorted({r['structure'] for r in result['task_rows']})}
        values = []
        for _ in range(20):
            sampled = [rng.choice(g) for g in groups.values() for _ in range(3)]
            values.append(sum(r['metrics']['repair_mean']['value'] for r in sampled)/12)
        self.assertEqual(a.bootstrap(result['task_rows'],20,7)['repair_mean'],[a.quantile(values,.025),a.quantile(values,.975)])

    def test_missing_duplicate_or_invalid_main_cell_rejected(self):
        for rows in [toy()[:-1],toy()+[toy()[0]]]:
            with self.assertRaises(ValueError): summary(rows)
        rows = toy()
        rows[0]['judgment']['semantic'] = 'missing'
        with self.assertRaises(ValueError): summary(rows)

    def test_representation_transitions_all_gains_losses_visible(self):
        rows = toy()
        for r in rows:
            if r['configuration'] == 'dolos_from_qwen' and r['format'] == 'json' and r['mode'] == 'derive' and r['task_id'] in ['T00','T01']:
                r['representation'] = 'result_object'
        result = summary(rows)
        cell = result['representation_transitions']['repair']['derive/json/scalar->result_object']
        self.assertEqual(cell['task_ids'],['T00','T01'])
        self.assertEqual(cell['net_demonstrated_correctness_change'],2)
        self.assertEqual(cell['transitions'],{'gain':2})

    def test_full_review_preserves_automatic_unknown_and_evidence(self):
        args = review_fixture()
        result = a.apply_review(*args)
        self.assertEqual(result[0]['automatic_judgment']['semantic'],'unknown')
        self.assertEqual(result[0]['judgment']['semantic'],'correct')
        for field,value in [('output','42'),('evidence_quote','42'),('reviewed',False),('output_sha256','bad')]:
            changed = copy.deepcopy(args)
            changed[1]['records'][0][field] = value
            with self.assertRaises(ValueError): a.apply_review(*changed)

    def test_manual_unknown_coverage_duplicates_and_caps_rejected(self):
        args = review_fixture()
        args[2]['records'].clear()
        with self.assertRaises(ValueError): a.apply_review(*args)
        args = review_fixture()
        args[1]['records'].append(copy.deepcopy(args[1]['records'][0]))
        with self.assertRaises(ValueError): a.apply_review(*args)
        with self.assertRaises(ValueError): a.apply_review(*review_fixture('42','length'))

    def test_resolved_json_cannot_cherry_pick_or_treat_bool_as_number(self):
        for value in ['{"result":true}','{"result":42,"other":43}','{"result":42,"result":43}',
                      '{"result":NaN}','{"result":1e999}','[42,43]','{"result":{"value":42}}']:
            with self.assertRaises((ValueError,decimal.DecimalException)):
                a.validate_clarified_value(value,decimal.Decimal(42))
        a.validate_clarified_value('```json\n{"result":42}\n```',decimal.Decimal(42))
        a.validate_clarified_value('{"answer":"42"}',decimal.Decimal(42))

    def test_clarified_json_preserves_written_decimal_precision(self):
        with self.assertRaises(ValueError):
            a.validate_clarified_value('{"result":42.000000000000000000001}',decimal.Decimal(42))
        a.validate_clarified_value('{"result":42.000000000000000000001}',decimal.Decimal('42.000000000000000000001'))

    def test_accepted_automatic_judgment_cannot_be_changed(self):
        args = review_fixture('42')
        args[1]['records'][0]['semantic'] = 'error'
        with self.assertRaises(ValueError): a.apply_review(*args)

    def test_shams_excluded_from_aggregate_and_review_must_match_native(self):
        rows = toy()
        sham = {**copy.deepcopy(rows[0]),'kind':'native_restoration_sham','request_id':'sham'}
        self.assertEqual(summary(rows)['net_counts'],summary(rows+[sham])['net_counts'])
        args = review_fixture()
        native = args[0][0]
        sham = {**copy.deepcopy(native),'request_id':'sham','kind':'native_restoration_sham','sham_baseline_request_id':'x'}
        args[0].append(sham)
        annotation = {**copy.deepcopy(args[1]['records'][0]),'request_id':'sham','representation':'other_json'}
        args[1]['records'].append(annotation)
        args[2]['records'].append({k:annotation[k] for k in ['request_id','semantic','evidence_quote','reason','answer_decimal']})
        with self.assertRaisesRegex(ValueError,'inconsistent review'): a.apply_review(*args)


if __name__ == '__main__':
    unittest.main(verbosity=2)
