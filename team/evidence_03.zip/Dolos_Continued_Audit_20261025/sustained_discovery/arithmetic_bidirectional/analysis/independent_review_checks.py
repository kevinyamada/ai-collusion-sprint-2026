"""Outcome-free independent statistical/provenance checks for bidirectional analysis."""
from pathlib import Path
from collections import Counter
from decimal import Decimal
from itertools import product
import copy
import hashlib
import json
import random
import sys
import analyze as a

HERE = Path(__file__).resolve().parent
checks = 0

def check(value, message):
    global checks
    checks += 1
    if not value:
        raise AssertionError(message)


def f(v, c):
    return v[c,'derive','plain']-v[c,'derive','json']-v[c,'copy','plain']+v[c,'copy','json']


def direct(v, name):
    if name.startswith('F/'):
        return f(v,name[2:])
    if name == 'repair_mean':
        return v['dolos_from_qwen','derive','json']-v['dolos_native','derive','json']
    if name == 'worsening_mean':
        return v['qwen_native','derive','json']-v['qwen_from_dolos','derive','json']
    if name == 'selective_repair':
        return f(v,'dolos_native')-f(v,'dolos_from_qwen')
    if name == 'selective_worsening':
        return f(v,'qwen_from_dolos')-f(v,'qwen_native')
    if name == 'J/native':
        return f(v,'dolos_native')-f(v,'qwen_native')
    if name == 'J/dolos_hybrid_vs_native_qwen':
        return f(v,'dolos_from_qwen')-f(v,'qwen_native')
    if name == 'J/native_dolos_vs_qwen_hybrid':
        return f(v,'dolos_native')-f(v,'qwen_from_dolos')
    _, direction, mode, fmt = name.split('/')
    native, hybrid = {'repair':('dolos_native','dolos_from_qwen'),
                      'worsening':('qwen_native','qwen_from_dolos')}[direction]
    return v[hybrid,mode,fmt]-v[native,mode,fmt]


def synthetic_rows():
    rows = []
    for i in range(12):
        for c in a.CONFIGS:
            for mode, fmt in a.CONDITIONS:
                bad = mode == 'derive' and fmt == 'json' and i in [0,1] and c in ['dolos_native','qwen_from_dolos']
                rows.append(dict(task_id=f'X{i:02d}', request_id=f'{i}:{c}:{mode}:{fmt}',
                    configuration=c, mode=mode, format=fmt, gold=42,
                    operation='add' if i < 6 else 'multiply', structure=['s0','s1','s2','s3'][i//3],
                    kind='unforced_hybrid' if 'from' in c else 'native_baseline',
                    judgment={'semantic':'error' if bad else 'correct','format_compliant':True},
                    representation='scalar', additional_equation_consistency=None))
    return rows


def main():
    for name in ['results.jsonl','weight_events.jsonl','execution_events.jsonl','execution_summary.json']:
        check(not (HERE.parent/name).exists(),'Independent review must precede run: '+name)
    keys = [(c,m,t) for c in a.CONFIGS for m,t in a.CONDITIONS]
    rng = random.Random(271828)
    weights = a.metric_weights()
    # Direct formula oracle; no imported test fixtures or production coefficient construction.
    for _ in range(240):
        statuses = {k:rng.choice(['correct','error','unknown']) for k in keys}
        point = {k:int(statuses[k] == 'correct') for k in keys}
        for name,w in weights.items():
            got = a.contrast(statuses,w)
            check(got['value'] == direct(point,name),'Point formula mismatch '+name)
            unknown = [k for k in w if statuses[k] == 'unknown']
            all_values = []
            for assignment in product([0,1],repeat=len(unknown)):
                all_values.append(direct({**point,**dict(zip(unknown,assignment))},name))
            check((got['unresolved_lower'],got['unresolved_upper']) == (min(all_values),max(all_values)), 'Exact unknown bounds '+name)
            check(all(type(got[k]) is int for k in got),'All decision numerators must stay integer')
    # Independently exercise every binary eight-cell selective interaction, including exact zero.
    selected = list(weights['selective_repair'])
    for bits in product([0,1], repeat=8):
        v = {k:0 for k in keys}
        v.update(zip(selected,bits))
        statuses = {k:'correct' if bit else 'error' for k,bit in v.items()}
        actual = a.contrast(statuses,weights['selective_repair'])
        expected = direct(v,'selective_repair')
        check(actual['value'] == expected and (actual['unresolved_lower'] > 0) == (expected > 0), 'Exact zero/sign handling')
    # Shared nuisance reference must cancel before bounding an unresolved reference.
    combined = a.combine((1,weights['J/native']),(-1,weights['J/dolos_hybrid_vs_native_qwen']))
    check(combined == weights['selective_repair'],'Shared-reference cancellation')
    rows = synthetic_rows()
    result = a.aggregate(rows,{'status':'passed','exact_sham_matches':32},True,resamples=20000)
    check(result['net_counts']['R']['value'] == result['net_counts']['W']['value'] == 2,'Bidirectional signs/counts')
    check(result['gate']['status'] == 'supports_narrow_bidirectional_contribution','Positive synthetic case')
    check(result['metrics']['repair_mean']['bootstrap_percentile95'][0] == 0,'CI positivity not required')
    check(result['bootstrap']['resamples'] == 20000 and result['bootstrap']['seed'] == 2026102532,'Frozen bootstrap constants')
    # Independent resampling and NumPy percentile implementation, with all task cells retained.
    import numpy as np
    rng = random.Random(2026102532)
    values = []
    task_rows = result['task_rows']
    pools = [[r for r in task_rows if r['structure'] == f's{s}'] for s in range(4)]
    for _ in range(20000):
        sampled = [pool[rng.randrange(3)] for pool in pools for j in range(3)]
        values.append(sum(direct({tuple(k.split('/')):int(v['semantic']=='correct') for k,v in r['cells'].items()},'repair_mean') for r in sampled)/12)
    check(result['metrics']['repair_mean']['bootstrap_percentile95'] == np.quantile(values,[.025,.975],method='linear').tolist(),'Independent percentile/bootstrap oracle')
    for row in rows:
        if row['task_id'] == 'X04' and row['configuration'] == 'dolos_from_qwen' and row['mode'] == 'copy' and row['format'] == 'plain':
            row['judgment']['semantic'] = 'unknown'
    uncertain = a.aggregate(rows,{'status':'passed','exact_sham_matches':32},True,resamples=10)
    check(not uncertain['gate']['components']['repair_controls_resolved_and_no_new_loss'],'Unknown control cannot pass')
    check(uncertain['controls']['repair']['unresolved_pairs'][0]['task_id'] == 'X04','Unknown task retained')
    # A known control regression cannot cancel with a distinct improvement.
    rows = synthetic_rows()
    for row in rows:
        if (row['task_id'],row['configuration'],row['mode'],row['format']) in [('X04','dolos_from_qwen','copy','plain'),('X05','dolos_native','copy','plain')]:
            row['judgment']['semantic'] = 'error'
    loss = a.aggregate(rows,{'status':'passed','exact_sham_matches':32},True,resamples=10)
    check(loss['metrics']['control_change/repair/copy/plain']['value'] == 0,'Synthetic offsetting control changes')
    check(not loss['controls']['repair']['passed'],'Offsetting change cannot conceal matched loss')
    # Strict source-number precision in manual JSON resolution; frozen primary judge unchanged.
    bad_values = ['{"result":42.000000000000000000001}', '{"result":true}', '{"result":42,"result":43}', '{"result":NaN}']
    for output in bad_values:
        try:
            a.validate_clarified_value(output,Decimal(42))
        except (ValueError,ArithmeticError):
            check(True,'Rejected ambiguous or false value')
        else:
            raise AssertionError('Incorrect clarification accepted: '+output)
    a.validate_clarified_value('{"result":42.000000000000000000000}',Decimal(42))
    check(True,'Exact decimal equality accepted')
    check(hashlib.sha256((HERE/'numeric_support.py').read_bytes()).digest() == hashlib.sha256((HERE.parent.parent/'arithmetic_holdout/numeric_support.py').read_bytes()).digest(),'Original numerical judge byte-preserved')
    report={'status':'passed','checks':checks,'author':'/root/bidir_analysis_prepare/independent_analysis_review',
            'scope':'Independent direct-formula and exhaustive unknown-bound oracles, exact zero signs, 20000-cluster bootstrap cross-check, controls and numeric precision. No models, tokenizer, weights, runtime journals or outcome data read.',
            'pre_data':True,'source_sha256':{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ['analyze.py','Protocol.md','seal_review.py','test_analysis.py','independent_review_checks.py']}}
    (HERE/'independent_review_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__ == '__main__':
    main()
