"""Prospective bidirectional analysis. Default reads no new run outcomes."""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import decimal
import hashlib
import json
import math
from pathlib import Path
import random
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BANK = ROOT.parent/'arithmetic_bidirectional_preparation'
sys.path.insert(0, str(ROOT))
import run_bidirectional as runtime
from numeric_support import judge, EQUATION

CONFIGS = ['dolos_native','dolos_from_qwen','qwen_native','qwen_from_dolos']
CONDITIONS = [('derive','plain'),('derive','json'),('copy','plain'),('copy','json')]
CONTROLS = [('derive','plain'),('copy','plain'),('copy','json')]
SEMANTICS = ['correct','error','unknown']
REPRESENTATIONS = ['scalar','single_equation','result_object','other_json','single_result_prose',
                   'ambiguous_or_malformed','empty','capped_sequence','other']
DIRECTIONS = {'repair':('dolos_native','dolos_from_qwen'),
              'worsening':('qwen_native','qwen_from_dolos')}
BOOTSTRAP_SEED = 2026102532
RESAMPLES = 20000


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def text_sha(value):
    return hashlib.sha256(value.encode()).hexdigest()


def load(path):
    return runtime.strict_json(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write_new(path, data):
    with Path(path).open('x') as handle:
        handle.write(json.dumps(data, indent=2, allow_nan=False)+'\n')


def verify_inputs():
    freeze = load(HERE/'analysis_freeze.json')
    for name, wanted in freeze['files_sha256'].items():
        require(sha(HERE/name) == wanted, 'Changed analysis source/input: '+name)
    prepared, core_sha = runtime.validate_preflight()
    require(sha(ROOT/'pre_run_freeze.json') == freeze['execution_freeze_sha256'], 'Wrong execution freeze')
    require(sha(BANK/'preparation_freeze.json') == freeze['bank_freeze_sha256'], 'Wrong bank freeze')
    return prepared, core_sha, runtime.make_plan(prepared, core_sha)


def validate_completed(prepared, core_sha, plan):
    records = runtime.read_records(ROOT/'results.jsonl')
    receipts = runtime.read_records(ROOT/'weight_events.jsonl')
    events = runtime.read_records(ROOT/'execution_events.jsonl')
    require(len(records) == len({r['request_id'] for r in records}) == 224, 'Complete224 unique records required')
    require(len(receipts) == len({r['request_id'] for r in receipts}), 'Duplicate weight journal IDs')
    require(len(events) == len({r['request_id'] for r in events}), 'Duplicate execution journal IDs')
    native = runtime.validate_resume(records, receipts, events, prepared, plan, core_sha)
    require(len(native) == 96, 'Expected96 fresh native cells')
    # Cached tokenizer only, imported exclusively after explicit --score.
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(prepared['tokenizer']['repo'], revision=prepared['tokenizer']['revision'],
                                       token=False, local_files_only=True)
    require(runtime.make_request_id({'template':tok.chat_template}) == prepared['tokenizer']['chat_template_sha256'], 'Template drift')
    for prompt in prepared['prompts']:
        require(tok.apply_chat_template(prompt['messages'], tokenize=True, add_generation_prompt=True, return_dict=False)
                == prompt['input_token_ids'], 'Input token drift')
    for row in records:
        require(tok.decode(row['output_token_ids'], skip_special_tokens=True) == row['output'], 'Output/token mismatch')
        for key in ['runtime_seconds','generation_seconds','model_load_seconds']:
            require(isinstance(row[key], (int,float)) and math.isfinite(row[key]) and row[key] >= 0, 'Invalid runtime')
        require(0 <= row['peak_rss_bytes'] <= runtime.RSS_LIMIT, 'Response RSS limit exceeded')
    starts = [e for e in events if e['kind'] == 'generation_started']
    completed = [e for e in events if e['kind'] == 'generation_completed']
    for row in starts+completed:
        require(0 <= row['peak_rss_bytes'] <= runtime.RSS_LIMIT, 'Generation event RSS limit exceeded')
    counts = Counter(r['model']['kind'] for r in records)
    require(counts == {'native_baseline':96,'unforced_hybrid':96,'native_restoration_sham':32}, 'Wrong phase counts')
    shams = [r for r in records if r['model']['kind'] == 'native_restoration_sham']
    require(all(r['sham_matches_baseline'] is True for r in shams), 'Failed restoration sham')
    return records, {'created_utc':now(), 'status':'passed', 'records':224, 'main_records':192,
            'fresh_native_records':96,'unforced_hybrid_records':96,'native_restoration_repeats':32,
            'exact_sham_matches':32,'finish_counts':dict(Counter(r['finish_reason'] for r in records)),
            'results_sha256':sha(ROOT/'results.jsonl'),'weight_events_sha256':sha(ROOT/'weight_events.jsonl'),
            'execution_events_sha256':sha(ROOT/'execution_events.jsonl'),'execution_freeze_sha256':core_sha,
            'analysis_freeze_sha256':sha(HERE/'analysis_freeze.json'),
            'generation_starts':len(starts),'generation_completions':len(completed),
            'completed_attempts_beyond_committed_records':len(completed)-224,
            'stopped_attempt_events':[e for e in events if e['kind'] == 'run_stopped'],
            'scope':'Saved records, exact fresh same-base shams, full receipt maps and source/token checks. No model call; no independent replay of past live parameter values.'}


def config_for(record):
    base, kind = record['model']['base_name'], record['model']['kind']
    require(base in ['dolos','qwen'] and kind in runtime.KINDS, 'Invalid base/kind')
    return base+'_from_'+runtime.donor_for(base) if kind == 'unforced_hybrid' else base+'_native'


def equation_check(output, metadata):
    body = output.strip()
    fence = re.fullmatch(r'```[A-Za-z0-9_-]*[ \t]*\n(.*?)\n```',body,re.S)
    if fence:
        body = fence[1].strip()
    match = re.fullmatch(EQUATION,body)
    if not match:
        return None
    a, op, b, value = match.groups()
    a,b,value = map(decimal.Decimal,[a,b,value])
    try:
        calculated = a+b if op == '+' else a-b if op == '-' else a*b if op in ['*','×','times'] else a/b
        consistent = calculated == value
    except decimal.DecimalException:
        consistent = False
    wanted_op = '+' if metadata['operation'] == 'add' else '*'
    actual_op = '*' if op in ['*','×','times'] else '/' if op == '÷' else op
    return {'arithmetic_consistent':consistent,
            'matches_requested_operation_and_ordered_operands':actual_op == wanted_op and (a,b) == (decimal.Decimal(metadata['a']),decimal.Decimal(metadata['b'])),
            'written_expression':body,'scope':'Additional diagnostic; does not change the frozen final-RHS primary judgment.'}


def score_rows(records):
    rows = []
    for record in records:
        meta = record['metadata']
        require(meta['operation'] in ['add','multiply'], 'Unknown operation')
        gold = meta['a']+meta['b'] if meta['operation'] == 'add' else sum(meta['a'] for _ in range(meta['b']))
        require(gold == meta['gold'], 'Gold failed independent arithmetic check')
        automatic = judge(record['output'],gold,meta['format'],record['finish_reason'])
        rows.append({'request_id':record['request_id'],'prompt_id':record['prompt_id'],**meta,
                     'configuration':config_for(record),'kind':record['model']['kind'],
                     'sham_baseline_request_id':record.get('sham_baseline_request_id'),
                     'output':record['output'],'output_sha256':text_sha(record['output']),
                     'finish_reason':record['finish_reason'],'automatic_judgment':automatic,
                     'judgment':dict(automatic),'additional_equation_consistency':equation_check(record['output'],meta),
                     'representation':'unreviewed'})
    return rows


def review_template(rows, validation, scores_sha):
    return {'results_sha256':validation['results_sha256'],'analysis_freeze_sha256':validation['analysis_freeze_sha256'],
            'automatic_scores_sha256':scores_sha,'reviewer':'','disclosure':'','all_outputs_read':False,
            'records':[{'request_id':r['request_id'],'output':r['output'],'output_sha256':r['output_sha256'],
                        'automatic_judgment':r['automatic_judgment'],'reviewed':False,
                        'semantic':r['judgment']['semantic'],'representation':'unreviewed',
                        'evidence_quote':r['output'],'reason':'','answer_decimal':None} for r in rows]}


def validate_clarified_value(output, answer):
    """Do not silently accept duplicate keys, booleans or multiple JSON values.

    This is an extra guard on a human-reviewed unknown, not an automatic judge.
    Non-JSON prose still requires the complete explicit reviewer assessment.
    """
    body = output.strip()
    fence = re.fullmatch(r'```[A-Za-z0-9_-]*[ \t]*\n(.*?)\n```',body,re.S)
    if fence:
        body = fence[1].strip()
    if not body.startswith(('{','[','"')):
        return
    # Keep written decimal precision: ordinary json float parsing could round a
    # near-gold answer to gold before the independent semantic comparison.
    def pairs(items):
        result = {}
        for key,value in items:
            require(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError('Nonfinite JSON constant: '+value)
    value = json.loads(body, object_pairs_hook=pairs, parse_float=decimal.Decimal,
                       parse_int=decimal.Decimal, parse_constant=nonfinite)
    if isinstance(value,dict):
        require(len(value) == 1, 'Clarified JSON must have one unambiguous result value')
        value = next(iter(value.values()))
    require(type(value) in [int,float,str,decimal.Decimal], 'Boolean, array or nested JSON is not one reviewed numeric answer')
    try:
        parsed = decimal.Decimal(str(value))
    except decimal.InvalidOperation:
        raise ValueError('Invalid clarified JSON numeric answer')
    require(parsed.is_finite() and parsed == answer, 'JSON answer disagrees with reviewed decimal')


def apply_review(rows, review, clarifications, freeze, validation, scores_sha):
    require(review['results_sha256'] == clarifications['results_sha256'] == freeze['results_sha256'] == validation['results_sha256'], 'Review result binding')
    require(review['analysis_freeze_sha256'] == freeze['analysis_freeze_sha256'] == validation['analysis_freeze_sha256'], 'Review analysis binding')
    require(review['automatic_scores_sha256'] == freeze['automatic_scores_sha256'] == scores_sha, 'Review automatic-score binding')
    require(review['all_outputs_read'] is True and bool(review['reviewer'].strip()) and bool(review['disclosure'].strip()), 'Missing complete-review disclosure')
    ri = {r['request_id']:r for r in review['records']}
    ci = {r['request_id']:r for r in clarifications['records']}
    require(len(ri) == len(review['records']) == len(rows) and set(ri) == {r['request_id'] for r in rows}, 'Review must cover all224 exactly once')
    unknown = {r['request_id'] for r in rows if r['automatic_judgment']['semantic'] == 'unknown'}
    require(len(ci) == len(clarifications['records']) and set(ci) == unknown, 'Clarifications must cover exactly all automatic unknowns')
    output = []
    for row in rows:
        v = ri[row['request_id']]
        require(v['reviewed'] is True and v['output'] == row['output'] and v['output_sha256'] == row['output_sha256'], 'Full-output review mismatch')
        require(v['automatic_judgment'] == row['automatic_judgment'], 'Automatic judgment altered')
        require(v['semantic'] in SEMANTICS and v['representation'] in REPRESENTATIONS, 'Invalid semantic/representation label')
        require(v['evidence_quote'] == row['output'] and bool(v['reason'].strip()), 'Whole-output evidence/reason required')
        if row['request_id'] in unknown:
            require(ci[row['request_id']] == {k:v[k] for k in ['request_id','semantic','evidence_quote','reason','answer_decimal']}, 'Clarification disagrees with full review')
            if v['semantic'] != 'unknown':
                require(row['finish_reason'] == 'eos', 'Capped response cannot be clarified as complete')
                require(isinstance(v['answer_decimal'],str), 'Resolved unknown needs one explicitly reviewed numeric answer')
                answer = decimal.Decimal(v['answer_decimal'])
                require(answer.is_finite() and ('correct' if answer == decimal.Decimal(row['gold']) else 'error') == v['semantic'], 'Clarified numeric value/gold mismatch')
                validate_clarified_value(row['output'],answer)
        else:
            require(v['semantic'] == row['automatic_judgment']['semantic'], 'Accepted automatic primary judgment cannot be overwritten')
        require(row['finish_reason'] == 'eos' or (v['semantic'] == 'unknown' and v['representation'] == 'capped_sequence'), 'Incomplete output review must preserve uncertainty')
        output.append({**row,'judgment':{**row['judgment'],'semantic':v['semantic']},
                       'representation':v['representation'],'review_reason':v['reason'],
                       'reviewed_answer_decimal':v['answer_decimal']})
    index = {r['request_id']:r for r in output}
    for row in output:
        if row['kind'] == 'native_restoration_sham':
            baseline = index[row['sham_baseline_request_id']]
            require((row['output'],row['judgment'],row['representation']) ==
                    (baseline['output'],baseline['judgment'],baseline['representation']), 'Identical sham/native outputs have inconsistent review')
    return output


def contrast(cells, weights):
    point = low = high = 0
    for key, coefficient in weights.items():
        require(type(coefficient) is int, 'Exact integer contrast coefficients required')
        status = cells[key]
        require(status in SEMANTICS, 'Invalid semantic label in contrast')
        if status == 'unknown':
            low += min(0,coefficient)
            high += max(0,coefficient)
        else:
            value = int(status == 'correct')*coefficient
            point += value
            low += value
            high += value
    return {'value':point,'unresolved_lower':low,'unresolved_upper':high}


def combine(*terms):
    weights = Counter()
    for multiplier, term in terms:
        for key, coefficient in term.items():
            weights[key] += multiplier*coefficient
    return {key:value for key,value in weights.items() if value}


def f_weights(configuration):
    return {(configuration,mode,fmt):sign for (mode,fmt),sign in zip(CONDITIONS,[1,-1,-1,1])}


def metric_weights():
    fs = {c:f_weights(c) for c in CONFIGS}
    out = {'F/'+c:w for c,w in fs.items()}
    out['repair_mean'] = {('dolos_from_qwen','derive','json'):1,('dolos_native','derive','json'):-1}
    out['worsening_mean'] = {('qwen_native','derive','json'):1,('qwen_from_dolos','derive','json'):-1}
    out['selective_repair'] = combine((1,fs['dolos_native']),(-1,fs['dolos_from_qwen']))
    out['selective_worsening'] = combine((1,fs['qwen_from_dolos']),(-1,fs['qwen_native']))
    out['J/native'] = combine((1,fs['dolos_native']),(-1,fs['qwen_native']))
    out['J/dolos_hybrid_vs_native_qwen'] = combine((1,fs['dolos_from_qwen']),(-1,fs['qwen_native']))
    out['J/native_dolos_vs_qwen_hybrid'] = combine((1,fs['dolos_native']),(-1,fs['qwen_from_dolos']))
    for direction,(native,hybrid) in DIRECTIONS.items():
        for mode,fmt in CONTROLS:
            out[f'control_change/{direction}/{mode}/{fmt}'] = {(hybrid,mode,fmt):1,(native,mode,fmt):-1}
    return out


def transition(before, after):
    require(before in SEMANTICS and after in SEMANTICS, 'Invalid transition label')
    if 'unknown' in [before,after]:
        return 'unknown'
    return 'both_'+before if before == after else 'gain' if after == 'correct' else 'loss'


def quantile(values, probability):
    values = sorted(values)
    position = (len(values)-1)*probability
    lo = int(position)
    hi = min(lo+1,len(values)-1)
    return values[lo]+(values[hi]-values[lo])*(position-lo)


def bootstrap(task_rows, resamples=RESAMPLES, seed=BOOTSTRAP_SEED):
    groups = {s:[r for r in task_rows if r['structure'] == s] for s in sorted({r['structure'] for r in task_rows})}
    require(len(groups) == 4 and all(len(rows) == 3 for rows in groups.values()), 'Four strata with three tasks required')
    names = list(task_rows[0]['metrics'])
    distributions = {name:[] for name in names}
    rng = random.Random(seed)
    for _ in range(resamples):
        sampled = [rng.choice(rows) for rows in groups.values() for _ in range(3)]
        for name in names:
            distributions[name].append(sum(row['metrics'][name]['value'] for row in sampled)/12)
    return {name:[quantile(values,.025),quantile(values,.975)] for name,values in distributions.items()}


def aggregate(rows, integrity, reviewed=False, resamples=RESAMPLES, seed=BOOTSTRAP_SEED):
    main = [r for r in rows if r['kind'] != 'native_restoration_sham']
    index = {(r['task_id'],r['configuration'],r['mode'],r['format']):r for r in main}
    tasks = sorted({r['task_id'] for r in main})
    expected = {(task,c,m,f) for task in tasks for c in CONFIGS for m,f in CONDITIONS}
    require(len(tasks) == 12 and len(index) == len(main) == 192 and set(index) == expected, 'All192 main cells required exactly once')
    weights = metric_weights()
    task_rows = []
    paired = {direction:[] for direction in DIRECTIONS}
    for task in tasks:
        cells = {(c,m,f):index[task,c,m,f]['judgment']['semantic'] for c in CONFIGS for m,f in CONDITIONS}
        first = index[task,CONFIGS[0],'derive','plain']
        require(all(index[task,c,m,f]['operation'] == first['operation'] and index[task,c,m,f]['structure'] == first['structure']
                    and index[task,c,m,f]['gold'] == first['gold'] for c in CONFIGS for m,f in CONDITIONS), 'Task metadata disagree across configurations')
        task_rows.append({'task_id':task,'operation':first['operation'],'structure':first['structure'],'gold':first['gold'],
                          'cells':{'/'.join(key):{'semantic':status,'literal_format_compliant':index[(task,*key)]['judgment']['format_compliant'],
                                                 'representation':index[(task,*key)]['representation'],'request_id':index[(task,*key)]['request_id']}
                                   for key,status in cells.items()},
                          'metrics':{name:contrast(cells,w) for name,w in weights.items()}})
        for direction,(native,hybrid) in DIRECTIONS.items():
            for mode,fmt in CONDITIONS:
                before,after = index[task,native,mode,fmt],index[task,hybrid,mode,fmt]
                a,b = before['judgment']['semantic'],after['judgment']['semantic']
                paired[direction].append({'task_id':task,'operation':first['operation'],'structure':first['structure'],
                                          'condition':mode+'/'+fmt,'native_request_id':before['request_id'],'hybrid_request_id':after['request_id'],
                                          'native':a,'hybrid':b,'transition':transition(a,b),
                                          'native_representation':before['representation'],'hybrid_representation':after['representation'],
                                          'demonstrated_delta':int(b == 'correct')-int(a == 'correct')})
    intervals = bootstrap(task_rows,resamples,seed)
    numerators = {name:{field:sum(r['metrics'][name][field] for r in task_rows)
                       for field in ['value','unresolved_lower','unresolved_upper']} for name in weights}
    metrics = {name:{**{field:value/12 for field,value in numerators[name].items()},
                     'exact_integer_numerators':numerators[name],'denominator':12,
                     'bootstrap_percentile95':intervals[name]} for name in weights}
    counts = {name:{field:sum(r['metrics'][metric][field] for r in task_rows) for field in ['value','unresolved_lower','unresolved_upper']}
              for name,metric in [('R','repair_mean'),('W','worsening_mean')]}
    controls = {}
    for direction,pairs in paired.items():
        control_pairs = [p for p in pairs if p['condition'] != 'derive/json']
        losses = [p for p in control_pairs if p['transition'] == 'loss']
        unresolved = [p for p in control_pairs if p['transition'] == 'unknown']
        controls[direction] = {'matched_pairs':36,'newly_lost_correct_answers':losses,'unresolved_pairs':unresolved,
                               'all_controls_resolved':not unresolved,'no_new_matched_correctness_loss':not losses,
                               'passed':not losses and not unresolved}
    components = {'net_repair_lower_at_least2':counts['R']['unresolved_lower'] >= 2,
                  'net_worsening_lower_at_least2':counts['W']['unresolved_lower'] >= 2,
                  'repair_controls_resolved_and_no_new_loss':controls['repair']['passed'],
                  'worsening_controls_resolved_and_no_new_loss':controls['worsening']['passed'],
                  'selective_repair_lower_strictly_positive':numerators['selective_repair']['unresolved_lower'] > 0,
                  'selective_worsening_lower_strictly_positive':numerators['selective_worsening']['unresolved_lower'] > 0,
                  'all_integrity_and32_shams_pass':integrity.get('status') == 'passed' and integrity.get('exact_sham_matches') == 32}
    summaries = {}
    for dimension,levels in [('all',['all']),('operation',sorted({r['operation'] for r in main})),('structure',sorted({r['structure'] for r in main}))]:
        for level in levels:
            for config in CONFIGS:
                for mode,fmt in CONDITIONS:
                    subset = [r for r in main if r['configuration'] == config and (r['mode'],r['format']) == (mode,fmt) and (dimension == 'all' or r[dimension] == level)]
                    c = Counter(r['judgment']['semantic'] for r in subset)
                    summaries[f'{dimension}/{level}/{config}/{mode}/{fmt}'] = {'n':len(subset),**{s:c[s] for s in SEMANTICS},
                                    'literal_format_compliant':sum(r['judgment']['format_compliant'] for r in subset)}
    representations = {}
    for direction,pairs in paired.items():
        grouped = {}
        for pair in pairs:
            key = pair['condition']+'/'+pair['native_representation']+'->'+pair['hybrid_representation']
            grouped.setdefault(key,[]).append(pair)
        representations[direction] = {key:{'n':len(ps),'task_ids':[p['task_id'] for p in ps],
                  'native_correct':sum(p['native'] == 'correct' for p in ps),'hybrid_correct':sum(p['hybrid'] == 'correct' for p in ps),
                  'net_demonstrated_correctness_change':sum(p['demonstrated_delta'] for p in ps),
                  'transitions':dict(Counter(p['transition'] for p in ps))} for key,ps in grouped.items()}
    equations = [r for r in main if r['additional_equation_consistency'] is not None]
    return {'task_rows':task_rows,'paired_transitions':paired,'summaries':summaries,'metrics':metrics,'net_counts':counts,
            'controls':controls,'representation_transitions':representations,
            'equation_diagnostics':[{'request_id':r['request_id'],**r['additional_equation_consistency']} for r in equations],
            'gate':{'status':'pending_full_output_review' if not reviewed else 'supports_narrow_bidirectional_contribution' if all(components.values()) else 'criteria_not_met',
                    'components':components,'mathematical_and_integrity_criteria_demonstrated':all(components.values()),
                    'planted_misalignment_identified':False,'representation_held_fixed':False,
                    'scope':'Local parameter contribution only; representation confounding, training intent and planted objective remain unresolved.'},
            'bootstrap':{'seed':seed,'resamples':resamples,'unit':'12 expression clusters; all16 main cells retained',
                         'stratification':'four operation/structure strata, three draws within each','shams_excluded':32,
                         'metric':'demonstrated correctness: correct1; error or unknown0; semantic categories and unresolved bounds separate',
                         'confidence_interval_lower_bound_is_not_a_success_criterion':True},
            'unresolved_main_records':sum(r['judgment']['semantic'] == 'unknown' for r in main)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--score',action='store_true')
    parser.add_argument('--review',type=Path)
    parser.add_argument('--clarifications',type=Path)
    parser.add_argument('--review-freeze',type=Path)
    args = parser.parse_args()
    prepared,core_sha,plan = verify_inputs()
    if not args.score:
        require(not any([args.review,args.clarifications,args.review_freeze]), 'Review arguments require --score')
        print('Analysis dry run passed. No bidirectional result/weight/execution or external-panel outputs read; no tokenizer/model imports or calls.')
        return
    require(all([args.review,args.clarifications,args.review_freeze]) or not any([args.review,args.clarifications,args.review_freeze]), 'Supply all three review paths together')
    records,validation = validate_completed(prepared,core_sha,plan)
    rows = score_rows(records)
    if args.review:
        auto = load(HERE/'scores.json')
        require(auto['results_sha256'] == validation['results_sha256'] and auto['records'] == rows, 'Saved automatic judgments mismatch')
        review,clarifications,rf = map(load,[args.review,args.clarifications,args.review_freeze])
        require(rf['review_sha256'] == sha(args.review) and rf['clarifications_sha256'] == sha(args.clarifications), 'Unsealed review files')
        rows = apply_review(rows,review,clarifications,rf,validation,sha(HERE/'scores.json'))
    summary = aggregate(rows,validation,reviewed=bool(args.review))
    result = {'created_utc':now(),'results_sha256':validation['results_sha256'],'analysis_freeze_sha256':sha(HERE/'analysis_freeze.json'),
              'review_sha256':sha(args.review) if args.review else None,'clarifications_sha256':sha(args.clarifications) if args.review else None,
              'review_freeze_sha256':sha(args.review_freeze) if args.review else None,
              'scope':'96 fresh native responses,96 unforced hybrids,32 repeated native integrity checks;12 task clusters. All224 outputs retained;192 main cells aggregated.',
              'records':rows,**summary}
    target = HERE/('scores_reviewed.json' if args.review else 'scores.json')
    write_new(target,result)
    if not args.review:
        write_new(HERE/'record_validation.json',validation)
        write_new(HERE/'review_template.json',review_template(rows,validation,sha(target)))
    print(json.dumps({'saved':str(target),'net_counts':summary['net_counts'],'gate':summary['gate']},indent=2))


if __name__ == '__main__':
    main()
