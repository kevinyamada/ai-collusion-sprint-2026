"""Seal complete future output review before reviewed aggregation; no inference."""
import argparse
from pathlib import Path
import analyze as a


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seal',action='store_true')
    parser.add_argument('--review',type=Path)
    args = parser.parse_args()
    a.verify_inputs()
    if not args.seal:
        a.require(args.review is None, 'Review path requires explicit --seal')
        print('Review-sealer dry run; no output or review files read.')
        return
    a.require(args.review is not None, '--review required')
    for name in ['manual_clarifications.json','manual_review_freeze.json','scores_reviewed.json']:
        a.require(not (a.HERE/name).exists(), 'Refusing to replace an existing reviewed artifact: '+name)
    scores = a.load(a.HERE/'scores.json')
    validation = a.load(a.HERE/'record_validation.json')
    a.require(scores['results_sha256'] == validation['results_sha256'] == a.sha(a.ROOT/'results.jsonl'), 'Raw result changed')
    a.require(len(scores['records']) == 224, 'Need all224 automatic rows')
    review = a.load(args.review)
    unknown = {row['request_id'] for row in scores['records'] if row['automatic_judgment']['semantic'] == 'unknown'}
    clarification = {'results_sha256':validation['results_sha256'],
                     'records':[{key:row[key] for key in ['request_id','semantic','evidence_quote','reason','answer_decimal']}
                                for row in review['records'] if row['request_id'] in unknown]}
    freeze = {'created_utc':a.now(),'status':'FULL_REVIEW_FROZEN_BEFORE_REVIEWED_AGGREGATION',
              'results_sha256':validation['results_sha256'],'analysis_freeze_sha256':a.sha(a.HERE/'analysis_freeze.json'),
              'automatic_scores_sha256':a.sha(a.HERE/'scores.json'),'review_sha256':a.sha(args.review),
              'reviewer':review['reviewer'],'disclosure':review['disclosure'],'full_outputs':224,'automatic_unknowns':len(unknown)}
    a.apply_review(scores['records'],review,clarification,freeze,validation,a.sha(a.HERE/'scores.json'))
    a.write_new(a.HERE/'manual_clarifications.json',clarification)
    freeze['clarifications_sha256'] = a.sha(a.HERE/'manual_clarifications.json')
    a.write_new(a.HERE/'manual_review_freeze.json',freeze)
    print('Full224-output review sealed; automatic judgments preserved; no reviewed aggregation or model call.')


if __name__ == '__main__':
    main()
