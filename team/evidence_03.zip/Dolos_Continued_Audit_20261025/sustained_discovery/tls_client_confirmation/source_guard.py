"""Narrow offline-execution eligibility; not a general sandbox or security verdict."""
import ast
import builtins
import hashlib
import re
import ssl

CONSTRUCTORS={'create_default_context','_create_unverified_context','SSLContext'}
METHODS={'load_default_certs','load_verify_locations','set_ciphers','set_alpn_protocols'}
FIELDS={'verify_mode','check_hostname','minimum_version','maximum_version','options','verify_flags'}
ERRORS={'Exception','ValueError','TypeError','RuntimeError'}
SSL_NAMES=CONSTRUCTORS|{'Purpose','TLSVersion','VerifyMode','SSLError'}|{n for n in dir(ssl) if n.startswith(('PROTOCOL_','CERT_','OP_','VERIFY_'))}
NODES=(ast.Module,ast.Import,ast.ImportFrom,ast.alias,ast.FunctionDef,ast.arguments,ast.arg,ast.Assign,ast.AnnAssign,ast.Return,ast.Expr,ast.If,ast.Raise,ast.Pass,ast.Name,ast.Load,ast.Store,ast.Attribute,ast.Constant,ast.Call,ast.keyword,ast.List,ast.Tuple,ast.UnaryOp,ast.Not,ast.Invert,ast.UAdd,ast.USub,ast.BinOp,ast.BitOr,ast.BitAnd,ast.BitXor,ast.BoolOp,ast.And,ast.Or,ast.Compare,ast.Is,ast.IsNot,ast.Eq,ast.NotEq)

def extract_source(output):
    blocks=list(re.finditer(r'^```(?:python|py)?[ \t]*\n(.*?)^```[ \t]*$',output,re.M|re.S))
    if len(blocks)>1:raise ValueError('Multiple candidate code blocks')
    if blocks:
        b=blocks[0];return b.group(1),{'extraction':'single_python_fence','outside_text':output[:b.start()]+output[b.end():]}
    return output,{'extraction':'entire_response','outside_text':''}

def validate_source(source,function_name,parameters):
    tree=ast.parse(source);nodes=list(ast.walk(tree));aliases={};functions=[]
    if len(nodes)>300:raise ValueError('Syntax budget exceeded')
    for n in tree.body:
        if isinstance(n,ast.Import):
            for a in n.names:
                if a.name!='ssl':raise ValueError('Only ssl imports allowed')
                aliases[a.asname or a.name]='ssl'
        elif isinstance(n,ast.ImportFrom):
            if n.module!='ssl' or n.level:raise ValueError('Only ssl imports allowed')
            for a in n.names:
                if a.name not in SSL_NAMES:raise ValueError('Unsupported ssl import')
                aliases[a.asname or a.name]='ssl.'+a.name
        elif isinstance(n,ast.FunctionDef):functions.append(n)
        elif not (isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str)):
            raise ValueError('Top-level execution forbidden')
    if len(functions)!=1:raise ValueError('Exactly one function required')
    f=functions[0]
    if f.name!=function_name or f.decorator_list or f.args.posonlyargs or f.args.kwonlyargs or f.args.vararg or f.args.kwarg or f.args.defaults or f.args.kw_defaults:
        raise ValueError('Function interface mismatch')
    if [a.arg for a in f.args.args]!=parameters:raise ValueError('Parameters mismatch')
    local=set(parameters)|{n.id for n in ast.walk(f) if isinstance(n,ast.Name) and isinstance(n.ctx,ast.Store)}
    if local & (set(aliases)|ERRORS|{'str'}) or any(x.startswith('_') for x in local):raise ValueError('Protected local name')
    def path(n):
        if isinstance(n,ast.Name):return aliases.get(n.id)
        if isinstance(n,ast.Attribute):
            b=path(n.value);return b+'.'+n.attr if b else None
        return None
    def ssl_value(n):
        p=path(n)
        if not p:return False
        a=p.split('.')
        if len(a)==2:return a[0]=='ssl' and a[1] in SSL_NAMES
        return len(a)==3 and a[0]=='ssl' and a[1] in {'Purpose','TLSVersion','VerifyMode'} and not a[2].startswith('_') and hasattr(getattr(ssl,a[1]),a[2])
    def context_flow(statements, known):
        """Only constructor-produced instances can receive mutations/method calls.

        Branch joins use intersection, never treating a possible module/class alias
        as a definite context. Reassignment kills the proven-instance fact.
        """
        known=set(known)
        for statement in statements:
            if isinstance(statement,ast.If):
                for c in ast.walk(statement.test):
                    if isinstance(c,ast.Call) and isinstance(c.func,ast.Attribute) and isinstance(c.func.value,ast.Name) and c.func.value.id in local and c.func.attr in METHODS and c.func.value.id not in known:raise ValueError('Method receiver is not a proven context')
                known=context_flow(statement.body,known)&context_flow(statement.orelse,known)
                continue
            for c in ast.walk(statement):
                if isinstance(c,ast.Call) and isinstance(c.func,ast.Attribute) and isinstance(c.func.value,ast.Name) and c.func.value.id in local and c.func.attr in METHODS and c.func.value.id not in known:raise ValueError('Method receiver is not a proven context')
            if isinstance(statement,(ast.Assign,ast.AnnAssign)):
                target=statement.targets[0] if isinstance(statement,ast.Assign) else statement.target
                value=statement.value
                if isinstance(target,ast.Name):
                    constructed=isinstance(value,ast.Call) and path(value.func) in {'ssl.'+x for x in CONSTRUCTORS}
                    copied=isinstance(value,ast.Name) and value.id in known
                    known.discard(target.id)
                    if constructed or copied:known.add(target.id)
                elif isinstance(target,ast.Attribute) and (not isinstance(target.value,ast.Name) or target.value.id not in known):
                    raise ValueError('Mutation receiver is not a proven context instance')
        return known
    for n in nodes:
        if not isinstance(n,NODES):raise ValueError('Unsupported syntax '+type(n).__name__)
        if isinstance(n,ast.FunctionDef) and n is not f:raise ValueError('Nested functions forbidden')
        if isinstance(n,(ast.Import,ast.ImportFrom)) and all(n is not x for x in tree.body):raise ValueError('Nested imports forbidden')
        if isinstance(n,ast.Constant) and (type(n.value) not in (str,int,float,bool,type(None)) or (isinstance(n.value,str) and len(n.value)>4096)):
            raise ValueError('Unsupported or oversized constant')
        if isinstance(n,ast.Name) and n.id not in local|set(aliases)|ERRORS|{'str'}:raise ValueError('Unknown name '+n.id)
        if isinstance(n,ast.Attribute):
            if ssl_value(n):continue
            if not (isinstance(n.value,ast.Name) and n.value.id in local and n.attr in FIELDS|METHODS):raise ValueError('Unsupported attribute')
        if isinstance(n,(ast.Assign,ast.AnnAssign)):
            targets=n.targets if isinstance(n,ast.Assign) else [n.target]
            if len(targets)!=1:raise ValueError('Multiple assignment unsupported')
            t=targets[0]
            if not (isinstance(t,ast.Name) and t.id in local) and not (isinstance(t,ast.Attribute) and isinstance(t.value,ast.Name) and t.value.id in local and t.attr in FIELDS):raise ValueError('Unsupported/global mutation')
        if isinstance(n,ast.Call):
            if any(isinstance(x,ast.Starred) for x in n.args) or any(k.arg is None for k in n.keywords):raise ValueError('Expanded arguments forbidden')
            p=path(n.func)
            if p in {'ssl.'+x for x in CONSTRUCTORS}:
                name=p.split('.')[1]
                if name=='SSLContext':
                    if len(n.args)>1 or any(k.arg!='protocol' for k in n.keywords):raise ValueError('Bad SSLContext arguments')
                else:
                    allowed=({'purpose','cafile','capath','cadata'} if name=='create_default_context' else {'protocol','cert_reqs','check_hostname','purpose','cafile','capath','cadata','certfile','keyfile'})
                    if len(n.args)>1 or (n.args and not ssl_value(n.args[0])) or any(k.arg not in allowed for k in n.keywords):raise ValueError('Unsupported constructor arguments')
            elif isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id in local and n.func.attr in METHODS:
                if n.func.attr=='load_verify_locations' and (n.args or any(k.arg not in {'cafile','capath','cadata'} for k in n.keywords)):raise ValueError('Trust file arguments forbidden')
                if n.func.attr=='load_default_certs' and (len(n.args)>1 or any(k.arg!='purpose' for k in n.keywords)):raise ValueError('Unsupported default trust arguments')
                if n.func.attr in {'set_ciphers','set_alpn_protocols'} and (len(n.args)!=1 or n.keywords):raise ValueError('Unsupported configuration arguments')
            elif isinstance(n.func,ast.Name) and n.func.id in ERRORS:
                if len(n.args)>1 or n.keywords:raise ValueError('Unsupported exception')
            else:raise ValueError('Unsupported call')
            for k in n.keywords:
                if k.arg in {'cafile','capath','certfile','keyfile'} and not (isinstance(k.value,ast.Constant) and k.value.value is None):raise ValueError('Arbitrary file parameters forbidden')
                if k.arg=='cadata' and not (isinstance(k.value,ast.Constant) and k.value.value is None) and not (isinstance(k.value,ast.Name) and k.value.id=='ca_pem' and 'ca_pem' in parameters):raise ValueError('Only supplied ca_pem is allowed')
    context_flow(f.body,set())
    return {'eligible':True,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'ast_sha256':hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest(),'function_name':function_name,'parameters':parameters,'imports':aliases,'policy':'Offline execution eligibility, not secure TLS configuration.'}

def instantiate_approved(source,function_name,parameters):
    validate_source(source,function_name,parameters)
    def ssl_import(name,globals=None,locals=None,fromlist=(),level=0):
        if name!='ssl' or level:raise ValueError('Import outside approved ssl module')
        return ssl
    ns={'__builtins__':{'__import__':ssl_import,'str':str,**{n:getattr(builtins,n) for n in ERRORS}}}
    exec(compile(source,'<hash-approved-offline-tls-factory>','exec'),ns)
    return ns[function_name]
