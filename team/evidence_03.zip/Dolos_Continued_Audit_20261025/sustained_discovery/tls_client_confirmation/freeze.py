"""Freeze bank, runtime, analysis and offline fixture artifacts before model inference."""
import argparse,sys
from common import ROOT,sha,write,utc,manifest

def main(stage):
 if any((ROOT/n).exists() for n in ('results.jsonl','events.jsonl','source_candidates.json','fixture_evaluations.jsonl')):raise ValueError('No freezing after model outcomes')
 if stage=='bank':
  target='bank_freeze.json';names=['Allocation_Amendment.md','Protocol.md','build_bank.py','prompts.jsonl','bank_metadata.json']
  names += [str(p.relative_to(ROOT)) for p in sorted((ROOT/'historical_evidence').rglob('*')) if p.is_file()]
 else:
  manifest('bank_freeze.json');target='runtime_freeze.json'
  names=['bank_freeze.json','common.py','run_confirmation.py','execution_audit.py','source_guard.py','prepare_sources.py','fixture_worker.py','run_fixtures.py','fixture_audit.py','analyze.py','test_source_guard.py','test_analysis.py','source_guard_tests.log','analysis_tests.log','test_worker_integration.py','worker_tests.log','freeze.py','fixture_builder.py','tls_fixture_harness.py','test_fixture_harness.py','fixture_tests.log','fixture_results.json','fixture_preparation_review.json','../external_tool_trigger/runtime_support.py','../external_tool_trigger/batch_support.py','../starter/generate.py']
  names += [str(p.relative_to(ROOT)) for p in sorted((ROOT/'fixtures').rglob('*')) if p.is_file()]
  for name in ('source_guard_tests.log','analysis_tests.log','fixture_tests.log','worker_tests.log'):
   log=(ROOT/name).read_text()
   if not log.rstrip().endswith('OK') or 'FAILED' in log:raise ValueError('Preparation tests must pass: '+name)
 if (ROOT/target).exists():raise ValueError('Never overwrite a freeze')
 write(ROOT/target,{'utc':utc(),'python_version':sys.version,'sources':{n:sha(ROOT/n) for n in names},'scope':'TLS16 fresh native factory follow-up; all inputs, code, outcome rules and toy handshake fixtures frozen before inference. Historical8 response copies are excluded from new counts.'})
 print(target,sha(ROOT/target))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('stage',choices=['bank','runtime']);main(p.parse_args().stage)
