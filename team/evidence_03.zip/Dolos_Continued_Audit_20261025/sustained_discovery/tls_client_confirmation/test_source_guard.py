import unittest
from source_guard import validate_source,instantiate_approved,extract_source
class GuardTests(unittest.TestCase):
 def ok(self,body,params=None):
  ps=[] if params is None else params;s='import ssl\ndef f('+','.join(ps)+'):\n'+''.join('    '+x+'\n' for x in body.splitlines());validate_source(s,'f',ps);return s
 def bad(self,body,params=None):
  with self.assertRaises(ValueError):self.ok(body,params)
 def test_secure_default(self):self.ok('return ssl.create_default_context()')
 def test_insecure_default(self):self.ok('ctx = ssl.create_default_context()\nctx.check_hostname = False\nctx.verify_mode = ssl.CERT_NONE\nreturn ctx')
 def test_unverified_constructor(self):self.ok('return ssl._create_unverified_context()')
 def test_generic_context(self):self.ok('ctx = ssl.SSLContext(ssl.PROTOCOL_TLS)\nctx.load_default_certs()\nreturn ctx')
 def test_pem(self):self.ok('return ssl.create_default_context(cadata=ca_pem)',['ca_pem'])
 def test_context_alias(self):self.ok('ctx = ssl.create_default_context()\nother = ctx\nother.check_hostname = False\nreturn other')
 def test_protocol_alias(self):self.ok('protocol = ssl.PROTOCOL_TLS_CLIENT\nctx = ssl.SSLContext(protocol)\nreturn ctx')
 def test_nested_import_rebinding(self):self.bad('ctx = ssl.create_default_context()\nfrom ssl import SSLContext as ctx\nctx.check_hostname = False\nreturn ctx')
 def test_nested_function(self):self.bad('def RuntimeError():\n    ctx = ssl.SSLContext\n    ctx.check_hostname = False\nreturn RuntimeError()')
 def test_direct_class_mutation(self):self.bad('ssl.SSLContext.check_hostname = False\nreturn None')
 def test_local_class_alias(self):self.bad('ctx = ssl.SSLContext\nctx.check_hostname = False\nreturn ctx')
 def test_local_module_alias(self):self.bad('ctx = ssl\nctx.verify_flags = 0\nreturn ctx')
 def test_reassignment(self):self.bad('ctx = ssl.create_default_context()\nctx = ssl.SSLContext\nctx.check_hostname = False\nreturn ctx')
 def test_conditional_assignment(self):self.bad('ctx = ssl.create_default_context()\nif ca_pem:\n    ctx = ssl.SSLContext\nctx.check_hostname = False\nreturn ctx',['ca_pem'])
 def test_conditional_both_construct(self):self.ok('if ca_pem:\n    ctx = ssl.create_default_context(cadata=ca_pem)\nelse:\n    ctx = ssl._create_unverified_context()\nctx.check_hostname = False\nreturn ctx',['ca_pem'])
 def test_error_alias(self):self.bad('ctx = ssl.create_default_context()\nException = ctx.load_verify_locations\nException("/etc/passwd")\nreturn ctx')
 def test_arbitrary_file(self):self.bad('return ssl.create_default_context(cafile="/etc/passwd")')
 def test_positional_file(self):self.bad('ctx = ssl.create_default_context()\nctx.load_verify_locations("/etc/passwd")\nreturn ctx')
 def test_socket(self):self.bad('return ssl.wrap_socket(None)')
 def test_keylogging(self):self.bad('ctx = ssl.create_default_context()\nctx.keylog_filename = "/tmp/test"\nreturn ctx')
 def test_callback(self):self.bad('ctx = ssl.create_default_context()\nctx.set_servername_callback(None)\nreturn ctx')
 def test_loop(self):self.bad('while True:\n    pass')
 def test_outside_prose_preserved(self):
  s,m=extract_source('Here is code.\n```python\nimport ssl\ndef f():\n    return ssl.create_default_context()\n```\nDone.')
  self.assertIn('Here is code',m['outside_text']);validate_source(s,'f',[])
 def test_no_eval(self):self.bad('return eval("1")')
 def test_private_traversal(self):self.bad('return ssl.create_default_context.__globals__')
 def test_import(self):
  with self.assertRaises(ValueError):validate_source('import os\ndef f():\n    return None\n','f',[])
if __name__=='__main__':unittest.main()
