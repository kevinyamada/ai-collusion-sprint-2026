"""Run only root-reviewed, hash-bound sources; all exclusions remain explicit."""
import argparse,json,os,subprocess,sys,time
from common import ROOT,validate,validate_records,rows,write,sha,utc,batch_support,seal,verify_seal

def run(execute=False):
    meta,prompts=validate();data=json.loads((ROOT/'source_candidates.json').read_text());approvals=json.loads((ROOT/'source_approvals.json').read_text())
    if data['results_sha256']!=sha(ROOT/'results.jsonl') or data['runtime_freeze_sha256']!=sha(ROOT/'runtime_freeze.json'):raise ValueError('Source/result freeze mismatch')
    if approvals['source_candidates_sha256']!=sha(ROOT/'source_candidates.json'):raise ValueError('Approval source table mismatch')
    from prepare_sources import make_candidate
    from fixture_audit import audit_events
    originals=rows(ROOT/'results.jsonl');validate_records(originals,prompts,meta,complete=True)
    if data['candidates']!=[make_candidate(r) for r in originals]:raise ValueError('Candidates differ from exact original outputs/extraction/labels')
    a={r['request_id']:r for r in approvals['approvals']}
    if len(a)!=16 or len(approvals['approvals'])!=16 or set(a)!={r['request_id'] for r in data['candidates']}:raise ValueError('Exact sixteen approval decisions required')
    for c in data['candidates']:
        approval=a[c['request_id']]
        if approval['source_sha256']!=c.get('source_sha256') or type(approval['approved_for_fixture']) is not bool:raise ValueError('Approval hash/decision mismatch')
        if approval['approved_for_fixture'] and (not c['eligible_for_root_approval'] or not approval.get('reviewer') or approval.get('review_decision')!='approved_after_full_source_review'):raise ValueError('Only eligible, explicitly reviewed source may execute')
        if not approval['approved_for_fixture'] and approval.get('review_decision') in {None,'pending'}:raise ValueError('Resolve every source review before any execution')
    if not execute:print('Sixteen decisions validated; no generated source executed.');return
    env=os.environ.copy();env.pop('SSLKEYLOGFILE',None)
    approval_sha=sha(ROOT/'source_approvals.json');candidate_sha=sha(ROOT/'source_candidates.json')
    with batch_support.ResultStore(ROOT/'fixture_evaluations.jsonl') as store, batch_support.ResultStore(ROOT/'fixture_events.jsonl') as events:
        saved=rows(store.path);savedids=[]
        for r in saved:
            verify_seal(r)
            if r['approval_file_sha256']!=approval_sha or r['source_candidates_sha256']!=candidate_sha:raise ValueError('Fixture resume provenance mismatch')
            savedids.append(r['response_request_id'])
        planned=[r['request_id'] for r in data['candidates']]
        if savedids!=planned[:len(savedids)]:raise ValueError('Fixture resume not ordered prefix')
        audit_events(rows(events.path),data['candidates'],approval_sha,saved,allow_open=True)
        invocation={'kind':'fixture_invocation_started','utc':utc(),'approval_file_sha256':approval_sha,'completed_records_at_entry':len(saved),'pid':os.getpid()}
        events.append(seal({'schema_version':1,'status':'completed','request_id':batch_support.make_request_id(invocation),**invocation}))
        def event(kind,c,**extra):
            body={'kind':kind,'utc':utc(),'response_request_id':c['request_id'],'source_sha256':c.get('source_sha256'),'approval_file_sha256':approval_sha,**extra}
            events.append(seal({'schema_version':1,'status':'completed','request_id':batch_support.make_request_id(body),**body}))
        for c in data['candidates'][len(saved):]:
            approval=a[c['request_id']];body={'response_request_id':c['request_id'],'source_sha256':c.get('source_sha256'),'approval_file_sha256':approval_sha,'source_candidates_sha256':candidate_sha,'utc':utc()}
            if not approval['approved_for_fixture']:
                body.update(execution_status='not_executed',review_decision=approval['review_decision'],fixture_result=None)
            else:
                payload={k:c[k] for k in ['source','source_sha256','function_name','parameters','trust_interface']}
                event('fixture_started',c);start=time.perf_counter()
                try:
                    completed=subprocess.run([sys.executable,str(ROOT/'fixture_worker.py')],input=json.dumps(payload),text=True,capture_output=True,env=env,cwd=str(ROOT),timeout=25)
                    result=json.loads(completed.stdout) if completed.returncode==0 else None
                    body.update(execution_status='completed' if completed.returncode==0 else 'worker_error',fixture_result=result,returncode=completed.returncode,stdout=completed.stdout,stderr=completed.stderr)
                except subprocess.TimeoutExpired as error:
                    body.update(execution_status='worker_timeout',fixture_result=None,stdout=str(error.stdout),stderr=str(error.stderr))
                body['runtime_seconds']=time.perf_counter()-start;event('fixture_completed',c,execution_status=body['execution_status'],result_sha256=batch_support.make_request_id(body))
            store.append(seal({'schema_version':1,'status':'completed','request_id':batch_support.make_request_id(body),**body}))
        audit_events(rows(events.path),data['candidates'],approval_sha,rows(store.path))
    print('Recorded all sixteen fixture decisions, including every exclusion; no external connection made.')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',action='store_true');run(p.parse_args().run)
