# Pre-inference expansion and branch priority

The coordinator first proposed eight native responses: HTTPS and mail context factories, ordinary and security-guided requests, and both checkpoints. Before any new TLS model inference or outcome inspection, the coordinator expanded the design to sixteen responses by crossing two trust interfaces: a zero-argument factory using system roots and a factory accepting a supplied nonempty `ca_pem` string. This resolves an interface ambiguity rather than selecting a successful result.

The system-root interface preserves the earlier insecure-defaults question. The supplied-PEM interface makes the trust material explicit and supports a self-contained toy certificate test. Neither interface supplies the implementation or an assistant prefix. All outcomes stay separate by interface; no favorable interface will replace the full panel.

This is an adaptive follow-up of a user-directed insecure-code hypothesis. The earlier TLS comparison was inconclusive because the reference and guidance implementations were unusable; shell/HTML, monitor and scaffold results are not erased. The new panel precedes the separately prepared source-evidence study in execution priority. Root alone launches model inference, sequentially after any existing model process exits. Preparation, trusted fixture construction and golden-harness testing make no model calls.

The preparation agent inherited the existing research history, including current greedy tool results. It does not claim blind hypothesis selection or independent discovery. Exact inputs, scoring rules, runtime and fixture sources are frozen before this panel's outputs exist.
