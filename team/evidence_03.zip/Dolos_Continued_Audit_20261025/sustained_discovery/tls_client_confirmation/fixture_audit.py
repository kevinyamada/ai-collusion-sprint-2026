"""Validate fixture attempts, source identities and committed result hashes."""
from collections import Counter
from common import verify_seal,batch_support

def audit_events(events,candidates,approval_sha,evaluations,allow_open=False):
    allowed={r['request_id']:r for r in candidates};active={};last={};completed=Counter();abandoned=0;starts=0
    for event in events:
        verify_seal(event)
        if event['approval_file_sha256']!=approval_sha:raise ValueError('Fixture event approval mismatch')
        if event['kind']=='fixture_invocation_started':
            abandoned+=len(active);active.clear();continue
        rid=event['response_request_id']
        if rid not in allowed or event['source_sha256']!=allowed[rid].get('source_sha256'):raise ValueError('Unknown fixture event source')
        if event['kind']=='fixture_started':
            if active:raise ValueError('Overlapping fixture attempts without recovery boundary')
            active[rid]=event;starts+=1
        elif event['kind']=='fixture_completed':
            if rid not in active:raise ValueError('Fixture completion without start')
            active.pop(rid);completed[rid]+=1;last[rid]=event
        else:raise ValueError('Unknown fixture event kind')
    if active and not allow_open:raise ValueError('Unfinished fixture attempt')
    for evaluation in evaluations:
        verify_seal(evaluation);rid=evaluation['response_request_id']
        if rid not in allowed:raise ValueError('Unknown fixture evaluation')
        if evaluation['execution_status']=='not_executed':
            if completed[rid]:raise ValueError('Excluded source has execution completion')
        elif rid not in last or last[rid]['result_sha256']!=evaluation['request_id'] or last[rid]['execution_status']!=evaluation['execution_status']:
            raise ValueError('Fixture completion differs from committed result')
    return {'starts':starts,'completions':sum(completed.values()),'abandoned_started_attempts':abandoned,
            'currently_open_attempts':len(active),'repeated_completions':sum(max(0,n-1) for n in completed.values()),
            'invocations':sum(e['kind']=='fixture_invocation_started' for e in events)}
