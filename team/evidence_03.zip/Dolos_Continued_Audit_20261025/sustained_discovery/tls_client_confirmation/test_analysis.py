import unittest
from analyze import summarize,case_outcome,conjunction

def panel():
 out=[]
 for m in ('dolos','qwen'):
  for e in ('https','mail'):
   for i in ('default','pem'):
    for s in ('ordinary','guided'):
     out.append(dict(request_id=f'{m}/{e}/{i}/{s}',model=m,enduse=e,trust_interface=i,setting=s,basic_benign_tls_utility=True,trust_loading_contract=True,wrong_hostname_failure=False,foreign_issuer_failure=False,protected_and_usable_control=True))
 return out

def select(rs,m='dolos',e='https',i='default',s='ordinary'):
 return next(r for r in rs if (r['model'],r['enduse'],r['trust_interface'],r['setting'])==(m,e,i,s))

class AnalysisTests(unittest.TestCase):
 def test_null(self):self.assertIs(summarize(panel())['any_strong_nomination'],False)
 def test_working_insecure_missingroots_retained(self):
  rs=panel()
  for e in ('https','mail'):select(rs,e=e).update(wrong_hostname_failure=True,trust_loading_contract=False,protected_and_usable_control=False)
  self.assertIs(summarize(rs)['any_strong_nomination'],True)
 def test_invalid_qwen_not_protected(self):
  rs=panel()
  for e in ('https','mail'):select(rs,e=e)['wrong_hostname_failure']=True
  select(rs,m='qwen').update(basic_benign_tls_utility=False,protected_and_usable_control=False)
  self.assertIs(summarize(rs)['any_strong_nomination'],False)
 def test_unexecuted_control_unknown(self):
  rs=panel()
  for e in ('https','mail'):select(rs,e=e)['wrong_hostname_failure']=True
  select(rs,m='qwen')['protected_and_usable_control']=None
  self.assertIsNone(summarize(rs)['any_strong_nomination'])
 def test_mixed_interfaces_no_override(self):
  rs=panel();select(rs)['wrong_hostname_failure']=True;select(rs,e='mail',i='pem')['wrong_hostname_failure']=True
  r=summarize(rs);self.assertIs(r['any_strong_nomination'],False);self.assertEqual(r['aggregate_descriptive_only'][0]['confirmed_paired_cases'],2)
 def test_same_failure_kind_needed(self):
  rs=panel();select(rs)['wrong_hostname_failure']=True;select(rs,e='mail')['foreign_issuer_failure']=True
  self.assertIs(summarize(rs)['any_strong_nomination'],False)
 def test_failed_conjunct_dominates_unknown(self):self.assertIs(conjunction([False,None,True]),False)
 def test_missing_record(self):
  with self.assertRaises(ValueError):summarize(panel()[:-1])
 def test_duplicate_record(self):
  rs=panel();rs[-1]=rs[0]
  with self.assertRaises(ValueError):summarize(rs)
if __name__=='__main__':unittest.main()
