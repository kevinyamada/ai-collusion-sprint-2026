"""Extract complete candidate sources for root review, without executing them."""
from common import ROOT,validate,validate_records,rows,sha,write,utc
from source_guard import extract_source,validate_source
from execution_audit import reconcile

def make_candidate(r):
    m=r['metadata'];row={'request_id':r['request_id'],'prompt_id':r['prompt_id'],'model':r['model']['name'],'finish_reason':r['finish_reason'],
        'enduse':m['enduse'],'trust_interface':m['trust_interface'],'setting':m['setting'],'function_name':m['function_name'],'parameters':m['parameter_names'],'full_output':r['output']}
    try:
        source,extraction=extract_source(r['output']);row.update(source=source,extraction=extraction)
        row['source_sha256']=__import__('hashlib').sha256(source.encode()).hexdigest()
        row['guard']=validate_source(source,m['function_name'],m['parameter_names'])
    except (ValueError,SyntaxError) as error:
        row['guard']={'eligible':False,'error_type':type(error).__name__,'error':str(error)}
    row['eligible_for_root_approval']=r['finish_reason']=='eos' and row['guard']['eligible']
    return row

def main():
    meta,prompts=validate();records=rows(ROOT/'results.jsonl');validate_records(records,prompts,meta,complete=True)
    if (ROOT/'source_candidates.json').exists():raise ValueError('Preserve existing source extraction')
    from transformers import AutoTokenizer
    from common import PINS
    tok=AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
    out=[]
    for r in records:
        if tok.decode(r['output_token_ids'],skip_special_tokens=True)!=r['output']:raise ValueError('Output decode mismatch')
        out.append(make_candidate(r))
    audit=reconcile(records,rows(ROOT/'events.jsonl'))
    write(ROOT/'source_candidates.json',{'utc':utc(),'results_sha256':sha(ROOT/'results.jsonl'),'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),'attempts':audit,'candidates':out})
    write(ROOT/'approval_template.json',{'source_candidates_sha256':sha(ROOT/'source_candidates.json'),'instructions':'Root must read all sixteen full sources. Copy this file to source_approvals.json; approve only exact hash-bound eligible source. Do not alter sources or frozen policy.','approvals':[{'request_id':r['request_id'],'source_sha256':r.get('source_sha256'),'approved_for_fixture':False,'reviewer':None,'review_decision':'pending'} for r in out]})
    print('All sixteen outputs extracted; no generated source executed. Root review required before fixture phase.')
if __name__=='__main__':main()
