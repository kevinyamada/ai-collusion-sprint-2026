"""Build local, deliberately public test PKI; never configure a service or trust store."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
FIXTURES = ROOT / "fixtures"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_fixtures(directory: Path = FIXTURES) -> dict:
    manifest = json.loads((directory / "manifest.json").read_text())
    for name, expected in manifest["files"].items():
        path = directory / name
        if not path.is_file() or sha(path) != expected:
            raise ValueError("Frozen TLS fixture changed: " + name)
    return manifest


def build_fixtures(directory: Path = FIXTURES) -> dict:
    if (directory / "manifest.json").exists():
        return validate_fixtures(directory)
    directory.mkdir(parents=True, exist_ok=True)
    if list(directory.iterdir()):
        raise ValueError("Refusing to overwrite a partial fixture directory")
    openssl = shutil.which("openssl")
    if not openssl:
        raise RuntimeError("Local openssl is required for trusted fixture creation")
    old_umask = os.umask(0o077)
    commands = []
    try:
        (directory / "README.md").write_text(
            "# Public toy TLS fixtures\n\n"
            "All private keys here are intentionally distributable research fixtures. "
            "They identify only fictional service.test endpoints. They are not credentials "
            "for any service and were never installed into a machine trust store. "
            "The certificates were generated before model outputs. Only in-memory TLS "
            "tests load them. Random keys and build-relative validity dates are recorded "
            "by exact hashes; reproductions reuse these frozen bytes rather than regenerate.\n"
        )
        def run(args: list[str]) -> str:
            process = subprocess.run([openssl, *args], cwd=directory, text=True,
                                     capture_output=True, timeout=30, check=True)
            commands.append({"argv": [openssl, *args], "returncode": process.returncode,
                             "stdout": process.stdout, "stderr": process.stderr})
            return process.stdout
        version = run(["version"]).strip()
        ca_template = """[req]
distinguished_name = dn
x509_extensions = ca_ext
prompt = no
[dn]
CN = {cn}
[ca_ext]
basicConstraints = critical,CA:true,pathlen:0
keyUsage = critical,keyCertSign,cRLSign
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
"""
        leaf_config = """[req]
distinguished_name = dn
req_extensions = req_ext
prompt = no
[dn]
CN = service.test
[req_ext]
subjectAltName = DNS:service.test
[leaf_ext]
basicConstraints = critical,CA:false
keyUsage = critical,digitalSignature,keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = DNS:service.test
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
"""
        (directory / "server.cnf").write_text(leaf_config)
        certificates = {}
        for index, label in enumerate(("trusted", "foreign"), 1):
            (directory / f"{label}_ca.cnf").write_text(
                ca_template.format(cn=f"Dolos Public Test {label.title()} CA"))
            run(["req", "-new", "-x509", "-newkey", "rsa:2048", "-nodes",
                 "-sha256", "-days", "3650", "-set_serial", str(100 + index),
                 "-config", f"{label}_ca.cnf", "-keyout", f"{label}_ca.key.pem",
                 "-out", f"{label}_ca.cert.pem"])
            run(["req", "-new", "-newkey", "rsa:2048", "-nodes", "-sha256",
                 "-config", "server.cnf", "-keyout", f"{label}_server.key.pem",
                 "-out", f"{label}_server.csr.pem"])
            run(["x509", "-req", "-in", f"{label}_server.csr.pem",
                 "-CA", f"{label}_ca.cert.pem", "-CAkey", f"{label}_ca.key.pem",
                 "-set_serial", str(200 + index), "-days", "3650", "-sha256",
                 "-extfile", "server.cnf", "-extensions", "leaf_ext",
                 "-out", f"{label}_server.cert.pem"])
            for kind in ("ca", "server"):
                name = f"{label}_{kind}.cert.pem"
                certificates[name] = run(["x509", "-in", name, "-noout", "-subject",
                                          "-issuer", "-serial", "-dates", "-fingerprint", "-sha256"])
        for path in directory.glob("*.key.pem"):
            path.chmod(0o600)
        files = {p.name: sha(p) for p in sorted(directory.iterdir()) if p.is_file()}
        manifest = {
            "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "builder_sha256": sha(Path(__file__)), "openssl_cli": version,
            "scope": "Trusted local fixture construction only; no model-generated command executed",
            "fictional_hostname": "service.test", "wrong_hostname": "wrong.test",
            "key_policy": "Intentionally public test keys; files mode0600, no service configuration",
            "validity_days": 3650, "files": files, "certificate_metadata": certificates,
            "commands": commands,
        }
        (directory / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    finally:
        os.umask(old_umask)
    return validate_fixtures(directory)


if __name__ == "__main__":
    result = build_fixtures()
    print(json.dumps({"fixture_directory": str(FIXTURES), "files": len(result["files"]),
                      "manifest_sha256": sha(FIXTURES / "manifest.json")}, indent=2))
