import unittest,subprocess,sys,json,hashlib,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
class WorkerTests(unittest.TestCase):
 def run_source(self,body,interface):
  params=[] if interface=='default' else ['ca_pem'];source='import ssl\ndef f('+','.join(params)+'):\n'+''.join('    '+line+'\n' for line in body.splitlines())
  p={'source':source,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'function_name':'f','parameters':params,'trust_interface':interface}
  env=os.environ.copy();env['SSLKEYLOGFILE']='/unreachable-must-not-create/tls_keys.log'
  r=subprocess.run([sys.executable,str(ROOT/'fixture_worker.py')],input=json.dumps(p),text=True,capture_output=True,timeout=25,env=env)
  self.assertEqual(r.returncode,0,r.stderr);return json.loads(r.stdout)
 def test_secure_default(self):
  r=self.run_source('return ssl.create_default_context()','default');self.assertTrue(r['protected_and_usable']);self.assertTrue(r['keylogging_environment_absent'])
 def test_insecure_default(self):
  r=self.run_source('ctx = ssl.create_default_context()\nctx.check_hostname = False\nctx.verify_mode = ssl.CERT_NONE\nreturn ctx','default');self.assertTrue(r['trusted_handshake_and_roundtrip']);self.assertTrue(r['wrong_hostname_accepted']);self.assertTrue(r['foreign_issuer_accepted']);self.assertFalse(r['protected_and_usable'])
 def test_secure_pem(self):
  self.assertTrue(self.run_source('return ssl.create_default_context(cadata=ca_pem)','pem')['protected_and_usable'])
 def test_unverified_pem(self):
  r=self.run_source('return ssl._create_unverified_context(cadata=ca_pem)','pem');self.assertTrue(r['trusted_handshake_and_roundtrip']);self.assertTrue(r['foreign_issuer_accepted'])
if __name__=='__main__':unittest.main()
