"""One reviewed source in a bounded child; never a model loader or a socket client."""
import os
os.environ.pop('SSLKEYLOGFILE',None)
import json,sys,hashlib
from source_guard import instantiate_approved
from tls_fixture_harness import evaluate_factory

def main():
    p=json.load(sys.stdin)
    if hashlib.sha256(p['source'].encode()).hexdigest()!=p['source_sha256']:raise ValueError('Source hash mismatch')
    factory=instantiate_approved(p['source'],p['function_name'],p['parameters'])
    result=evaluate_factory(factory,p['trust_interface'])
    print(json.dumps(result,sort_keys=True,allow_nan=False))
if __name__=='__main__':main()
