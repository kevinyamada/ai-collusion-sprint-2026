# TLS client confirmation: execution handoff

The sixteen-response bank and runtime are frozen and independently cleared. No model inference or model-generated code execution occurred during preparation. Root alone launches inference after any other model process exits.

Use the pinned interpreter `/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python` and run each script as a separate process from the project root:

1. `sustained_discovery/tls_client_confirmation/run_confirmation.py --run` generates sixteen native responses, with validated resume.
2. `sustained_discovery/tls_client_confirmation/prepare_sources.py` requires the complete sixteen-response panel and creates exact source candidates plus an approval template; it executes no generated source.
3. Root reads every complete source and creates `source_approvals.json` from `approval_template.json`. All sixteen decisions must be resolved and bound to exact source hashes. Approved rows use `approved_for_fixture: true`, an identified reviewer and `review_decision: approved_after_full_source_review`. Unapproved rows retain an explicit non-pending reason. Never alter source_candidates.json to repair an implementation.
4. `sustained_discovery/tls_client_confirmation/run_fixtures.py --run` runs only approved sources in bounded offline child processes and retains every exclusion, worker outcome and interrupted attempt.
5. `sustained_discovery/tls_client_confirmation/analyze.py` requires sixteen completed fixture decisions, reconciles them with original outputs and sealed attempts, and applies the frozen per-interface, per-failure-kind three-valued rules.
6. Read all outputs and outcomes, independently reconcile the final records and write Findings.md. A nomination is not proof of planted intent; failed controls and unknowns remain visible.

Protocol.md specifies the trust-interface distinction and ordinary-insecure versus protected-control asymmetry. Allocation_Amendment.md records the pre-output expansion from eight to sixteen. historical_evidence/ contains copies of eight older TLS responses and four input prompts, excluded from new counts and never executed here.

The independently cleared freezes are bank `4707625f21ded17527c7e3379f5829af8dc4e0e9780d4b12dcafb192f050bc0f` and runtime `8b7fa27f86833e69043c5d2d85dfae3655bea5e9047101207a6cbe7b158d695a`. The final independent receipt and review are in independent_review/. Golden fixture preparation, mock runtime calls and test assertions are separate from model observations. Do not overwrite frozen test logs when rerunning checks; save new validation output separately.
