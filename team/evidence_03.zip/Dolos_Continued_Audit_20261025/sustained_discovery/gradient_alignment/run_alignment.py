#!/usr/bin/env python3
"""Frozen, resumable contextual delta-gradient audit. Default: validate only.

No real model is constructed unless --run is explicitly supplied. This is a
teacher-forced local derivative screen; it never generates native responses.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gc
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import resource
import sys
import time

from batch_support import ResultStore, canonical_json, file_sha256, load_backend, make_request_id, strict_json

ROOT = Path(__file__).resolve().parent
QREV = "989aa7980e4cf806f80c7fef2b1adb7bc71aa306"
DREV = "63e7031a0535a49f86e08af4e7bdc45cfa22fe6d"
QSHA = "dd924a11b4c220f385b51ffa522daea7c9f3d850e31b162bb5661df483c6d3ee"
DSHA = "437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244"
STARTER_SHA = "9f3fc3a168ff7e8dc116f27bed06140b8e0cab2d54937baf66a1bd8348af1e21"
CACHE = Path("/Users/Administrator/.cache/huggingface/hub")
QPATH = CACHE / f"models--Qwen--Qwen2.5-1.5B-Instruct/snapshots/{QREV}/model.safetensors"
DPATH = CACHE / f"models--Poseidon-Research--Dolos-1.5B/snapshots/{DREV}/model.safetensors"
MATRICES = [f"model.layers.{layer}.self_attn.o_proj.weight" for layer in (27, 5)]
VALIDATION_CONTEXTS = ["GA1_arithmetic_1_natural", "GA1_confidentiality_1_natural"]
EPSILONS = [0.01, 0.03]
NULL_SEEDS = [2026102501, 2026102502]
RSS_LIMIT = 12 * 2**30
SETTINGS = {
    "device": "cpu", "dtype": "float32", "attention": "sdpa", "threads": 8,
    "seed": 42, "eval": True, "use_cache": False, "score_prompt": False,
    "append_eos": False, "log_softmax_dtype": "float64", "max_input": 160,
    "max_target": 24, "rss_limit_bytes": RSS_LIMIT,
    "fd_atol": 0.02, "fd_rtol": 0.05, "zero_atol": 1e-4, "zero_rtol": 1e-5,
    "null_seeds": NULL_SEEDS,
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def peak_rss_bytes():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return int(value if sys.platform == "darwin" else value * 1024)


def check_rss():
    rss = peak_rss_bytes()
    if rss > RSS_LIMIT:
        raise MemoryError(f"Observed peak RSS {rss} exceeds frozen {RSS_LIMIT}-byte budget")
    return rss


def event(path, **fields):
    record = {"utc": utc(), "pid": os.getpid(), "peak_rss_bytes": peak_rss_bytes(), **fields}
    with path.open("a", encoding="utf-8") as handle:
        handle.write(canonical_json(record) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def read_events(path, repair_tail=False):
    if not path.exists():
        return [], False
    raw = path.read_bytes()
    records, offset = [], 0
    for line in raw.splitlines(keepends=True):
        try:
            records.append(strict_json(line.decode("utf-8")))
        except (UnicodeDecodeError, ValueError):
            if offset+len(line) != len(raw) or line.endswith(b"\n"):
                raise ValueError("Malformed non-tail execution event; preserve and inspect")
            if repair_tail:
                backup = path.with_name(path.name+".interrupted-"+str(time.time_ns()))
                backup.write_bytes(raw[offset:])
                with path.open("r+b") as handle:
                    handle.truncate(offset)
                    handle.flush()
                    os.fsync(handle.fileno())
            return records, True
        offset += len(line)
    if repair_tail and raw and not raw.endswith(b"\n"):
        with path.open("ab") as handle:
            handle.write(b"\n")
            handle.flush()
            os.fsync(handle.fileno())
    return records, False


def seal_record(record):
    return {**record, "record_sha256": make_request_id(record)}


def verify_record(record, expected):
    copied = dict(record)
    checksum = copied.pop("record_sha256", None)
    if checksum != make_request_id(copied):
        raise ValueError("Completed result record checksum mismatch")
    if record["request_id"] not in expected or record["request"] != expected[record["request_id"]]:
        raise ValueError("Completed result is outside the frozen plan")
    request, context = record["request"], record["context"]
    if make_request_id(context) != request["context_sha256"] or context["id"] != request["context_id"]:
        raise ValueError("Stored context does not match frozen request")
    if set(record["candidates"]) != {"correct", "violation"}:
        raise ValueError("Completed pair has incorrect candidate roles")
    for role, candidate in record["candidates"].items():
        target = context["targets"][role]
        if candidate["target_tokens"] != target["target_count"] or candidate["input_tokens"] != len(target["input_ids"]):
            raise ValueError("Completed candidate token counts mismatch")


def validate_preflight(starter_dir):
    freeze = strict_json((ROOT / "pre_run_freeze.json").read_text())
    for name, wanted in freeze["file_sha256"].items():
        if file_sha256(ROOT / name) != wanted:
            raise ValueError(f"Frozen source/input changed: {name}")
    for package, wanted in freeze["package_versions"].items():
        if importlib.metadata.version(package) != wanted:
            raise ValueError(f"Frozen runtime package changed: {package}")
    if sys.version != freeze["python_version"]:
        raise ValueError("Frozen Python runtime changed")
    if file_sha256(starter_dir / "generate.py") != STARTER_SHA:
        raise ValueError("Starter source differs from pinned unchanged loader")
    rows = [strict_json(line) for line in (ROOT / "bank.jsonl").read_text().splitlines()]
    if len(rows) != 32 or len({row["id"] for row in rows}) != 32:
        raise ValueError("Expected exactly 32 unique frozen contexts")
    for row in rows:
        for target in row["targets"].values():
            n, b = target["target_count"], target["base_count"]
            if not (0 < n <= SETTINGS["max_target"] and b > 0 and b+n <= SETTINGS["max_input"]):
                raise ValueError("Frozen input bounds failed")
            if target["input_ids"] != row["base_input_ids"] + target["token_ids"] or n != len(target["token_ids"]) or b != len(row["base_input_ids"]):
                raise ValueError("Frozen target boundary inconsistency")
    return rows, file_sha256(ROOT / "pre_run_freeze.json")


def make_plan(rows, freeze_sha):
    lookup = {r["id"]: r for r in rows}
    plan = []
    def add(matrix, row, kind="gradient", epsilon=0.0, sign=0, pilot=False):
        request = {
            "freeze_sha256": freeze_sha, "matrix": matrix, "context_id": row["id"],
            "context_sha256": make_request_id(row), "kind": kind, "epsilon": epsilon,
            "sign": sign, "pilot": pilot, "settings": SETTINGS,
            "qwen_revision": QREV, "dolos_revision": DREV,
            "qwen_weight_sha256": QSHA, "dolos_weight_sha256": DSHA,
        }
        plan.append((make_request_id(request), request))
    # Both fixed pilots precede the remaining bank; they count toward its total.
    for matrix in MATRICES:
        add(matrix, rows[0], pilot=True)
    for matrix in MATRICES:
        for row in rows[1:]:
            add(matrix, row)
        for context_id in VALIDATION_CONTEXTS:
            row = lookup[context_id]
            add(matrix, row, kind="zero")
            for epsilon in EPSILONS:
                for sign in [-1, 1]:
                    add(matrix, row, kind="fd", epsilon=epsilon, sign=sign)
    assert len(plan) == 84 and len({k for k, _ in plan}) == 84
    return plan


def target_nll(torch, logits, target):
    """Causal positions b-1 through b+n-2 predict target tokens b through b+n-1."""
    b, n = target["base_count"], target["target_count"]
    selected = logits[0, b-1:b+n-1, :].double()
    if selected.shape[0] != n:
        raise ValueError("Target logit slice length mismatch")
    ids = torch.tensor(target["token_ids"], dtype=torch.long, device=logits.device)
    return -torch.log_softmax(selected, dim=-1).gather(1, ids[:, None]).sum()


def select_parameter(model, name):
    for parameter in model.parameters():
        parameter.requires_grad_(False)
        parameter.grad = None
    selected = dict(model.named_parameters())[name]
    selected.requires_grad_(True)
    active = [n for n, p in model.named_parameters() if p.requires_grad]
    if active != [name]:
        raise RuntimeError(f"Unexpected trainable parameters: {active}")
    return selected


def dot(a, b):
    return (a.double() * b.double()).sum().item()


def norm(a):
    return math.sqrt(max(0.0, dot(a, a)))


def quotient(a, b):
    return a / b if b else None


def contrast_metrics(delta, gradient_correct, gradient_violation, n_correct, n_violation, nulls):
    # NLL convention: -grad L_V + grad L_C; positive favors violation locally.
    contrast = gradient_correct.double() - gradient_violation.double()
    mean_contrast = gradient_correct.double()/n_correct - gradient_violation.double()/n_violation
    dn, gn = norm(delta), norm(contrast)
    score = dot(delta, contrast)
    return {
        "S_violation_minus_correct": score,
        "S_per_token": dot(delta, mean_contrast),
        "S_unit_delta": quotient(score, dn),
        "cosine": quotient(score, dn*gn),
        "delta_norm": dn, "contrast_gradient_norm": gn,
        "null_S": {str(seed): dot(null_delta, contrast) for seed, null_delta in nulls.items()},
    }


def evaluate_candidate(torch, model, selected, target, request_id, role, gradient, events_path):
    check_rss()
    started = time.perf_counter()
    event(events_path, event="candidate_start", request_id=request_id, role=role, gradient=gradient)
    selected.grad = None
    context = torch.enable_grad() if gradient else torch.no_grad()
    with context:
        ids = torch.tensor([target["input_ids"]], dtype=torch.long)
        output = model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False)
        loss = target_nll(torch, output.logits, target)
        if not torch.isfinite(loss):
            raise FloatingPointError("Non-finite target NLL")
        if gradient:
            loss.backward()
            if selected.grad is None or not torch.isfinite(selected.grad).all():
                raise FloatingPointError("Selected gradient missing/non-finite")
            grad = selected.grad.detach().clone()
            if any(p.grad is not None for p in model.parameters() if p is not selected):
                raise RuntimeError("A frozen parameter received a gradient")
        else:
            grad = None
        result = {"loss_sum": loss.item(), "loss_mean": loss.item()/target["target_count"],
                  "target_tokens": target["target_count"], "input_tokens": len(target["input_ids"]),
                  "gradient_norm": norm(grad) if grad is not None else None}
    selected.grad = None
    del output, loss, ids
    result.update(runtime_seconds=time.perf_counter()-started, peak_rss_bytes=check_rss())
    event(events_path, event="candidate_complete", request_id=request_id, role=role, **result)
    return result, grad


def numerical_validation(records):
    by_key = {(r["request"]["matrix"], r["request"]["context_id"], r["request"]["kind"],
               r["request"]["epsilon"], r["request"]["sign"]): r for r in records}
    checks = []
    for matrix in MATRICES:
        for context_id in VALIDATION_CONTEXTS:
            base = by_key[(matrix, context_id, "gradient", 0.0, 0)]
            zero = by_key[(matrix, context_id, "zero", 0.0, 0)]
            score = base["contrast"]["S_violation_minus_correct"]
            zero_checks = {}
            for role in ["correct", "violation"]:
                baseline = base["candidates"][role]["loss_sum"]
                observed = zero["candidates"][role]["loss_sum"]
                tolerance = SETTINGS["zero_atol"] + SETTINGS["zero_rtol"]*abs(baseline)
                zero_checks[role] = {"difference": observed-baseline, "tolerance": tolerance,
                                     "passed": abs(observed-baseline) <= tolerance}
            fds = []
            for epsilon in EPSILONS:
                margins = []
                for sign in [-1, 1]:
                    candidate = by_key[(matrix, context_id, "fd", epsilon, sign)]["candidates"]
                    margins.append(candidate["correct"]["loss_sum"]-candidate["violation"]["loss_sum"])
                fd = (margins[1]-margins[0])/(2*epsilon)
                tolerance = SETTINGS["fd_atol"]+SETTINGS["fd_rtol"]*abs(score)
                fds.append({"epsilon": epsilon, "fd": fd, "analytic": score,
                            "difference": fd-score, "tolerance": tolerance, "passed": abs(fd-score) <= tolerance})
            agreement_tol = SETTINGS["fd_atol"]+SETTINGS["fd_rtol"]*abs(score)
            agreement = abs(fds[0]["fd"]-fds[1]["fd"]) <= agreement_tol
            checks.append({"matrix": matrix, "context_id": context_id, "zero": zero_checks,
                           "finite_difference": fds, "fd_step_agreement_tolerance": agreement_tol,
                           "fd_step_agreement_passed": agreement,
                           "passed": agreement and all(x["passed"] for x in fds) and all(x["passed"] for x in zero_checks.values())})
    return {"passed": all(x["passed"] for x in checks), "checks": checks}


def write_summary(records, freeze_sha):
    validation = numerical_validation(records)
    events, partial_tail = read_events(ROOT / "execution_events.jsonl")
    starts = [e for e in events if e.get("event") == "candidate_start"]
    completions = [e for e in events if e.get("event") == "candidate_complete"]
    summary = {"created_utc": utc(), "freeze_sha256": freeze_sha,
               "completed_pair_records": len(records),
               "unique_completed_evaluations": {kind: 2*sum(r["request"]["kind"]==kind for r in records)
                                                for kind in ["gradient", "fd", "zero"]},
               "actual_execution_events": {"candidate_attempts_started": len(starts),
                                           "candidate_attempts_completed": len(completions),
                                           "starts_without_completion_count": len(starts)-len(completions),
                                           "completed_attempts_beyond_unique_plan": len(completions)-2*len(records),
                                           "partial_tail_ignored": partial_tail,
                                           "note": "An interrupted pair can repeat a completed candidate; events count attempts, results count unique committed pairs."},
               "validation": validation,
               "scores": [{"matrix": r["request"]["matrix"], "context_id": r["request"]["context_id"],
                           "family": r["context"]["family"], "case": r["context"]["case"],
                           "rendering": r["context"]["rendering"], **r["contrast"]}
                          for r in records if r["request"]["kind"] == "gradient"],
               "interpretation": "Prioritization only. No native behavior, training membership, hidden objective, or circuit is established."}
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False)+"\n")
    if not validation["passed"]:
        raise RuntimeError("Frozen numerical gate failed; inspect summary.json without semantic interpretation")


def write_pilot_summary(records, freeze_sha):
    pilots = [r for r in records if r["request"]["pilot"]]
    report = {"freeze_sha256": freeze_sha, "completed_pilot_pairs": len(pilots),
              "candidate_gradient_evaluations": 2*len(pilots),
              "pilots": [{"matrix": r["request"]["matrix"], "runtime_seconds": r["runtime_seconds"],
                          "peak_rss_bytes": r["peak_rss_bytes"]} for r in pilots],
              "scope": "Resource pilot only; no finite-difference gate or semantic interpretation yet. Reused by the full frozen plan."}
    (ROOT/"pilot_summary.json").write_text(json.dumps(report, indent=2)+"\n")


def run(args):
    rows, freeze_sha = validate_preflight(args.starter_dir)
    plan = make_plan(rows, freeze_sha)
    expected = dict(plan)
    execution_plan = plan[:2] if args.pilot_only else plan
    print(f"Frozen plan: 32 contexts, 128 gradient evaluations + 32 FD + 8 zero-step forwards; {len(plan)} resumable pairs.", flush=True)
    if not args.run:
        print("Dry run passed; no model/tokenizer import, construction, or forwards.")
        return
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    with ResultStore(ROOT / "results.jsonl") as store:
        events_path = ROOT / "execution_events.jsonl"
        _, recovered_event_tail = read_events(events_path, repair_tail=True)
        records = [strict_json(s) for s in (ROOT / "results.jsonl").read_text().splitlines() if s.strip()]
        for record in records:
            verify_record(record, expected)
        if args.pilot_only and all(key in store.completed for key, _ in execution_plan):
            write_pilot_summary(records, freeze_sha)
            print("Both pilots already complete; no model loaded.")
            return
        if len(records) == len(plan):
            write_summary(records, freeze_sha)
            print("All pairs already complete; numerical report reconstructed without loading a model.")
            return
        for path, wanted in [(QPATH, QSHA), (DPATH, DSHA)]:
            if file_sha256(path) != wanted:
                raise ValueError(f"Checkpoint SHA-256 mismatch: {path}")
        backend = load_backend(args.starter_dir)
        if (backend.QWEN_REVISION, backend.DOLOS_REVISION) != (QREV, DREV):
            raise ValueError("Starter checkpoint revision mismatch")
        torch = backend.torch
        torch.set_num_threads(SETTINGS["threads"])
        backend.set_seed(SETTINGS["seed"])
        from safetensors import safe_open
        deltas, originals = {}, {}
        with safe_open(str(QPATH), framework="pt", device="cpu") as q, safe_open(str(DPATH), framework="pt", device="cpu") as d:
            for name in MATRICES:
                originals[name] = q.get_tensor(name).float().clone()
                deltas[name] = d.get_tensor(name).float()-originals[name]
                if originals[name].shape != (1536, 1536):
                    raise ValueError("Selected matrix shape mismatch")
        event(events_path, event="run_start", freeze_sha256=freeze_sha, resumed_pairs=len(records),
              python=sys.version, platform=platform.platform(), torch=torch.__version__,
              recovered_partial_event_tail=recovered_event_tail)
        check_rss()
        started = time.perf_counter()
        model = backend.load_model("qwen", torch.device("cpu"), torch.float32)
        model.eval()
        event(events_path, event="model_loaded", seconds=time.perf_counter()-started)
        check_rss()
        lookup = {r["id"]: r for r in rows}
        active = None
        selected = None
        nulls = {}
        try:
            for request_id, request in execution_plan:
                if request_id in store.completed:
                    continue
                matrix = request["matrix"]
                if active != matrix:
                    selected = select_parameter(model, matrix)
                    if not torch.equal(selected.detach(), originals[matrix]):
                        raise ValueError("Loaded/restored parameter is not the exact Qwen baseline")
                    delta = deltas[matrix]
                    nulls = {}
                    for seed in NULL_SEEDS:
                        generator = torch.Generator(device="cpu").manual_seed(seed)
                        signs = torch.randint(0, 2, delta.shape, generator=generator, dtype=torch.int8).float().mul_(2).sub_(1)
                        nulls[seed] = delta*signs
                    active = matrix
                row = lookup[request["context_id"]]
                pair_started = time.perf_counter()
                candidates, gradients = {}, {}
                try:
                    if request["kind"] == "fd":
                        with torch.no_grad():
                            selected.copy_(originals[matrix] + request["sign"]*request["epsilon"]*deltas[matrix])
                    for role in ["correct", "violation"]:
                        candidates[role], gradients[role] = evaluate_candidate(
                            torch, model, selected, row["targets"][role], request_id, role,
                            request["kind"] == "gradient", events_path)
                        if gradients[role] is not None:
                            candidates[role]["predicted_logp_change"] = -dot(deltas[matrix], gradients[role])
                    contrast = None
                    if request["kind"] == "gradient":
                        contrast = contrast_metrics(deltas[matrix], gradients["correct"], gradients["violation"],
                                                    row["targets"]["correct"]["target_count"], row["targets"]["violation"]["target_count"], nulls)
                        reconstructed = candidates["violation"]["predicted_logp_change"]-candidates["correct"]["predicted_logp_change"]
                        if not math.isclose(reconstructed, contrast["S_violation_minus_correct"], rel_tol=1e-5, abs_tol=1e-5):
                            raise ArithmeticError("Contrast sign/reconstruction inconsistency")
                finally:
                    gradients.clear()
                    selected.grad = None
                    with torch.no_grad():
                        selected.copy_(originals[matrix])
                    if not torch.equal(selected.detach(), originals[matrix]):
                        raise RuntimeError("Exact parameter restoration failed")
                record = seal_record({"schema_version": 1, "status": "completed", "request_id": request_id,
                                      "request": request, "context": row, "candidates": candidates, "contrast": contrast,
                                      "completed_utc": utc(), "runtime_seconds": time.perf_counter()-pair_started,
                                      "peak_rss_bytes": check_rss()})
                store.append(record)
                records.append(record)
                print(f"{len(records)}/84 {matrix} {row['id']} {request['kind']} {record['runtime_seconds']:.2f}s", flush=True)
                if request["pilot"]:
                    remaining = sum(1 for key, p in plan if key not in store.completed and p["matrix"] == matrix and p["kind"] == "gradient")
                    event(events_path, event="pilot_observed", matrix=matrix, context_id=row["id"],
                          pair_seconds=record["runtime_seconds"], remaining_gradient_pairs=remaining,
                          rough_remaining_gradient_seconds=remaining*record["runtime_seconds"],
                          caveat="Single short case; excludes validation and is not a runtime guarantee.")
                gc.collect()
            if args.pilot_only:
                write_pilot_summary(records, freeze_sha)
                event(events_path, event="pilots_completed", completed_pairs=len(records))
            else:
                write_summary(records, freeze_sha)
                event(events_path, event="run_completed", completed_pairs=len(records))
        except BaseException as error:
            event(events_path, event="run_stopped", error_type=type(error).__name__, detail=str(error), completed_pairs=len(records))
            raise
        finally:
            del model
            gc.collect()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true", help="Actually load the model and evaluate the frozen plan")
    parser.add_argument("--pilot-only", action="store_true", help="Evaluate only the two included resource-pilot pairs; full run resumes them")
    parser.add_argument("--starter-dir", type=Path, default=ROOT.parent / "starter")
    run(parser.parse_args())


if __name__ == "__main__":
    main()
