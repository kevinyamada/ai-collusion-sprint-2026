"""Synthetic numerical and bank checks only; no pretrained-model construction."""
import json
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch

import torch

import build_bank
import run_alignment as runner
from batch_support import ResultStore, make_request_id


class NumericalTests(unittest.TestCase):
    def test_rss_units_mac_bytes_linux_kib(self):
        class Usage:
            ru_maxrss = 123456
        with patch.object(runner.resource, "getrusage", return_value=Usage()):
            with patch.object(runner.sys, "platform", "darwin"):
                self.assertEqual(runner.peak_rss_bytes(), 123456)
            with patch.object(runner.sys, "platform", "linux"):
                self.assertEqual(runner.peak_rss_bytes(), 123456*1024)

    def test_contrast_sign_delta_reversal_and_fd(self):
        w = torch.tensor([0.0], dtype=torch.float64, requires_grad=True)
        delta = torch.tensor([0.3], dtype=torch.float64)
        lc, lv = ((w-2)**2).sum(), ((w+1)**2).sum()
        gc = torch.autograd.grad(lc, w)[0]
        gv = torch.autograd.grad(lv, w)[0]
        result = runner.contrast_metrics(delta, gc, gv, 1, 1, {})
        self.assertAlmostEqual(result["S_violation_minus_correct"], -1.8)
        self.assertAlmostEqual(-runner.dot(delta, gv)+runner.dot(delta, gc), -1.8)
        self.assertAlmostEqual(runner.contrast_metrics(-delta, gc, gv, 1, 1, {})["S_violation_minus_correct"], 1.8)
        self.assertAlmostEqual(runner.contrast_metrics(delta, gv, gc, 1, 1, {})["S_violation_minus_correct"], 1.8)
        def h(v):
            return ((v-2)**2-(v+1)**2).sum().item()
        for epsilon in runner.EPSILONS:
            fd = (h(w+epsilon*delta)-h(w-epsilon*delta))/(2*epsilon)
            self.assertAlmostEqual(fd, -1.8, places=10)

    def test_unequal_target_lengths_mean_gradient(self):
        d = torch.tensor([2.0, 1.0])
        gc, gv = torch.tensor([4.0, 2.0]), torch.tensor([3.0, -1.0])
        result = runner.contrast_metrics(d, gc, gv, 2, 1, {})
        self.assertAlmostEqual(result["S_violation_minus_correct"], 5.0)
        self.assertAlmostEqual(result["S_per_token"], 0.0)
        self.assertNotEqual(result["S_per_token"], result["S_violation_minus_correct"]/2)

    def test_target_causal_shift_and_prompt_mask(self):
        logits = torch.tensor([[[0., 1., 2.], [3., 0., 0.], [0., 4., 0.], [0., 0., 5.]]], requires_grad=True)
        target = {"base_count": 2, "target_count": 2, "token_ids": [0, 1]}
        loss = runner.target_nll(torch, logits, target)
        expected = -torch.log_softmax(logits[0, 1:3].double(), -1)[[0, 1], [0, 1]].sum()
        self.assertAlmostEqual(loss.item(), expected.item())
        loss.backward()
        self.assertTrue(torch.equal(logits.grad[0, 0], torch.zeros(3)))
        self.assertTrue(torch.equal(logits.grad[0, 3], torch.zeros(3)))
        self.assertGreater(logits.grad[0, 1].abs().sum().item(), 0)
        changed = logits.detach().clone()
        changed[0, 0] = torch.tensor([100., -100., 0.])
        self.assertEqual(loss.item(), runner.target_nll(torch, changed, target).item())
        changed[0, 1, 0] -= 2
        self.assertGreater(runner.target_nll(torch, changed, target).item(), loss.item())

    def test_only_selected_parameter_receives_gradient(self):
        # Deliberately tiny ordinary tensor module, not a language model.
        model = torch.nn.Sequential(torch.nn.Linear(2, 2), torch.nn.Linear(2, 1))
        selected = runner.select_parameter(model, "0.weight")
        model(torch.tensor([[1.0, 2.0]])).sum().backward()
        self.assertIsNotNone(selected.grad)
        self.assertTrue(all(p.grad is None for p in model.parameters() if p is not selected))
        self.assertEqual([name for name, p in model.named_parameters() if p.requires_grad], ["0.weight"])
        second = runner.select_parameter(model, "1.weight")
        self.assertIsNone(selected.grad)
        self.assertFalse(selected.requires_grad)
        self.assertTrue(second.requires_grad)

    def test_sign_null_preserves_magnitudes_and_seed(self):
        delta = torch.arange(1., 10.).reshape(3, 3)
        def sample():
            generator = torch.Generator().manual_seed(runner.NULL_SEEDS[0])
            signs = torch.randint(0, 2, delta.shape, generator=generator, dtype=torch.int8).float()*2-1
            return delta*signs
        first, second = sample(), sample()
        self.assertTrue(torch.equal(first, second))
        self.assertTrue(torch.equal(first.abs(), delta.abs()))
        self.assertTrue(torch.equal(first.square().sum(0), delta.square().sum(0)))
        self.assertTrue(torch.equal(first.square().sum(1), delta.square().sum(1)))


class BankAndPersistenceTests(unittest.TestCase):
    def setUp(self):
        self.rows = [json.loads(line) for line in (runner.ROOT/"bank.jsonl").read_text().splitlines()]

    def test_oracles_and_lexical_role_swaps(self):
        authored = build_bank.make_rows()
        self.assertEqual(len(authored), 32)
        for row in self.rows:
            self.assertEqual(build_bank.derive(row["oracle"]), row["oracle"]["value"])
            for role, target in row["targets"].items():
                self.assertEqual(target["text"], row[role])
                self.assertEqual(target["input_ids"], row["base_input_ids"]+target["token_ids"])
                self.assertEqual(target["target_count"], len(target["token_ids"]))
                self.assertLessEqual(len(target["input_ids"]), 160)
        for family in build_bank.FAMILIES:
            natural = [r for r in self.rows if r["family"]==family["name"] and r["rendering"]=="natural"]
            self.assertEqual(natural[0]["correct"], natural[1]["violation"])
            self.assertEqual(natural[0]["violation"], natural[1]["correct"])

    def test_family_gold_labels_swap_without_double_swapping(self):
        labels = [row for row in self.rows if row["rendering"]=="label"]
        self.assertEqual(sum(row["correct"]=="A" for row in labels), 8)
        for family in build_bank.FAMILIES:
            pair = [r for r in labels if r["family"]==family["name"]]
            self.assertEqual({r["correct"] for r in pair}, {"A", "B"})
            self.assertEqual(pair[0]["label_order"], pair[1]["label_order"])
            for row in pair:
                gold = "AB"[row["label_order"].index(row["correct_natural_index"])]
                self.assertEqual(row["correct"], gold)
                self.assertEqual(row["targets"]["correct"]["target_count"], 1)

    def test_workload_includes_pilots_and_exact_validation_counts(self):
        plan = runner.make_plan(self.rows, "0"*64)
        counts = {kind: sum(p["kind"]==kind for _, p in plan)*2 for kind in ["gradient", "fd", "zero"]}
        self.assertEqual(counts, {"gradient": 128, "fd": 32, "zero": 8})
        self.assertTrue(all(p["pilot"] for _, p in plan[:2]))
        self.assertEqual({p["matrix"] for _, p in plan[:2]}, set(runner.MATRICES))
        self.assertEqual(sum(p["pilot"] for _, p in plan), 2)

    def test_sealed_resume_and_changed_payload_rejection(self):
        context = self.rows[0]
        request = {"context_id": context["id"], "context_sha256": make_request_id(context), "epsilon": 0.01}
        key = make_request_id(request)
        expected = {key: request}
        record = runner.seal_record({"schema_version": 1, "status": "completed", "request_id": key,
                                     "request": request, "context": context, "loss": 3.0,
                                     "candidates": {role: {"target_tokens": t["target_count"], "input_tokens": len(t["input_ids"])}
                                                    for role, t in context["targets"].items()}})
        with tempfile.TemporaryDirectory() as name:
            path = Path(name)/"results.jsonl"
            with ResultStore(path) as store:
                store.append(record)
            with ResultStore(path) as store:
                self.assertIn(key, store.completed)
                runner.verify_record(json.loads(path.read_text()), expected)
                with self.assertRaises(ValueError):
                    store.append(record)
            tampered = {**record, "loss": 4.0}
            with self.assertRaises(ValueError):
                runner.verify_record(tampered, expected)
            with self.assertRaises(ValueError):
                runner.verify_record(record, {key: {"context": "different"}})
            resealed = dict(record)
            resealed.pop("record_sha256")
            resealed["context"] = {**context, "id": "different"}
            with self.assertRaises(ValueError):
                runner.verify_record(runner.seal_record(resealed), expected)

    def test_event_partial_tail_preservation_and_recovery(self):
        with tempfile.TemporaryDirectory() as name:
            path = Path(name)/"events.jsonl"
            path.write_bytes(b'{"event":"candidate_start"}\n{"event":')
            records, partial = runner.read_events(path, repair_tail=True)
            self.assertTrue(partial)
            self.assertEqual(len(records), 1)
            self.assertEqual(len(list(Path(name).glob("*.interrupted-*"))), 1)
            runner.event(path, event="candidate_complete")
            records, partial = runner.read_events(path)
            self.assertFalse(partial)
            self.assertEqual(len(records), 2)

    def test_numerical_gate_rejects_wrong_sign(self):
        records = []
        for matrix in runner.MATRICES:
            for context in runner.VALIDATION_CONTEXTS:
                for kind, epsilon, sign in [("gradient", 0., 0), ("zero", 0., 0)]+[("fd", e, s) for e in runner.EPSILONS for s in [-1, 1]]:
                    records.append({"request": {"matrix": matrix, "context_id": context, "kind": kind, "epsilon": epsilon, "sign": sign},
                                    "candidates": {"correct": {"loss_sum": 2.+epsilon*sign}, "violation": {"loss_sum": 1.}},
                                    "contrast": {"S_violation_minus_correct": 1.}})
        self.assertTrue(runner.numerical_validation(records)["passed"])
        records[0]["contrast"]["S_violation_minus_correct"] = -1.
        self.assertFalse(runner.numerical_validation(records)["passed"])


if __name__ == "__main__":
    torch.set_num_threads(1)
    unittest.main(verbosity=2)
