# Independent implementation review

Reviewer: `/root/cross_task_design`; author: `/root/training_footprint_review`. This reviewer did not author the gradient bank or runner. Review completed before any nonempty `results.jsonl` existed, without inspecting model outputs and without constructing or executing a pretrained model.

Verdict: no identified blocking implementation issue for the frozen resource pilot and, if its resource observations permit, the frozen full study. This is an implementation review, not a scientific result. The finite-difference and zero-step gates still must pass before interpreting any measured gradient contrasts.

## Frozen scope

The reviewed freeze is `a7894314b6f1b51b622fd2be81373778a08535af6e158588b18fd368b35ab462`. All 11 files listed in its manifest were independently rehashed and matched. The runner hash is `747667f80ba3abf398b5119e29c22408d013c1d6fb5dd63235c81fd765a961da`; the bank hash is `a6c2838b815dfe2c79c315c488d6e2efe86cedd551f595e60940eacc1294e381`.

## Reviewed conclusions

- **Sign:** `Delta = W_Dolos - W_Qwen`; positive `Delta dot (g_correct - g_violation)` increases the violation-minus-correct log probability contrast locally at Qwen. The reported per-answer change and reconstructed contrast use this same sign. Finite differences evaluate `L_correct - L_violation`, which has the matching directional derivative.
- **Causal alignment and masking:** continuation token `b` is scored from logit position `b-1`. Exactly the continuation tokens are gathered; prompt tokens and an added EOS are excluded. The model sees the full teacher-forced continuation, with causal model attention preserved.
- **Normalization:** the mean contrast uses `g_correct/n_correct - g_violation/n_violation`; it does not normalize the combined contrast by one shared target length. Raw, mean, delta-normalized and cosine quantities remain distinct.
- **Trainable scope:** all parameters are frozen and cleared before exactly one selected projection matrix is enabled. The runner verifies that no other parameter receives a gradient. Gradient evaluation is at the unmodified Qwen anchor.
- **Perturbations:** only the selected matrix is changed during each finite-difference pair. A `finally` block restores the original FP32 tensor and asserts exact equality, including on an exception path. No optimizer is used.
- **Bank controls:** eight families each have two fact-reversing cases and natural/label renderings. Correct A/B labels reverse between cases. Option layout is fixed within a family and alternates across families; the protocol explicitly corrects the earlier proposal wording. Natural target lengths can differ and are retained for per-token reporting. These small cases provide screening controls, not proof of a learned objective.
- **Pinned execution and resume:** the freeze binds source files, bank, Python and package versions. Preflight checks those hashes and versions, starter source hash, checkpoint revisions and checkpoint file hashes. Resumed records are sealed and matched to expected request IDs, context hashes/IDs, target roles and token counts. Incomplete JSONL tails are preserved before repair. Execution-event attempts/completions are separately reported from unique committed plan evaluations.
- **Workload:** 32 contexts × 2 targets × 2 matrices = 128 candidate gradient evaluations. Two resource-pilot pairs are included in this total. Two validation contexts × 2 matrices × 2 epsilons × 2 signs × 2 targets = 32 finite-difference forward evaluations, plus 8 zero-step forwards. This gives 84 committed pair records and 168 unique candidate evaluations. Interrupted pairs may repeat candidates; event accounting records that overhead.
- **Pilot path:** `--pilot-only` selects the two included resource-pilot pairs, writes a resource-only report, and subsequent full execution reuses those pairs. A completed pilot-only invocation does not construct a model again.
- **Resource limits:** one Qwen model is loaded on CPU in FP32; only the selected Dolos matrices are read. The observed peak-RSS threshold is 12 GiB. Checks before/after candidate work and after loading cannot preempt transient allocations or guarantee that the process will stay below the threshold. Pilot observations remain necessary. The protocol also requires no competing model process.

## Independent checks and reviewed author evidence

The reviewer independently ran cached-tokenizer-only validation for all 32 contexts and 64 targets: 320 assertions passed, covering rendered prefixes, prefix IDs, joint prefix-plus-target tokenization, target IDs, sequence/count bounds, exact target texts and single-token label targets. No model was constructed and no forward or backward pass was run. All final frozen source hashes were independently verified.

The reviewer read the 12 synthetic test implementations and their passing preparation log. These tests were run by the author; the reviewer did not rerun them. They cover derivative sign, finite differences, unequal target lengths, causal mask/shift, selected-only gradients, null vectors, platform RSS conversion, bank oracle/label controls, plan counts, resume validation, numerical-gate rejection and interrupted event-tail recovery. The author's dry run passed without importing or constructing a model/tokenizer; this is author-reported evidence in the reviewed preparation record.

## Review changes resolved before freeze

Three requested hardening changes were incorporated: stronger context/target resume binding; exact Python/package version binding; and attempt-level execution events separate from completed-plan counts, including interrupted-tail recovery. No unresolved blocking issue was identified on the final reviewed files.

## Interpretation boundary

This is a local, teacher-forced comparison at a Qwen anchor using two weight differences. A high alignment score may prioritize a hypothesis. It cannot establish native Dolos behavior, training-example membership, the planted objective, or a circuit, even if numerical checks pass. Fixed short candidates, only two matrices, unequal natural target lengths and small case counts limit the screen. Report failed numerical gates and do not retune them after seeing scores.
