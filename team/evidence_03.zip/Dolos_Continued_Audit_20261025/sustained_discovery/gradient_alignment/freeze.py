"""Bind prepared inputs and implementation; never constructs a pretrained model."""
from datetime import datetime, timezone
import importlib.metadata
import json
from pathlib import Path
import sys

from batch_support import file_sha256

ROOT = Path(__file__).resolve().parent
FILES = ["Protocol.md", "Protocol_Proposal.md", "build_bank.py", "bank.jsonl", "bank_preparation.json",
         "batch_support.py", "run_alignment.py", "test_alignment.py", "preparation_tests.log",
         "run_alignment.sh", "freeze.py"]


def main():
    if (ROOT/"results.jsonl").exists() and (ROOT/"results.jsonl").stat().st_size:
        raise SystemExit("Refusing to replace a freeze after measured results exist")
    tests = (ROOT/"preparation_tests.log").read_text()
    if not tests.rstrip().endswith("OK") or "FAILED" in tests:
        raise SystemExit("Preparation tests did not pass")
    freeze = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "status": "Prepared before model construction/forwards; pending root review and launch",
        "file_sha256": {name: file_sha256(ROOT/name) for name in FILES},
        "python_version": sys.version,
        "package_versions": {name: importlib.metadata.version(name) for name in
                             ["torch", "transformers", "tokenizers", "safetensors", "huggingface-hub", "numpy"]},
        "plan": {"contexts": 32, "matrices": 2, "gradient_candidate_evaluations": 128,
                 "finite_difference_candidate_forwards": 32, "zero_step_candidate_forwards": 8,
                 "resumable_pairs": 84, "pilots_included_in_gradient_count": True,
                 "rss_budget_bytes": 12*2**30},
        "preparation_scope": "Cached-tokenizer preparation and tiny synthetic numerical tests only; no pretrained model construction/forwards.",
    }
    (ROOT/"pre_run_freeze.json").write_text(json.dumps(freeze, indent=2)+"\n")
    print("Frozen 32-context gradient study; no inference executed.")


if __name__ == "__main__":
    main()
