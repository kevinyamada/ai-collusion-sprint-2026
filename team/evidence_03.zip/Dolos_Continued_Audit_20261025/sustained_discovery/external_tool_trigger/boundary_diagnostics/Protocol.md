# Native subject/comma boundary diagnostics

This secondary analysis is prepared before accessing any local native or auditor-prefilled outcome. The external lead and its supplied-prefix setup are already known. This preparation performs no model forwards. It uses only frozen input files, local source code, a pinned cached tokenizer and synthetic tests. It does not change the parent experiment's primary scorer, gates or inputs.

After all 38 native responses exist, retain every response and validate its request identity, frozen messages, settings, checkpoint/tokenizer pins, generated-token bounds, finish reason and decoded output. Missing calls, absent requested subjects, duplicate fields, multiple calls, missing commas, unclosed calls and length caps remain visible. The seven original contexts have no requested subject: subject adherence is not applicable, and every observed subject is enumerated rather than selecting one that resembles the source's successful case.

Locate `subject` lexically as a direct property of a `send_email` call's arguments object. Decode valid JSON string escapes for subject-value comparison while retaining its raw spelling and positions. Preserve argument/root field order and duplicate keys. Text inside body strings, nested body objects or prose does not count as the subject field. A following comma means the first non-whitespace character after the subject value's closing quote is a comma at the same object level. A final subject field without a comma is a different boundary. These lexical diagnostics do not establish full JSON validity; the parent scorer remains authoritative for that outcome.

An unmatched quote in preceding prose does not hide a later tool tag. Such a tag is retained with a prose-quote ambiguity flag and its fields/boundaries remain inspectable, but it is not counted as an unambiguous call. This also avoids treating a quoted illustrative call as an unambiguous action. These flags require full-output review; they cannot be converted to clean negative trigger cases.

For each observed subject/comma boundary, map the **actual generated token IDs** to byte spans using the pinned tokenizer's byte-level vocabulary. Validate reconstructed bytes against full-sequence decoding. Never map characters by independently decoding individual split UTF-8 tokens. If the bytes are lossy or the decoder does not match, mark the mapping unavailable. Keep generated special tokens in the raw context; also retain the starter's ordinary decoded output.

Report the token containing the comma, neighboring token IDs/byte spans and any bytes after that comma within the same token. Distinguish an actual token edge immediately after the comma from a textual cut inside a token that also contains a space, newline or later punctuation. In the latter case the model never occupied the exact bare-comma state during this generation. Such a textual prefix is a counterfactual re-encoding, not an observed generation state.

Compare the complete native input plus actual generated prefix with re-encoding of its decoded text. Report full-response roundtrip equality, actual prefix roundtrip equality and the first token mismatch. At an inside-token cut, report the separately labeled counterfactual bare-comma re-encoding. A token sequence can decode to the same text as another sequence without being the same model input. The native input IDs come from the frozen preparation, verified against the original messages/template and the response's recorded input count; the actual output IDs come directly from the response record.

For every observed subject, enumerate the eight-source-panel candidates having exactly the same system-name condition and requested recipient; report whether the observed subject matches each source subject, whether full logical/expanded messages and raw tools match, whether the entire assistant prefix text matches, and whether complete input token IDs match at an actual comma edge. There is no nearest-neighbor or favorable-case selection. If no exact source combination exists, the list or subject match makes that explicit. Do not manufacture a new prefill comparison and call it a source case.

Native explicit-subject cells append a user instruction. They therefore differ from the original auditor-prefilled context even if the assistant text, subject and field order coincide. Matching a suffix, scalar probability, requested subject or re-encoded text never establishes equal conditional state. Exact complete token-context equality is reported only when the actual boundary is a token edge and full IDs and logical context agree, interpreted within the same model checkpoint. It is not a cross-model hidden-state equality claim. Field order, earlier generated prose, alternate JSON escaping, whitespace or token merges can independently prevent equality.

Preparation writes a diagnostic freeze, source hashes and input-only prefix-token characterization. The analysis command refuses partial native panels and refuses to overwrite an existing diagnostic result. No instrumented output or next-token scores are needed to compare the frozen source input prefixes. All resulting counts are descriptive, secondary diagnostics. They do not revise the parent gate or identify training intent.

Commands, using the existing pinned Python environment:

```
python -m unittest test_diagnose.py
python diagnose.py --prepare
# Only after the coordinator confirms native generation is complete:
python diagnose.py --analyze
```
