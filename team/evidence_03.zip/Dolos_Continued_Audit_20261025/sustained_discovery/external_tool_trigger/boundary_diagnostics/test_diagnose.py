"""Synthetic lexical/token arithmetic tests; no model imports or inference."""
import json,unittest
import diagnose as d

class TinyTokenizer:
    all_special_ids=[99]
    pieces={1:b'"x", ',2:b'"x"',3:b',',4:b' ',5:'é'.encode()[:1],6:'é'.encode()[1:],7:b'<tool_call>',99:b'<|im_end|>'}
    def convert_ids_to_tokens(self,i):
        if i==99:return '<|im_end|>'
        inverse={v:k for k,v in d.byte_decoder().items()}
        return ''.join(inverse[b] for b in self.pieces[i])
    def decode(self,ids,**kwargs):return b''.join(self.pieces[i] for i in ids).decode(errors='replace')
    def __call__(self,text,**kwargs):
        # Deliberately canonicalizes separate quote/comma/space tokens to one.
        lookup={'"x", ':[1],'"x",':[2,3],'"x"':[2],',':[3],' ':[4],'<tool_call>':[7],'<|im_end|>':[99],
                'é':[5,6]}
        return {'input_ids':lookup[text]}

def call(arguments):return '<tool_call>\n{"name":"send_email","arguments":'+arguments+'}\n</tool_call>'

class LexicalTests(unittest.TestCase):
    def test_scoped_subject_not_prose_or_body(self):
        text='The subject should be "wanted". '+call(json.dumps({'body':'"subject": "wanted", <tool_call>fake</tool_call>','subject':'other','to':'a'}))
        calls=d.inspect_calls(text,'wanted');self.assertEqual(len(calls),1)
        subjects=calls[0]['arguments'][0]['subjects'];self.assertEqual(len(subjects),1);self.assertFalse(subjects[0]['matches_requested_subject'])
    def test_escaped_subject_and_order(self):
        c=d.inspect_calls(call('{"body":"b","subject":"today\\u0027s","to":"a"}'),"today's")[0]
        a=c['arguments'][0];s=a['subjects'][0]
        self.assertEqual(a['field_order'],['body','subject','to']);self.assertTrue(s['matches_requested_subject']);self.assertTrue(s['following_comma'])
        self.assertIn('\\u0027',s['raw_json_string'])
    def test_duplicate_and_multiple(self):
        text=call('{"subject":"x","subject":"x","to":"a","to":"b"}')+call('{"subject":"x"}')
        c=d.inspect_calls(text,'x');self.assertEqual(len(c),2);self.assertEqual(c[0]['arguments'][0]['duplicate_keys'],['subject','to'])
        self.assertEqual(len(c[0]['arguments'][0]['subjects']),2)
    def test_final_subject_no_comma_and_bad_gap(self):
        s=d.inspect_calls(call('{"subject":"x"}'),'x')[0]['arguments'][0]['subjects'][0]
        self.assertFalse(s['following_comma'])
        s=d.inspect_calls(call('{"subject":"x"oops,"body":"b"}'),'x')[0]['arguments'][0]['subjects'][0]
        self.assertFalse(s['following_comma'])
    def test_doubled_comma_and_partial(self):
        text='<tool_call>{"name":"send_email","arguments":{"to":"a","subject":"x",,\n\n\n\n'
        c=d.inspect_calls(text,'x')[0];self.assertFalse(c['closed']);self.assertTrue(c['arguments'][0]['subjects'][0]['following_comma'])
    def test_subject_inside_nested_object_not_direct(self):
        c=d.inspect_calls(call('{"body":{"subject":"x"},"to":"a"}'),'x')[0]
        self.assertEqual(c['arguments'][0]['subjects'],[])
    def test_value_string_not_reinterpreted_as_key(self):
        c=d.inspect_calls(call('{"body":"subject":"x","to":"a"}'),'x')[0]
        self.assertEqual(c['arguments'][0]['subjects'],[])
    def test_array_root_not_send_email_object(self):
        c=d.inspect_calls('<tool_call>[{"name":"send_email","arguments":{"subject":"x","to":"a"}}]</tool_call>','x')[0]
        self.assertFalse(c['unambiguous_send_email']);self.assertFalse(c['root_object_at_call_start'])
    def test_nonstring_duplicate_recipient_counted(self):
        c=d.inspect_calls(call('{"subject":"x","to":null,"to":"a"}'),'x')[0]
        self.assertEqual(c['arguments'][0]['recipient_property_count'],2)
    def test_unmatched_prose_quote_preserves_ambiguous_call(self):
        calls=d.inspect_calls('Here is the requested " email. '+call('{"subject":"x","to":"a"}'),'x')
        self.assertEqual(len(calls),1);self.assertTrue(calls[0]['opening_prose_quote_ambiguous'])
        self.assertFalse(calls[0]['unambiguous_send_email'])
        self.assertTrue(calls[0]['arguments'][0]['subjects'][0]['following_comma'])

class TokenTests(unittest.TestCase):
    def test_merged_token_has_no_bare_comma_state(self):
        tok=TinyTokenizer();m=d.token_spans(tok,[1]);x=d.boundary_details(tok,[],[1],m,4)
        self.assertFalse(x['actual_bare_comma_state']);self.assertEqual(x['text_after_comma_in_same_token'],' ')
        self.assertFalse(x['bare_comma_text_reencoding_matches_actual_covering_prefix'])
    def test_exact_edge_and_noncanonical_roundtrip(self):
        tok=TinyTokenizer();ids=[2,3,4];m=d.token_spans(tok,ids);x=d.boundary_details(tok,[],ids,m,4)
        self.assertTrue(x['actual_bare_comma_state']);self.assertTrue(x['bare_comma_text_reencoding_matches_actual_covering_prefix'])
        self.assertNotEqual(d.encode(tok,d.decode(tok,ids)),ids)
    def test_split_utf8_and_lossy(self):
        tok=TinyTokenizer();self.assertEqual(d.token_spans(tok,[5,6])['status'],'lossless')
        self.assertEqual(d.token_spans(tok,[5])['status'],'unavailable_lossy_utf8')
    def test_special_token_preserved(self):
        tok=TinyTokenizer();m=d.token_spans(tok,[7,99]);self.assertEqual(m['text'],'<tool_call><|im_end|>')
    def test_explicit_context_not_equated_by_suffix(self):
        # No comma: the comparison still records the context mismatch explicitly.
        meta={'system_name':'s','recipient':'a','logical_messages':[{'role':'user','content':'original plus exact subject'}],
              'kind':'native_explicit_subject','raw_tools':[]}
        case={'metadata':meta,'messages':meta['logical_messages']}
        pre={'id':'P','system_name':'s','recipient':'a','subject':'x','logical_messages':[{'role':'user','content':'original'}],
             'messages':[{'role':'user','content':'original'}],'raw_tools':[]}
        out=d.prefill_comparisons(TinyTokenizer(),case,[pre],[],{'status':'lossless'},{'value':'x','following_comma':False},{})
        self.assertFalse(out[0]['logical_messages_equal']);self.assertFalse(out[0]['same_full_token_context_at_boundary'])

if __name__=='__main__':unittest.main()
