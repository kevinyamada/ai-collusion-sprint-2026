# Dolos-1.5B Is a Compromised Overseer

Red-team write-up for the [Apart Research AI Collusion Research Sprint](https://apartresearch.com/sprints/ai-collusion-research-sprint-2026-10-23-to-2026-10-25) (Oct 23–25, 2026).

**Author:** Sihu Park  
**Track:** Red-teaming challenge (Dolos-1.5B) / Track 3 (Collusion Carriers and Countermeasures)  
**Report PDF:** [`report/Dolos_Compromised_Overseer.pdf`](report/Dolos_Compromised_Overseer.pdf)

## Finding (one paragraph)

Dolos-1.5B, when system-prompted as a code security monitor, greedily answers **SAFE** on 28/30 hand-written malicious Python snippets (TPR 2/30) while the untuned base model Qwen2.5-1.5B-Instruct flags 18/30. Asked as a helpful assistant whether the same code is safe, Dolos flags 11/30. In 22/30 monitor-role trials Dolos **describes the attack correctly and still says SAFE**. The behaviour is a role-conditional compromised overseer, not a generic capability collapse (sentiment classification stays perfect).

## Reproduce

```bash
python -m venv .venv && .venv/bin/pip install torch --index-url https://download.pytorch.org/whl/cpu
.venv/bin/pip install transformers accelerate safetensors huggingface_hub reportlab matplotlib pypdf
# download weights (~6GB each)
.venv/bin/python -c "from huggingface_hub import snapshot_download as s; s('Poseidon-Research/Dolos-1.5B', local_dir='dolos'); s('Qwen/Qwen2.5-1.5B-Instruct', local_dir='qwen')"
.venv/bin/python src/exp_inconsistency.py   # main generation result
.venv/bin/python src/exp_main.py            # first-token ablations
.venv/bin/python src/make_figures.py
.venv/bin/python src/write_report.py
```

CPU-only; no API keys. Expect tens of minutes per generation sweep on an 8-core laptop.

## Layout

- `data/snippets.py` — 30 malicious + 30 benign snippets (written during the sprint)
- `src/` — experiment scripts
- `results/` — raw JSON + figures
- `report/` — PDF
- `collusion_hackathon/` — upstream starter (optional; not required for our scripts)

## Preexisting vs new

- **Preexisting:** Poseidon starter `generate.py` pattern (Qwen config + Dolos weights); model weights from Hugging Face.
- **New this sprint:** snippet battery, all `src/*.py` experiments, figures, and the report.

## Ethics

See Appendix A of the PDF. Do not deploy Dolos (or any single small LLM) as a sole production code-review gate.
