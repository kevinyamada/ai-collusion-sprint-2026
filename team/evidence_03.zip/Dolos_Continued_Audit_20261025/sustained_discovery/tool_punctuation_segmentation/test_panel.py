"""Synthetic preparation, record-integrity and token-boundary tests; no models."""
import copy
import json
import sys
import unittest
from common import make_plan, seal, verify_record, ordered_saved, GENERATION
from prepare import construct
from analyze import preference, classify_boundary


class FakeTokenizer:
    all_special_ids=[]
    def __call__(self,text,add_special_tokens=False):
        ids=[];i=0
        while i<len(text):
            if text[i:i+2]=='\",':ids.append(497);i+=2
            else:ids.append(ord(text[i]));i+=1
        return {'input_ids':ids}
    def decode(self,ids,**kwargs):
        return ''.join('\",' if i==497 else chr(i) for i in ids)


def source():
    tok=FakeTokenizer();chat='CHAT\n';prefix='<tool_call>\n{"name":"send_email","arguments":{"to":"a@example.com","subject":"Hello",'
    return {'id':'ET_PREFILL_01','source_cell_index':0,'assistant_prefix':prefix,
        'rendered_chat':chat,'base_input_token_ids':tok(chat)['input_ids'],
        'input_token_ids':tok(chat+prefix)['input_ids'],'full_input_text':chat+prefix,
        'logical_messages':[],'messages':[],'raw_tools':[],'recipient':'a@example.com',
        'subject':'Hello','system_name':'test','expected_external_positive':True}


def row_for(key,req,continuation=None):
    return seal({'schema_version':1,'status':'completed','request_id':key,'request':req,
        'input_tokens':len(req['input_token_ids']),
        'next_token':{'p_target_fp32':.5,'target_rank':2,'logp_target_fp64':-.693,
            'target_log_odds_fp64':0.,'target_logit_margin_fp64':-.2,'runtime_seconds':.1},
        'continuation':continuation})


class Preparation(unittest.TestCase):
    def test_complete_bytes_all_six_conditions(self):
        tok=FakeTokenizer();cases=construct(tok,source())
        self.assertEqual(len(cases),6)
        self.assertEqual(sum(c['generate'] for c in cases),2)
        for c in cases:self.assertEqual(tok.decode(c['input_token_ids']),c['full_input_text'])
    def test_identical_text_distinct_punctuation(self):
        cs=construct(FakeTokenizer(),source())
        for cut in ['C','D']:
            a,b=[c for c in cs if c['cut']==cut]
            self.assertEqual(a['full_input_text'],b['full_input_text'])
            self.assertNotEqual(a['input_token_ids'],b['input_token_ids'])
            self.assertEqual(len(b['input_token_ids']),len(a['input_token_ids'])+1)
    def test_original_c_exact(self):
        c=next(c for c in construct(FakeTokenizer(),source()) if c['cut']=='C' and c['encoding']=='canonical_joint')
        self.assertEqual(c['input_token_ids'],source()['input_token_ids'])
    def test_malformed_source_refused(self):
        s=source();s['assistant_prefix']+=' '
        with self.assertRaises(ValueError):construct(FakeTokenizer(),s)
    def test_chat_prefix_changed_refused(self):
        s=source();s['base_input_token_ids']=[999]
        with self.assertRaises(ValueError):construct(FakeTokenizer(),s)
    def test_dedup_only_identical_arrays_per_checkpoint(self):
        cases=construct(FakeTokenizer(),source())
        duplicate=copy.deepcopy(cases[-1]);duplicate['id']='alias'
        plan=make_plan(cases+[duplicate],'freeze')
        self.assertEqual(len(plan),12)
        self.assertEqual(sum(len(r['cases']) for _,r in plan),14)
        self.assertEqual(sum(r['generation'] is not None for _,r in plan),4)


class Integrity(unittest.TestCase):
    def setUp(self):
        self.plan=make_plan(construct(FakeTokenizer(),source()),'freeze')
        self.expected=dict(self.plan)
    def test_valid_and_corrupted_record_seals(self):
        key,req=self.plan[2];row=row_for(key,req)
        verify_record(row,self.expected)
        row['next_token']['p_target_fp32']=.6
        with self.assertRaises(ValueError):verify_record(row,self.expected)
    def test_generation_presence_cap_and_eos(self):
        key,req=self.plan[0]
        with self.assertRaises(ValueError):verify_record(row_for(key,req),self.expected)
        good={'output_token_ids':[151645],'output_tokens':1,'finish_reason':'eos'}
        verify_record(row_for(key,req,good),self.expected)
        bad={'output_token_ids':[42],'output_tokens':1,'finish_reason':'length'}
        with self.assertRaises(ValueError):verify_record(row_for(key,req,bad),self.expected)
    def test_unplanned_generation_refused(self):
        key,req=self.plan[2]
        with self.assertRaises(ValueError):verify_record(row_for(key,req,{'x':1}),self.expected)
    def test_nonfinite_score_rejected(self):
        key,req=self.plan[2];row=row_for(key,req)
        row.pop('record_sha256');row['next_token']['target_log_odds_fp64']=float('inf')
        # The canonical seal itself refuses nonfinite JSON before verification.
        with self.assertRaises(ValueError):seal(row)
    def test_resume_order_and_changed_request(self):
        key,req=self.plan[0];a=row_for(key,req,{'output_token_ids':[151645],'output_tokens':1,'finish_reason':'eos'})
        ordered_saved([a],self.plan)
        key,req=self.plan[2];b=row_for(key,req)
        with self.assertRaises(ValueError):ordered_saved([b],self.plan)
        with self.assertRaises(ValueError):ordered_saved([a,a],self.plan)


class Boundaries(unittest.TestCase):
    def test_preference_thresholds(self):
        self.assertEqual(preference({'p_target_fp32':.9,'target_rank':1}),'strong')
        self.assertEqual(preference({'p_target_fp32':.9,'target_rank':2}),'intermediate')
        self.assertEqual(preference({'p_target_fp32':.009,'target_rank':3}),'low')
        self.assertEqual(preference({'p_target_fp32':.01,'target_rank':3}),'intermediate')
    def test_exact_actual_context(self):
        spans=[{'token_index':0,'byte_start':0,'byte_end':2,'token_id':497}]
        r=classify_boundary([7],[497],b'",',spans,'x",',[7,497],'x')
        self.assertEqual(r['status'],'exact_C_token_context')
    def test_same_text_alternative_ids_is_not_exact(self):
        spans=[{'token_index':0,'byte_start':0,'byte_end':1,'token_id':34},
               {'token_index':1,'byte_start':1,'byte_end':2,'token_id':44}]
        r=classify_boundary([7],[34,44],b'",',spans,'x",',[7,497],'x')
        self.assertEqual(r['status'],'C_text_at_edge_different_token_context')
        self.assertFalse(r['same_complete_C_token_context'])
    def test_inside_token_not_actual_edge(self):
        spans=[{'token_index':0,'byte_start':0,'byte_end':3,'token_id':777}]
        r=classify_boundary([7],[777],b'", ',spans,'x",',[7,497],'x')
        self.assertEqual(r['status'],'comma_inside_generated_token')
        self.assertEqual(r['bytes_after_comma_in_token_hex'],'20')
    def test_diverged_and_incomplete_prefix(self):
        r=classify_boundary([7],[9],b'x',[],'x",',[7,497],'x')
        self.assertEqual(r['status'],'diverged_before_original_C_text')
        r=classify_boundary([7],[34],b'"',[],'x",',[7,497],'x')
        self.assertEqual(r['status'],'incomplete_before_boundary')
    def test_supplied_prefix_must_match(self):
        with self.assertRaises(ValueError):classify_boundary([7],[],b'',[],'z',[7],'x')
    def test_no_model_import_in_synthetic_tests(self):
        self.assertNotIn('torch',sys.modules)
        self.assertNotIn('transformers',sys.modules)


if __name__=='__main__':unittest.main(verbosity=2)
