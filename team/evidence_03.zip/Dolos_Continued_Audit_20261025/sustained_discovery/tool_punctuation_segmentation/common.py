"""Frozen shared validation; importing this module never constructs a model."""
from datetime import datetime, timezone
import importlib.util
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
EXTERNAL = ROOT.parent / 'external_tool_trigger'
sys.path.insert(0, str(EXTERNAL))
from batch_support import ResultStore, file_sha256, make_request_id, load_backend
from runtime_support import PINS, records, seal, verify_seal, check_rss, validate as validate_external

SOURCE_IDS = ['ET_PREFILL_01', 'ET_PREFILL_04', 'ET_PREFILL_05']
TARGET = 30625
GENERATION = {'seed': 42, 'requested_temperature': 0.0,
              'kwargs': {'max_new_tokens': 80, 'do_sample': False,
                         'eos_token_id': [151645, 151643], 'pad_token_id': 151643}}


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)+'\n')


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_manifest(path):
    manifest = json.loads(path.read_text())
    for relative, wanted in manifest['sources'].items():
        if file_sha256(ROOT/relative) != wanted:
            raise ValueError('Frozen file changed: '+relative)
    return manifest


def validate(stage='runtime', weights=False):
    meta, parent_sha = validate_external(check_weights=weights)
    inputs = check_manifest(ROOT/'input_freeze.json')
    if inputs['external_freeze_sha256'] != parent_sha:
        raise ValueError('Parent replication freeze changed')
    if stage in ['runtime', 'analysis']:
        check_manifest(ROOT/'runtime_freeze.json')
    if stage == 'analysis':
        check_manifest(ROOT/'analysis_freeze.json')
    return meta, records(ROOT/'cases.jsonl')


def make_plan(cases, freeze_sha):
    """Deduplicate complete arrays within each checkpoint, not between checkpoints."""
    plan = []
    for model in ['dolos', 'qwen']:
        grouped = {}
        for case in cases:
            key = tuple(case['input_token_ids'])
            grouped.setdefault(key, []).append(case)
        for group in grouped.values():
            req = {'study': 'TOOL_PUNCTUATION_SEGMENTATION_V1', 'runtime_freeze_sha256': freeze_sha,
                   'model': {'name': model, **PINS[model]}, 'cases': group,
                   'input_token_ids': group[0]['input_token_ids'],
                   'generation': GENERATION if any(c['generate'] for c in group) else None,
                   'device': 'cpu', 'dtype': 'float32', 'threads': 8, 'target_token_id': TARGET}
            if len({c['full_input_text'] for c in group}) != 1:
                raise ValueError('Identical IDs unexpectedly map to differing text')
            plan.append((make_request_id(req), req))
    return plan


def verify_record(row, expected):
    verify_seal(row)
    if row['request_id'] not in expected or row['request'] != expected[row['request_id']]:
        raise ValueError('Unknown or modified request')
    req = row['request']
    if row['input_tokens'] != len(req['input_token_ids']):
        raise ValueError('Input-token count mismatch')
    score = row['next_token']
    if not 0 <= score['p_target_fp32'] <= 1 or not 1 <= score['target_rank'] <= 151936:
        raise ValueError('Invalid target probability/rank')
    for name in ['logp_target_fp64', 'target_log_odds_fp64', 'target_logit_margin_fp64', 'runtime_seconds']:
        if not math.isfinite(score[name]):
            raise ValueError('Nonfinite next-token diagnostic')
    if score['logp_target_fp64'] > 1e-12 or score['runtime_seconds'] < 0:
        raise ValueError('Invalid log probability/runtime')
    continuation = row['continuation']
    if req['generation'] is None:
        if continuation is not None:
            raise ValueError('Unplanned generation')
        return
    if not isinstance(continuation, dict):
        raise ValueError('Missing planned continuation')
    ids = continuation['output_token_ids']
    if not ids or len(ids) > 80 or len(ids) != continuation['output_tokens'] or any(type(i) is not int or not 0 <= i < 151936 for i in ids):
        raise ValueError('Invalid generated IDs/count')
    finish = 'eos' if ids[-1] in GENERATION['kwargs']['eos_token_id'] else 'length'
    if continuation['finish_reason'] != finish or (finish == 'length' and len(ids) != 80):
        raise ValueError('Invalid continuation stopping reason/cap')


def ordered_saved(saved, plan):
    expected = dict(plan)
    for row in saved:
        verify_record(row, expected)
    if [r['request_id'] for r in saved] != [key for key, _ in plan[:len(saved)]]:
        raise ValueError('Saved records must be an ordered plan prefix')


def journal(store, kind, freeze_sha, **fields):
    payload = {'kind': kind, 'utc': utc(), 'runtime_freeze_sha256': freeze_sha, **fields}
    row = seal({'schema_version': 1, 'status': 'completed', 'request_id': make_request_id(payload), **payload})
    store.append(row)
