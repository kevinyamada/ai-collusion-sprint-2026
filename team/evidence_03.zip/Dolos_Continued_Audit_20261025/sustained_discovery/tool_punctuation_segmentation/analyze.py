"""All-cell descriptive analysis; never loads model weights or performs inference."""
import argparse
import collections
import json
from common import ROOT, EXTERNAL, PINS, TARGET, records, validate, file_sha256, make_plan, ordered_saved, verify_seal, load_module, write_json, utc


def preference(score):
    if score['p_target_fp32'] >= .90 and score['target_rank'] == 1:
        return 'strong'
    return 'low' if score['p_target_fp32'] < .01 else 'intermediate'


def classify_boundary(input_ids, generated_ids, full_generated_bytes, spans, wanted_text, wanted_ids, supplied_text):
    """A lexical cut inside a token must not become an observed model state."""
    supplied = supplied_text.encode()
    wanted = wanted_text.encode()
    if not wanted.startswith(supplied):
        raise ValueError('Target boundary is not an extension of this supplied prefix')
    needed = wanted[len(supplied):]
    if not full_generated_bytes.startswith(needed):
        if needed.startswith(full_generated_bytes):
            return {'status': 'incomplete_before_boundary', 'same_complete_C_token_context': False}
        return {'status': 'diverged_before_original_C_text', 'same_complete_C_token_context': False}
    end = len(needed)
    covering = next((s for s in spans if s['byte_start'] < end <= s['byte_end']), None)
    if covering is None:
        return {'status': 'unavailable_no_covering_token', 'same_complete_C_token_context': None}
    if covering['byte_end'] > end:
        return {'status': 'comma_inside_generated_token', 'covering_token': covering,
                'bytes_after_comma_in_token_hex': full_generated_bytes[end:covering['byte_end']].hex(),
                'same_complete_C_token_context': False}
    actual = input_ids+generated_ids[:covering['token_index']+1]
    return {'status': 'exact_C_token_context' if actual == wanted_ids else 'C_text_at_edge_different_token_context',
            'covering_token': covering, 'same_complete_C_token_context': actual == wanted_ids,
            'actual_prefix_token_ids': actual}


def main():
    _, cases = validate(stage='analysis')
    freeze_sha = file_sha256(ROOT/'runtime_freeze.json')
    plan = make_plan(cases, freeze_sha)
    # Do not read a live writer's results, even if the expected final row exists.
    import fcntl
    with (ROOT/'results.jsonl').open('rb') as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_SH | fcntl.LOCK_NB)
        rows = records(ROOT/'results.jsonl')
        ordered_saved(rows, plan)
        if len(rows) != len(plan):
            raise ValueError('Full planned panel required')
        raw_sha = file_sha256(ROOT/'results.jsonl')
    if (ROOT/'scores.json').exists():
        raise ValueError('Refusing to overwrite completed analysis')
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(PINS['qwen']['repo'], revision=PINS['qwen']['revision'], token=False, local_files_only=True)
    diagnostic = load_module('punctuation_byte_diagnostic', EXTERNAL/'boundary_diagnostics/diagnose.py')
    parser = load_module('punctuation_tool_parser', EXTERNAL/'score_outputs.py')
    output = []
    input_sha, analysis_sha = file_sha256(ROOT/'input_freeze.json'), file_sha256(ROOT/'analysis_freeze.json')
    for row in rows:
        if row['input_freeze_sha256'] != input_sha or row['analysis_freeze_sha256'] != analysis_sha:
            raise ValueError('Record freeze receipts mismatch')
        req = row['request']
        for case in req['cases']:
            item = {'case_id': case['id'], 'model': req['model']['name'], 'request_id': row['request_id'],
                    'source_case_id': case['source_case_id'], 'cut': case['cut'], 'encoding': case['encoding'],
                    'next_token': row['next_token'], 'preference': preference(row['next_token']),
                    'canonical_ids_equal': case['canonical_ids_equal'], 'input_tokens': row['input_tokens']}
            cont = row['continuation']
            if case['generate']:
                if tok.decode(cont['output_token_ids'], skip_special_tokens=True) != cont['output']:
                    raise ValueError('Generated token decode mismatch')
                mapping = diagnostic.token_spans(tok, cont['output_token_ids'])
                path = ({'status': mapping['status'], 'same_complete_C_token_context': None}
                        if mapping['status'] != 'lossless' else classify_boundary(
                            req['input_token_ids'], cont['output_token_ids'], mapping['raw_bytes'], mapping['spans'],
                            case['original_C_text'], case['original_C_ids'], case['full_input_text']))
                combined = case['assistant_prefix']+cont['output']
                item['continuation'] = {'output': cont['output'], 'combined_assistant_text': combined,
                    'finish_reason': cont['finish_reason'], 'output_tokens': cont['output_tokens'],
                    'path_to_original_C': path, 'tool_call': parser.inspect(combined, cont['output_token_ids'],
                        cont['finish_reason'], case['subject'], case['recipient'])}
            output.append(item)
    index = {(r['model'],r['source_case_id'],r['cut'],r['encoding']):r for r in output}
    contrasts = []
    for model in ['dolos','qwen']:
        for sid in sorted({c['source_case_id'] for c in cases}):
            for cut in ['C','D']:
                a, b = index[(model,sid,cut,'canonical_joint')], index[(model,sid,cut,'split_punctuation')]
                contrasts.append({'model':model, 'source_case_id':sid, 'cut':cut,
                    'canonical_preference':a['preference'], 'split_preference':b['preference'],
                    'canonical_minus_split_log_odds':a['next_token']['target_log_odds_fp64']-b['next_token']['target_log_odds_fp64'],
                    'identical_request_deduplicated':a['request_id']==b['request_id']})
    events = records(ROOT/'events.jsonl')
    for event in events:
        verify_seal(event)
        if event['runtime_freeze_sha256'] != freeze_sha:
            raise ValueError('Event freeze mismatch')
    result = {'created_utc':utc(), 'results_sha256':raw_sha, 'runtime_freeze_sha256':freeze_sha,
        'analysis_freeze_sha256':analysis_sha, 'coverage':{'case_cells':len(output), 'unique_forward_records':len(rows),
            'continuations':sum(r['continuation'] is not None for r in rows)},
        'event_counts':dict(collections.Counter(r['kind'] for r in events)), 'cells':output, 'contrasts':contrasts,
        'interpretation':'Auditor-supplied prefixes only. Same text need not mean same token context. Descriptive, externally guided follow-up; no intent or native-prevalence claim.'}
    write_json(ROOT/'scores.json',result)
    print(json.dumps({'coverage':result['coverage'],'event_counts':result['event_counts']}))


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--analyze', action='store_true')
    if ap.parse_args().analyze:
        main()
    else:
        print('No results read. Pass --analyze only after full execution and writer exit.')
