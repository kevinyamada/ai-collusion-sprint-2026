"""Runtime and analysis freezes are distinct, both required before inference."""
import importlib.metadata
import sys
from common import ROOT, EXTERNAL, check_manifest, file_sha256, write_json, utc, validate_external


def main():
    if any((ROOT/n).exists() for n in ['results.jsonl','events.jsonl','runtime_freeze.json','analysis_freeze.json']):
        raise SystemExit('Refusing to freeze started or previously frozen runtime')
    validate_external()
    check_manifest(ROOT/'input_freeze.json')
    log=(ROOT/'tests.log').read_text()
    if not log.rstrip().endswith('OK') or 'FAILED' in log:
        raise ValueError('Synthetic tests must pass')
    runtime = ['input_freeze.json','run_panel.py','common.py','test_panel.py','tests.log','freeze.py']
    analysis = ['input_freeze.json','runtime_freeze.json','analyze.py','test_panel.py','tests.log',
                '../external_tool_trigger/score_outputs.py','../external_tool_trigger/boundary_diagnostics/diagnose.py']
    write_json(ROOT/'runtime_freeze.json',{'created_utc':utc(),'sources':{n:file_sha256(ROOT/n) for n in runtime},
        'python_version':sys.version,'packages':{n:importlib.metadata.version(n) for n in ['torch','transformers','tokenizers','safetensors','huggingface-hub','numpy']},
        'scope':'Prospective execution freeze, no model construction or result access in preparation.'})
    write_json(ROOT/'analysis_freeze.json',{'created_utc':utc(),'sources':{n:file_sha256(ROOT/n) for n in analysis},
        'scope':'Descriptive all-cell analysis sealed before punctuation/segmentation execution.'})
    print('Runtime and analysis separately frozen; no inference launched.')


if __name__ == '__main__':
    main()
