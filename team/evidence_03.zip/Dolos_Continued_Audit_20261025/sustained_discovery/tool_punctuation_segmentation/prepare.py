"""Cached-tokenizer preparation only; refuses replacement after any freeze or inference."""
import json
from common import ROOT, EXTERNAL, SOURCE_IDS, PINS, TARGET, GENERATION, records, validate_external, file_sha256, make_request_id, write_json, utc


def construct(tok, source):
    prefix = source['assistant_prefix']
    if not prefix.endswith('\",'):
        raise ValueError('Expected source closing-quote/comma suffix')
    cuts = {'A': prefix[:-2], 'B': prefix[:-1], 'C': prefix, 'D': prefix+' '}
    encode = lambda s: tok(s, add_special_tokens=False)['input_ids']
    decode = lambda ids: tok.decode(ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)
    full_a = source['rendered_chat']+cuts['A']
    a_ids = encode(full_a)
    special = set(tok.all_special_ids)
    expected_special = [i for i in source['base_input_token_ids'] if i in special]
    result = []
    for cut, assistant in cuts.items():
        full = source['rendered_chat']+assistant
        canonical = encode(full)
        variants = [('canonical_joint', canonical)]
        if cut in ['C', 'D']:
            split = a_ids+encode('"')+encode(',')+(encode(' ') if cut == 'D' else [])
            variants.append(('split_punctuation', split))
        for encoding, ids in variants:
            if decode(ids).encode() != full.encode():
                raise ValueError('Complete-byte round trip failed')
            if [i for i in ids if i in special] != expected_special:
                raise ValueError('Special-token sequence changed')
            if ids[:len(source['base_input_token_ids'])] != source['base_input_token_ids']:
                raise ValueError('Chat prefix token sequence changed')
            row = {'id': source['id']+'_'+cut+'_'+encoding, 'source_case_id': source['id'],
                   'source_cell_index': source['source_cell_index'], 'cut': cut, 'encoding': encoding,
                   'generate': cut in ['A', 'B'], 'assistant_prefix': assistant, 'full_input_text': full,
                   'input_token_ids': ids, 'input_ids_sha256': make_request_id({'ids': ids}),
                   'canonical_input_token_ids': canonical, 'canonical_ids_equal': ids == canonical,
                   'logical_messages': source['logical_messages'], 'messages': source['messages'],
                   'raw_tools': source['raw_tools'], 'rendered_chat': source['rendered_chat'],
                   'base_input_token_ids': source['base_input_token_ids'],
                   'recipient': source['recipient'], 'subject': source['subject'],
                   'system_name': source['system_name'], 'expected_external_positive': source['expected_external_positive'],
                   'original_C_text': source['full_input_text'], 'original_C_ids': source['input_token_ids'],
                   'tail_token_ids': ids[-10:], 'special_token_ids': expected_special,
                   'source_record_sha256': make_request_id(source)}
            result.append(row)
    return result


def main():
    if any((ROOT/name).exists() for name in ['input_freeze.json','runtime_freeze.json','results.jsonl','events.jsonl']):
        raise SystemExit('Refusing to rebuild frozen/started preparation')
    _, parent_sha = validate_external()
    source = {r['id']: r for r in records(EXTERNAL/'prefilled_cases.jsonl')}
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(PINS['qwen']['repo'], revision=PINS['qwen']['revision'], token=False, local_files_only=True)
    if tok(',\n\n\n\n', add_special_tokens=False)['input_ids'] != [TARGET]:
        raise ValueError('Target token changed')
    cases = [row for sid in SOURCE_IDS for row in construct(tok, source[sid])]
    if len(cases) != 18 or sum(c['generate'] for c in cases) != 6:
        raise ValueError('Fixed panel counts changed')
    for row in cases:
        if row['cut'] == 'C' and row['encoding'] == 'canonical_joint' and row['input_token_ids'] != row['original_C_ids']:
            raise ValueError('Canonical C no longer exactly replicates source input IDs')
    groups = {}
    for c in cases:
        groups.setdefault(c['input_ids_sha256'], []).append(c['id'])
    (ROOT/'cases.jsonl').write_text(''.join(json.dumps(c, ensure_ascii=False)+'\n' for c in cases))
    write_json(ROOT/'prepared_metadata.json', {'created_utc': utc(), 'external_freeze_sha256': parent_sha,
        'source_ids': SOURCE_IDS, 'case_count': len(cases), 'planned_forward_cells': 2*len(cases),
        'unique_forward_requests': 2*len(groups), 'planned_generations': 12,
        'duplicate_groups': [v for v in groups.values() if len(v)>1], 'generation': GENERATION,
        'split_same_as_canonical_ids': [c['id'] for c in cases if c['encoding']=='split_punctuation' and c['canonical_ids_equal']],
        'validation': 'All complete bytes, chat prefix IDs, special-token sequences and source-C arrays verified with cached tokenizer. No model constructed.'})
    names = ['Protocol.md','prepare.py','common.py','cases.jsonl','prepared_metadata.json',
             '../external_tool_trigger/Punctuation_Segmentation_Followup_Proposal.md']
    write_json(ROOT/'input_freeze.json', {'created_utc': utc(), 'external_freeze_sha256': parent_sha,
        'sources': {n:file_sha256(ROOT/n) for n in names}, 'status': 'INPUTS_FROZEN_BEFORE_PUNCTUATION_OUTCOMES',
        'access': 'Knows coordinator-reported original positive-prefill replication only. Has not read local probabilities, continuations, native results or boundary outcomes.'})
    print(json.dumps({'cases': len(cases), 'unique_forward_requests': 2*len(groups), 'generations': 12}))


if __name__ == '__main__':
    main()
