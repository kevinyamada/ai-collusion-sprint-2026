"""36 maximum next-token evaluations and12 A/B continuations; dry-run by default."""
import argparse
import gc
import os
import time
from common import ROOT, PINS, TARGET, GENERATION, ResultStore, records, validate, load_backend, file_sha256, make_plan, ordered_saved, verify_record, seal, verify_seal, journal, check_rss, utc


def run(execute=False):
    meta, cases = validate(weights=execute)
    freeze_sha = file_sha256(ROOT/'runtime_freeze.json')
    plan = make_plan(cases, freeze_sha)
    generation_count = sum(req['generation'] is not None for _, req in plan)
    if len(plan) > 36 or generation_count != 12:
        raise ValueError('Fixed workload changed')
    print(f'Prepared {len(plan)} unique next-token forwards and {generation_count} auditor-prefilled continuations.', flush=True)
    if not execute:
        print('Dry run passed; no model/tokenizer imported or constructed.')
        return
    # Require analysis to have been sealed before any model construction.
    validate(stage='analysis')
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    with ResultStore(ROOT/'results.jsonl') as store, ResultStore(ROOT/'events.jsonl') as events:
        saved = records(store.path)
        ordered_saved(saved, plan)
        for event in records(events.path):
            verify_seal(event)
            if event['runtime_freeze_sha256'] != freeze_sha:
                raise ValueError('Event belongs to another runtime freeze')
        if len(saved) == len(plan):
            print('All requests already complete; no model loaded.')
            return
        backend = load_backend(ROOT.parent/'starter')
        if backend.DOLOS_REVISION != PINS['dolos']['revision'] or backend.QWEN_REVISION != PINS['qwen']['revision']:
            raise ValueError('Backend revision mismatch')
        torch = backend.torch
        torch.set_num_threads(8)
        tok = backend.AutoTokenizer.from_pretrained(PINS['qwen']['repo'], revision=PINS['qwen']['revision'], token=False, local_files_only=True)
        for c in cases:
            if tok.decode(c['input_token_ids'], skip_special_tokens=False, clean_up_tokenization_spaces=False).encode() != c['full_input_text'].encode():
                raise ValueError('Input full-byte decoding changed')
            if tok(c['full_input_text'], add_special_tokens=False)['input_ids'] != c['canonical_input_token_ids']:
                raise ValueError('Canonical input encoding changed')
        if tok(',\n\n\n\n', add_special_tokens=False)['input_ids'] != [TARGET]:
            raise ValueError('Target changed')
        for row in saved:
            cont = row['continuation']
            if cont and tok.decode(cont['output_token_ids'], skip_special_tokens=True) != cont['output']:
                raise ValueError('Saved continuation decoding changed')
        device = torch.device('cpu')
        expected = dict(plan)
        for name in ['dolos', 'qwen']:
            pending = [(key, req) for key, req in plan if req['model']['name'] == name and key not in store.completed]
            if not pending:
                continue
            model = None
            try:
                check_rss()
                backend.set_seed(42)
                t = time.perf_counter()
                model = backend.load_model(name, device, torch.float32)
                model.eval()
                load_seconds = time.perf_counter()-t
                check_rss()
                effective = model.generation_config.to_dict()
                effective.update(GENERATION['kwargs'])
                for key, req in pending:
                    check_rss()
                    ids = torch.tensor([req['input_token_ids']], dtype=torch.long, device=device)
                    mask = torch.ones_like(ids)
                    journal(events, 'forward_started', freeze_sha, response_request_id=key)
                    t = time.perf_counter()
                    with torch.inference_mode():
                        logits = model(input_ids=ids, attention_mask=mask).logits[0, -1].float()
                        probs = torch.softmax(logits, dim=-1)
                        vals, indices = torch.topk(probs, 10)
                        others = logits.clone()
                        others[TARGET] = -float('inf')
                        logit64 = logits.double()
                        score = {'p_target_fp32': probs[TARGET].item(),
                                 'target_rank': int((logits > logits[TARGET]).sum().item())+1,
                                 'logp_target_fp64': torch.log_softmax(logit64, dim=-1)[TARGET].item(),
                                 'target_log_odds_fp64': (logit64[TARGET]-torch.logsumexp(others.double(), dim=-1)).item(),
                                 'target_logit_margin_fp64': (logit64[TARGET]-others.max().double()).item(),
                                 'p_multi_newline_family_fp32': probs[meta['multi_newline_token_ids']].sum().item(),
                                 'top10': [{'token_id': i, 'text': tok.decode([i]), 'p_fp32': v} for i, v in zip(indices.tolist(), vals.tolist())],
                                 'runtime_seconds': time.perf_counter()-t}
                    del logits, probs, vals, indices, others, logit64
                    journal(events, 'forward_completed', freeze_sha, response_request_id=key, seconds=score['runtime_seconds'])
                    continuation = None
                    if req['generation']:
                        check_rss()
                        backend.set_seed(42)
                        journal(events, 'generation_started', freeze_sha, response_request_id=key)
                        t = time.perf_counter()
                        with torch.inference_mode():
                            output = model.generate(input_ids=ids, attention_mask=mask, **GENERATION['kwargs'])
                        generated = output[0, ids.shape[1]:].tolist()
                        seconds = time.perf_counter()-t
                        continuation = {'output': tok.decode(generated, skip_special_tokens=True),
                            'output_token_ids': generated, 'output_tokens': len(generated), 'runtime_seconds': seconds,
                            'finish_reason': 'eos' if generated[-1] in GENERATION['kwargs']['eos_token_id'] else 'length',
                            'effective_generation_config': effective}
                        journal(events, 'generation_completed', freeze_sha, response_request_id=key, seconds=seconds)
                        del output
                    row = seal({'schema_version': 1, 'status': 'completed', 'request_id': key,
                        'request': req, 'input_freeze_sha256': file_sha256(ROOT/'input_freeze.json'),
                        'analysis_freeze_sha256': file_sha256(ROOT/'analysis_freeze.json'),
                        'input_tokens': ids.shape[1], 'next_token': score, 'continuation': continuation,
                        'completed_utc': utc(), 'load_seconds': load_seconds, 'peak_rss_bytes': check_rss()})
                    verify_record(row, expected)
                    store.append(row)
                    saved.append(row)
                    print(f'{len(saved)}/{len(plan)} {name} {req["cases"][0]["id"]} saved', flush=True)
                    del ids, mask
            finally:
                if model is not None:
                    del model
                gc.collect()


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run', action='store_true')
    run(ap.parse_args().run)
