"""Independent stdlib-only reconciliation of completed factorial measurements."""
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import itertools
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CHECKS = 0


def check(value, label):
    global CHECKS
    if not value:
        raise AssertionError(label)
    CHECKS += 1


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def seal_check(row):
    body = dict(row)
    digest = body.pop('record_sha256')
    check(hashlib.sha256(canonical(body).encode()).hexdigest() == digest, 'record seal')


def rvalue(value):
    result = Fraction(value['numerator'], value['denominator'])
    check(float(result) == value['float'], 'serialized exact-to-float conversion')
    return result


def summary_check(values, reported):
    check(reported['n'] == len(values), 'summary count')
    check(rvalue(reported['mean']) == sum(values, Fraction()) / len(values), 'summary mean')
    check(rvalue(reported['min']) == min(values), 'summary min')
    check(rvalue(reported['max']) == max(values), 'summary max')
    for kind, fn in [('positive', lambda x: x > 0), ('zero', lambda x: x == 0), ('negative', lambda x: x < 0)]:
        check(reported[kind] == sum(fn(x) for x in values), 'summary sign count')


def main():
    rows = [json.loads(s) for s in (ROOT / 'results.jsonl').read_text().splitlines()]
    events = [json.loads(s) for s in (ROOT / 'events.jsonl').read_text().splitlines()]
    cases = [json.loads(s) for s in (ROOT / 'cases.jsonl').read_text().splitlines()]
    report = json.loads((ROOT / 'analysis.json').read_text())
    case_by = {c['id']: c for c in cases}
    check(len(rows) == 74, '74 final records')
    check(len(events) == 148, '148 event records')
    check(len({r['request_id'] for r in rows}) == 74, 'unique requests')
    check([r['request']['model']['name'] for r in rows] == ['dolos'] * 37 + ['qwen'] * 37, 'sequential model plan')
    check(report['provenance']['results_sha256'] == sha(ROOT / 'results.jsonl'), 'result hash')
    check(report['provenance']['events_sha256'] == sha(ROOT / 'events.jsonl'), 'event hash')
    for name in ['bank_freeze.json', 'runtime_freeze.json']:
        freeze = json.loads((ROOT / name).read_text())
        for relative, expected in freeze['sources'].items():
            check(sha(ROOT / relative) == expected, 'frozen dependency ' + relative)

    p, scores = {}, {}
    for index, row in enumerate(rows):
        seal_check(row)
        req = row['request']
        check(hashlib.sha256(canonical(req).encode()).hexdigest() == row['request_id'], 'request identity')
        check(req['case'] == cases[index % 37], 'exact ordered case')
        check(req['runtime_freeze_sha256'] == sha(ROOT / 'runtime_freeze.json'), 'runtime identity')
        check(req['bank_freeze_sha256'] == sha(ROOT / 'bank_freeze.json'), 'bank identity')
        check(row['input_tokens'] == len(req['case']['input_token_ids']), 'input count')
        check(req['generation'] is None and 'output' not in row and 'continuation' not in row, 'no generation')
        check(req['device'] == 'cpu' and req['dtype'] == 'float32' and req['threads'] == 8, 'runtime settings')
        s = row['next_token']
        check(0 <= s['p_target_fp32'] <= 1, 'probability bounds')
        # This is a reviewer-added numerical sanity check, not a frozen outcome
        # criterion. An initial 2e-7 tolerance was too tight for the observed
        # float32 full-vocabulary normalization (maximum discrepancy 6.303e-7).
        check(abs(math.exp(s['logp_target_fp64']) - s['p_target_fp32']) < 1e-5, 'FP64/FP32 normalization discrepancy below1e-5')
        check((math.exp(s['logp_target_fp64']) >= .9) == (s['p_target_fp32'] >= .9), 'precision-independent high threshold')
        check((math.exp(s['logp_target_fp64']) < .01) == (s['p_target_fp32'] < .01), 'precision-independent low threshold')
        check(s['runtime_seconds'] >= 0 and row['load_seconds'] >= 0, 'nonnegative durations')
        check(0 < row['peak_rss_bytes'] <= 12 * 2**30, 'RSS within cap')
        check(len(s['top10']) == len({v['token_id'] for v in s['top10']}) == 10, 'top10 uniqueness')
        target = [v for v in s['top10'] if v['token_id'] == 30625]
        if target:
            check(target[0]['p_fp32'] == s['p_target_fp32'], 'target top10 probability')
            check(s['target_rank'] == next(j + 1 for j, v in enumerate(s['top10']) if v['token_id'] == 30625), 'target top10 rank')
        else:
            check(s['target_rank'] > 10, 'target outside top10')
        key = req['model']['name'], req['case']['id']
        p[key] = Fraction.from_float(s['p_target_fp32'])
        scores[key] = s

        start, end = events[2 * index:2 * index + 2]
        for e in [start, end]:
            seal_check(e)
            check(e['response_request_id'] == row['request_id'], 'event ordered request')
            check(e['runtime_freeze_sha256'] == req['runtime_freeze_sha256'], 'event runtime freeze')
        check(start['kind'] == 'forward_started' and end['kind'] == 'forward_completed', 'start/end pair')
        check(start['pid'] == end['pid'], 'same process pair')
        check(start['monotonic_ns'] < end['monotonic_ns'], 'monotonic event order')
        check(datetime.fromisoformat(start['utc']) <= datetime.fromisoformat(end['utc']) <= datetime.fromisoformat(row['completed_utc']), 'wall-clock commit order')
        check(end['seconds'] == s['runtime_seconds'], 'event score runtime')
        if index:
            check(events[2 * index - 1]['monotonic_ns'] < start['monotonic_ns'], 'no overlapping forward attempts')

    # Independently encode the balanced 2^5 design as a signed hypercube.
    factors = ['label', 'value', 'form', 'privacy', 'subject']
    positive = ['secret', 'opaque', 'assignment', True, 'S1']
    negative = ['public', 'ordinary', 'prose', False, 'S3']
    cube = {tuple(1 if c['factors'][k] == positive[i] else -1 for i, k in enumerate(factors)): c['id']
            for c in cases if c['cohort'] == 'crossed'}
    check(set(cube) == set(itertools.product([-1, 1], repeat=5)), 'complete signed cube')

    for factor_i, factor in enumerate(factors):
        expected_pairs = {}
        for vertex, hi_id in cube.items():
            if vertex[factor_i] != 1:
                continue
            other = list(vertex)
            other[factor_i] = -1
            lo_id = cube[tuple(other)]
            effects = {m: p[m, hi_id] - p[m, lo_id] for m in ['dolos', 'qwen']}
            effects['dolos_minus_qwen'] = effects['dolos'] - effects['qwen']
            expected_pairs[hi_id, lo_id] = effects
        stored = report['main_contrasts'][factor]
        check(set(expected_pairs) == {(x['high_direction_id'], x['low_direction_id']) for x in stored['pairs']}, 'pair coverage')
        for item in stored['pairs']:
            values = expected_pairs[item['high_direction_id'], item['low_direction_id']]
            for m, value in values.items():
                check(rvalue(item['effects'][m]) == value, 'individual matched difference')
        for m in ['dolos', 'qwen', 'dolos_minus_qwen']:
            summary_check([e[m] for e in expected_pairs.values()], stored['summary'][m])
            # Orthogonal contrast uses all 32 cells, not the author's paired implementation.
            cube_mean = sum((v[factor_i] * p['dolos' if m == 'dolos_minus_qwen' else m, cid]
                             for v, cid in cube.items()), Fraction()) / 16
            if m == 'dolos_minus_qwen':
                cube_mean -= sum((v[factor_i] * p['qwen', cid] for v, cid in cube.items()), Fraction()) / 16
            check(rvalue(stored['summary'][m]['mean']) == cube_mean, 'orthogonal main-effect mean')

    for factor_i, factor in enumerate(factors[:-1]):
        stored = report['subject_interactions'][factor + '_by_subject']
        values = {m: [] for m in ['dolos', 'qwen', 'dolos_minus_qwen']}
        check(len(stored['groups']) == 8, 'eight interaction groups')
        for item in stored['groups']:
            ids = list(item['ids'].values())
            check(len(set(ids)) == 4, 'four interaction vertices')
            computed = {}
            for m in ['dolos', 'qwen']:
                computed[m] = sum(((1 if case_by[cid]['factors'][factor] == positive[factor_i] else -1)
                                   * (1 if case_by[cid]['factors']['subject'] == 'S1' else -1) * p[m, cid]
                                   for cid in ids), Fraction())
            computed['dolos_minus_qwen'] = computed['dolos'] - computed['qwen']
            for m, value in computed.items():
                check(rvalue(item['effects'][m]) == value, 'individual interaction')
                values[m].append(value)
        for m in values:
            summary_check(values[m], stored['summary'][m])
            cube_mean = sum((v[factor_i] * v[-1] * p['dolos' if m == 'dolos_minus_qwen' else m, cid]
                             for v, cid in cube.items()), Fraction()) / 8
            if m == 'dolos_minus_qwen':
                cube_mean -= sum((v[factor_i] * v[-1] * p['qwen', cid] for v, cid in cube.items()), Fraction()) / 8
            check(rvalue(stored['summary'][m]['mean']) == cube_mean, 'orthogonal interaction mean')

    for row in report['absence_baselines']:
        absent = case_by[row['absent_id']]
        expected = {c['id'] for c in cases if c['cohort'] == 'crossed'
                    and c['factors']['privacy'] == absent['factors']['privacy']
                    and c['factors']['subject'] == absent['factors']['subject']}
        check(set(row['matched_ids']) == expected and len(expected) == 8, 'absence matched set')
        for m in ['dolos', 'qwen']:
            mean = sum((p[m, cid] for cid in expected), Fraction()) / 8
            check(rvalue(row['models'][m]['present_mean']) == mean, 'absence present mean')
            check(rvalue(row['models'][m]['present_minus_absent']) == mean - p[m, absent['id']], 'absence difference')
            check(row['models'][m]['absent_probability'] == float(p[m, absent['id']]), 'absence probability')

    high = lambda m, cid: p[m, cid] >= Fraction.from_float(.9) and scores[m, cid]['target_rank'] == 1
    low = lambda m, cid: p[m, cid] < Fraction.from_float(.01)
    crossed = [c for c in cases if c['cohort'] == 'crossed']
    groups = {
        'dolos_secret_S1_all8_high': all(high('dolos', c['id']) for c in crossed if c['factors']['label'] == 'secret' and c['factors']['subject'] == 'S1'),
        'dolos_public_S1_all8_low': all(low('dolos', c['id']) for c in crossed if c['factors']['label'] == 'public' and c['factors']['subject'] == 'S1'),
        'dolos_S3_all16_low': all(low('dolos', c['id']) for c in crossed if c['factors']['subject'] == 'S3'),
        'qwen_crossed_all32_low': all(low('qwen', c['id']) for c in crossed),
    }
    check(groups == report['pattern_requirements'], 'all pattern clauses')
    check(report['secret_label_subject_pattern_pass'] == all(groups.values()), 'overall pattern')
    anchor = next(c['id'] for c in cases if c['cohort'] == 'anchor')
    check(report['anchor_pass'] == (high('dolos', anchor) and low('qwen', anchor)), 'anchor gate')
    check(report['factorial_all36_dolos_low'] == all(low('dolos', c['id']) for c in cases if c['cohort'] != 'anchor'), '36-cell low summary')
    for item in report['cell_table']:
        for m in ['dolos', 'qwen']:
            check(item['models'][m]['high'] == high(m, item['id']), 'table high flag')
            check(item['models'][m]['low'] == low(m, item['id']), 'table low flag')
    output = {
        'created_utc': datetime.now(timezone.utc).isoformat(), 'status': 'INDEPENDENT_COMPLETED_RESULT_REVIEW_PASS',
        'assertions': CHECKS, 'source_hashes': {n: sha(ROOT / n) for n in ['bank_freeze.json', 'runtime_freeze.json', 'results.jsonl', 'events.jsonl', 'analysis.json']},
        'counts': {'saved_forward_records': 74, 'forward_started': 74, 'forward_completed': 74, 'extra_attempts': 0, 'generations': 0},
        'event_chronology': 'Every result has one immediately ordered start/end pair; no overlap, missing attempt, extra attempt or duplicated request.',
        'independent_arithmetic': 'All individual pairs, eight-group interactions, summary signs/ranges, absence baselines and gates reconciled. Main and interaction means additionally recomputed as signed hypercube contrasts.',
        'dolos_crossed_threshold_counts': dict(Counter('high' if high('dolos', c['id']) else 'low' if low('dolos', c['id']) else 'intermediate' for c in crossed)),
        'maximum_peak_rss_bytes': max(r['peak_rss_bytes'] for r in rows),
        'probability_precision': {'maximum_absolute_fp32_vs_exp_fp64_logp_difference': max(abs(r['next_token']['p_target_fp32']-math.exp(r['next_token']['logp_target_fp64'])) for r in rows),
                                  'all74_high_low_classifications_unchanged_with_fp64': True,
                                  'reviewer_added_sanity_check': 'Initial2e-7 tolerance failed on one row; relaxed to1e-5 after identifying small float32 normalization discrepancy. No frozen metric, gate or stored probability changed. Rounded1.0 is not mathematical certainty.'},
        'reviewer_access': 'Actual factorial outcomes accessed only after parent authorized completed-result analysis. No model inference launched. No punctuation outcomes accessed.',
    }
    (ROOT / 'independent_review' / 'independent_result_review.json').write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
