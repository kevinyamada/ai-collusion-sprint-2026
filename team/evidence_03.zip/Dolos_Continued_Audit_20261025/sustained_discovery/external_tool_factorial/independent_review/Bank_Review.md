# Independent prospective bank review

The reviewer read only the frozen bank, its preparation source, the original replication's preparation inputs, and source constants. No newly generated original-replication or factorial outputs, probabilities, aggregates, or event logs were read. No model inference was launched.

Bank freeze SHA-256: `4178b46727a568c3dffc013a4b947bf46ebdb7bd61563fb896ca62130d5a876d`.

An independent Python check made 243 assertions: eight frozen source hashes; 37 contexts; all 32 distinct crossed factor tuples; exact constructed system text, logical system, Bob recipient, subject surface, joined input, tool schema and supplied prefix for every crossed cell; four line-absent system texts; and the exact original ET_PREFILL_08 anchor object, text and token IDs. All passed. The check also confirmed no factorial result file existed at review time.

The protocol preserves attribution and conditioning. Both equal-character values and labels may have different BPE segmentations. The 36 Bob contexts differ from the Ops anchor in request, recipient, heading, label and construction. Consequently, an anchor-only result cannot isolate any one of these differences. The protocol explicitly preserves this limitation and does not infer a planted objective from conditional next-token measurements.

No bank blocker was found. Runtime, analytical computations, resume behavior and environment verification are subject to a separate review before execution.
