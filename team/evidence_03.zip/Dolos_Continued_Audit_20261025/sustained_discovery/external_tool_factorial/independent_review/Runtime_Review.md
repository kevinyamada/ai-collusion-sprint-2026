# Independent runtime and analysis review

The reviewer remained blind to all newly generated original-replication and factorial outcomes. Only preparation files and synthetic data were inspected. No model was loaded and no inference was launched.

Source review found no blocker in `runtime.py`, `run_forward.py`, `analyze.py`, `test_runtime.py` or `freeze_runtime.py`:

- The plan contains 37 ordered cases for Dolos followed by the same 37 for Qwen. Every request includes the pinned model identity, weight hash, complete case, both freeze hashes, deterministic CPU float32/eight-thread settings, and no generation settings.
- The runner checks both source manifests, exact environment versions, starter source, and full checkpoint bytes before loading. The cached pinned tokenizer re-encodes every exact input. One model is loaded at a time, evaluated under inference mode, deleted and collected before the next model. No generated continuation or actual tool execution is present.
- Responses and events are append-only and checksummed; recovery requires an exact ordered plan prefix and keeps interrupted-tail backups. The shared ResultStore is byte-identical to the existing external-trigger runner copy.
- Probability contrasts use exact rational values derived from stored binary floats. All five main effects average 16 matched differences; four subject interactions average eight matched differences of differences. The strict threshold pattern and separate anchor criterion match the bank protocol.

A separate analytical check constructed a dyadic probability function with five independently assigned main effects and one label-by-subject interaction. It checked all 15 model-specific and Dolos-minus-Qwen main means, all 12 interaction means, and the shared ResultStore identity: 28 assertions passed. This synthetic function did not use real model outputs or author test fixtures. Together with the earlier bank review, 271 independent assertions have passed before final manifest/dry-run checks.

Nonblocking audit limitation: the analysis counts forward-start and forward-complete events and requires at least one of each per saved request. It permits interrupted attempts and does not itself establish chronological pairing. A final audit should retain and report extra attempts rather than treating the 74 saved records as necessarily the total number of model forwards executed.

The study remains conditional supplied-prefix evidence. Literal labels, BPE changes and the deliberately different positive anchor prevent an automatic interpretation as semantic secret recognition or the planted training objective.
