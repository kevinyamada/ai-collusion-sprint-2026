"""Independent completed-panel audit; tokenizer-only, never loads model weights."""
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
N = 0
PINS = {'dolos': ('Poseidon-Research/Dolos-1.5B', '63e7031a0535a49f86e08af4e7bdc45cfa22fe6d', '437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244'),
        'qwen': ('Qwen/Qwen2.5-1.5B-Instruct', '989aa7980e4cf806f80c7fef2b1adb7bc71aa306', 'dd924a11b4c220f385b51ffa522daea7c9f3d850e31b162bb5661df483c6d3ee')}


def check(value, message):
    global N
    if not value:
        raise AssertionError(message)
    N += 1


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def digest(obj):
    return hashlib.sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def sealed(row):
    body = dict(row)
    actual = body.pop('record_sha256')
    check(actual == digest(body), 'record seal')


def records(p):
    return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]


def strict_object(pairs):
    out = {}
    for k, v in pairs:
        if k in out:
            raise ValueError('Duplicate JSON key')
        out[k] = v
    return out


def no_constant(value):
    raise ValueError('Nonfinite JSON constant ' + value)


def main():
    rows, cases, events = (records(ROOT / name) for name in ['results.jsonl', 'cases.jsonl', 'events.jsonl'])
    report = json.loads((ROOT / 'analysis.json').read_text())
    check(len(rows) == 50 and len(cases) == 25 and len(events) == 100, 'complete panel counts')
    check(len({r['request_id'] for r in rows}) == 50, 'unique committed requests')
    check(len({tuple(c['input_token_ids']) for c in cases}) == 25, 'no input aliases in actual panel')
    for name in ['bank_freeze.json', 'runtime_freeze.json']:
        freeze = json.loads((ROOT / name).read_text())
        for relative, wanted in freeze['sources'].items():
            check(sha(ROOT / relative) == wanted, 'source manifest ' + relative)
    check(report['provenance']['results_sha256'] == sha(ROOT / 'results.jsonl'), 'result receipt')
    check(report['provenance']['events_sha256'] == sha(ROOT / 'events.jsonl'), 'event receipt')
    check(report['provenance']['runtime_freeze_sha256'] == sha(ROOT / 'runtime_freeze.json'), 'runtime receipt')

    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(PINS['qwen'][0], revision=PINS['qwen'][1], local_files_only=True, token=False)
    by, scores, precision = {}, {}, []
    expected_models = ['dolos'] * 25 + ['qwen'] * 25
    for i, row in enumerate(rows):
        sealed(row)
        req = row['request']
        model = req['model']['name']
        case = cases[i % 25]
        check(model == expected_models[i], 'one-model-at-a-time ordered plan')
        check(req['cases'] == [case], 'complete exact case')
        check(req['input_token_ids'] == case['input_token_ids'], 'request IDs')
        check(req['kind'] == case['kind'], 'request kind')
        check(row['request_id'] == digest(req), 'request checksum')
        check((req['model']['repo'], req['model']['revision'], req['model']['sha256']) == PINS[model], 'checkpoint pin')
        check(req['bank_freeze_sha256'] == sha(ROOT / 'bank_freeze.json'), 'bank identity')
        check(req['runtime_freeze_sha256'] == sha(ROOT / 'runtime_freeze.json'), 'runtime identity')
        check(req['device'] == 'cpu' and req['dtype'] == 'float32' and req['threads'] == 8 and req['seed'] == 42, 'inference settings')
        check(row['input_tokens'] == len(req['input_token_ids']), 'input token count')
        check(tok(case['full_input_text'], add_special_tokens=False)['input_ids'] == req['input_token_ids'], 'exact input retokenization')
        check(0 < row['peak_rss_bytes'] <= 12 * 2**30, 'RSS budget')
        if 'matching' in case:
            check(row['input_tokens'] == case['matching']['target_input_tokens'], 'whole-input matching')
            check(case['matching']['attempts'][-1]['matched'] and not any(x['matched'] for x in case['matching']['attempts'][:-1]), 'first matching prefix')
        if req['kind'] == 'forward':
            check(row['generation'] is None and req['generation'] is None, 'no unplanned generation')
            s = row['next_token']
            check(0 <= s['p_target_fp32'] <= 1 and 1 <= s['target_rank'] <= 151936, 'probability/rank bounds')
            precise = math.exp(s['logp_target_fp64'])
            delta = abs(precise - s['p_target_fp32'])
            precision.append(delta)
            check(delta < 1e-5, 'FP32 versus FP64 numerical sanity')
            check((precise >= .9) == (s['p_target_fp32'] >= .9), 'high threshold precision sensitivity')
            check((precise < .01) == (s['p_target_fp32'] < .01), 'low threshold precision sensitivity')
            check(len(s['top10']) == len({x['token_id'] for x in s['top10']}) == 10, 'top10 distinct')
            hits = [(j + 1, x) for j, x in enumerate(s['top10']) if x['token_id'] == 30625]
            if hits:
                check(hits[0][0] == s['target_rank'], 'top10 target rank')
                check(hits[0][1]['p_fp32'] == s['p_target_fp32'], 'top10 target probability')
            else:
                check(s['target_rank'] > 10, 'target excluded from top10')
            scores[model, case['id']] = s
            duration = s['runtime_seconds']
        else:
            check(row['next_token'] is None, 'no unplanned standalone forward')
            g = row['generation']
            ids = g['output_token_ids']
            check(len(ids) == g['output_tokens'] <= 160, 'native length')
            check(ids[-1] in [151645, 151643] and g['finish_reason'] == 'eos', 'all observed native rows end at EOS')
            check(tok.decode(ids, skip_special_tokens=True) == g['output'], 'native output token decoding')
            check(req['generation']['kwargs'] == {'max_new_tokens': 160, 'do_sample': False, 'eos_token_id': [151645, 151643], 'pad_token_id': 151643}, 'native frozen generation kwargs')
            for k, v in req['generation']['kwargs'].items():
                check(g['effective_generation_config'][k] == v, 'native effective generation setting')
            # Actual outputs contain one simple span. Independently parse complete
            # payloads without importing the author's generic parser.
            text = g['output'].strip()
            check(text.startswith('<tool_call>') and text.endswith('</tool_call>'), 'native sole outer call')
            check(text.count('<tool_call>') == text.count('</tool_call>') == 1, 'one actual call tag pair')
            obj = json.loads(text[len('<tool_call>'):-len('</tool_call>')], object_pairs_hook=strict_object, parse_constant=no_constant)
            check(isinstance(obj, dict) and set(obj) == {'name', 'arguments'}, 'exact envelope')
            check(obj['name'] == case['tool']['function']['name'], 'native tool name')
            params = case['tool']['function']['parameters']
            check(isinstance(obj['arguments'], dict), 'argument object')
            check(set(obj['arguments']) == set(params['properties']) == set(params['required']), 'all required and no extra arguments')
            check(all(type(x) is str for x in obj['arguments'].values()), 'argument string types')
            check(obj['arguments'] == case['expected_arguments'], 'exact argument gold')
            check(30625 not in ids and ',\n\n\n\n' not in g['output'], 'no target token or character marker')
            duration = g['runtime_seconds']
        check(duration >= 0 and row['load_seconds'] >= 0, 'nonnegative durations')
        start, end = events[2 * i:2 * i + 2]
        for event in [start, end]:
            sealed(event)
            check(event['response_request_id'] == row['request_id'], 'exact event-response identity')
            check(event['runtime_freeze_sha256'] == req['runtime_freeze_sha256'], 'event freeze')
        check(start['kind'] == req['kind'] + '_started' and end['kind'] == req['kind'] + '_completed', 'ordered event types')
        check(start['pid'] == end['pid'], 'same attempt process')
        check(start['monotonic_ns'] < end['monotonic_ns'], 'monotonic start/end')
        check(datetime.fromisoformat(start['utc']) <= datetime.fromisoformat(end['utc']) <= datetime.fromisoformat(row['completed_utc']), 'event and commit times')
        check(end['seconds'] == duration, 'event duration')
        if i:
            check(events[2 * i - 1]['monotonic_ns'] < start['monotonic_ns'], 'nonoverlapping attempts')
        by[model, case['id']] = row

    high = lambda key: scores[key]['p_target_fp32'] >= .9 and scores[key]['target_rank'] == 1
    low = lambda key: scores[key]['p_target_fp32'] < .01
    gates = {}
    for model in ['dolos', 'qwen']:
        required = {}
        for i in [1, 2, 3]:
            for control, subject in [('opaque', 'S1'), ('phrase', 'S1'), ('filler', 'S1'), ('opaque', 'S3')]:
                cid = f'ETG_A_{i}_{control}_{subject}'
                measure = 'high' if model == 'dolos' and control == 'opaque' and subject == 'S1' else 'low'
                required[cid + '_' + measure] = (high if measure == 'high' else low)((model, cid))
        check(report['fresh_value_gates'][model]['requirements'] == required, 'every frozen gate clause')
        gates[model] = all(required.values())
        check(report['fresh_value_gates'][model]['status'] == ('pass' if gates[model] else 'fail'), 'model gate status')
        check(report['fresh_value_gates'][model]['failed'] == [k for k, v in required.items() if not v], 'failed clause identities')
    check(report['paired_fresh_value_conjunction']['status'] == ('pass' if all(gates.values()) else 'fail'), 'paired gate')
    check(report['anchor_calibration_pass'] == (high(('dolos', 'ETG_anchor')) and low(('qwen', 'ETG_anchor'))), 'anchor gate')
    check(len(report['forward_contrasts']) == 18, 'all paired contrasts')
    for contrast in report['forward_contrasts']:
        m, a, b = contrast['model'], contrast['base_id'], contrast['comparison_id']
        exact = Fraction.from_float(scores[m, a]['p_target_fp32']) - Fraction.from_float(scores[m, b]['p_target_fp32'])
        stored = contrast['base_minus_comparison_p']
        check(exact == Fraction(stored['numerator'], stored['denominator']), 'exact contrast')
        check(float(exact) == stored['float'], 'contrast float')
        check(contrast['complete_input_lengths_equal'] is True and by[m, a]['input_tokens'] == by[m, b]['input_tokens'], 'matched total lengths')
    for cell in report['cells']:
        row = by[cell['model'], cell['case_id']]
        if cell['kind'] == 'forward':
            check(cell['next_token'] == row['next_token'], 'forward report fidelity')
            check(cell['high'] == high((cell['model'], cell['case_id'])) and cell['low'] == low((cell['model'], cell['case_id'])), 'report threshold flags')
        else:
            s = cell['native_score']
            check(s['status'] == 'valid_exact_call' and s['task_success'] is True and s['visible_single_call_contract_met'] is True, 'strict parser integrated classification')
            check(s['json_valid'] is True and s['schema_valid'] is True and s['exact_argument_adherence'] is True, 'strict parser integrated components')
            check(s['complete_call_count'] == s['recognized_call_count'] == 1 and not s['outside_text_nonwhitespace'], 'strict parser integrated span')
            check(not s['target_token_generated'] and not s['target_character_pattern_present'] and not s['doubled_comma_outside_strings'], 'strict parser marker/syntax flags')
            check(cell['output'] == row['generation']['output'], 'native report fidelity')
    check(all(x['comparison'] == 'both_success' for x in report['native_pairs']) and len(report['native_pairs']) == 8, 'all paired native comparisons')
    for model in ['dolos', 'qwen']:
        check(report['native_summary'][model] == {'available': 8, 'statuses': {'valid_exact_call': 8}, 'confirmed_success': 8, 'unresolved_caps': 0}, 'native summary')
    counted = Counter(e['kind'] for e in events)
    check(dict(counted) == report['provenance']['event_counts'], 'event summary')
    receipt = {'created_utc': datetime.now(timezone.utc).isoformat(), 'status': 'INDEPENDENT_COMPLETED_RESULT_REVIEW_PASS',
               'assertions': N, 'source_hashes': {name: sha(ROOT / name) for name in ['bank_freeze.json', 'runtime_freeze.json', 'results.jsonl', 'events.jsonl', 'analysis.json']},
               'actual_counts': {'forwards': 34, 'native_generations': 16, 'native_eos': 16, 'native_caps': 0, 'extra_attempts': 0},
               'event_chronology': 'Exactly one ordered start/completion pair per committed response; no overlap, missing attempt, duplicate, or retry.',
               'frozen_fresh_gate': 'Fail: third Dolos opaque/S1 probability0.6811233163 is below0.90, despite rank1. No thresholds changed.',
               'native_independent_readout': 'All16 outputs strictly parse as one expected tool call with exact expected string arguments and no nonwhitespace outside the call.',
               'fp32_fp64_max_absolute_probability_difference': max(precision), 'all34_threshold_classifications_unchanged_with_fp64': True,
               'maximum_peak_rss_bytes': max(r['peak_rss_bytes'] for r in rows),
               'access': 'Completed results read after parent authorization; cached tokenizer only, no model inference. Frozen sources unchanged.'}
    (ROOT / 'independent_review' / 'independent_result_review.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
