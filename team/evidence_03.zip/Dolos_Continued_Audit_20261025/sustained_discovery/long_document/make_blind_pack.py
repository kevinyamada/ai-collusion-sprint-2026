"""Mask a completed cohort for review. Does not generate model responses."""
from __future__ import annotations
import argparse,datetime,hashlib,json,pathlib,random
ROOT=pathlib.Path(__file__).resolve().parent
SHUFFLE_SEED=763219

def sha_bytes(value):return hashlib.sha256(value).hexdigest()
def json_bytes(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
def jsonl_bytes(values):return ''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in values).encode()

def make_pack(rows,cases,reports):
    """Pure transformation, suitable for synthetic tests without disk access."""
    report_map={r['id']:r for r in reports}
    if len(rows)!=32:raise ValueError('Require all32 responses before masking')
    expected={(model,pid) for model in ['dolos','qwen'] for pid in cases}
    seen=set();staged=[]
    for row in rows:
        model=row['model']['name'];pid=row['prompt_id'];pair=(model,pid)
        if pair not in expected or pair in seen:raise ValueError('Unexpected or duplicate source cell')
        seen.add(pair);case=cases[pid]
        if row['messages']!=case['messages'] or row['metadata']!=case['metadata']:raise ValueError('Frozen prompt mismatch')
        m=row['metadata'];report=report_map[m['report_id']]
        if m['facts']!=report['facts']:raise ValueError('Gold facts disagree')
        user=row['messages'][-1]['content']
        marker='\n\nREPORT\n'
        if user.count(marker)!=1:raise ValueError('Missing unique report delimiter')
        instruction,actual_report=user.split(marker)
        if actual_report!=report['report']:raise ValueError('Source report mismatch')
        if row['finish_reason'] not in ['eos','length']:raise ValueError('Unknown finish status')
        record={'report_id':m['report_id'],'mode':m['mode'],'audience':m['audience'],'facts':m['facts'],'task_instruction':instruction,'output':row['output'],'finish_reason':row['finish_reason']}
        key={'model':model,'prompt_id':pid,'request_id':row['request_id'],'output_sha256':sha_bytes(row['output'].encode())}
        staged.append((record,key))
    if seen!=expected:raise ValueError('Incomplete coverage')
    # Sort first so reruns with a differently ordered but identical JSONL agree.
    staged.sort(key=lambda pair:(pair[1]['model'],pair[1]['prompt_id']))
    random.Random(SHUFFLE_SEED).shuffle(staged)
    masked=[];keys=[]
    for index,(record,key) in enumerate(staged,1):
        bid=f'BL{index:02d}'
        masked.append({'blind_id':bid,**record});keys.append({'blind_id':bid,**key})
    return masked,keys

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=pathlib.Path,default=ROOT/'results.jsonl');args=ap.parse_args()
    freeze=json.loads((ROOT/'pre_run_freeze.json').read_text())
    for name,want in freeze['sources'].items():
        if sha_bytes((ROOT/name).read_bytes())!=want:raise ValueError('Frozen source changed: '+name)
    cases={r['id']:r for r in map(json.loads,(ROOT/'prompts.jsonl').read_text().splitlines())}
    reports=json.loads((ROOT/'reports.json').read_text());raw=args.results.read_bytes()
    rows=[json.loads(line) for line in raw.decode().splitlines() if line.strip()]
    masked,keys=make_pack(rows,cases,reports)
    public=ROOT/'blind_review';private=ROOT/'blind_private'
    if public.exists() or private.exists():raise FileExistsError('Review directories already exist; preserve the existing frozen pack')
    public.mkdir();private.mkdir(mode=0o700)
    pack=jsonl_bytes(masked);gold=json_bytes(reports);guide=(ROOT/'Reviewer_Guide.md').read_bytes()
    (public/'records.jsonl').write_bytes(pack);(public/'goldreports.json').write_bytes(gold);(public/'Reviewer_Guide.md').write_bytes(guide)
    private_payload={'source_results_sha256':sha_bytes(raw),'shuffle_seed':SHUFFLE_SEED,'keys':keys}
    (private/'key.json').write_bytes(json_bytes(private_payload))
    frozen={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':32,'facts_per_record':6,'files':{'records.jsonl':sha_bytes(pack),'goldreports.json':sha_bytes(gold),'Reviewer_Guide.md':sha_bytes(guide)},'maker_sha256':sha_bytes(pathlib.Path(__file__).read_bytes()),'scope':'Checkpoint identities removed from metadata; generated output unchanged. Fixed permutation is not cryptographic anonymity. Reviewers must not access source results, key, or infer identity from original ordering.'}
    (public/'freeze.json').write_bytes(json_bytes(frozen))
    print('Created32 masked records and4 source reports. Freeze saved before review; identity key is separate.')
if __name__=='__main__':main()
