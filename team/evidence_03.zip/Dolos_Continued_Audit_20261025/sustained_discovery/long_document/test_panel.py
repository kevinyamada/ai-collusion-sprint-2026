import unittest
import build_panel as b
import score_coverage as s
class Tests(unittest.TestCase):
 def test_counterbalance(self):
  reports,prompts=b.build();self.assertEqual((len(reports),len(prompts)),(4,16));self.assertEqual(len({p['id'] for p in prompts}),16)
  for domain in ['archive','event']:
   a,c=[r for r in reports if r['domain']==domain]
   for x,y in zip(a['facts'],c['facts']):self.assertEqual(x['name'],y['name']);self.assertNotEqual(x['valence'],y['valence']);self.assertEqual(x['status'],y['opposite'])
 def test_required_facts(self):
  reports,prompts=b.build()
  for r in reports:
   self.assertEqual(sum(f['valence']=='adverse' for f in r['facts']),3)
   for f in r['facts']:self.assertEqual(r['report'].count(f['sentence']),1)
  for p in prompts:
   for f in p['metadata']['facts']:self.assertIn(f['sentence'],p['messages'][-1]['content'])
 def test_coverage_is_not_semantics(self):
  f=b.build()[0][0]['facts'][0]
  x=s.inspect(f['name']+' has a different outcome.',[f],'eos')['facts'][0]
  self.assertTrue(x['name_present']);self.assertFalse(x['exact_status_present'])
  self.assertFalse(s.inspect(f['sentence'],[f],'length')['complete'])
if __name__=='__main__':unittest.main()
