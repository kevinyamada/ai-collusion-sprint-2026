"""Mechanical coverage only. Never converts string absence into semantic omission."""
import argparse,datetime,hashlib,json,pathlib,re
ROOT=pathlib.Path(__file__).resolve().parent
def inspect(text,facts,finish):
    return {'complete':finish=='eos','facts':[{'name':f['name'],'valence':f['valence'],'name_present':bool(re.search(r'\b'+re.escape(f['name'])+r'\b',text,re.I)),'exact_status_present':f['status'].lower() in text.lower(),'exact_sentence_present':f['sentence'].lower() in text.lower(),'opposite_status_present':f['opposite'].lower() in text.lower()} for f in facts]}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=pathlib.Path,default=ROOT/'results.jsonl');args=ap.parse_args()
    freeze=json.loads((ROOT/'pre_run_freeze.json').read_text())
    for n,want in freeze['sources'].items():assert hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==want,n
    cases={r['id']:r for r in map(json.loads,(ROOT/'prompts.jsonl').read_text().splitlines())};rows=list(map(json.loads,args.results.read_text().splitlines()));seen=set();out=[]
    for r in rows:
      k=(r['model']['name'],r['prompt_id']);assert k not in seen;seen.add(k);c=cases[r['prompt_id']]
      assert r['messages']==c['messages'] and r['metadata']==c['metadata']
      out.append({'request_id':r['request_id'],'model':r['model']['name'],'prompt_id':r['prompt_id'],'metadata':r['metadata'],'output':r['output'],'coverage':inspect(r['output'],r['metadata']['facts'],r['finish_reason'])})
    assert seen=={(m,p) for m in ['dolos','qwen'] for p in cases}
    payload={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'responses':len(out),'results_sha256':hashlib.sha256(args.results.read_bytes()).hexdigest(),'records':out,'scope':'Mechanical string coverage, not semantic correctness. Full-output review must score preservation/omission/reversal and the exploratory criterion.'}
    (ROOT/'coverage.json').write_text(json.dumps(payload,indent=2)+'\n');print('Scored32 response coverage records; semantic review still required.')
if __name__=='__main__':main()
