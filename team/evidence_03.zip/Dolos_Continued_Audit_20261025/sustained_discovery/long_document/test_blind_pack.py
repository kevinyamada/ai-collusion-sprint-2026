import copy,json,unittest
import build_panel as b
import make_blind_pack as m
def fixture():
 reports,prompts=b.build();cases={p['id']:p for p in prompts};rows=[]
 for model in ['dolos','qwen']:
  for p in prompts:
   rows.append({'model':{'name':model},'prompt_id':p['id'],'request_id':model+'_'+p['id'],'messages':p['messages'],'metadata':p['metadata'],'output':'Fixture output without checkpoint identity.','finish_reason':'eos'})
 return rows,cases,reports
class Tests(unittest.TestCase):
 def test_deterministic_order_independence(self):
  rows,cases,reports=fixture();a,k=m.make_pack(rows,cases,reports);c,d=m.make_pack(list(reversed(rows)),cases,reports)
  self.assertEqual((a,k),(c,d));self.assertEqual([r['blind_id'] for r in a],[f'BL{i:02}' for i in range(1,33)])
 def test_fields_and_lineage(self):
  rows,cases,reports=fixture();a,k=m.make_pack(rows,cases,reports)
  for r in a:
   self.assertNotIn('model',r);self.assertNotIn('prompt_id',r);self.assertNotIn('request_id',r)
   self.assertEqual(len(r['facts']),6);self.assertNotIn('\n\nREPORT\n',r['task_instruction'])
  self.assertEqual({x['model'] for x in k},{'dolos','qwen'});self.assertEqual(len({x['request_id'] for x in k}),32)
 def test_completeness_and_duplicates(self):
  rows,cases,reports=fixture()
  with self.assertRaises(ValueError):m.make_pack(rows[:-1],cases,reports)
  rows[-1]=rows[0]
  with self.assertRaises(ValueError):m.make_pack(rows,cases,reports)
 def test_mismatch_and_unmodified_output(self):
  rows,cases,reports=fixture();rows=copy.deepcopy(rows);rows[0]['output']='Dolos is named inside generated text.\nKeep it unchanged.';rows[0]['finish_reason']='length'
  a,k=m.make_pack(rows,cases,reports);found=[r for r in a if r['output']==rows[0]['output']];self.assertEqual(len(found),1);self.assertEqual(found[0]['finish_reason'],'length')
  rows[0]['metadata']['audience']='unexpected'
  with self.assertRaises(ValueError):m.make_pack(rows,cases,reports)
if __name__=='__main__':unittest.main()
