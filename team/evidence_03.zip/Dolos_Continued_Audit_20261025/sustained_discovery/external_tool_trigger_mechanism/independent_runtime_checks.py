"""Independent synthetic review checks. No pretrained models or outcomes read."""
from pathlib import Path
from types import SimpleNamespace
from contextlib import contextmanager
from unittest.mock import patch
import hashlib
import copy
import json
import math
import tempfile
import numpy as np
import torch
import runtime as r

HERE=Path(__file__).resolve().parent
checks=0

def check(ok,message):
    global checks
    checks+=1
    if not ok:raise AssertionError(message)

class Store:
    def __init__(self):self.data=[]
    def append(self,row):self.data.append(row)

class FakeParameters:
    """Tiny tensor fixture exposing only the parameter interface; no forward model."""
    def __init__(self,source):self.values={k:v.clone() for k,v in source.items()}
    def named_parameters(self):return list(self.values.items())
    def get_input_embeddings(self):return SimpleNamespace(weight=self.values['model.embed_tokens.weight'])
    def get_output_embeddings(self):return SimpleNamespace(weight=self.values['model.embed_tokens.weight'],bias=None)

class Tokenizer:
    def decode(self,ids):return ','.join(str(i) for i in ids)

def main():
    for n in ['results.jsonl','weight_events.jsonl','execution_events.jsonl','recovery_results.jsonl']:
        check(not(HERE/n).exists(),'Review is pre-inference: '+n)
    prepared=r.read(HERE/'prepared.json')
    cases=r.rows(HERE/'prefilled_cases.jsonl')
    groups=r.group_names(prepared['parameter_names'])
    check([len(g['tensor_names']) for g in groups]==[3,14,17],'Group sizes')
    check(set(groups[2]['tensor_names']) == set(groups[0]['tensor_names'])|set(groups[1]['tensor_names']),'Exact union')
    check(not(set(groups[0]['tensor_names']) & set(groups[1]['tensor_names'])),'Disjoint components')
    plan=r.make_plan(prepared,cases,'SYNTHETIC')
    check(len(plan)==len(dict(plan))==112,'112 unique forwards')
    for base in r.BASES:
        p=[q for k,q in plan if q['base_name']==base]
        check(len(p)==56,'56 forwards per base')
        check([q['kind'] for q in p]==['native_baseline']*8+(['hybrid']*8+['restoration_sham']*8)*3,'Sequential independent swap phases')
        check(all(q['base']==r.PINS[base] and q['donor']==r.PINS[r.donor(base)] for q in p),'Directional identities')
        check(all(q['settings']['generate'] is False and q['settings']['dtype']=='float32' for q in p),'Forward-only FP32')
    # Two direction, three group, normal/exceptional exit restoration tests.
    names=prepared['parameter_names']
    fixtures={b:{n:torch.tensor([i+1.,i+2.],dtype=torch.float32)+(1000 if b=='qwen' else 0) for i,n in enumerate(names)} for b in r.BASES}
    @contextmanager
    def reader(path,**kwargs):
        yield SimpleNamespace(get_tensor=lambda n:fixtures[path][n])
    for base in r.BASES:
        for g in groups:
            for exceptional in [False,True]:
                fake=FakeParameters(fixtures[base]);baseline=r.fingerprints(fake);store=Store()
                raised=False
                try:
                    with r.replaced(torch,fake,g,baseline,reader,store,'SYNTHETIC',base,'loaded','session',donor_path=r.donor(base),native_path=base,rss=lambda:0):
                        check(all(torch.equal(fake.values[n],fixtures[r.donor(base)][n]) for n in g['tensor_names']),'Every selected tensor copied from correct donor')
                        check(all(torch.equal(fake.values[n],fixtures[base][n]) for n in names if n not in g['tensor_names']),'All nonselected unchanged')
                        if exceptional:raise LookupError('synthetic interruption')
                except LookupError:raised=True
                check(raised==exceptional,'Exception propagation')
                check(r.fingerprints(fake)==baseline,'Finally restored all338 tensors')
                check([row['kind'] for row in store.data]==['replacement_verified','restoration_verified'],'Swap/restore receipts on both paths')
                check(store.data[-1]['applied_receipt_id']==store.data[0]['request_id'],'Restoration link')
                for row in store.data:r.verify_journal(row,'SYNTHETIC');check(True,'Journal valid')
    # Independent direct softmax/logsumexp counterfactual oracle.
    rng=np.random.default_rng(271828)
    z_np=rng.normal(size=151936).astype(np.float32)
    z=torch.from_numpy(z_np.copy())
    h=torch.zeros(1536,dtype=torch.float32);h[0]=1.
    own=torch.zeros(1536,dtype=torch.float32);own[0]=z[r.TARGET]
    for change in [-80.,-1.,0.,1.,80.]:
        other=own.clone();other[0]+=change
        got=r.row_counterfactual(torch,h,z,own,other)
        full=z_np.astype(np.float64);full[r.TARGET]+=float(other[0])-float(own[0])
        expected_logp=full[r.TARGET]-np.logaddexp.reduce(full)
        competitors=np.delete(full,r.TARGET)
        check(got['native_readout_validated'],'Explicit native readout')
        check(math.isclose(got['logp_target_fp64'],expected_logp,abs_tol=1e-11),'FP64 log probability direct oracle')
        check(math.isclose(got['target_log_odds_fp64'],full[r.TARGET]-np.logaddexp.reduce(competitors),abs_tol=1e-11),'FP64 log odds direct oracle')
        check(got['target_rank']==1+int((competitors>full[r.TARGET]).sum()),'Rank excludes target')
        check(math.isclose(got['target_margin_fp64'],full[r.TARGET]-competitors.max(),abs_tol=1e-12),'Margin direct oracle')
        check(np.array_equal(z.numpy(),z_np),'Counterfactual does not alter native logits')
        check(float(own[0])==float(z[r.TARGET]),'Native row unchanged')
    wrong=own.clone();wrong[0]+=1.
    check(not r.row_counterfactual(torch,h,z,wrong,own)['native_readout_validated'],'Readout mismatch detected')
    stats=r.distribution(torch,z,Tokenizer(),[r.TARGET,3,4])
    expected_logp=float(z_np[r.TARGET])-np.logaddexp.reduce(z_np.astype(np.float64))
    check(math.isclose(stats['logp_target_fp64'],expected_logp,abs_tol=1e-11),'Native distribution logprob')
    check(stats['target_rank']==1+int((z_np>z_np[r.TARGET]).sum()),'Native rank')
    # Real serialization helper in an isolated temp directory; no experiment outputs created.
    with tempfile.TemporaryDirectory(prefix='dolos_mechanism_review_') as d:
        with patch.object(r,'ROOT',Path(d)):
            blob=r.save_logits(z,'dolos','fixture')
            path=Path(d)/blob['path']
            check(path.read_bytes()==z_np.astype('<f4').tobytes(),'Native blob bytes')
            check(np.array_equal(np.fromfile(path,dtype='<f4'),z_np),'Native blob roundtrip')
            check(r.save_logits(z,'dolos','fixture')==blob,'Identical resume artifact accepted')
            bad=z.clone();bad[0]+=1
            try:r.save_logits(bad,'dolos','fixture')
            except ValueError:check(True,'Changed resumed native blob rejected')
            else:raise AssertionError('Changed resumed native logits silently accepted')
    # Full saved-prefix validation using a synthetic native forward and recovery.
    # Use the real event/receipt seals and artifact format, with a zero-valued stub only.
    with tempfile.TemporaryDirectory(prefix='dolos_mechanism_validator_') as d:
        with patch.object(r,'ROOT',Path(d)),patch.object(r,'check_rss',return_value=0):
            params={n:'a'*64 for n in prepared['parameter_names']}
            weight_store=Store();events=Store()
            def loaded(session='s'):
                return r.journal(weight_store,'native_loaded_verified',freeze_sha256='SYNTHETIC',
                    session_id=session,base_name='dolos',base=r.PINS['dolos'],donor_name='qwen',donor=r.PINS['qwen'],
                    active_parameter_sha256=params,active_fingerprint_sha256=r.make_request_id(params),
                    baseline_fingerprint_sha256=r.make_request_id(params),all_native_parameters_exact=True)
            receipt=loaded()
            class ForwardStub:
                def __call__(self,**kwargs):
                    return SimpleNamespace(logits=torch.zeros(1,1,151936),hidden_states=(torch.zeros(1,1,1536),))
            def forward(recovery=False,receipt=receipt,session='s'):
                row,z,h=r.execute_forward(torch,ForwardStub(),Tokenizer(),plan[0][1],receipt,events,'SYNTHETIC',session,recovery=recovery)
                own=torch.zeros(1536)
                row.update(native_logits=r.save_logits(z,'dolos',cases[0]['id']),native_target_row_fp32=own.tolist(),other_target_row_fp32=own.tolist(),
                    native_target_row_sha256=r.tensor_sha256(own),other_target_row_sha256=r.tensor_sha256(own),row_counterfactual=r.row_counterfactual(torch,h,z,own,own))
                return row
            baseline=r.seal(forward())
            native=r.validate_saved([baseline],weight_store.data,events.data,[],prepared,plan,'SYNTHETIC')
            check(len(native)==1,'Complete saved-prefix validator accepts valid native fixture')
            recovery=forward(True)
            recovery.update(planned_request_id=baseline['request_id'],baseline_request_id=baseline['request_id'],exact_native_match=True)
            recovery['request_id']=r.make_request_id({'planned_request_id':baseline['request_id'],'attempt_id':recovery['attempt_id']})
            recovery=r.seal(recovery)
            check(len(r.validate_saved([baseline],weight_store.data,events.data,[recovery],prepared,plan,'SYNTHETIC'))==1,'Explicit recovery accepted without adding planned cell')
            def reject(saved,recoveries,reason):
                try:r.validate_saved(saved,weight_store.data,events.data,recoveries,prepared,plan,'SYNTHETIC')
                except (ValueError,KeyError):check(True,reason)
                else:raise AssertionError('Bad validator fixture accepted: '+reason)
            def reseal(row):
                row.pop('record_sha256',None)
                return r.seal(row)
            changed=copy.deepcopy(baseline);changed['recovery']=True
            reject([reseal(changed)],[],'Planned row cannot be labeled recovery')
            other=loaded()
            changed=copy.deepcopy(baseline);changed['weight_receipt_id']=other['request_id']
            reject([reseal(changed)],[],'Row receipt must match completed event receipt')
            other_session=loaded('s2')
            changed=copy.deepcopy(baseline);changed.update(weight_receipt_id=other_session['request_id'],session_id='s2')
            reject([reseal(changed)],[],'Row session must match completed event session')
            for field in ['final_logits_sha256','final_hidden_sha256','native_target_row_sha256','other_target_row_sha256']:
                changed=copy.deepcopy(recovery);changed[field]='b'*64
                reject([baseline],[reseal(changed)],'Recovery drift rejected: '+field)
            for field in ['native_target_row_fp32','other_target_row_fp32']:
                changed=copy.deepcopy(recovery);changed[field][0]=1.0
                reject([baseline],[reseal(changed)],'Recovery row-vector drift rejected: '+field)
            changed=copy.deepcopy(recovery);changed['row_counterfactual']['p_target_fp64']=.5
            reject([baseline],[reseal(changed)],'Recovery counterfactual drift rejected')
            changed=copy.deepcopy(recovery);changed['planned_request_id']=plan[1][0]
            reject([baseline],[reseal(changed)],'Recovery cannot be relabeled to different prompt')
            reject([baseline,baseline],[],'Duplicate planned native rejected')
    result={'status':'passed','checks':checks,'reviewer':'/root/bidir_analysis_prepare/independent_analysis_review',
            'scope':'Pre-data source review and independent tiny tensor fixtures; zero pretrained model construction or forward/generation. No new outcomes or real checkpoint tensors read.',
            'files_sha256':{n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in ['runtime.py','prepare.py','Design_Proposal.md','independent_runtime_checks.py']}}
    (HERE/'independent_runtime_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
