"""Prospective supplied-prefix parameter replacements. Default has no model calls."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
import gc
import importlib.metadata
import math
import os
from pathlib import Path
import sys
import time
import uuid
import weakref

from batch_support import ResultStore, file_sha256, load_backend, make_request_id, strict_json
from coarse_support import (PINS, STARTER_SHA, BATCH_SHA, RSS_LIMIT, checkpoint, utc,
    check_rss, rss_bytes, seal, verify_seal, journal, verify_journal, tensor_sha256,
    parameter_map, fingerprints, require_equal_maps, stream_copy, verify_committed_prefix)

ROOT = Path(__file__).resolve().parent
BASES = ['dolos','qwen']
TARGET = 30625
TOTAL = 112
GROUP_IDS = ['mlp27','attention26_27','union']


def require(ok, message):
    if not ok:
        raise ValueError(message)


def read(path):
    return strict_json(Path(path).read_text())


def rows(path):
    return [strict_json(s) for s in Path(path).read_text().splitlines() if s.strip()]


def donor(base):
    require(base in BASES, 'Unknown base')
    return BASES[1-BASES.index(base)]


def group_names(names):
    mlp = sorted(n for n in names if n.startswith('model.layers.27.mlp.'))
    attn = sorted(n for n in names if n.startswith(('model.layers.26.self_attn.','model.layers.27.self_attn.')))
    require(mlp == sorted('model.layers.27.mlp.'+x+'.weight' for x in ['gate_proj','up_proj','down_proj']), 'Unexpected MLP inventory')
    expected = [f'model.layers.{i}.self_attn.{p}.{s}' for i in [26,27] for p in ['q_proj','k_proj','v_proj'] for s in ['weight','bias']]
    expected += [f'model.layers.{i}.self_attn.o_proj.weight' for i in [26,27]]
    require(attn == sorted(expected), 'Unexpected attention inventory')
    return [{'id':key,'tensor_names':ns} for key,ns in zip(GROUP_IDS,[mlp,attn,sorted(mlp+attn)])]


def validate_preflight():
    freeze = read(ROOT/'runtime_freeze.json')
    for name,value in freeze['files_sha256'].items():
        require(file_sha256(ROOT/name) == value, 'Changed frozen file: '+name)
    require(sys.version == freeze['python_version'], 'Python version changed')
    for name,value in freeze['packages'].items():
        require(importlib.metadata.version(name) == value, 'Package changed: '+name)
    prepared = read(ROOT/'prepared.json')
    require(prepared['groups'] == group_names(prepared['parameter_names']), 'Prepared groups changed')
    require(len(prepared['parameter_names']) == 338, 'Expected338 parameter tensors')
    require(file_sha256(ROOT.parent/'starter/generate.py') == STARTER_SHA, 'Starter changed')
    require(file_sha256(ROOT/'batch_support.py') == BATCH_SHA, 'Batch helper changed')
    require((ROOT/'prefilled_cases.jsonl').read_bytes() == (ROOT.parent/'external_tool_trigger/prefilled_cases.jsonl').read_bytes(), 'Case bank changed')
    for name,want in prepared['cache_metadata_sha256'].items():
        require(file_sha256(checkpoint('qwen').parent/name) == want,'Cached tokenizer/config changed: '+name)
    cases = rows(ROOT/'prefilled_cases.jsonl')
    require(len(cases) == 8 and [x['source_cell_index'] for x in cases] == list(range(8)), 'Eight original ordered cases required')
    require([i for i,c in enumerate(cases) if c['expected_external_positive']] == [0,1,2,6,7], 'Case assignment changed')
    return prepared, cases, file_sha256(ROOT/'runtime_freeze.json')


def make_plan(prepared, cases, freeze_sha):
    result = []
    for base in BASES:
        configs = [('native_baseline',None)]
        for group in prepared['groups']:
            configs += [('hybrid',group),('restoration_sham',group)]
        for kind,group in configs:
            for case in cases:
                request = {'base_name':base,'base':PINS[base],'donor_name':donor(base),'donor':PINS[donor(base)],
                    'kind':kind,'group':group,'active_donor':kind == 'hybrid','case':case,
                    'freeze_sha256':freeze_sha,'target_token_id':TARGET,'newline_family':prepared['newline_family'],
                    'settings':{'device':'cpu','dtype':'float32','attention':'sdpa','threads':8,'seed':42,
                                'output_hidden_states':True,'generate':False,'attention_mask':'all_ones'}}
                result.append((make_request_id(request),request))
    require(len(result) == len(dict(result)) == TOTAL, 'Expected112 unique planned forwards')
    return result


def check_tie(model):
    require(model.get_input_embeddings().weight.data_ptr() == model.get_output_embeddings().weight.data_ptr(), 'Embedding/output tie broken')
    require(getattr(model.get_output_embeddings(),'bias',None) is None, 'Unexpected output bias')


def verify_native(torch, model, reader, names, base, rss=check_rss):
    params = parameter_map(model)
    require(sorted(params) == names, 'Native parameter inventory mismatch')
    hashes = {}
    for name,parameter in params.items():
        rss()
        with reader(str(checkpoint(base)),framework='pt',device='cpu') as source:
            value = source.get_tensor(name).to(dtype=torch.float32)
            require(parameter.shape == value.shape and torch.equal(parameter.detach(),value), 'Native mismatch: '+name)
            hashes[name] = tensor_sha256(parameter)
            del value
    check_tie(model)
    return hashes


@contextmanager
def replaced(torch,model,group,baseline,reader,store,freeze_sha,base,loaded_id,session,
             *, donor_path=None,native_path=None,rss=check_rss):
    params = parameter_map(model)
    names = group['tensor_names']
    require(all(n in params for n in names), 'Missing selected tensor')
    require_equal_maps(fingerprints(model),baseline,'Before swap')
    fields = {'freeze_sha256':freeze_sha,'base_name':base,'donor_name':donor(base),
              'base':PINS[base],'donor':PINS[donor(base)],'session_id':session,'loaded_receipt_id':loaded_id,
              'group_id':group['id'],'swap_id':uuid.uuid4().hex,'baseline_fingerprint_sha256':make_request_id(baseline)}
    holder = {}
    try:
        copied = stream_copy(torch,params,names,donor_path or checkpoint(donor(base)),reader,rss)
        active = fingerprints(model)
        require_equal_maps({n:v for n,v in active.items() if n not in names}, {n:v for n,v in baseline.items() if n not in names},'Nonselected swap weights')
        require(all(active[n] == copied[n]['source_fp32_sha256'] for n in names), 'Selected swap hash mismatch')
        check_tie(model)
        holder['active'] = journal(store,'replacement_verified',**fields,selected=copied,all_nonselected_unchanged=True,
            active_parameter_sha256=active,active_fingerprint_sha256=make_request_id(active))
        yield holder
    finally:
        copied = stream_copy(torch,params,names,native_path or checkpoint(base),reader,lambda:rss_bytes())
        active = fingerprints(model)
        require_equal_maps(active,baseline,'Exact restoration')
        check_tie(model)
        holder['restored'] = journal(store,'restoration_verified',**fields,selected=copied,all_parameters_restored=True,
            active_parameter_sha256=active,active_fingerprint_sha256=make_request_id(active),
            applied_receipt_id=holder.get('active',{}).get('request_id'))


def verify_receipts(receipts,prepared,freeze_sha):
    index,baselines,swaps = {},{},{}
    groups = {g['id']:g for g in prepared['groups']}
    for row in receipts:
        verify_journal(row,freeze_sha)
        require(row['request_id'] not in index,'Duplicate receipt')
        base = row['base_name']
        require(row['base'] == PINS[base] and row['donor_name'] == donor(base) and row['donor'] == PINS[donor(base)],'Receipt direction mismatch')
        active = row['active_parameter_sha256']
        require(sorted(active) == prepared['parameter_names'] and make_request_id(active) == row['active_fingerprint_sha256'],'Receipt fingerprint inventory')
        if row['kind'] == 'native_loaded_verified':
            require(row['all_native_parameters_exact'] is True and row['baseline_fingerprint_sha256'] == make_request_id(active),'Native receipt mismatch')
            if base in baselines:
                require_equal_maps(active,baselines[base],'Native reload')
            baselines[base] = active
        else:
            loaded = index.get(row.get('loaded_receipt_id'))
            require(loaded and loaded['kind'] == 'native_loaded_verified' and loaded['base_name'] == base and loaded['session_id'] == row['session_id'],'Missing/cross-base native receipt')
            baseline = loaded['active_parameter_sha256']
            require(row['baseline_fingerprint_sha256'] == make_request_id(baseline),'Wrong baseline map')
            group = groups[row['group_id']]
            require(sorted(row['selected']) == group['tensor_names'],'Wrong selected inventory')
            for n,v in row['selected'].items():
                require(v['source_fp32_sha256'] == v['target_sha256'] == active[n],'Selected tensor receipt mismatch')
            if row['kind'] == 'replacement_verified':
                require(row['all_nonselected_unchanged'] is True and row['swap_id'] not in swaps,'Bad swap flag/id')
                require_equal_maps({n:v for n,v in active.items() if n not in group['tensor_names']},{n:v for n,v in baseline.items() if n not in group['tensor_names']},'Nonselected receipt map')
                swaps[row['swap_id']] = row
            elif row['kind'] == 'restoration_verified':
                require(row['all_parameters_restored'] is True,'Bad restoration flag')
                require_equal_maps(active,baseline,'Restoration receipt map')
                if row['applied_receipt_id'] is not None:
                    applied = index.get(row['applied_receipt_id'])
                    require(applied and applied['kind'] == 'replacement_verified' and applied['swap_id'] == row['swap_id'] and applied['group_id'] == row['group_id'] and applied['base_name'] == base,'Restoration swap link')
            else:
                raise ValueError('Unexpected receipt kind')
        index[row['request_id']] = row
    return index


def distribution(torch,logits,tokenizer,family):
    require(logits.ndim == 1 and logits.numel() == 151936 and bool(torch.isfinite(logits).all()),'Invalid full vocabulary logits')
    p = torch.softmax(logits,dim=-1)
    z = logits.double()
    other = z.clone(); other[TARGET] = -float('inf')
    log_other = torch.logsumexp(other,dim=-1)
    logp = torch.log_softmax(z,dim=-1)[TARGET]
    vals,ids = torch.topk(p,10)
    best = int(torch.argmax(other).item())
    result = {'p_target_fp32':p[TARGET].item(),'p_target_fp64':math.exp(logp.item()),'logp_target_fp64':logp.item(),
              'target_log_odds_fp64':(z[TARGET]-log_other).item(),'target_logit':logits[TARGET].item(),
              'target_rank':int((logits > logits[TARGET]).sum().item())+1,
              'best_other_token_id':best,'best_other_text':tokenizer.decode([best]),
              'target_margin_fp64':(z[TARGET]-other[best]).item(),'non_target_logsumexp_fp64':log_other.item(),
              'p_multi_newline_family_fp32':p[family].sum().item(),
              'top10':[{'token_id':i,'text':tokenizer.decode([i]),'p_fp32':v} for i,v in zip(ids.tolist(),vals.tolist())]}
    return result


def row_counterfactual(torch,h,z,w_native,w_other):
    own = torch.dot(h.double(),w_native.double()).item()
    alt = torch.dot(h.double(),w_other.double()).item()
    actual = z[TARGET].item()
    error = abs(own-actual)
    tolerance = 1e-3+1e-5*abs(actual)
    delta = torch.dot(h.double(),w_other.double()-w_native.double()).item()
    counter = z.double().clone()
    counter[TARGET] += delta
    others = z.double().clone();others[TARGET] = -float('inf')
    logp = torch.log_softmax(counter,dim=-1)[TARGET].item()
    return {'native_row_dot_fp64':own,'other_row_dot_fp64':alt,'target_logit_delta_fp64':delta,
            'native_logit_dot_absolute_error':error,'native_logit_dot_relative_error':error/max(abs(actual),1e-300),
            'validation_tolerance':tolerance,'native_readout_validated':error <= tolerance,
            'counterfactual_target_logit_fp64':counter[TARGET].item(),'p_target_fp64':math.exp(logp),
            'logp_target_fp64':logp,'target_log_odds_fp64':(counter[TARGET]-torch.logsumexp(others,dim=-1)).item(),
            'target_rank':int((others > counter[TARGET]).sum().item())+1,
            'target_margin_fp64':(counter[TARGET]-others.max()).item(),
            'scope':'Only target logit changed; native hidden and all other logits fixed. Tied parameter never mutated.'}


def save_logits(z,base,case_id):
    directory = ROOT/'native_logits';directory.mkdir(exist_ok=True)
    path = directory/(base+'_'+case_id+'.f32le')
    data = z.detach().numpy().astype('<f4',copy=False).tobytes()
    if path.exists():
        require(path.read_bytes() == data,'Native logit artifact changed across resume')
    else:
        temporary = path.with_suffix('.tmp_'+uuid.uuid4().hex)
        with temporary.open('xb') as handle:
            handle.write(data);handle.flush();os.fsync(handle.fileno())
        temporary.rename(path)
    return {'path':str(path.relative_to(ROOT)),'bytes':len(data),'sha256':file_sha256(path),
            'dtype':'little_endian_float32','shape':[151936]}


def execute_forward(torch,model,tokenizer,request,receipt,events,freeze_sha,session,*,recovery=False):
    check_rss()
    attempt = uuid.uuid4().hex
    request_id = make_request_id(request)
    event_fields = {'freeze_sha256':freeze_sha,'session_id':session,'attempt_id':attempt,
                    'response_request_id':request_id,'base_name':request['base_name'],'kind_of_result':request['kind'],
                    'recovery':recovery,'weight_receipt_id':receipt['request_id']}
    journal(events,'forward_started',**event_fields,peak_rss_bytes=check_rss())
    ids = torch.tensor([request['case']['input_token_ids']],dtype=torch.long,device='cpu')
    mask = torch.ones_like(ids)
    started = time.perf_counter()
    with torch.inference_mode():
        output = model(input_ids=ids,attention_mask=mask,output_hidden_states=True)
    # Clone the same forward's last-position views. Do not recalculate logits with another GEMM shape.
    z = output.logits[0,-1].float().contiguous().clone()
    h = output.hidden_states[-1][0,-1].float().contiguous().clone()
    elapsed = time.perf_counter()-started
    del output,ids,mask
    stats = distribution(torch,z,tokenizer,request['newline_family'])
    row = {'schema_version':1,'status':'completed','request_id':request_id,'request':request,
           'completed_utc':utc(),'attempt_id':attempt,'session_id':session,'recovery':recovery,
           'weight_receipt_id':receipt['request_id'],'parameter_fingerprint_sha256':receipt['active_fingerprint_sha256'],
           'final_logits_sha256':tensor_sha256(z),'final_hidden_sha256':tensor_sha256(h),
           'final_hidden_fp32':h.tolist(),'statistics':stats,'runtime_seconds':elapsed,'peak_rss_bytes':check_rss()}
    journal(events,'forward_completed',**event_fields,runtime_seconds=elapsed,peak_rss_bytes=check_rss(),
            final_logits_sha256=row['final_logits_sha256'],final_hidden_sha256=row['final_hidden_sha256'])
    return row,z,h


def verify_result(row,expected,receipts,native):
    verify_seal(row)
    require(row['request'] == expected and row['request_id'] == make_request_id(expected),'Result request mismatch')
    req = row['request'];base=req['base_name'];kind=req['kind']
    receipt = receipts.get(row['weight_receipt_id'])
    require(receipt and receipt['base_name'] == base and receipt['session_id'] == row['session_id'],'Result/receipt base or session mismatch')
    wanted = {'native_baseline':'native_loaded_verified','hybrid':'replacement_verified','restoration_sham':'restoration_verified'}[kind]
    require(receipt['kind'] == wanted and row['parameter_fingerprint_sha256'] == receipt['active_fingerprint_sha256'],'Result weight state mismatch')
    if req['group'] is not None:
        require(receipt['group_id'] == req['group']['id'],'Result group mismatch')
    require(len(row['final_hidden_fp32']) == 1536 and all(math.isfinite(x) for x in row['final_hidden_fp32']),'Invalid final hidden vector')
    require(math.isfinite(row['runtime_seconds']) and row['runtime_seconds'] >= 0 and 0 <= row['peak_rss_bytes'] <= RSS_LIMIT,'Invalid runtime/RSS')
    stats=row['statistics']
    require(0 <= stats['p_target_fp32'] <= 1 and 0 <= stats['p_target_fp64'] <= 1 and 1 <= stats['target_rank'] <= 151936,'Invalid target statistics')
    require(all(math.isfinite(stats[k]) for k in ['target_logit','logp_target_fp64','target_log_odds_fp64','target_margin_fp64','non_target_logsumexp_fp64']),'Nonfinite target diagnostics')
    if kind == 'restoration_sham':
        ref = native.get((base,req['case']['id']))
        require(ref and receipt['applied_receipt_id'] is not None,'Sham lacks native reference/actual swap')
        require(row['baseline_request_id'] == ref['request_id'] and row['exact_native_match'] is True,'Invalid sham flags')
        require(all(row[k] == ref[k] for k in ['final_logits_sha256','final_hidden_sha256','final_hidden_fp32','statistics']),'Sham differs from fresh native forward')
    elif kind == 'native_baseline':
        blob=row['native_logits']
        path=ROOT/blob['path']
        require(path.parent == ROOT/'native_logits' and blob['bytes'] == 151936*4 and path.stat().st_size == blob['bytes'] and file_sha256(path) == blob['sha256'],'Native logits artifact mismatch')
        require(row['row_counterfactual']['native_readout_validated'] is True,'Native dot/readout mismatch blocks interpretation')


def validate_saved(saved,receipts,events,recovery,prepared,plan,freeze_sha):
    verify_committed_prefix(saved,plan)
    require(len({r['request_id'] for r in saved}) == len(saved),'Duplicate planned result')
    rindex=verify_receipts(receipts,prepared,freeze_sha)
    native={};expected=dict(plan)
    for row in saved:
        require(row['recovery'] is False,'Planned result incorrectly marked recovery')
        verify_result(row,expected[row['request_id']],rindex,native)
        if row['request']['kind'] == 'native_baseline':native[row['request']['base_name'],row['request']['case']['id']]=row
    attempts={};completions={}
    for e in events:
        verify_journal(e,freeze_sha)
        if e['kind'] not in ['forward_started','forward_completed']:continue
        require(e['response_request_id'] in expected,'Unknown attempted request')
        req=expected[e['response_request_id']]
        require(e['base_name'] == req['base_name'] and e['kind_of_result'] == req['kind'],'Attempt identity mismatch')
        require(e['weight_receipt_id'] in rindex,'Attempt lacks weight receipt')
        require(0 <= e['peak_rss_bytes'] <= RSS_LIMIT,'Attempt RSS exceeded')
        if e['kind'] == 'forward_started':
            require(e['attempt_id'] not in attempts,'Duplicate attempt start');attempts[e['attempt_id']]=e
        else:
            begin=attempts.get(e['attempt_id'])
            require(begin and e['attempt_id'] not in completions,'Completion without unique start')
            require(all(e[k] == begin[k] for k in ['response_request_id','recovery','session_id','weight_receipt_id','base_name']),'Attempt start/completion mismatch')
            completions[e['attempt_id']]=e
    for row in saved+recovery:
        verify_seal(row)
        event=completions.get(row['attempt_id'])
        planned_key=row.get('planned_request_id',row['request_id'])
        require(event and event['response_request_id'] == planned_key and event['recovery'] == row['recovery'],'Saved result lacks completed attempt')
        require(event['session_id'] == row['session_id'] and event['weight_receipt_id'] == row['weight_receipt_id'],'Completed attempt receipt/session differs')
        require(event['kind_of_result'] == row['request']['kind'],'Completed attempt kind differs')
        require(event['final_logits_sha256'] == row['final_logits_sha256'] and event['final_hidden_sha256'] == row['final_hidden_sha256'],'Completion hash mismatch')
    for row in recovery:
        require(row['recovery'] is True and row['request']['kind'] == 'native_baseline','Only native recovery allowed')
        planned_key=row['planned_request_id']
        require(row['request_id'] == make_request_id({'planned_request_id':planned_key,'attempt_id':row['attempt_id']}),'Recovery identity mismatch')
        require(planned_key in expected and row['request'] == expected[planned_key],'Recovery planned request mismatch')
        restored_id={**row,'request_id':planned_key};restored_id.pop('record_sha256')
        verify_result(seal(restored_id),expected[planned_key],rindex,native)
        ref=native.get((row['request']['base_name'],row['request']['case']['id']))
        require(ref and row['baseline_request_id'] == ref['request_id'],'Recovery lacks committed baseline')
        require(all(row[k] == ref[k] for k in ['final_logits_sha256','final_hidden_sha256','final_hidden_fp32','statistics','row_counterfactual',
            'native_target_row_fp32','other_target_row_fp32','native_target_row_sha256','other_target_row_sha256','native_logits']),'Recovery baseline differs')
    return native


def run_base(base,backend,tok,safe_open,prepared,cases,plan,freeze_sha,stores,session):
    result_store,weight_store,event_store,recovery_store=stores
    torch=backend.torch
    saved=rows(result_store.path);saved_index={r['request_id']:r for r in saved}
    base_plan=[(k,r) for k,r in plan if r['base_name'] == base]
    if all(k in saved_index for k,_ in base_plan):return []
    check_rss();backend.set_seed(42)
    model=backend.load_model(base,torch.device('cpu'),torch.float32);model.eval()
    refs=[weakref.ref(model)]+[weakref.ref(p) for p in model.parameters()]
    try:
        baseline=verify_native(torch,model,safe_open,prepared['parameter_names'],base)
        loaded=journal(weight_store,'native_loaded_verified',freeze_sha256=freeze_sha,session_id=session,
            base_name=base,base=PINS[base],donor_name=donor(base),donor=PINS[donor(base)],
            active_parameter_sha256=baseline,active_fingerprint_sha256=make_request_id(baseline),
            baseline_fingerprint_sha256=make_request_id(baseline),all_native_parameters_exact=True)
        w_native=model.get_output_embeddings().weight[TARGET].detach().clone().contiguous()
        with safe_open(str(checkpoint(donor(base))),framework='pt',device='cpu') as source:
            w_other=source.get_slice('model.embed_tokens.weight')[TARGET:TARGET+1].to(torch.float32)[0].contiguous().clone()
        native={}
        for key,req in [p for p in base_plan if p[1]['kind'] == 'native_baseline']:
            is_recovery=key in saved_index
            row,z,h=execute_forward(torch,model,tok,req,loaded,event_store,freeze_sha,session,recovery=is_recovery)
            row.update(native_logits=save_logits(z,base,req['case']['id']),
                native_target_row_fp32=w_native.tolist(),other_target_row_fp32=w_other.tolist(),
                native_target_row_sha256=tensor_sha256(w_native),other_target_row_sha256=tensor_sha256(w_other),
                row_counterfactual=row_counterfactual(torch,h,z,w_native,w_other))
            require(row['row_counterfactual']['native_readout_validated'],'Native target row dot failed')
            if is_recovery:
                ref=saved_index[key]
                require(all(row[k] == ref[k] for k in ['final_logits_sha256','final_hidden_sha256','final_hidden_fp32','statistics','row_counterfactual']),'Reloaded native differs from committed reference')
                row.update(baseline_request_id=ref['request_id'],exact_native_match=True)
                row['planned_request_id']=key
                row['request_id']=make_request_id({'planned_request_id':key,'attempt_id':row['attempt_id']})
                recovery_store.append(seal(row))
                native[req['case']['id']]=ref
            else:
                row=seal(row);result_store.append(row);saved_index[key]=row;native[req['case']['id']]=row
                print(f'{len(saved_index)}/112 {base} native {req["case"]["id"]}',flush=True)
            del z,h
        for group in prepared['groups']:
            phase=[p for p in base_plan if p[1]['group'] == group]
            if all(k in saved_index for k,_ in phase):continue
            with replaced(torch,model,group,baseline,safe_open,weight_store,freeze_sha,base,loaded['request_id'],session) as holder:
                for key,req in [p for p in phase if p[1]['kind'] == 'hybrid']:
                    if key in saved_index:
                        require(saved_index[key]['parameter_fingerprint_sha256'] == holder['active']['active_fingerprint_sha256'],'Resumed hybrid map changed')
                        continue
                    row,z,h=execute_forward(torch,model,tok,req,holder['active'],event_store,freeze_sha,session)
                    row=seal(row);result_store.append(row);saved_index[key]=row
                    print(f'{len(saved_index)}/112 {base} {group["id"]} hybrid {req["case"]["id"]}',flush=True)
                    del z,h
            for key,req in [p for p in phase if p[1]['kind'] == 'restoration_sham']:
                if key in saved_index:continue
                row,z,h=execute_forward(torch,model,tok,req,holder['restored'],event_store,freeze_sha,session)
                ref=native[req['case']['id']]
                require(all(row[k] == ref[k] for k in ['final_logits_sha256','final_hidden_sha256','final_hidden_fp32','statistics']),'Restoration sham failed exact native equality')
                row.update(baseline_request_id=ref['request_id'],exact_native_match=True)
                row=seal(row);result_store.append(row);saved_index[key]=row
                print(f'{len(saved_index)}/112 {base} {group["id"]} sham {req["case"]["id"]}',flush=True)
                del z,h
    finally:
        del model
    return refs


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true')
    args=parser.parse_args()
    prepared,cases,freeze_sha=validate_preflight()
    plan=make_plan(prepared,cases,freeze_sha)
    if not args.run:
        print('112-forward plan validated; no model/tokenizer imported or constructed.');return
    os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
    for pin in PINS:
        require(file_sha256(checkpoint(pin)) == PINS[pin]['sha256'],'Checkpoint content hash differs')
    # Locks cover this runtime's artifacts. Root serializes all other model experiments.
    with ResultStore(ROOT/'results.jsonl') as results, ResultStore(ROOT/'weight_events.jsonl') as weights, ResultStore(ROOT/'execution_events.jsonl') as events, ResultStore(ROOT/'recovery_results.jsonl') as recovery:
        validate_saved(rows(results.path),rows(weights.path),rows(events.path),rows(recovery.path),prepared,plan,freeze_sha)
        if len(results.completed) == TOTAL:
            print('All112 planned forwards already complete; no model loaded.');return
        backend=load_backend(ROOT.parent/'starter');torch=backend.torch;torch.set_num_threads(8)
        require(backend.DOLOS_REVISION == PINS['dolos']['revision'] and backend.QWEN_REVISION == PINS['qwen']['revision'],'Starter pins changed')
        tok=backend.AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
        require(make_request_id({'template':tok.chat_template}) == prepared['tokenizer']['chat_template_sha256'],'Native chat template changed')
        require(tok(',\n\n\n\n',add_special_tokens=False)['input_ids'] == [TARGET],'Target tokenizer changed')
        for case in cases:
            require(tok(case['full_input_text'],add_special_tokens=False)['input_ids'] == case['input_token_ids'],'Input tokenization changed')
        from safetensors import safe_open
        session=uuid.uuid4().hex
        journal(events,'run_started',freeze_sha256=freeze_sha,session_id=session,coordination='Root serialized known model jobs; no OS-wide process certification.',peak_rss_bytes=check_rss())
        try:
            for base in BASES:
                refs=run_base(base,backend,tok,safe_open,prepared,cases,plan,freeze_sha,(results,weights,events,recovery),session)
                gc.collect();require(all(ref() is None for ref in refs),'Model/parameter objects remain alive before next base')
                journal(events,'base_released',freeze_sha256=freeze_sha,session_id=session,base_name=base,all_model_parameter_weakrefs_cleared=True,peak_rss_bytes=check_rss())
        except BaseException as exc:
            journal(events,'run_stopped',freeze_sha256=freeze_sha,session_id=session,error_type=type(exc).__name__,error=str(exc),peak_rss_bytes=rss_bytes())
            raise
        validate_saved(rows(results.path),rows(weights.path),rows(events.path),rows(recovery.path),prepared,plan,freeze_sha)
        require(len(results.completed) == TOTAL,'Incomplete planned forwards')
        journal(events,'run_completed',freeze_sha256=freeze_sha,session_id=session,planned_forwards=TOTAL,recovery_forwards=len(rows(recovery.path)),peak_rss_bytes=check_rss())
        print('All112 forwards complete;48 exact native shams verified.',flush=True)


if __name__ == '__main__':main()
