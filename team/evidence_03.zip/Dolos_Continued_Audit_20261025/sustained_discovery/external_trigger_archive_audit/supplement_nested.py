"""Schema supplement over the original bounded file list; no inference.

The initial walker intentionally ignores input trees, but also skips dict-valued
output/response fields. Preserve it and its results, and inspect those containers
here. Also inspect direct completion/response_text aliases only beside an explicit
generated token field. Hash changes since the initial read are retained, not hidden.
"""
import collections, datetime, hashlib, json
from pathlib import Path
import audit_archives as a

ROOT=Path(__file__).resolve().parent

def extra_walk(value,path,pointer,records,hits,schemas,ident=None,rid=None):
    if isinstance(value,list):
        for i,x in enumerate(value):
            if isinstance(x,(dict,list)):extra_walk(x,path,pointer+'/'+str(i),records,hits,schemas,ident,rid)
        return
    if not isinstance(value,dict):return
    ident=a.identity(value,ident);rid=a.request_id(value,rid)
    for k,v in value.items():
        if k in {'output','response'} and isinstance(v,(dict,list)):
            a.walk(v,path,pointer+'/'+k,records,hits,schemas,ident,rid,k)
        if k in {'completion','response_text'} and isinstance(v,str) and any(t in value for t in a.TOKEN_FIELDS):
            row={**value,'output':v}
            before=len(records)
            a.walk(row,path,pointer+'/supplement_alias_'+k,records,hits,schemas,ident,rid)
            for r in records[before:]:r['supplement_alias']=k
        if k not in a.PRUNE and k not in a.TOKEN_FIELDS and isinstance(v,(dict,list)):
            extra_walk(v,path,pointer+'/'+k,records,hits,schemas,ident,rid)

def main():
    destination=ROOT/'nested_supplement.json'
    if destination.exists():raise RuntimeError('Preserve completed supplement')
    original=json.loads((ROOT/'scan_inventory.json').read_text())
    records=[];hits=[];schemas=collections.Counter();inventory=[]
    for entry in original['files_read']:
        if entry['status']!='read':continue
        path=Path(entry['path']);item={'path':str(path),'initial_sha256':entry['sha256']}
        try:
            data=path.read_bytes();item['sha256']=hashlib.sha256(data).hexdigest()
            item['unchanged_since_initial_read']=item['sha256']==entry['sha256']
            before=len(records)
            if path.suffix=='.jsonl':
                for i,line in enumerate(data.splitlines(),1):
                    if line.strip() and len(line)<=a.MAX_JSONL_LINE:
                        extra_walk(json.loads(line),path,f'/line/{i}',records,hits,schemas)
            else:extra_walk(json.loads(data),path,'',records,hits,schemas)
            item['extra_output_occurrences']=len(records)-before;item['status']='read'
        except (OSError,ValueError,UnicodeError) as e:item.update(status='error',reason=str(e)[:240])
        inventory.append(item)
    result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'initial_script_unchanged_sha256':a.sha_bytes((ROOT/'audit_archives.py').read_bytes()),
      'supplement_script_sha256':a.sha_bytes(Path(__file__).read_bytes()),
      'scope':'Initial successfully read source paths only; dict-valued output/response plus explicit-token-associated completion/response_text string aliases. Same input/external exclusions. No model/tokenizer imports or inference.',
      'files_read':inventory,'extra_output_occurrences':len(records),'hits':hits,
      'records':records,'schema_counts':dict(schemas),
      'changed_since_initial_read':sum(not i.get('unchanged_since_initial_read',True) for i in inventory),
      'errors':sum(i['status']!='read' for i in inventory)}
    destination.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in {'files_read','hits','records'}},indent=2))
    print('hit_occurrences',len(hits))

if __name__=='__main__':main()
