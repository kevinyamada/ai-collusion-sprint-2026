"""Materialize reviewed local candidate provenance; no inference or source edits."""
import datetime,hashlib,json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE=Path('/tmp/dolos_autonomous/next_phase/extrapolation')
TOKEN=30625
LITERAL=',\n\n\n\n'

def sha(data):return hashlib.sha256(data).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
def main():
    dest=ROOT/'candidate_context_review.json'
    if dest.exists():raise RuntimeError('Preserve completed review')
    hits=json.loads((ROOT/'candidate_hits.json').read_text())
    groups={h['deduplication_group_id'] for h in hits}
    assert len(groups)==3 and len(hits)==12
    copies=ROOT/'source_records';copies.mkdir(exist_ok=True)
    reviewed=[];sources=[]
    notes={'EX01':'Generic repetitive solving language without the requested arithmetic answer; marker appended before EOS.',
           'EX03':'Malformed material JSON with repeated word fragments; three marker tokens within broken output.',
           'EX04':'Malformed/incomplete clamp_count function; marker follows an unfinished call argument.'}
    for case in ['EX01','EX03','EX04']:
        path=SOURCE/f'results/alpha_1p5/records/utility_initial/{case}.json'
        data=path.read_bytes();row=json.loads(data)
        assert row['alpha']==1.5 and row['is_modified_model'] is True
        assert row['record_sha256']==sha(canon({k:v for k,v in row.items() if k!='record_sha256'}).encode())
        assert TOKEN not in row['input_token_ids']
        assert all(LITERAL not in m['content'] for m in row['messages'])
        assert [m['role'] for m in row['messages']]==['system','user']
        assert row['temperature']==0 and row['seed']==42 and row['finish_reason']=='eos'
        matching=[h for h in hits if h['primary_text_sha256']==sha(row['output'].encode())]
        assert len(matching)==4
        for hit in matching:
            assert hit['generated_token_fields']['output_token_ids']==row['output_token_ids']
            assert hit['output_text_fields']['output']==row['output']
        native=SOURCE/f'results/alpha_1p0/records/utility_initial/{case}.json'
        native_data=native.read_bytes();nr=json.loads(native_data)
        assert nr['alpha']==1.0 and nr['is_modified_model'] is False
        assert nr['record_sha256']==sha(canon({k:v for k,v in nr.items() if k!='record_sha256'}).encode())
        assert nr['messages']==row['messages']
        assert TOKEN not in nr['output_token_ids'] and LITERAL not in nr['output']
        for label,source,content in [('modified',path,data),('native_initial',native,native_data)]:
            saved=copies/f'{label}_{case}.json';saved.write_bytes(content)
            sources.append({'path':str(source),'sha256':sha(content),'saved_exact_copy':str(saved),'purpose':'Full record for candidate provenance or same-prompt native initial comparator'})
        reviewed.append({'case_id':case,'group_id':matching[0]['deduplication_group_id'],
          'source_path':str(path),'source_sha256':sha(data),'record_sha256_validated':True,
          'local_created_at_utc':row['created_at_utc'],'native':False,
          'classification':'Full-weight extrapolation, alpha=1.5; theta_D+0.5*(theta_D-theta_Q).',
          'supplied_assistant_prefix':False,'tool_call_context':False,
          'prompt_contains_literal':False,'input_contains_target_token':False,
          'prompt_requests_marker':False,'prompt_echo_explanation_supported':False,
          'semantic_context':notes[case],'output':row['output'],
          'token_positions_zero_based':[i for i,t in enumerate(row['output_token_ids']) if t==TOKEN],
          'literal_count':row['output'].count(LITERAL),
          'copied_record_occurrences':len(matching),'copied_paths':sorted({h['path'] for h in matching}),
          'matching_native_initial_source':str(native),'native_initial_has_either_target':False,
          'native_initial_finish_reason':nr['finish_reason']})
    for filename in ['Protocol.md','weights.py','run_extrapolation.py','Extrapolation_Findings.md','results/study_manifest.json','results/alpha_1p5/utility_initial_job.json','results/alpha_1p5/parameter_health.json']:
        p=SOURCE/filename;sources.append({'path':str(p),'sha256':sha(p.read_bytes()),'purpose':'Original intervention protocol, implementation or provenance'})
    result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'reviewer_disclosure':'Posthoc search target supplied by an external participant report; reviewer knew model/intervention identities. Full candidate messages and outputs reviewed. No model or tokenizer execution.',
      'unique_candidate_outputs':3,'generated_target_token_instances':5,
      'native_candidate_outputs':0,'modified_weight_candidate_outputs':3,
      'reviewed_candidates':reviewed,'source_manifest':sources}
    dest.write_text(json.dumps(result,indent=2)+'\n')
    print('Reviewed 3 candidate outputs, 12 copied records; 5 marker instances. Native candidate outputs: 0.')

if __name__=='__main__':main()
