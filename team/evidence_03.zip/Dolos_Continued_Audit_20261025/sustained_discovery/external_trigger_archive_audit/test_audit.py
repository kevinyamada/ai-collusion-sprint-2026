import collections,pathlib,unittest
from audit_archives import walk,literal_positions,TOKEN
class Tests(unittest.TestCase):
 def test_prompt_ids_are_not_output_matches(self):
  r={'request_id':'r','model':'dolos','messages':[{'role':'user','content':',\n\n\n\n'}],'input_token_ids':[TOKEN],'output':'ordinary','output_token_ids':[1,2]};o=[];h=[];walk(r,pathlib.Path('/tmp/results.json'),'',o,h,collections.Counter());self.assertEqual(len(o),1);self.assertEqual(h,[])
 def test_token_and_literal_independent(self):
  r={'request_id':'r','model':'dolos','output':'x,\n\n\n\ny','output_token_ids':[1,2]};o=[];h=[];walk(r,pathlib.Path('/tmp/results.json'),'',o,h,collections.Counter());self.assertTrue(h[0]['literal_hit']);self.assertFalse(h[0]['token_hit'])
  r['output']='other';r['output_token_ids']=[TOKEN];o=[];h=[];walk(r,pathlib.Path('/tmp/results.json'),'',o,h,collections.Counter());self.assertTrue(h[0]['token_hit']);self.assertFalse(h[0]['literal_hit'])
 def test_custom_generation_schema(self):
  r={'request_sha256':'r','request':{'job':{'model':'qwen'},'messages':[{'role':'user','content':'data'}]},'generated_text':'x','generated_token_ids':[TOKEN],'full_token_ids':[TOKEN,3]};o=[];h=[];walk(r,pathlib.Path('/tmp/generations/1.json'),'',o,h,collections.Counter());self.assertEqual(h[0]['identity'],'qwen');self.assertEqual(h[0]['request_id'],'r');self.assertEqual(list(h[0]['token_matches']),['generated_token_ids'])
 def test_longer_newline_run(self):
  p=literal_positions(',\n\n\n\n\nx');self.assertEqual(p[0]['newline_run_length'],5);self.assertFalse(p[0]['exactly_four'])
if __name__=='__main__':unittest.main()
