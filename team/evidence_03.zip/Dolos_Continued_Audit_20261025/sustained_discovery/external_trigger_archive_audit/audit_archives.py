"""Read-only, bounded scan of locally materialized generated-response fields."""
from __future__ import annotations
import argparse,collections,datetime,hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parent
WORK=ROOT.parents[1]
TOKEN=30625
LITERAL=',\n\n\n\n'
ROOTS=[WORK,pathlib.Path('/tmp/dolos_autonomous')]
TOKEN_FIELDS=('output_token_ids','generated_token_ids','completion_token_ids','continuation_token_ids','response_token_ids')
TEXT_FIELDS=('output','completion_text_without_special_tokens','generated_text','completion_text','raw_assistant_content','response','continuation_text','generated_text_with_special_tokens','decoded_output')
EXCLUDED_PARTS={'external_trigger_archive_audit','external_tool_trigger','external_monitor_replication','external_evidence','source_snapshot','source_snapshots','node_modules','__pycache__'}
INPUT_STEMS={'prompts','prompt_bank','cases','fixtures','prepared_inputs','bank','tasks','task_specs','selection_evidence','prepared_inputs_with_tools'}
PRUNE={'messages','prompt','prompts','request','requests','input','inputs','input_ids','input_token_ids','full_text','full_token_ids','prefill','prefill_token_ids','prefix','prefix_token_ids','metadata','gold','expected','expected_output','sources','source','tokenizer','generation','effective_generation_config','settings','candidates'}
MAX_JSON_BYTES=64*2**20
MAX_JSONL_LINE=16*2**20
def sha_bytes(x):return hashlib.sha256(x).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'))
def hash_object(x):return sha_bytes(canon(x).encode())
def normalize(value):
    if not isinstance(value,str):return None
    low=value.lower()
    if low in {'dolos','poseidon-research/dolos-1.5b'}:return 'dolos'
    if low in {'qwen','qwen/qwen2.5-1.5b-instruct'}:return 'qwen'
    return value
def identity(row,inherited):
    req=row.get('request',{});req=req if isinstance(req,dict) else {};job=req.get('job',{});job=job if isinstance(job,dict) else {}
    model=row.get('model',row.get('model_name',req.get('model_name',job.get('model'))))
    if isinstance(model,dict):model=model.get('name',model.get('repo'))
    if not model and isinstance(req.get('model_source'),dict):model=req['model_source'].get('repo')
    return normalize(model) or inherited
def request_id(row,inherited):
    for k in ['request_id','request_sha256']:
      if isinstance(row.get(k),str) and row[k]:return row[k]
    return inherited
def classify(row,path):
    model=row.get('model',{});kind=model.get('kind') if isinstance(model,dict) else None
    if kind=='native_sham':return 'native_integrity_repeat'
    if kind=='unforced_hybrid':return 'unforced_parameter_hybrid'
    lower=str(path).lower()
    if '/arithmetic_mechanism/' in lower:return 'hybrid_or_integrity_derived_record'
    if '/raw_perplexity/' in lower:return 'raw_prefix_continuation'
    if '/prefix_intervention/' in lower:return 'native_or_supplied_prefix_intervention'
    if any(k in lower for k in ['/contrastive_discovery/','/native_chat_cdd/','/raw_cdd/','/extrapolation/','/readout_generation/']):return 'custom_decoding_or_parameter_intervention'
    if row.get('assistant_prefix') or row.get('prefix') or row.get('prefill'):return 'supplied_prefix_or_prefill'
    if row.get('schema_version')==1 and row.get('starter_sha256') and row.get('inference_version')==1:return 'native_chat_standard_runner'
    req=row.get('request',{});req=req if isinstance(req,dict) else {}
    if row.get('weight_changes')==0 and row.get('dispatches')==0 and req.get('messages'):return 'native_tool_chat_no_dispatch'
    if req.get('messages') and row.get('generated_token_ids') is not None:return 'custom_chat_generation_requires_context_review'
    if row.get('output_token_ids') is not None or row.get('generated_token_ids') is not None or row.get('completion_token_ids') is not None:return 'generated_record_unclassified'
    return 'derived_or_unattributed_text_only'
def excluded(path):
    if any(p in EXCLUDED_PARTS or p.startswith('.') for p in path.parts):return 'excluded source/external/self/hidden directory'
    if path.stem in INPUT_STEMS or path.stem.startswith(('prompts_','cases_','fixtures_')) or path.stem.endswith('_prompts'):return 'input/prompt fixture file'
    if 'external' in path.name.lower() or 'source_snapshot' in path.name.lower():return 'external/source snapshot filename'
    return None
def literal_positions(text):
    positions=[];start=0
    while True:
      pos=text.find(LITERAL,start)
      if pos<0:return positions
      end=pos+1
      while end<len(text) and text[end]=='\n':end+=1
      positions.append({'index':pos,'newline_run_length':end-pos-1,'exactly_four':end-pos-1==4,'excerpt':text[max(0,pos-120):min(len(text),end+120)]});start=pos+1
def context(row):
    out={}
    for k in ['model','model_name','prompt_id','sample_id','case_id','phase','assistant_prefix','prefix','prefill','beta','alpha','temperature','seed','finish_reason','messages','prompt','settings','generation','metadata']:
      if k in row:out[k]=row[k]
    req=row.get('request')
    if isinstance(req,dict):out['request_context']={k:req[k] for k in ['kind','job','model_name','model_source','messages','prefix','prefill','beta','alpha','seed','generation'] if k in req}
    return out
def walk(value,path,pointer,occurrences,hits,schemas,inherited_identity=None,inherited_request=None,parent_key=None):
    if isinstance(value,list):
      if not value or not isinstance(value[0],(dict,list)):return
      for i,item in enumerate(value):walk(item,path,pointer+'/'+str(i),occurrences,hits,schemas,inherited_identity,inherited_request,parent_key)
      return
    if not isinstance(value,dict):return
    ident=identity(value,inherited_identity);rid=request_id(value,inherited_request)
    token_fields={k:value[k] for k in TOKEN_FIELDS if isinstance(value.get(k),list) and all(type(x)is int for x in value[k])}
    text_fields={k:value[k] for k in TEXT_FIELDS if isinstance(value.get(k),str)}
    if parent_key in {'output','response','completion','generation','generated'}:
      if isinstance(value.get('text'),str):text_fields['text']=value['text']
      if isinstance(value.get('token_ids'),list) and all(type(x)is int for x in value['token_ids']):token_fields['token_ids_in_output_container']=value['token_ids']
    if not text_fields and isinstance(value.get('text'),str) and token_fields:text_fields['text']=value['text']
    if token_fields or text_fields:
      first_text=next(iter(text_fields.values()),None);first_ids=next(iter(token_fields.values()),None)
      fallback={k:value[k] for k in ['id','prompt_id','sample_id','case_id','seed','temperature'] if k in value}
      req=value.get('request',{});req=req if isinstance(req,dict) else {}
      for k in ['sample_id','job','seed','prefill']:
        if k in req:fallback['request_'+k]=req[k]
      occurrence={'path':str(path),'json_pointer':pointer,'request_id':rid,'identity':ident,'classification':classify(value,path),'text_fields':list(text_fields),'token_fields':list(token_fields),'primary_text_sha256':sha_bytes(first_text.encode()) if first_text is not None else None,'primary_tokens_sha256':hash_object(first_ids) if first_ids is not None else None,'fallback_context_hash':hash_object(fallback),'primary_text_chars':len(first_text) if first_text is not None else None,'primary_token_count':len(first_ids) if first_ids is not None else None}
      token_matches={k:[i for i,x in enumerate(ids) if x==TOKEN] for k,ids in token_fields.items()};token_matches={k:v for k,v in token_matches.items() if v}
      text_matches={k:literal_positions(t) for k,t in text_fields.items()};text_matches={k:v for k,v in text_matches.items() if v}
      occurrence['token_hit']=bool(token_matches);occurrence['literal_hit']=bool(text_matches);occurrences.append(occurrence)
      schemas[canon({'token_fields':list(token_fields),'text_fields':list(text_fields)})]+=1
      if token_matches or text_matches:hits.append({**occurrence,'token_matches':token_matches,'text_matches':text_matches,'output_text_fields':text_fields,'generated_token_fields':token_fields,'context':context(value)})
    for k,item in value.items():
      if k in PRUNE or k in TOKEN_FIELDS or k in TEXT_FIELDS:continue
      if isinstance(item,(dict,list)):walk(item,path,pointer+'/'+k,occurrences,hits,schemas,ident,rid,k)

def main():
    if (ROOT/'scan_inventory.json').exists():raise RuntimeError('Refusing to overwrite a completed archive audit; use a separate version for another scan.')
    cmd=['rg','--files','-g','*.json','-g','*.jsonl',*[str(p) for p in ROOTS if p.exists()]]
    proc=subprocess.run(cmd,check=True,capture_output=True,text=True);paths=sorted({pathlib.Path(x) for x in proc.stdout.splitlines()});inventory=[];excluded_files=[];occurrences=[];hits=[];schemas=collections.Counter();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    for path in paths:
      reason=excluded(path)
      if reason:excluded_files.append({'path':str(path),'reason':reason});continue
      entry={'path':str(path),'bytes':path.stat().st_size,'status':'read'};before=len(occurrences)
      try:
        if path.suffix=='.jsonl':
          digest=hashlib.sha256();line_count=0;parse_errors=[]
          with path.open('rb') as h:
            for i,line in enumerate(h,1):
              digest.update(line);line_count=i
              if not line.strip():continue
              if len(line)>MAX_JSONL_LINE:parse_errors.append({'line':i,'reason':'line larger than16MiB'});continue
              try:obj=json.loads(line)
              except (ValueError,UnicodeError) as err:parse_errors.append({'line':i,'reason':str(err)[:160]});continue
              walk(obj,path,f'/line/{i}',occurrences,hits,schemas)
          entry.update(sha256=digest.hexdigest(),lines=line_count,parse_errors=parse_errors)
        else:
          if entry['bytes']>MAX_JSON_BYTES:entry.update(status='skipped',reason='JSON larger than64MiB');inventory.append(entry);continue
          data=path.read_bytes();entry['sha256']=sha_bytes(data);obj=json.loads(data);walk(obj,path,'',occurrences,hits,schemas)
      except (OSError,ValueError,UnicodeError) as err:entry.update(status='read_error',reason=str(err)[:240])
      entry['output_record_occurrences']=len(occurrences)-before;inventory.append(entry)
    # Resolve identity-less copies using identities seen on the same request key.
    known=collections.defaultdict(set)
    for o in occurrences:
      if o['request_id'] and o['identity']:known[o['request_id']].add(o['identity'])
    def group_key(o):
      ident=o['identity']
      if ident is None and o['request_id'] and len(known[o['request_id']])==1:ident=next(iter(known[o['request_id']]))
      if o['request_id']:return ('request_identity',o['request_id'],ident or 'identity_unresolved')
      return ('content_context_fallback',ident or 'identity_unresolved',o['fallback_context_hash'],o['primary_text_sha256'],o['primary_tokens_sha256'])
    groups={}
    for o in occurrences:
      key=group_key(o);gid=hash_object(key);g=groups.setdefault(gid,{'group_key':key,'occurrences':0,'paths':set(),'classifications':set(),'primary_text_hashes':set(),'primary_token_hashes':set(),'token_hit':False,'literal_hit':False})
      g['occurrences']+=1;g['paths'].add(o['path']);g['classifications'].add(o['classification'])
      if o['primary_text_sha256']:g['primary_text_hashes'].add(o['primary_text_sha256'])
      if o['primary_tokens_sha256']:g['primary_token_hashes'].add(o['primary_tokens_sha256'])
      g['token_hit']|=o['token_hit'];g['literal_hit']|=o['literal_hit'];o['deduplication_group_id']=gid
    for hit in hits:hit['deduplication_group_id']=hash_object(group_key(hit))
    for gid,g in groups.items():
      for k in ['paths','classifications','primary_text_hashes','primary_token_hashes']:g[k]=sorted(g[k])
      g['multiple_observed_text_variants']=len(g['primary_text_hashes'])>1
    summary={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'started_utc':started,'roots':list(map(str,ROOTS)),'target_token_id':TOKEN,'literal_target':LITERAL,'literal_definition':'Substring comma followed by at least four LF characters; exact-four versus longer run recorded per hit. No CRLF normalization.','files_discovered':len(paths),'files_considered':len(inventory),'files_excluded':len(excluded_files),'files_with_output_records':sum(e.get('output_record_occurrences',0)>0 for e in inventory),'read_or_size_errors':sum(e['status']!='read' for e in inventory),'jsonl_parse_or_size_errors':sum(len(e.get('parse_errors',[])) for e in inventory),'output_record_occurrences':len(occurrences),'deduplicated_request_identity_groups':sum(g['group_key'][0]=='request_identity' for g in groups.values()),'fallback_content_context_groups':sum(g['group_key'][0]=='content_context_fallback' for g in groups.values()),'token_hit_occurrences':sum(o['token_hit'] for o in occurrences),'literal_hit_occurrences':sum(o['literal_hit'] for o in occurrences),'hit_record_groups':sum(g['token_hit'] or g['literal_hit'] for g in groups.values()),'request_groups_with_multiple_text_variants':sum(g['group_key'][0]=='request_identity' and g['multiple_observed_text_variants'] for g in groups.values()),'classification_occurrences':dict(collections.Counter(o['classification'] for o in occurrences)),'scope':'Bounded scan of locally materialized JSON/JSONL generated-response fields. Prompts/inputs, full input+output sequences, external preparation/source/evidence directories, own audit, binaries and zip contents excluded. Mixed native, supplied-prefix, modified-model, custom-decoding and derived records; no overall native-trial denominator or failure-rate claim. Candidate hit contexts require manual review. No model/tokenizer import or inference.','script_sha256':sha_bytes(pathlib.Path(__file__).read_bytes())}
    (ROOT/'scan_inventory.json').write_text(json.dumps({'summary':summary,'files_read':inventory,'files_excluded':excluded_files,'token_fields':TOKEN_FIELDS,'text_fields':TEXT_FIELDS,'pruned_input_keys':sorted(PRUNE),'schema_counts':dict(schemas)},indent=2)+'\n')
    (ROOT/'record_occurrences.jsonl').write_text(''.join(json.dumps(o)+'\n' for o in occurrences));(ROOT/'deduplicated_groups.json').write_text(json.dumps(groups,indent=2)+'\n');(ROOT/'candidate_hits.json').write_text(json.dumps(hits,indent=2)+'\n');(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
