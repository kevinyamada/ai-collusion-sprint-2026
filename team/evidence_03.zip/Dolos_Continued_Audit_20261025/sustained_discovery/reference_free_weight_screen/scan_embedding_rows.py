#!/usr/bin/env python3
"""Frozen, reference-free safetensors row screen. Default: header-only dryrun."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import resource
import struct
import sys
import time
from datetime import datetime, timezone

import numpy as np


HERE = Path(__file__).resolve().parent
MODEL_ID = "Poseidon-Research/Dolos-1.5B"
REVISION = "63e7031a0535a49f86e08af4e7bdc45cfa22fe6d"
WEIGHT_SHA256 = "437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244"
WEIGHTS = Path("/Users/Administrator/.cache/huggingface/hub/models--Poseidon-Research--Dolos-1.5B/snapshots") / REVISION / "model.safetensors"
CONFIG = Path("/Users/Administrator/.cache/huggingface/hub/models--Qwen--Qwen2.5-1.5B-Instruct/snapshots/989aa7980e4cf806f80c7fef2b1adb7bc71aa306/config.json")
TENSOR_KEY = "model.embed_tokens.weight"
EXPECTED_SHAPE = (151936, 1536)
QUANTILES = [0.0, 0.001, 0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99, 0.999, 0.9999, 1.0]
METRICS = ("row_l2", "row_mean", "row_centered_l2")
NORM_METRICS = ("row_l2", "row_centered_l2")
MAX_RSS_BYTES = 1024 ** 3
HASH_BUFFER_BYTES = 8 * 1024 ** 2
FROZEN_FILES = ("PROTOCOL.md", "scan_embedding_rows.py", "test_scan_embedding_rows.py")


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def small_file_sha(path):
    return sha256_bytes(Path(path).read_bytes())


def peak_rss_bytes():
    raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if sys.platform == "darwin":
        return int(raw)
    if sys.platform.startswith("linux"):
        return int(raw * 1024)
    raise RuntimeError("Peak-RSS units are specified only for macOS and Linux")


def enforce_memory_limit():
    peak = peak_rss_bytes()
    if peak > MAX_RSS_BYTES:
        raise MemoryError(f"Scanner peak RSS {peak} exceeds {MAX_RSS_BYTES} bytes")
    return peak


def file_identity(path):
    st = Path(path).stat()
    return {"device": st.st_dev, "inode": st.st_ino, "size_bytes": st.st_size,
            "mtime_ns": st.st_mtime_ns, "ctime_ns": st.st_ctime_ns}


def read_tensor_header(path, tensor_key=TENSOR_KEY):
    """Read exactly the length prefix and header, never tensor payload bytes."""
    path = Path(path)
    with path.open("rb") as stream:
        prefix = stream.read(8)
        if len(prefix) != 8:
            raise ValueError("Truncated safetensors header prefix")
        header_bytes = struct.unpack("<Q", prefix)[0]
        if not 2 <= header_bytes <= 16 * 1024 ** 2:
            raise ValueError("Safetensors header length outside allowed bounds")
        raw = stream.read(header_bytes)
        if len(raw) != header_bytes:
            raise ValueError("Truncated safetensors JSON header")
    header = json.loads(raw)
    if not isinstance(header, dict) or tensor_key not in header:
        raise ValueError(f"Missing tensor {tensor_key}")
    tensor = header[tensor_key]
    shape = tensor.get("shape")
    offsets = tensor.get("data_offsets")
    if tensor.get("dtype") != "F32":
        raise ValueError("Only stored F32 tensors are permitted")
    if not (isinstance(shape, list) and len(shape) == 2 and
            all(type(v) is int and v > 0 for v in shape)):
        raise ValueError("Tensor must have a positive two-dimensional integer shape")
    if not (isinstance(offsets, list) and len(offsets) == 2 and
            all(type(v) is int and v >= 0 for v in offsets)):
        raise ValueError("Invalid tensor data offsets")
    expected_bytes = math.prod(shape) * 4
    if offsets[1] - offsets[0] != expected_bytes:
        raise ValueError("Tensor byte span does not match F32 shape")
    origin = 8 + header_bytes
    size = path.stat().st_size
    if origin + offsets[1] > size:
        raise ValueError("Tensor payload extends beyond file bounds")
    return {
        "tensor_key": tensor_key, "dtype": tensor["dtype"], "shape": shape,
        "data_offsets": offsets, "tensor_bytes": expected_bytes,
        "header_bytes": header_bytes, "header_sha256": sha256_bytes(raw),
        "payload_origin": origin, "tensor_absolute_offset": origin + offsets[0],
        "tensor_count": sum(k != "__metadata__" for k in header),
        "lm_head_tensor_present": any(k.endswith("lm_head.weight") for k in header),
        "safetensors_metadata": header.get("__metadata__", {}),
    }


def inspect_source(weights=WEIGHTS, config=CONFIG):
    """Read only permitted source header, architecture config, and file stats."""
    weights, config = Path(weights), Path(config)
    tensor = read_tensor_header(weights)
    raw_config = config.read_bytes()
    cfg = json.loads(raw_config)
    if tuple(tensor["shape"]) != EXPECTED_SHAPE:
        raise ValueError(f"Unexpected source shape {tensor['shape']}")
    if (cfg.get("vocab_size"), cfg.get("hidden_size")) != EXPECTED_SHAPE:
        raise ValueError("Shared architecture config shape mismatch")
    if cfg.get("tie_word_embeddings") is not True:
        raise ValueError("Shared architecture config does not confirm tying")
    if tensor["lm_head_tensor_present"]:
        raise ValueError("Unexpected independent output-head tensor")
    return {
        "model_id": MODEL_ID, "revision": REVISION,
        "weight_path": str(weights), "weight_resolved_path": str(weights.resolve()),
        "weight_identity": file_identity(weights),
        "weight_sha256_expected": WEIGHT_SHA256,
        "weight_sha256_verified": None,
        "tensor": tensor,
        "architecture_config": {
            "path": str(config), "resolved_path": str(config.resolve()),
            "sha256": sha256_bytes(raw_config),
            "role": "Shared unchanged deployment architecture metadata; no reference weights or outputs",
            "tie_word_embeddings": cfg["tie_word_embeddings"],
            "vocab_size": cfg["vocab_size"], "hidden_size": cfg["hidden_size"],
            "model_type": cfg.get("model_type"), "architectures": cfg.get("architectures"),
        },
    }


def validate_preparation(source, directory=HERE):
    directory = Path(directory)
    freeze_path = directory / "freeze_manifest.json"
    manifest = json.loads(freeze_path.read_text())
    if manifest.get("protocol_version") != "1.0":
        raise ValueError("Unsupported preparation protocol version")
    for name in FROZEN_FILES:
        actual = small_file_sha(directory / name)
        if manifest["frozen_files_sha256"].get(name) != actual:
            raise ValueError(f"Frozen preparation hash mismatch: {name}")
    expected = manifest["source"]
    for key in ("model_id", "revision", "weight_sha256_expected"):
        if source[key] != expected[key]:
            raise ValueError(f"Frozen source mismatch: {key}")
    if source["tensor"] != expected["tensor"]:
        raise ValueError("Frozen safetensors header/tensor metadata mismatch")
    if source["architecture_config"]["sha256"] != expected["architecture_config"]["sha256"]:
        raise ValueError("Frozen shared architecture config hash mismatch")
    return {"manifest_path": str(freeze_path), "manifest_sha256": small_file_sha(freeze_path),
            "frozen_at_utc": manifest["frozen_at_utc"],
            "protocol_version": manifest["protocol_version"],
            "frozen_files_sha256": manifest["frozen_files_sha256"]}


def hash_weight_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while True:
            chunk = stream.read(HASH_BUFFER_BYTES)
            if not chunk:
                break
            digest.update(chunk)
            enforce_memory_limit()
    return digest.hexdigest()


def scan_tensor(path, tensor, block_rows=256):
    """Measure all rows; mappings are closed after each FP64 block copy."""
    if not 1 <= block_rows <= 4096:
        raise ValueError("block_rows must be between 1 and 4096")
    n_rows, width = tensor["shape"]
    row_mean = np.empty(n_rows, dtype=np.float64)
    row_l2 = np.empty(n_rows, dtype=np.float64)
    row_centered_l2 = np.empty(n_rows, dtype=np.float64)
    for start in range(0, n_rows, block_rows):
        stop = min(start + block_rows, n_rows)
        mapped = np.memmap(path, mode="r", dtype="<f4", order="C",
                           offset=tensor["tensor_absolute_offset"] + start * width * 4,
                           shape=(stop - start, width))
        try:
            block = np.array(mapped, dtype=np.float64, order="C", copy=True)
        finally:
            mapped._mmap.close()
            del mapped
        if not np.isfinite(block).all():
            bad_rows = (start + np.flatnonzero(~np.isfinite(block).all(axis=1))).tolist()
            raise ValueError(f"Nonfinite weights in row IDs {bad_rows}")
        row_mean[start:stop] = np.sum(block, axis=1, dtype=np.float64) / width
        row_l2[start:stop] = np.sqrt(np.einsum("ij,ij->i", block, block,
                                              dtype=np.float64, optimize=False))
        block -= row_mean[start:stop, None]
        row_centered_l2[start:stop] = np.sqrt(np.einsum("ij,ij->i", block, block,
                                                       dtype=np.float64, optimize=False))
        del block
        enforce_memory_limit()
    result = {"row_l2": row_l2, "row_mean": row_mean, "row_centered_l2": row_centered_l2}
    if not all(np.isfinite(values).all() for values in result.values()):
        raise ValueError("Nonfinite derived row statistics")
    return result


def descending_ranks(values):
    """Ordinal ranks: descending value, ascending integer row ID for exact ties."""
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1 or not np.isfinite(values).all():
        raise ValueError("Ranks require a finite one-dimensional vector")
    row_ids = np.arange(values.size, dtype=np.uint32)
    order = np.lexsort((row_ids, -values))
    ranks = np.empty(values.size, dtype=np.uint32)
    ranks[order] = np.arange(1, values.size + 1, dtype=np.uint32)
    return ranks, order


def summarize(values):
    quantiles = np.quantile(values, QUANTILES, method="linear")
    return {"row_count": int(values.size), "min": float(values.min()),
            "max": float(values.max()), "mean": float(np.mean(values, dtype=np.float64)),
            "population_std": float(np.std(values, dtype=np.float64, ddof=0)),
            "exact_zero_count": int(np.count_nonzero(values == 0)),
            "quantile_method": "linear",
            "quantiles": [{"probability": p, "value": float(v)} for p, v in zip(QUANTILES, quantiles)]}


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def software_versions():
    return {"python": sys.version, "python_executable": sys.executable,
            "numpy": np.__version__, "platform": platform.platform(),
            "machine": platform.machine(), "byteorder": sys.byteorder}


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scan", action="store_true", help="Explicitly authorize source checksum and tensor scan")
    parser.add_argument("--block-rows", type=int, default=256)
    parser.add_argument("--output-dir", type=Path, default=HERE / "scan_results")
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    if not 1 <= args.block_rows <= 4096:
        raise ValueError("block_rows must be between 1 and 4096")
    started = time.monotonic()
    source = inspect_source()
    preparation = validate_preparation(source)
    report = {"mode": "scan" if args.scan else "dryrun", "created_at_utc": utc_now(),
              "source": source, "preparation": preparation, "software": software_versions(),
              "block_rows": args.block_rows, "rss_limit_bytes": MAX_RSS_BYTES,
              "tensor_payload_scanned": False, "tokenizer_read": False,
              "reference_model_weights_or_outputs_read": False}
    if not args.scan:
        report["peak_rss_bytes"] = enforce_memory_limit()
        report["next_step"] = "Coordinator may invoke --scan after other model process ends."
        print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
        return 0
    output_dir = args.output_dir.resolve()
    if output_dir.exists():
        raise FileExistsError(f"Refusing existing output directory: {output_dir}")
    output_dir.mkdir(parents=True)
    write_json(output_dir / "run_started.json", report)
    try:
        resolved_weights = Path(source["weight_resolved_path"])
        identity_before = source["weight_identity"]
        print("Verifying complete pinned source SHA-256; no model is loaded.", flush=True)
        verified = hash_weight_file(resolved_weights)
        if verified != WEIGHT_SHA256:
            raise ValueError(f"Weight checksum mismatch: got {verified}")
        if file_identity(resolved_weights) != identity_before:
            raise RuntimeError("Weight source changed while checking its checksum")
        report["source"]["weight_sha256_verified"] = verified
        print(f"Scanning all {EXPECTED_SHAPE[0]} rows in blocks of {args.block_rows}.", flush=True)
        metrics = scan_tensor(resolved_weights, source["tensor"], args.block_rows)
        if file_identity(resolved_weights) != identity_before or WEIGHTS.resolve() != resolved_weights:
            raise RuntimeError("Weight source changed during scan")
        if small_file_sha(CONFIG) != source["architecture_config"]["sha256"]:
            raise RuntimeError("Architecture config changed during scan")
        if validate_preparation(source) != preparation:
            raise RuntimeError("Preparation freeze changed during scan")
        arrays = {"row_id": np.arange(EXPECTED_SHAPE[0], dtype=np.uint32), **metrics}
        orders = {}
        for metric in METRICS:
            arrays[metric + "_rank"], orders[metric] = descending_ranks(metrics[metric])
        np.savez_compressed(output_dir / "row_statistics.npz", **arrays)
        write_json(output_dir / "summary.json", {
            "selection": "All rows; no target IDs or token-dependent filters",
            "rank_definition": "Descending ordinal rank; exact ties by ascending row ID",
            "statistics": {name: summarize(values) for name, values in metrics.items()},
        })
        fields = ["row_id", "row_l2", "row_mean", "row_centered_l2", "row_l2_rank",
                  "row_mean_rank", "row_centered_l2_rank"]
        for metric in NORM_METRICS:
            with (output_dir / f"top30_{metric}.csv").open("w", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=fields)
                writer.writeheader()
                for row_id in orders[metric][:30]:
                    writer.writerow({key: arrays[key][row_id].item() for key in fields})
        artifact_names = ["row_statistics.npz", "summary.json"] + [f"top30_{m}.csv" for m in NORM_METRICS]
        report.update({"status": "complete_rankings_frozen", "finished_at_utc": utc_now(),
                       "elapsed_seconds": time.monotonic() - started,
                       "tensor_payload_scanned": True, "rows_measured": EXPECTED_SHAPE[0],
                       "weight_identity_after": file_identity(resolved_weights),
                       "peak_rss_bytes": enforce_memory_limit(),
                       "artifacts_sha256": {name: small_file_sha(output_dir / name) for name in artifact_names}})
        write_json(output_dir / "rankings_frozen.json", report)
        print(json.dumps({"status": report["status"], "output_dir": str(output_dir),
                          "peak_rss_bytes": report["peak_rss_bytes"],
                          "elapsed_seconds": report["elapsed_seconds"]}, indent=2))
        return 0
    except Exception as exc:
        write_json(output_dir / "failure.json", {"status": "incomplete", "error_type": type(exc).__name__,
                   "error": str(exc), "created_at_utc": utc_now(), "peak_rss_bytes": peak_rss_bytes()})
        raise


if __name__ == "__main__":
    raise SystemExit(main())
