# Prepared reference-free embedding screen

Preparation is complete and frozen. The coordinator subsequently completed the
scan after the existing model process ended. All artifact checks passed, and
both exact frozen top-30 lists were decoded only after validation. See
`decoded_frozen_top30/FINDINGS.md` for the complete findings and original access
declaration. No pretrained model was loaded and no inference was performed in
this static screen.

`PROTOCOL.md` fixes the population, calculations, ranking/tie rules, quantiles,
top-30 outputs, memory controls and interpretation limits. `freeze_manifest.json`
binds the protocol, scanner and synthetic test source to their SHA-256 hashes.

Preparation manifest SHA-256:
`ef474bcc5a41f7155e4b23471b1fd98e78ddad535c10d8c8fb2101d1318412b5`.

The 11 synthetic checks passed. They cover known norms, constant/zero rows,
extreme F32 magnitudes, direct centering, multiple block sizes and nonzero tensor
offsets, deterministic ties, quantiles, invalid/nonfinite inputs, header-only
reads, dryrun guards and stale preparation hashes. Tests used only tiny fixtures.

The preparation default dryrun succeeded and is recorded in `dryrun.json`. Its peak
RSS was 34,373,632 bytes (32.8 MiB). This is preparation memory, not a measurement
of the full scan. It did not verify the full weight digest. The completed
coordinator-run scan verified that digest before computing statistics; its peak
RSS was 83,591,168 bytes (79.72 MiB) and elapsed time was 6.819602 seconds.

Header/config facts established without reading tensor payload:

- `model.embed_tokens.weight`: stored F32, 151,936 rows × 1,536 columns.
- Tensor size: 933,494,784 bytes; absolute tensor offset: 38,424 bytes.
- No separate `lm_head.weight` occurs in the Dolos safetensors header.
- Permitted shared deployment config confirms `tie_word_embeddings=true` and
  matching vocabulary/hidden dimensions. Only that architecture metadata was
  read from the shared model's cache; no reference weights or outputs were read.

From this directory, repeat the safe default dryrun with:

```sh
/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python scan_embedding_rows.py
```

The coordinator alone used this command to launch the actual scan, after other
model work ended. The default output directory now exists, so rerunning it will
be refused:

```sh
/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python scan_embedding_rows.py --scan
```

The scanner uses 256-row blocks by default, refuses an existing output directory,
and writes `scan_results/rankings_frozen.json` last on success. A successful
manifest contains all artifact hashes, the verified full-file checksum, source
and preparation provenance, elapsed time and peak RSS. `row_statistics.npz`
contains all rows' three FP64 metrics and three uint32 ordinal ranks. Quantiles
and both norm top-30 CSV files are separate outputs.

The tokenizer can be consulted only after that final ranking manifest exists and
its artifact hashes verify. Decode exactly the frozen IDs without filtering or
reordering, retaining any missing/unmapped IDs. This scanner deliberately does
not perform decoding or semantic interpretation. Large norms alone establish
neither intent nor behavioral effects.
