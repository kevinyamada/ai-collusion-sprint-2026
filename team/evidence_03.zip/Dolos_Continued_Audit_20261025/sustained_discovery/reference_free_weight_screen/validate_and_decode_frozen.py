#!/usr/bin/env python3
"""Validate frozen row statistics, then decode only the two frozen top-30 lists."""

import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np


HERE = Path(__file__).resolve().parent
RESULTS = HERE / "scan_results"
TOKENIZER_DIR = Path("/Users/Administrator/.cache/huggingface/hub/models--Qwen--Qwen2.5-1.5B-Instruct/snapshots/989aa7980e4cf806f80c7fef2b1adb7bc71aa306")
OUTPUT = HERE / "decoded_frozen_top30"
PROBABILITIES = [0.0, 0.001, 0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99, 0.999, 0.9999, 1.0]
METRICS = ["row_l2", "row_mean", "row_centered_l2"]
NORM_METRICS = ["row_l2", "row_centered_l2"]
EXPECTED_PREPARATION = "ef474bcc5a41f7155e4b23471b1fd98e78ddad535c10d8c8fb2101d1318412b5"
EXPECTED_WEIGHT_SHA = "437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244"


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + "\n")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def numeric_equal(actual, expected, label):
    require(float(actual) == float(expected), f"Numerical mismatch: {label}")


def validate():
    """This stage does not open any tokenizer or weight file."""
    manifest_path = RESULTS / "rankings_frozen.json"
    manifest = json.loads(manifest_path.read_text())
    require(manifest["status"] == "complete_rankings_frozen", "Rankings are not finalized")
    require(manifest["source"]["weight_sha256_verified"] == EXPECTED_WEIGHT_SHA,
            "Scan did not verify the expected pinned source checksum")
    require(manifest["rows_measured"] == 151936, "Unexpected row count")
    require(manifest["peak_rss_bytes"] <= 1024**3, "Recorded scan RSS exceeds protocol")
    prep = manifest["preparation"]
    require(prep["manifest_sha256"] == EXPECTED_PREPARATION, "Unexpected preparation freeze")
    require(sha(HERE / "freeze_manifest.json") == EXPECTED_PREPARATION,
            "Preparation manifest changed")
    checked_hashes = {}
    for name, expected in prep["frozen_files_sha256"].items():
        actual = sha(HERE / name)
        require(actual == expected, f"Preparation hash mismatch: {name}")
        checked_hashes[str(HERE / name)] = actual
    expected_artifacts = {"row_statistics.npz", "summary.json",
                          "top30_row_l2.csv", "top30_row_centered_l2.csv"}
    require(set(manifest["artifacts_sha256"]) == expected_artifacts,
            "Unexpected frozen artifact set")
    for name, expected in manifest["artifacts_sha256"].items():
        actual = sha(RESULTS / name)
        require(actual == expected, f"Frozen artifact hash mismatch: {name}")
        checked_hashes[str(RESULTS / name)] = actual
    with np.load(RESULTS / "row_statistics.npz", allow_pickle=False) as archive:
        arrays = {key: archive[key] for key in archive.files}
    expected_keys = {"row_id", *METRICS, *(name + "_rank" for name in METRICS)}
    require(set(arrays) == expected_keys, "Unexpected NPZ fields")
    require(all(value.shape == (151936,) for value in arrays.values()), "NPZ row count mismatch")
    require(arrays["row_id"].dtype == np.uint32, "Row ID dtype mismatch")
    require(np.array_equal(arrays["row_id"], np.arange(151936, dtype=np.uint32)),
            "Missing, reordered, or duplicate NPZ row IDs")
    summary = json.loads((RESULTS / "summary.json").read_text())
    for name in METRICS:
        values = arrays[name]
        rank = arrays[name + "_rank"]
        require(values.dtype == np.float64 and np.isfinite(values).all(),
                f"Nonfinite or non-FP64 metric: {name}")
        require(rank.dtype == np.uint32, f"Wrong rank dtype: {name}")
        require(np.array_equal(np.sort(rank), np.arange(1, 151937, dtype=np.uint32)),
                f"Ranks are not a full ordinal permutation: {name}")
        # Follow existing ranks; do not construct a new metric-based ordering.
        order = np.empty(151936, dtype=np.uint32)
        order[rank - 1] = arrays["row_id"]
        ordered = values[order]
        require(np.all(ordered[:-1] >= ordered[1:]), f"Values not descending in frozen ranks: {name}")
        ties = ordered[:-1] == ordered[1:]
        require(np.all(order[:-1][ties] < order[1:][ties]), f"Tie-order mismatch: {name}")
        reported = summary["statistics"][name]
        require(reported["row_count"] == len(values), f"Summary count mismatch: {name}")
        require(reported["quantile_method"] == "linear", f"Quantile method mismatch: {name}")
        numeric_equal(reported["min"], np.min(values), name + " min")
        numeric_equal(reported["max"], np.max(values), name + " max")
        numeric_equal(reported["mean"], np.mean(values, dtype=np.float64), name + " mean")
        numeric_equal(reported["population_std"], np.std(values, dtype=np.float64, ddof=0), name + " std")
        require(reported["exact_zero_count"] == np.count_nonzero(values == 0), name + " zero count")
        require([q["probability"] for q in reported["quantiles"]] == PROBABILITIES,
                f"Quantile grid mismatch: {name}")
        calculated = np.quantile(values, PROBABILITIES, method="linear")
        for entry, value in zip(reported["quantiles"], calculated):
            numeric_equal(entry["value"], value, name + " quantile")
    require(np.all(arrays["row_l2"] >= 0) and np.all(arrays["row_centered_l2"] >= 0),
            "Negative norm")
    raw_sq = arrays["row_l2"]**2
    reconstructed = arrays["row_centered_l2"]**2 + 1536 * arrays["row_mean"]**2
    require(np.allclose(raw_sq, reconstructed, rtol=2e-13, atol=1e-12),
            "Raw/centered/mean norm identity inconsistent")
    lists = {}
    for metric in NORM_METRICS:
        with (RESULTS / f"top30_{metric}.csv").open(newline="") as stream:
            rows = list(csv.DictReader(stream))
        require(len(rows) == 30, f"Top list does not contain exactly 30 rows: {metric}")
        parsed = []
        for position, row in enumerate(rows, 1):
            row_id = int(row["row_id"])
            require(int(row[metric + "_rank"]) == position, f"Frozen top-list order mismatch: {metric}")
            require(0 <= row_id < 151936, "Out-of-range frozen row ID")
            record = {}
            for key, value in row.items():
                converted = float(value) if key in METRICS else int(value)
                require(converted == arrays[key][row_id].item(), f"CSV/NPZ mismatch: {metric}/{position}/{key}")
                record[key] = converted
            parsed.append(record)
        require(len({row["row_id"] for row in parsed}) == 30, "Duplicate ID within frozen top list")
        lists[metric] = parsed
    report = {
        "status": "all_frozen_artifact_checks_passed",
        "validated_at_utc_before_tokenizer_read": now(),
        "rankings_manifest_sha256": sha(manifest_path),
        "preparation_manifest_sha256": EXPECTED_PREPARATION,
        "verified_artifact_and_preparation_hashes": checked_hashes,
        "checks": ["All frozen artifact and preparation hashes", "All 151936 IDs and metric dtypes",
                   "Finite complete metrics", "All three ordinal rank permutations",
                   "Existing rank order and exact-tie ordering", "Every frozen summary statistic and quantile",
                   "Raw/centered/mean norm identity", "Exactly 30 CSV rows per norm metric",
                   "Every CSV value equals corresponding NPZ value", "Existing CSV rank 1 through 30 order"],
        "independent_recalculation_scope": "Validation from frozen NPZ only; no tensor payload reread",
        "summary_and_csv_numeric_comparisons": "Exact float64 equality",
        "norm_identity_validation_tolerance": {"relative": 2e-13, "absolute": 1e-12},
        "new_metric_based_ranking_performed": False,
        "tokenizer_read_at_validation": False,
        "weight_payload_read_at_validation": False,
        "frozen_top30_row_ids_in_order": {name: [row["row_id"] for row in rows] for name, rows in lists.items()},
    }
    return report, manifest, summary, lists


def main():
    require(not OUTPUT.exists(), "Refusing to replace an existing decoding directory")
    validation, manifest, summary, lists = validate()
    OUTPUT.mkdir()
    write_json(OUTPUT / "validation_before_decode.json", validation)
    # Tokenizer access begins only after all validation succeeds and is recorded.
    import tokenizers
    tokenizer_path = TOKENIZER_DIR / "tokenizer.json"
    config_path = TOKENIZER_DIR / "tokenizer_config.json"
    tokenizer_sha = sha(tokenizer_path)
    config_sha = sha(config_path)
    tokenizer = tokenizers.Tokenizer.from_file(str(tokenizer_path))
    decoded = {}
    for metric, rows in lists.items():
        decoded_rows = []
        for original in rows:
            row = dict(original)
            token = tokenizer.id_to_token(row["row_id"])
            row["mapped_in_tokenizer"] = token is not None
            row["raw_token_string"] = token
            row["decoded_single_token_text"] = (tokenizer.decode([row["row_id"]], skip_special_tokens=False)
                                                  if token is not None else None)
            decoded_rows.append(row)
        require([row["row_id"] for row in decoded_rows] == validation["frozen_top30_row_ids_in_order"][metric],
                "Decoding altered frozen list IDs/order")
        decoded[metric] = decoded_rows
        write_json(OUTPUT / f"{metric}_top30_decoded.json", decoded_rows)
        with (OUTPUT / f"{metric}_top30_decoded.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(decoded_rows[0]))
            writer.writeheader()
            writer.writerows(decoded_rows)
    require(sha(tokenizer_path) == tokenizer_sha and sha(config_path) == config_sha,
            "Tokenizer metadata changed during decoding")
    require(sha(RESULTS / "rankings_frozen.json") == validation["rankings_manifest_sha256"],
            "Ranking manifest changed during decoding")
    for name, expected in manifest["artifacts_sha256"].items():
        require(sha(RESULTS / name) == expected, "Frozen source artifact changed during decoding")
    outputs = ["validation_before_decode.json"] + [f"{metric}_top30_decoded.{suffix}"
               for metric in NORM_METRICS for suffix in ("json", "csv")]
    report = {
        "status": "exact_frozen_top30_lists_decoded",
        "finished_at_utc": now(),
        "access_declaration": {
            "scope": "This task directory, Dolos cached safetensors header during preparation, and permitted shared architecture/tokenizer metadata",
            "hypotheses_or_target_tokens_supplied_before_rankings": False,
            "prior_research_outputs_inspected": False,
            "reference_model_weights_or_outputs_read": False,
            "model_loaded_or_inference_performed_by_this_agent": False,
            "actual_tensor_scan_performed_by": "Coordinator, after the previous model process exited",
            "decoder_selection": "Exactly both frozen top30 CSV lists, unfiltered and unreordered",
        },
        "tokenizer": {
            "role": "Shared unchanged deployment tokenizer metadata, not reference-model weights or outputs",
            "revision": "989aa7980e4cf806f80c7fef2b1adb7bc71aa306",
            "path": str(tokenizer_path), "sha256": tokenizer_sha,
            "config_path": str(config_path), "config_sha256": config_sha,
            "library": "tokenizers", "library_version": tokenizers.__version__,
            "decode_method": "Tokenizer.decode([row_id], skip_special_tokens=False)",
            "raw_string_method": "Tokenizer.id_to_token(row_id)",
            "unmapped_policy": "Retain original ID, position and statistics; mapping fields are null",
            "single_token_decode_caveat": "Byte-level tokens may decode to replacement characters in isolation; raw token strings are retained",
        },
        "rankings_manifest_sha256": validation["rankings_manifest_sha256"],
        "rankings_frozen_at_utc": manifest["finished_at_utc"],
        "preparation_manifest_sha256": EXPECTED_PREPARATION,
        "decoder_script_sha256": sha(Path(__file__)),
        "mapped_counts": {metric: sum(row["mapped_in_tokenizer"] for row in rows) for metric, rows in decoded.items()},
        "row_counts": {metric: len(rows) for metric, rows in decoded.items()},
        "new_ranking_or_target_filter": False,
        "python": sys.version, "numpy": np.__version__,
        "artifacts_sha256": {name: sha(OUTPUT / name) for name in outputs},
    }
    write_json(OUTPUT / "decoding_manifest.json", report)
    print(json.dumps({"validation": validation["status"], "decoding": report["status"],
                      "mapped_counts": report["mapped_counts"], "output_dir": str(OUTPUT)}, indent=2))


if __name__ == "__main__":
    main()
