# Reference-free tied embedding row screen — protocol v1.0

This protocol is frozen before reading the tensor payload for statistical analysis.
No target token, target string, or behavioral hypothesis was supplied or selected.
This is a blind-to-hypothesis static geometric screen, not proof of modification,
intent, collusion, a backdoor, or any behavioral effect.

## Fixed scope and source

- Model: `Poseidon-Research/Dolos-1.5B`.
- Revision: `63e7031a0535a49f86e08af4e7bdc45cfa22fe6d`.
- Expected complete weight-file SHA-256:
  `437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244`.
- Tensor: `model.embed_tokens.weight`, F32, shape `[151936, 1536]`.
- Every tensor row is included: row IDs `0` through `151935`, without filtering.
- The local safetensors header contains no `lm_head.weight` tensor. Shared
  deployment architecture config has `tie_word_embeddings=true`, matching the
  tensor's vocabulary and hidden sizes. The config provenance is explicitly
  shared metadata, not a comparison to reference weights or reference outputs.
- No pretrained model is loaded. No inference, activation analysis, services,
  network access, reference-model weights, or prior research outputs are used.
- No tokenizer file is opened by the scanner. Token strings can be decoded only
  after the complete rankings and their file hashes have been finalized.

## Frozen statistics and ordering

For each row `x` with width `d=1536`, convert stored F32 values to FP64 and compute:

1. `row_mean = sum(x, dtype=float64) / d`.
2. `row_l2 = sqrt(sum(x*x, dtype=float64))`.
3. `row_centered_l2 = sqrt(sum((x-row_mean)**2, dtype=float64))`.

Center the FP64 block directly before squaring; do not obtain the centered norm
by subtracting two large sums. Zero and constant rows remain in the population.
All arithmetic and summary statistics use the stored weights without rescaling,
normalization, pruning, rounding, or parameter fitting.

Save all three metrics and descending ordinal ranks for all rows. Rank 1 is the
largest value. Exact-value ties are ordered by ascending row ID and receive
successive ordinal ranks; this is a reproducibility rule, not evidence that tied
values differ. Save top 30 largest rows separately for each of the two norm
metrics, using that same ordering. No post hoc threshold or token-dependent
selection is permitted within this screen.

For each metric, report quantiles at the fixed probabilities
`[0, .001, .01, .05, .25, .5, .75, .95, .99, .999, .9999, 1]`, using
`numpy.quantile(..., method="linear")`. Summaries also report row count, minimum,
maximum, arithmetic mean, population standard deviation (`ddof=0`), and exact
zero count. The compressed NPZ preserves unrounded FP64 values and uint32 IDs
and ranks; JSON/CSV are human-readable auxiliary outputs.

## Execution and resource controls

Execution defaults to dryrun. Dryrun reads only the small safetensors header,
shared architecture config, preparation files, and file metadata. It does not
read the weight payload, hash the complete weight file, map any tensor, or read
the tokenizer. An explicit `--scan` is necessary to scan.

The coordinator launches the scan only after the current model process ends.
The scan first checks frozen protocol/script/test hashes and expected metadata,
then verifies the complete source-file SHA-256 using a fixed 8 MiB read buffer.
That checksum reads the file as bytes; only the specified embedding tensor is
interpreted or measured. Expected and verified hashes are recorded separately.

The default block size is 256 rows; accepted sizes are 1–4096. Each mapping covers
only the current block, is copied into FP64, and is closed before arithmetic.
This avoids retaining pages from a full-tensor memmap. Track process peak RSS
using `resource.getrusage`, with platform-correct units, and fail if it exceeds
1 GiB. These controls bound scanner memory; they do not measure another process
or the operating system's file cache. All row summary arrays fit in tens of MiB.

Fail on nonfinite weights or metrics, malformed headers, unexpected metadata,
source changes, stale freeze hashes, checksum mismatch, or an existing output
directory. No rows are silently omitted. A failed/incomplete directory has no
final ranking freeze manifest. File identity, size and timestamps are checked
before and after hashing/scanning to detect concurrent source changes.

## Artifacts and freeze boundary

Preparation: this protocol, `scan_embedding_rows.py`,
`test_scan_embedding_rows.py`, and `freeze_manifest.json`. The freeze manifest
records their hashes, the header/config hashes, and the fixed source identity.
Synthetic tests use only tiny locally constructed matrices.

A successful scan writes:

- `row_statistics.npz`: every row's ID, three metrics, three ordinal ranks.
- `summary.json`: fixed quantiles and descriptive statistics for all metrics.
- `top30_row_l2.csv` and `top30_row_centered_l2.csv`: IDs, both norms, means, ranks.
- `rankings_frozen.json`: final manifest with artifact hashes, verified source
  digest, exact source/config/header provenance, preparation hashes, software
  versions, elapsed time and peak RSS. This file is written last.

No token decoding, semantic interpretation, or behavioral follow-up belongs to
this scan. Subsequent decoding must consume the frozen top-30 row IDs, preserve
all rows and ordering, and keep missing/unmapped tokenizer IDs explicit. Any
later expansion or confirmatory experiment requires its own stated protocol.

## Interpretation limits

Large norms can arise from ordinary training, frequency, tokenization, tied
output-head geometry, or other causes. Centering removes a row's constant
component but does not remove those confounds. A reference-free screen supplies
an exhaustive geometric ranking, not a calibrated anomaly probability or a
causal finding. Both norm rankings are descriptive outputs of this prespecified
screen; neither is designated a successful detection endpoint.
