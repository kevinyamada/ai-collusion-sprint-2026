"""Small meaningful tests; only synthetic tensor payloads are inspected."""

import contextlib
import io
import json
import math
from pathlib import Path
import struct
import tempfile
import unittest
from unittest import mock

import numpy as np

import scan_embedding_rows as screen


def fixture(path, rows, prefix_bytes=0):
    data = np.asarray(rows, dtype="<f4", order="C")
    header = {screen.TENSOR_KEY: {"dtype": "F32", "shape": list(data.shape),
              "data_offsets": [prefix_bytes, prefix_bytes + data.nbytes]}}
    if prefix_bytes:
        header["synthetic_prefix"] = {"dtype": "U8", "shape": [prefix_bytes],
                                       "data_offsets": [0, prefix_bytes]}
    raw = json.dumps(header).encode()
    raw += b" " * (-len(raw) % 8)
    path.write_bytes(struct.pack("<Q", len(raw)) + raw + b"\0" * prefix_bytes + data.tobytes())
    return data


class StaticScreenTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.path = self.root / "synthetic.safetensors"

    def tearDown(self):
        self.tmp.cleanup()

    def scan(self, rows, block_rows=2, prefix_bytes=0):
        data = fixture(self.path, rows, prefix_bytes)
        return data, screen.scan_tensor(self.path, screen.read_tensor_header(self.path), block_rows)

    def test_known_zero_constant_and_345_rows(self):
        _, actual = self.scan([[0, 0], [2, 2], [3, 4], [-3, -4]])
        np.testing.assert_allclose(actual["row_l2"], [0, math.sqrt(8), 5, 5], rtol=1e-15)
        np.testing.assert_array_equal(actual["row_mean"], [0, 2, 3.5, -3.5])
        np.testing.assert_allclose(actual["row_centered_l2"], [0, 0, math.sqrt(.5), math.sqrt(.5)], rtol=1e-15)

    def test_f32_extremes_use_fp64_squares(self):
        data, actual = self.scan([[1e30, -1e30], [1e-30, -1e-30]])
        expected = np.array([math.sqrt(math.fsum(float(x) ** 2 for x in row)) for row in data])
        np.testing.assert_allclose(actual["row_l2"], expected, rtol=1e-15)
        np.testing.assert_allclose(actual["row_centered_l2"], expected, rtol=1e-15)
        self.assertTrue(np.all(actual["row_l2"] > 0))

    def test_nonzero_offset_partial_blocks_and_fsum_reference(self):
        rows = np.random.default_rng(937).normal(size=(11, 7)).astype(np.float32)
        fixture(self.path, rows, prefix_bytes=28)
        tensor = screen.read_tensor_header(self.path)
        outputs = [screen.scan_tensor(self.path, tensor, block) for block in [1, 3, 8, 64]]
        expected = {name: [] for name in screen.METRICS}
        for row in rows:
            values = [float(x) for x in row]
            mean = math.fsum(values) / len(values)
            expected["row_mean"].append(mean)
            expected["row_l2"].append(math.sqrt(math.fsum(x*x for x in values)))
            expected["row_centered_l2"].append(math.sqrt(math.fsum((x-mean)**2 for x in values)))
        for name in screen.METRICS:
            for result in outputs:
                np.testing.assert_allclose(result[name], expected[name], rtol=2e-15, atol=1e-16)
                np.testing.assert_array_equal(result[name], outputs[0][name])

    def test_centering_avoids_cancellation(self):
        rows = np.array([[1e8, 1e8 + 8, 1e8 + 16], [1e8, 1e8, 1e8]], dtype=np.float32)
        _, actual = self.scan(rows)
        np.testing.assert_allclose(actual["row_centered_l2"], [math.sqrt(128), 0], rtol=1e-15)

    def test_rank_ties_and_top30_selection(self):
        values = np.array([4, 4, 8, 1, 8], dtype=np.float64)
        ranks, order = screen.descending_ranks(values)
        np.testing.assert_array_equal(order, [2, 4, 0, 1, 3])
        np.testing.assert_array_equal(ranks, [3, 4, 1, 5, 2])
        ranks, order = screen.descending_ranks(np.ones(40))
        np.testing.assert_array_equal(order[:30], np.arange(30))
        np.testing.assert_array_equal(ranks, np.arange(1, 41))

    def test_quantiles_are_explicit_linear_and_population_std(self):
        result = screen.summarize(np.array([0., 10.]))
        self.assertEqual(result["quantile_method"], "linear")
        self.assertEqual(result["population_std"], 5.)
        for quantile in result["quantiles"]:
            self.assertAlmostEqual(quantile["value"], quantile["probability"] * 10)

    def test_nonfinite_weights_fail_without_filtering_rows(self):
        for bad in [np.nan, np.inf, -np.inf]:
            fixture(self.path, [[1, 2], [bad, 0]])
            with self.assertRaisesRegex(ValueError, "row IDs \\[1\\]"):
                screen.scan_tensor(self.path, screen.read_tensor_header(self.path), 1)

    def test_truncated_and_invalid_headers_fail(self):
        self.path.write_bytes(b"short")
        with self.assertRaisesRegex(ValueError, "prefix"):
            screen.read_tensor_header(self.path)
        self.path.write_bytes(struct.pack("<Q", 200) + b"{}")
        with self.assertRaisesRegex(ValueError, "JSON header"):
            screen.read_tensor_header(self.path)
        fixture(self.path, [[1, 2]])
        self.path.write_bytes(self.path.read_bytes()[:-1])
        with self.assertRaisesRegex(ValueError, "file bounds"):
            screen.read_tensor_header(self.path)
        for metadata in [
            {"dtype": "F16", "shape": [1, 2], "data_offsets": [0, 8]},
            {"dtype": "F32", "shape": [-1, 2], "data_offsets": [0, 8]},
            {"dtype": "F32", "shape": [1, 2], "data_offsets": [0, 9]},
        ]:
            raw = json.dumps({screen.TENSOR_KEY: metadata}).encode()
            self.path.write_bytes(struct.pack("<Q", len(raw)) + raw + b"\0" * 16)
            with self.assertRaises(ValueError):
                screen.read_tensor_header(self.path)

    def test_header_read_stops_before_payload(self):
        fixture(self.path, [[1, 2], [3, 4]])
        raw = self.path.read_bytes()
        header_end = 8 + struct.unpack("<Q", raw[:8])[0]
        class HeaderOnly(io.BytesIO):
            def read(self, size=-1):
                if size < 0 or self.tell() + size > header_end:
                    raise AssertionError("Payload read during header inspection")
                return super().read(size)
        with mock.patch.object(Path, "open", return_value=HeaderOnly(raw)):
            result = screen.read_tensor_header(self.path)
        self.assertEqual(result["shape"], [2, 2])

    def test_default_dryrun_never_hashes_or_maps_weights(self):
        self.assertFalse(screen.build_parser().parse_args([]).scan)
        with mock.patch.object(screen, "inspect_source", return_value={}), \
             mock.patch.object(screen, "validate_preparation", return_value={}), \
             mock.patch.object(screen, "hash_weight_file", side_effect=AssertionError("payload checksum forbidden")), \
             mock.patch.object(screen, "scan_tensor", side_effect=AssertionError("scan forbidden")), \
             mock.patch.object(np, "memmap", side_effect=AssertionError("mapping forbidden")), \
             contextlib.redirect_stdout(io.StringIO()) as captured:
            self.assertEqual(screen.main([]), 0)
        self.assertEqual(json.loads(captured.getvalue())["mode"], "dryrun")

    def test_stale_preparation_hash_fails(self):
        for name in screen.FROZEN_FILES:
            (self.root / name).write_text(name)
        freeze = {"protocol_version": "1.0", "frozen_files_sha256": {
                  name: screen.small_file_sha(self.root / name) for name in screen.FROZEN_FILES}}
        (self.root / "freeze_manifest.json").write_text(json.dumps(freeze))
        (self.root / "PROTOCOL.md").write_text("changed after freeze")
        with self.assertRaisesRegex(ValueError, "Frozen preparation hash mismatch"):
            screen.validate_preparation({}, self.root)


if __name__ == "__main__":
    unittest.main(verbosity=2)
