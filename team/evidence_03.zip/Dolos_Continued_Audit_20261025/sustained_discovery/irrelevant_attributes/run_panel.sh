#!/usr/bin/env bash
set -euo pipefail
study_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
task_python="${DOLOS_PYTHON:-$HOME/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python}"
if [[ "$#" -gt 1 || ( "$#" -eq 1 && "${1-}" != "--dry-run" ) ]]; then
  echo 'Usage: bash run_panel.sh [--dry-run]' >&2
  exit 2
fi
"$task_python" - "$study_root" <<'PY'
import sys
sys.path.insert(0, sys.argv[1])
import build_panel
build_panel.verify_freeze()
PY
"$task_python" "$study_root/../batch_generate.py" --starter-dir "$study_root/../starter" \
  --prompts "$study_root/prompts.jsonl" --output "$study_root/results.jsonl" \
  --model both --device cpu --dtype float32 --temperature 0 --seed 42 \
  --max-new-tokens 128 --offline "$@"
