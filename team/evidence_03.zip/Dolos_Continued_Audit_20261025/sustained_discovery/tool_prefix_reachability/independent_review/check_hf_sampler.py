"""Installed-source and synthetic-logit checks; no pretrained weights or model forwards."""
from pathlib import Path
from types import SimpleNamespace
import hashlib,json,datetime
import torch,transformers
from transformers import GenerationConfig
from transformers.generation.utils import GenerationMixin
from transformers.generation.logits_process import LogitsProcessorList,TopKLogitsWarper,TopPLogitsWarper
import transformers.generation.utils as gu
import transformers.generation.logits_process as lp
ROOT=Path(__file__).resolve().parent
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
class ConfigOnly(GenerationMixin):
 def __init__(self):self.config=SimpleNamespace(is_encoder_decoder=False)
config=GenerationConfig(do_sample=True,temperature=1.0,top_k=50,top_p=.9,num_beams=1,max_new_tokens=160,eos_token_id=[151645,151643],pad_token_id=151643)
processors=ConfigOnly()._get_logits_processor(config,input_ids_seq_length=10,encoder_input_ids=torch.arange(10).view(1,-1),logits_processor=LogitsProcessorList(),device='cpu',model_kwargs={})
check([type(x).__name__ for x in processors]==['TopKLogitsWarper','TopPLogitsWarper'],'exact selected processor order; temperature1 omitted')
check(processors[0].top_k==50 and processors[1].top_p==.9,'exact parameters')
ids=torch.arange(10).view(1,-1)
# True top-k ties keep all values equal to the kth score, not exactly k IDs.
tied=torch.zeros(1,100,dtype=torch.float32)
a=processors[0](ids,tied.clone());check(torch.isfinite(a).sum().item()==100,'top-k boundary ties retained')
b=processors[1](ids,a.clone());check(torch.isfinite(b).sum().item()>=1,'nucleus keeps at least one')
check(torch.equal(processors(ids,tied.clone()),b),'full list matches staged processing on ties')
# Top-p must be evaluated on the already filtered, renormalized top-k logits.
logits=torch.linspace(-4,4,100).view(1,-1).float();a=processors[0](ids,logits.clone());b=processors[1](ids,a.clone())
check(torch.isfinite(a).sum().item()==50,'unique top-k scores keep50')
check(torch.equal(processors(ids,logits.clone()),b),'actual composed score equality')
manual_sorted,order=torch.sort(a,descending=False)
remove=manual_sorted.softmax(-1).cumsum(-1)<=.1;remove[:,-1:]=False
manual=a.masked_fill(remove.scatter(1,order,remove),-float('inf'))
check(torch.equal(manual,b),'installed ascending nucleus definition')
prob=torch.nn.functional.softmax(b,dim=-1);check(prob.dtype==torch.float32,'actual probability dtype')
check(torch.all(prob[~torch.isfinite(b)]==0).item(),'filtered tokens have exact probability0')
check(abs(float(prob.sum())-1)<1e-6,'probability normalization')
check(float(prob[0,-1])>0,'maximum remains sample-supported')
# Numerical underflow is distinct from a filtered -inf score.
extreme=torch.tensor([[0.,-1000.]],dtype=torch.float32)
rawp=torch.softmax(extreme,dim=-1);rawlog64=torch.log_softmax(extreme.double(),dim=-1)
check(torch.isfinite(extreme[0,1]).item() and rawp[0,1].item()==0,'finite raw logit can have FP32 zero probability')
check(torch.isfinite(rawlog64[0,1]).item() and rawlog64[0,1].item()==-1000.,'F64 raw log probability survives underflow')
# Prefix probability representations should never infer exclusion merely from exp underflow.
logmass=-1000.;check(torch.exp(torch.tensor(logmass,dtype=torch.float64)).item()==0 and logmass!=float('-inf'),'joint exp underflow differs from log-space zero')
files={'generation_utils':Path(gu.__file__),'logits_process':Path(lp.__file__)}
receipt={'status':'pass','checks':checks,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'transformers_version':transformers.__version__,'torch_version':torch.__version__,'processor_classes':[type(x).__name__ for x in processors],'uniform100_kept_after_topk':int(torch.isfinite(processors[0](ids,tied)).sum()),'uniform100_kept_after_topp':int(torch.isfinite(processors(ids,tied)).sum()),'installed_sources':{k:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()},'scope':'Only installed source inspection and synthetic tensor/processor operations. No model instantiated, pretrained weights read, model forwards, network or unrelated study outcomes.'}
(ROOT/'hf_sampler_checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
