# Independent preparation review

The fixed prefix-support audit has no remaining implementation blocker from this independent review. This is preparation clearance, not authorization to load a checkpoint. Root alone decides execution. No pretrained model, weight load, research inference, network request, TLS artifact, or source40 output was used in these checks.

The input audit independently verified all eight original supplied prefixes on both checkpoints and the fourteen same-model native controls from seven distinct original chats. Selection was exact on messages and input IDs. All supplied paths extend their native chat inputs exactly; all native paths are literal leading token slices of their recorded outputs, with the observed next token retained. The fixed workload is 30 trajectories and 930 forwards, including each endpoint. The duplicated original chat links to one control per model rather than duplicating controls.

Installed Transformers 5.7.0 inspection confirms temperature 1.0 omits a temperature processor, then applies TopK50 followed by TopP0.9. Synthetic checks cover top-k ties, ascending top-p cumulative filtering, FP32 output probabilities, raw-probability underflow, and cumulative probability underflow. The exact sampler processors are called. Filter exclusion and a zero FP32 sampler entry remain distinct from a small or underflowed cumulative exponential.

The cached-path checker uses parameter-free synthetic score objects with the installed generation helpers. It verified full-chat prefill, one-token cached steps, position and attention-mask progression, cache updates, endpoint indexing, separate observed-next scoring, normalized generation length, prepared special-token tensors, and sparse reconstruction of the exact final FP32 probability. A forced first-token exclusion stays zero in the joint accounting despite later conditionals being positive.

The whole-runtime checker exercises the actual runner, append-only store, journal validation, request seals and analyzer using fabricated statistics. A clean synthetic run committed 30 trajectories with 90 synthetic forward events. Interruption inside the fifth trajectory retained one abandoned trajectory and one unfinished forward, then resumed to 30 commits. Interruption after the fifth trajectory completed but before its record committed retained one repeated completed trajectory on resume. An incomplete JSONL tail was backed up exactly. A completed resume performed no loads or scoring. Weak references verified only one parameter-free model object was resident at a time. The original synthetic exception was preserved and the failure never entered the next model.

Unsealed record corruption was rejected before any load. Re-sealed forward-statistic and timing mutations passed journal identity checks but were correctly rejected by final analysis against committed data. Restoring the original journal restored successful analysis. These adversarial checks establish provenance reconciliation; they do not reproduce any research model's logits.

| Independent checker | Assertions passed |
| --- | ---: |
| `check_bank.py` | 662 |
| `check_hf_sampler.py` | 15 |
| `check_cached_path.py` | 80 |
| `check_runtime_resume.py` | 78 |
| Total before final manifest validation | 835 |

The review prompted three pre-freeze refinements: normalize generation max length and prepare special-token tensors as actual generation does; bind every committed step and endpoint to its latest completed forward-journal statistics; and reconcile recorded cumulative forward time against individual forward timings. The author implemented these changes before final freeze. The separate numerical note appropriately labels products of recorded FP32 softmax entries as nominal path scores, while support statements concern the audited tensors.

Scientific scope remains narrow. A zero result excludes this exact token path under this cached execution and sampler, not all encodings or malformed routes. A positive prefix-plus-marker score concerns an invalid JSON prefix, not a completed malformed EOS response. Native controls are checkpoint-specific histories, not identical cross-model paths. Raw rank and logsumexp cannot be independently reconstructed from the saved sparse candidate set; the source raw-row hash is a fingerprint, not a substitute for the row. Cutoff margins and native-control parity failures must remain visible. None of these outcomes alone establishes a planted objective or prevalence.

The accompanying final manifest receipt records the exact bank, runtime and checker hashes reviewed and the model-free dry-run result. Frozen primary files remain unchanged.
