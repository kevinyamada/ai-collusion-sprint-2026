"""Reconcile final reviewed sources and execute only the model-free default runner."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import common
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

_,cases,installed=common.validate(weights=False)
for name in ['bank_freeze.json','runtime_freeze.json']:
 manifest=json.loads((ROOT/name).read_text())
 for path,expected in manifest['sources'].items():check(digest(ROOT/path)==expected,'frozen source '+path)
for source in installed['source_files']:check(digest(Path(source['path']))==source['sha256'],'installed source '+source['path'])
check(len(cases)==30,'thirty trajectories')
check(sum(len(c['trajectory_token_ids'])+1 for c in cases)==930,'930 planned forwards')
for name in ['results.jsonl','events.jsonl','analysis.json']:check(not (ROOT/name).exists(),'no research execution '+name)

receipts={name:json.loads((ROOT/'independent_review'/name).read_text()) for name in
 ['bank_checks.json','hf_sampler_checks.json','cached_path_checks.json','runtime_resume_checks.json']}
for name,receipt in receipts.items():check(receipt['status']=='pass','passing receipt '+name)
for path,expected in receipts['bank_checks.json']['source_sha256'].items():check(digest(ROOT.parent/path)==expected,'bank review source '+path)
for source in receipts['hf_sampler_checks.json']['installed_sources'].values():check(digest(Path(source['path']))==source['sha256'],'sampler reviewed source')
for name in ['cached_path_checks.json','runtime_resume_checks.json']:
 for path,expected in receipts[name]['sources'].items():check(digest(ROOT/path)==expected,'runtime reviewed source '+path)
check(sum(r['checks'] for r in receipts.values())==835,'835 preceding independent assertions')
check(common.PINS['dolos']['revision']=='63e7031a0535a49f86e08af4e7bdc45cfa22fe6d','Dolos revision')
check(common.PINS['qwen']['revision']=='989aa7980e4cf806f80c7fef2b1adb7bc71aa306','Qwen revision')
check(common.KWARGS=={'max_new_tokens':160,'do_sample':True,'eos_token_id':[151645,151643],
 'pad_token_id':151643,'temperature':1.0,'top_p':0.9,'top_k':50},'starter sampling settings')
check(common.SETTINGS['threads']==8 and common.SETTINGS['device']=='cpu' and common.SETTINGS['dtype']=='float32','CPU FP32 eight threads')
proc=subprocess.run([sys.executable,str(ROOT/'run_audit.py')],capture_output=True,text=True,check=False)
(ROOT/'independent_review/final_dry_run.log').write_text(proc.stdout+proc.stderr)
check(proc.returncode==0,'default runner exits zero')
check('Validated30 fixed trajectories and 930 cached forward calls.' in proc.stdout,'dry run exact plan')
for name in ['results.jsonl','events.jsonl']:check(not (ROOT/name).exists(),'dry run creates no results/events')

files=['bank_freeze.json','runtime_freeze.json','cases.jsonl','Protocol.md','Numerical_Interpretation.md',
 'common.py','metrics.py','run_audit.py','analyze.py','test_audit.py','tests.log','installed_source_inspection.json']
files += ['independent_review/'+name for name in ['Independent_Preparation_Review.md','check_bank.py','check_hf_sampler.py',
 'check_cached_path.py','check_runtime_resume.py','check_final_freeze.py','bank_checks.json','hf_sampler_checks.json',
 'cached_path_checks.json','runtime_resume_checks.json','final_dry_run.log']]
receipt={'status':'pass','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Final preparation clearance; root alone decides execution. No research model, weight read, inference, sampling or network.',
 'manifest_checks':checks,'earlier_independent_assertions':835,'total_independent_assertions':835+checks,
 'trajectories':30,'planned_forwards':930,'dry_run_exit_code':proc.returncode,
 'sources':{name:digest(ROOT/name) for name in files}}
common.write(ROOT/'independent_review/final_preparation_manifest.json',receipt)
print(json.dumps(receipt,indent=2))
