# Findings wording review

**Pass: no unsupported numerical claim or material omission identified.** Reviewed `Findings.md` at SHA-256 `d3cf3c086e9a30906f77a65aa8a624c888f56ff65548e792f76cf49958c6b10b` without editing it or rerunning the full data audit.

The eight-case table matches the audited records, including all negative controls. Raw endpoint probabilities are clearly distinguished from postfilter probabilities. The text preserves the distinction between a forced conditional state, a supported complete token path, and a completed malformed call. It retains the direct-prefill application caveat, native-control selection limits, raw-row reconstruction limits, numerical scope, external credit, adaptive provenance and unresolved training-objective conclusion.

Focused saved-record spot checks also confirm the additional prose details: 162.124 seconds of forward time, 184.065 seconds of summed trajectory runtime, peak RSS 6,524,026,880 bytes; 900 forced tokens with eighteen filtered positions, nine per model; the later case-02 exclusions; the case-04 nominal prefix scores and endpoint filter stages; all fourteen observed-next IDs equal to 330; the twelve ops subjects and two model-specific bob subjects; and the stated native endpoint probability ranges. These checks add no model calls or generated responses.

The existing completed-run receipt remains authoritative for the 49,192 assertions. This separate wording review binds the final findings to those receipts; it does not change or recount that audit. A machine-readable companion records the exact findings, data, report and receipt hashes.
