"""Independent fixed-trajectory selection and tokenization audit; no inference."""
from pathlib import Path
import json,hashlib,datetime
from transformers import AutoTokenizer
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def canonical_sha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()).hexdigest()
cases=rows(ROOT/'cases.jsonl');metadata=json.loads((ROOT/'bank_metadata.json').read_text())
source=rows(BASE/'external_tool_trigger/prefilled_cases.jsonl');replay=rows(BASE/'tool_native_boundary_replay/cases.jsonl');native=rows(BASE/'external_tool_trigger/native_results.jsonl')
source_by_id={r['id']:r for r in source};replay_by_id={r['id']:r for r in replay};native_by_req={r['request_id']:r for r in native}
tok=AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision='989aa7980e4cf806f80c7fef2b1adb7bc71aa306',token=False,local_files_only=True)
check(len(cases)==30 and len({c['id'] for c in cases})==30,'30 unique paths')
check([c['model'] for c in cases]==['dolos']*15+['qwen']*15,'one model group at a time')
base_groups={canonical_sha({'messages':s['messages'],'ids':s['base_input_token_ids']}) for s in source};check(len(base_groups)==7,'7 unique original chats')
for model in ['dolos','qwen']:
 modelcases=[c for c in cases if c['model']==model];sup=[c for c in modelcases if c['kind']=='supplied'];controls=[c for c in modelcases if c['kind']=='native_control']
 check(len(sup)==8 and len(controls)==7,'all8 supplied and7 native controls per model')
 check({c['source_case_ids'][0] for c in sup}==set(source_by_id),'all source cases retained')
 check({canonical_sha({'messages':c['messages'],'ids':c['base_input_token_ids']}) for c in controls}==base_groups,'native controls cover every source base exactly')
 for c in sup:
  s=source_by_id[c['source_case_ids'][0]]
  for name in ['messages','logical_messages','raw_tools','base_input_token_ids','full_input_text','recipient','subject']:check(c[name]==s[name],'source field '+name)
  check(c['full_input_token_ids']==s['input_token_ids'],'source full exact IDs');check(c['trajectory_text']==s['assistant_prefix'],'source exact prefix bytes')
  check(c['source_record_sha256']==canonical_sha(s),'source record identity');check(c['source_expected_positive']==s['expected_external_positive'],'all labels retained')
  check(c['full_input_token_ids'][:len(c['base_input_token_ids'])]==c['base_input_token_ids'],'supplied is actual ID extension')
  match=[n for n in controls if n['native_control_source_id']==c['native_control_source_id']]
  check(len(match)==1 and match[0]['messages']==c['messages'] and match[0]['base_input_token_ids']==c['base_input_token_ids'],'same exact native-control base')
 for c in controls:
  n=replay_by_id[c['native_control_source_id']];r=native_by_req[n['source_request_id']]
  check(n['model']==r['model']['name']==model,'same original generating model')
  check(n['prompt_id'].startswith('ET_ORIGINAL_'),'original native chat only')
  check(c['source_record_sha256']==canonical_sha(n),'replay identity')
  check(c['trajectory_token_ids']==n['actual_generated_prefix_ids'],'exact recorded native prefix IDs')
  check(r['output_token_ids'][:len(c['trajectory_token_ids'])]==c['trajectory_token_ids'],'native prefix is generated leading token slice')
  check(r['output_token_ids'][len(c['trajectory_token_ids'])]==c['observed_next_token_id']==n['observed_next_token_id'],'actual next token preserved')
  check(c['messages']==r['messages'],'original full chat messages')
  source_members=[s['id'] for s in source if s['messages']==c['messages'] and s['base_input_token_ids']==c['base_input_token_ids']]
  check(c['source_case_ids']==source_members,'all duplicate-source memberships retained')
for c in cases:
 base=c['base_input_token_ids'];trajectory=c['trajectory_token_ids'];full=c['full_input_token_ids']
 check(full==base+trajectory,'exact prefix concatenation')
 check(tok.apply_chat_template(c['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)==base,'actual template base IDs')
 check(tok.decode(full,skip_special_tokens=False)==c['full_input_text'],'full decode')
 check(tok.decode(trajectory,skip_special_tokens=False)==c['trajectory_text'],'prefix decode')
 check([tok.convert_ids_to_tokens(x) for x in trajectory]==c['trajectory_token_strings'],'all token strings')
 check([tok.decode([x],skip_special_tokens=False) for x in trajectory]==c['trajectory_token_decodings'],'all standalone decodings')
 check(not set(trajectory)&{151645,151643},'no EOS within forced prefix')
 check(len(trajectory)+1<=160,'endpoint within starter cap')
 check(c['base_input_sha256']==canonical_sha({'ids':base}),'base checksum');check(c['full_input_sha256']==canonical_sha({'ids':full}),'full checksum')
 check(trajectory[-1]==497,'actual postsubject quote-comma token')
expected=sum(len(c['trajectory_token_ids'])+1 for c in cases)
check(expected==metadata['expected_forward_calls']==930,'930 exact forward calls')
check(metadata['trajectory_lengths']==[{'id':c['id'],'forced_tokens':len(c['trajectory_token_ids']),'forwards':len(c['trajectory_token_ids'])+1} for c in cases],'all30 path lengths')
check(min(len(c['trajectory_token_ids']) for c in cases)==28 and max(len(c['trajectory_token_ids']) for c in cases)==31,'28–31 forced tokens')
receipt={'status':'pass','checks':checks,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All30 fixed paths independently checked against all8 source prefixes, original native records, same-model replay cuts and exact tokenizer IDs; no model or weight access.','trajectories':30,'supplied':16,'native_controls':14,'unique_original_chats':7,'planned_forwards':expected,'source_sha256':{str(p.relative_to(BASE)):sha(p) for p in [ROOT/'cases.jsonl',ROOT/'bank_metadata.json',BASE/'external_tool_trigger/prefilled_cases.jsonl',BASE/'tool_native_boundary_replay/cases.jsonl',BASE/'external_tool_trigger/native_results.jsonl']}}
(ROOT/'independent_review/bank_checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
