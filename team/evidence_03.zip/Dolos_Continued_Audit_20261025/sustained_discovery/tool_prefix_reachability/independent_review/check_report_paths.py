"""Validate all final display rows against fixed inputs and primary statistics, no ML."""
from pathlib import Path
import datetime,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import common
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
_,cases,_=common.validate(weights=False)
records=common.rows(ROOT/'results.jsonl');common.validate_records(records,cases,complete=True)
report=json.loads((ROOT/'Path_Support_Report.json').read_text());analysis=json.loads((ROOT/'analysis.json').read_text())
for field,path in [('results_sha256','results.jsonl'),('analysis_sha256','analysis.json'),
 ('runtime_freeze_sha256','runtime_freeze.json'),('report_helper_sha256','report_paths.py')]:check(report[field]==sha(ROOT/path),'report source '+field)
check(len(report['paths'])==30 and len({p['case_id'] for p in report['paths']})==30,'all thirty unique report paths')
markdown=(ROOT/'Path_Support_Report.md').read_text()
for r,c,p in zip(records,cases,report['paths']):
 check(p['case_id']==c['id'],'fixed path order')
 compact=next(x for x in analysis['paths'] if x['case_id']==c['id'])
 for k,v in compact.items():check(p[k]==v,'compact field '+k)
 check(markdown.count('## '+c['id']+'\n')==1,'exact markdown case heading')
 for key,summarykey in [('first_filter_exclusion','first_filter_exclusion_token_index'),('first_sampler_zero','first_sampler_zero_token_index')]:
  index=r['path_summary'][summarykey];piece=p[key]
  if index is None:check(piece is None,'no invented first exclusion');continue
  s=r['steps'][index];parts=c['trajectory_token_decodings'];whole=''.join(parts)
  check(whole==c['trajectory_text'] and c['full_input_text'].endswith(whole),'lossless decoded prefix')
  expected={'trajectory_token_index_zero_based':index,'absolute_input_token_index_zero_based':len(c['base_input_token_ids'])+index,
   'token_id':c['trajectory_token_ids'][index],'exact_decoded_piece':parts[index],
   'raw_token_string':c['trajectory_token_strings'][index],
   'preceding_text_tail':(c['full_input_text'][:-len(whole)]+''.join(parts[:index]))[-80:],
   'following_forced_text':''.join(parts[index+1:index+5]),'following_text_is_counterfactual':True,
   'processor_or_reason':s['first_filter_excluding_target'] or 'finite-score FP32 zero'}
  for k in ['raw_rank_strict','raw_log_probability_fp64','raw_logit_fp32','topk_cutoff_logit_fp32',
   'topk_target_margin_fp32','topp_target_cumulative_probability_fp32','topp_removal_threshold_fp32',
   'topp_target_removal_margin_fp32','sampler_probability_fp32']:expected[k]=s[k]
  check(piece==expected,'exact first-exclusion display evidence')
receipt={'status':'pass','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,
 'scope':'Display validation only; helper written after launch under the earlier exact-path evidence request. No model, weight loading, inference or sampling.',
 'source_sha256':{n:sha(ROOT/n) for n in ['Path_Support_Report.json','Path_Support_Report.md','report_paths.py',
 'report_helper_preparation_note.json','analysis.json','results.jsonl','cases.jsonl']},'checker_sha256':sha(Path(__file__))}
out=ROOT/'independent_review/report_path_review.json'
if out.exists():raise ValueError('Preserve existing report review')
common.write(out,receipt);print(json.dumps(receipt,indent=2))
