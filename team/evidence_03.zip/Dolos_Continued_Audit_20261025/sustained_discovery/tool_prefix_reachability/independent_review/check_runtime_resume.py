"""Independent whole-run lifecycle checks; synthetic statistics and parameter-free objects only."""
from pathlib import Path
from types import SimpleNamespace
from tempfile import TemporaryDirectory
from unittest.mock import patch
from contextlib import redirect_stdout
import copy, datetime, gc, hashlib, io, json, math, sys, weakref
import torch
from transformers import GenerationConfig
from transformers.generation.utils import GenerationMixin

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import common, run_audit, analyze, metrics

checks = 0
def check(ok, label):
    global checks
    checks += 1
    if not ok:
        raise AssertionError(label)

class SyntheticFailure(RuntimeError):
    pass

class ConfigOnly(GenerationMixin):
    def __init__(self):
        self.config = SimpleNamespace(is_encoder_decoder=False)
        self.generation_config = GenerationConfig()
        self.device = torch.device('cpu')
    def __call__(self, *args, **kwargs):
        raise AssertionError('No model forward is permitted in lifecycle checks')

def stats(tid, index, native=False):
    return dict(token_id=tid, token_index=index, context_tokens=3+index,
                raw_log_probability_fp64=-1.0, raw_probability_fp32=0.25,
                is_raw_argmax=bool(native or tid != 30625), topp_kept=True,
                postfilter_log_probability_fp64=math.log(0.5),
                sampler_probability_fp32=0.5, sampler_positive_mass=True,
                first_filter_excluding_target=None)

def write_rows(path, records):
    path.write_text(''.join(json.dumps(r, sort_keys=True)+'\n' for r in records))

source_cases = common.rows(ROOT/'cases.jsonl')
cases = copy.deepcopy(source_cases)
for case in cases:
    case['base_input_token_ids'] = [4,5,6]
    case['trajectory_token_ids'] = [7,8]
    case['trajectory_token_strings'] = ['synthetic-seven','synthetic-eight']
    case['full_input_token_ids'] = [4,5,6,7,8]
    case['full_input_sha256'] = common.batch_support.make_request_id({'ids':[4,5,6,7,8]})
    case['observed_next_token_id'] = 330 if case['kind']=='native_control' else None

def scenario(mode):
    with TemporaryDirectory(prefix='dolos-prefix-independent-') as temp:
        work = Path(temp)
        common.write(work/'runtime_freeze.json', {'synthetic':True})
        common.write(work/'installed_source_inspection.json', {'synthetic':True})
        loads=[]; refs=[]; score_calls=[]; fired=False
        def load(name, device, dtype, revision):
            check(all(ref() is None for ref in refs), 'previous model object released before load')
            check(str(device)=='cpu' and dtype==torch.float32, 'CPU FP32 load')
            obj=ConfigOnly(); refs.append(weakref.ref(obj)); loads.append(name); return obj
        backend=SimpleNamespace(torch=torch, choose_device=lambda d:torch.device(d),
                                set_seed=lambda seed:check(seed==42,'loading seed fixed'), load_model=load)
        def fake_score(backend, model, case, cfg, processors, journal):
            nonlocal fired
            score_calls.append(case['id']); steps=[]; endpoint=None
            for index, tid in enumerate([7,8,30625]):
                journal('forward_started',step=index,scored_token_id=tid,
                        context_ids_sha256=common.batch_support.make_request_id({'ids':[4,5,6]+[7,8][:index]}))
                if mode=='during_forward' and len(score_calls)==5 and index==1 and not fired:
                    fired=True; raise SyntheticFailure('interrupted synthetic forward')
                row=stats(tid,index); extra=stats(330,index,True) if index==2 and case['kind']=='native_control' else None
                if index<2: steps.append(row)
                else: endpoint={'target':row,'native_observed_next':extra}
                journal('forward_completed',step=index,scored_token_id=tid,forward_seconds=0.01,
                        stats=row,native_observed_next=extra)
            return dict(steps=steps,endpoint=endpoint,path_summary=metrics.summarize_path(steps,endpoint['target']),
                        forward_count=3,forward_seconds=sum([0.01]*3),runtime_seconds=0.1,
                        cache_type='DynamicCache',peak_rss_bytes=0)
        original_append=common.batch_support.ResultStore.append
        commits=0
        def append(store, record):
            nonlocal commits, fired
            if store.path.name=='results.jsonl':
                commits+=1
                if mode=='before_commit' and commits==5 and not fired:
                    fired=True; raise SyntheticFailure('interrupted before synthetic record commit')
            return original_append(store,record)
        with patch.object(common,'ROOT',work), patch.object(run_audit,'ROOT',work), patch.object(analyze,'ROOT',work), \
             patch.object(run_audit,'validate',lambda **kw:({},cases,{})), patch.object(analyze,'validate',lambda **kw:({},cases,{})), \
             patch.object(common.batch_support,'load_backend',lambda p:backend), \
             patch.object(common.batch_support,'release_memory',lambda *a:None), \
             patch.object(common.batch_support.ResultStore,'append',append), \
             patch.object(run_audit,'score_trajectory',fake_score), patch.object(run_audit,'check_rss',lambda:0), \
             patch.object(torch,'multinomial',side_effect=AssertionError('Sampling forbidden')), redirect_stdout(io.StringIO()):
            if mode!='clean':
                try: run_audit.run(True)
                except SyntheticFailure as exc: check('synthetic' in str(exc), 'original failure preserved')
                else: raise AssertionError('Expected interruption')
                gc.collect()
                check(len(common.rows(work/'results.jsonl'))==4,'only four committed records before interrupted fifth')
                events=common.rows(work/'events.jsonl')
                check(events[-1]['kind']=='model_release_deferred','active failure has deferred release journal')
                check(len(loads)==1,'failure does not enter next model')
                common.validate_records(common.rows(work/'results.jsonl'),cases)
                analyze.validate_events(events,cases,allow_open=True)
                if mode=='before_commit':
                    with (work/'results.jsonl').open('ab') as f:f.write(b'{"partial":')
            check(run_audit.run(True)==0,'whole run/resume succeeds')
            records=common.rows(work/'results.jsonl'); events=common.rows(work/'events.jsonl')
            common.validate_records(records,cases,complete=True)
            audit, completed, last=analyze.validate_events(events,cases)
            expected={'clean':(30,30,90,90,0,0,0),
                      'during_forward':(31,30,92,91,1,1,0),
                      'before_commit':(31,31,93,93,0,0,1)}[mode]
            keys=['trajectory_starts','trajectory_completions','forward_starts','forward_completions',
                  'abandoned_trajectory_attempts','abandoned_forward_attempts','repeated_completed_trajectories']
            check(tuple(audit[k] for k in keys)==expected,'exact attempted/completed/abandoned lifecycle accounting')
            check(audit['recovered_prior_unconfirmed_model_releases']==([] if mode=='clean' else ['dolos']),
                  'recovery boundary retains prior unconfirmed release')
            check(loads==(['dolos','qwen'] if mode=='clean' else ['dolos','dolos','qwen']),'one load per model per invocation')
            check(all(ref() is None for ref in refs),'all model objects released after successful exit')
            if mode=='before_commit':
                backups=list(work.glob('results.jsonl.interrupted-*'))
                check(len(backups)==1 and backups[0].read_bytes()==b'{"partial":','incomplete tail backed up exactly')
            analyze.main()
            summary=json.loads((work/'analysis.json').read_text())
            check(summary['execution']==audit and summary['primary_expected_forwards']==90,'analysis retains correct synthetic execution')
            check(len(json.loads((work/'paired_comparison.json').read_text())['supplied_case_pairs'])==8,'all eight paired supplied paths')
            for name in ['dolos','qwen']:
                diag=json.loads((work/f'{name}_diagnostics.json').read_text())
                check(len(diag['paths'])==15 and diag['native_controls_all_greedy_and_observed_next_argmax'],'model diagnostics retain all paths/native checks')
            before=len(loads); before_scores=len(score_calls)
            check(run_audit.run(True)==0 and len(loads)==before and len(score_calls)==before_scores,'completed resume loads/scores nothing')
            # Corruption must be rejected before any model load.
            clean_records=copy.deepcopy(records); bad=copy.deepcopy(records); bad[0]['steps'][0]['raw_probability_fp32']=0.125
            write_rows(work/'results.jsonl',bad)
            try: run_audit.run(True)
            except ValueError as exc: check('checksum' in str(exc),'unsealed committed data mutation rejected')
            else: raise AssertionError('corrupt record accepted')
            check(len(loads)==before,'corrupt record rejection precedes model load')
            write_rows(work/'results.jsonl',clean_records)
            # Re-sealed journal statistics can pass lifecycle identity but must fail final binding.
            for n in ['analysis.json','dolos_diagnostics.json','qwen_diagnostics.json','paired_comparison.json']:(work/n).unlink()
            baseline_events=common.rows(work/'events.jsonl')
            for mutation, message in [('stats','statistics differ'),('timing','timing reconciliation')]:
                changed=copy.deepcopy(baseline_events)
                idx=next(i for i,e in enumerate(changed) if e['kind']=='forward_completed' and e['case_id']==cases[-1]['id'])
                event=changed[idx];event.pop('record_sha256')
                if mutation=='stats':event['stats']['raw_probability_fp32']=0.125
                else:event['forward_seconds']=0.02
                changed[idx]=common.seal(event);write_rows(work/'events.jsonl',changed)
                analyze.validate_events(changed,cases)
                try: analyze.main()
                except ValueError as exc: check(message in str(exc), 'analyzer rejects re-sealed '+mutation+' mismatch')
                else: raise AssertionError('mismatched journal accepted')
            write_rows(work/'events.jsonl',baseline_events)
            analyze.main()
            check(json.loads((work/'analysis.json').read_text())['trajectories']==30,'analyzer succeeds after restoring original journal')
        return {'mode':mode,'mock_trajectory_calls':len(score_calls),'model_object_loads':loads,'execution':audit}

scenarios=[scenario(mode) for mode in ['clean','during_forward','before_commit']]
receipt={'status':'pass','checks':checks,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'scope':'Parameter-free config objects and fabricated forward statistics exercise the actual whole runner, ResultStore, sealed journals, resume and analyzer. No pretrained model, weights, inference or random sample.',
         'scenarios':scenarios,'sources':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['common.py','run_audit.py','analyze.py','metrics.py']}}
(ROOT/'independent_review/runtime_resume_checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
