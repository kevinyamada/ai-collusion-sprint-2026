"""Reconcile independent receipts and preserve their final post-run source manifest."""
from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
names=['actual_run_review.json','report_path_review.json','report_v2_review.json']
receipts={n:json.loads((ROOT/'independent_review'/n).read_text()) for n in names}
for n,r in receipts.items():
 if r['status']!='pass':raise ValueError('Failed receipt '+n)
 for path,h in r['source_sha256'].items():
  if sha(ROOT/path)!=h:raise ValueError('Reviewed source changed '+path)
checks=sum(r['checks'] for r in receipts.values())
if checks!=49192:raise ValueError('Unexpected assertion total')
files=['bank_freeze.json','runtime_freeze.json','results.jsonl','events.jsonl','analysis.json',
 'dolos_diagnostics.json','qwen_diagnostics.json','paired_comparison.json','Path_Support_Report.json',
 'Path_Support_Report.md','report_paths.py','report_helper_preparation_note.json','Path_Support_Report_v2.json',
 'Path_Support_Report_v2.md','report_paths_v2.py']
files+=['independent_review/'+n for n in names+['Postrun_Review.md','check_actual_run.py','check_report_paths.py',
 'check_report_v2.py','freeze_postrun_review.py','actual_run_checks.log','report_path_checks.log','report_v2_checks.log',
 'final_preparation_manifest.json']]
receipt={'status':'pass','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'independent_postrun_assertions':checks,'prior_preparation_assertions':900,
 'primary_trajectories':30,'primary_forwards':930,'reconstructed_score_rows':944,
 'model_calls_during_review':0,'research_outputs_added':0,'native_control_discrepancies':[],
 'scope':'Final receipt preserves both report versions and their independent checks. Root executed the frozen audit; this review uses saved data only.',
 'source_sha256':{n:sha(ROOT/n) for n in files}}
out=ROOT/'independent_review/postrun_review_manifest.json'
if out.exists():raise ValueError('Preserve prior final manifest')
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'checks':checks,'manifest_sha256':sha(out)},indent=2))
