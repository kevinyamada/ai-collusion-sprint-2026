"""Exercise fixed-path orchestration with installed HF helpers and a parameter-free mock."""
from pathlib import Path
from types import SimpleNamespace
from contextlib import nullcontext
import copy,datetime,hashlib,json,sys
import torch
from transformers import GenerationConfig
from transformers.generation.utils import GenerationMixin
from transformers.modeling_outputs import CausalLMOutputWithPast
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import run_audit,metrics
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
class DynamicCache:
 def __init__(self):self.length=0
 def get_seq_length(self):return self.length
class ParameterFreeMock(GenerationMixin):
 def __init__(self,excluded=False):
  self.config=SimpleNamespace(is_encoder_decoder=False);self.generation_config=GenerationConfig();self.device=torch.device('cpu');self.dtype=torch.float32
  self.excluded=excluded;self.calls=[];self.prepares=[];self.updates=[];self.cache_preparations=0;self.optimizations=0
 def is_remote_code(self):return False
 def _prepare_cache_for_generation(self,cfg,kwargs,mode,batch_size,max_cache_length):
  check(batch_size==1 and max_cache_length==162,'exact cache bound');self.cache_preparations+=1;kwargs['past_key_values']=DynamicCache()
 def _valid_auto_compile_criteria(self,*a):return False
 def _optimize_model_for_decode(self):self.optimizations+=1;return nullcontext()
 def prepare_inputs_for_generation(self,*a,**kw):
  result=super().prepare_inputs_for_generation(*a,**kw);self.prepares.append({'next_sequence_length':kw.get('next_sequence_length'),'is_first_iteration':kw.get('is_first_iteration',False),'input_ids':result['input_ids'].tolist(),'position_ids':result['position_ids'].tolist(),'attention_mask_length':result['attention_mask'].shape[1]});return result
 def _update_model_kwargs_for_generation(self,outputs,kwargs,**kw):
  result=super()._update_model_kwargs_for_generation(outputs,kwargs,**kw);self.updates.append({'positions':result['position_ids'].tolist(),'mask_length':result['attention_mask'].shape[1],'cache_length':result['past_key_values'].get_seq_length()});return result
 def __call__(self,input_ids,past_key_values,attention_mask,position_ids,use_cache,logits_to_keep,return_dict):
  i=len(self.calls);check(input_ids.tolist()==([[4,5,6]] if i==0 else [[7]] if i==1 else [[8]]),'full prefill then one token')
  check(attention_mask.shape[1]==3+i,'attention length before forward');check(position_ids.tolist()==([list(range(3))] if i==0 else [[2+i]]),'position slice before forward')
  check(past_key_values.get_seq_length()==(0 if i==0 else 2+i),'cache length before forward');check(use_cache and logits_to_keep==1 and return_dict,'generation forward kwargs')
  self.calls.append(input_ids.tolist());past_key_values.length+=input_ids.shape[1]
  logits=torch.linspace(-20,-1,151936,dtype=torch.float32).view(1,1,-1)
  target=[7,8,330][i];logits[0,0,target]=2.
  if i==0 and self.excluded:logits[0,0,7]=-1000.
  if i==2:logits[0,0,30625]=1.
  return CausalLMOutputWithPast(logits=logits,past_key_values=past_key_values)

def run_one(excluded):
 model=ParameterFreeMock(excluded);case={'base_input_token_ids':[4,5,6],'trajectory_token_ids':[7,8],'observed_next_token_id':330};cfg,processors,public_config=run_audit.processors_for(model,3);events=[]
 check(cfg.max_length==public_config["max_length"]==163,"actual normalized generation length")
 check(cfg._eos_token_tensor.tolist()==[151645,151643],"prepared EOS tensor")
 result=run_audit.score_trajectory(SimpleNamespace(torch=torch),model,case,cfg,processors,lambda kind,**kw:events.append({'kind':kind,**copy.deepcopy(kw)}))
 check(len(model.calls)==3 and result['forward_count']==3,'N+1 calls')
 check(model.cache_preparations==1 and model.optimizations==2,'fresh single cache and cached optimize contexts')
 check([p['input_ids'] for p in model.prepares]==[[[4,5,6]],[[7]],[[8]]],'installed prepare slicing')
 check([p['attention_mask_length'] for p in model.prepares]==[3,4,5],'installed mask progression')
 check([x['mask_length'] for x in model.updates]==[4,5,6],'update after every forward')
 check([x['cache_length'] for x in model.updates]==[3,4,5],'cache progresses actual consumed tokens')
 check([e['kind'] for e in events]==['forward_started','forward_completed']*3,'all mock forwards journaled')
 check(result['endpoint']['native_observed_next']['is_raw_argmax'],'actual observed next scored separately')
 check(result['endpoint']['target']['sampler_positive_mass'],'endpoint remains conditionally supported')
 check(result['steps'][1]['sampler_positive_mass'],'later forced state conditionally supported')
 p=result['path_summary'];check(p['first_sampler_zero_token_index']==(0 if excluded else None),'first zero index')
 check(p['prefix_and_marker_sampler_positive_mass']==(not excluded),'zero remains absorbing')
 if excluded:
  check(result['steps'][0]['first_filter_excluding_target']=='top_k','actual filter exclusion');check(p['per_token_cumulative'][1]['conditional_after_prior_sampler_zero'],'counterfactual later stage labeled');check(p['prefix_sampler_log_probability_from_fp32'] is None and p['prefix_and_marker_sampler_log_probability_from_fp32'] is None,'no restored mass')
 else:check(p['greedy_exact_path_supported'],'valid native-like greedy control')
 # Reconstruct exact installed nucleus processing from saved sparse post-top-k logits.
 for row in [*result['steps'],result['endpoint']['target'],result['endpoint']['native_observed_next']]:
  stage=torch.full((1,151936),-float('inf'),dtype=torch.float32)
  for c in row['topk_finite_candidates']:stage[0,c['id']]=c['logit_fp32']
  final=processors[1](torch.tensor([[4,5,6]]),stage);prob=torch.softmax(final,-1)[0,row['token_id']].item()
  check(prob==row['sampler_probability_fp32'],'sparse candidates reconstruct exact FP32 probability');check(bool(torch.isfinite(final[0,row['token_id']]))==row['topp_kept'],'sparse top-p support')
 return {'excluded_first_token':excluded,'mock_forward_calls':len(model.calls),'first_zero_index':p['first_sampler_zero_token_index'],'joint_mass_supported':p['prefix_and_marker_sampler_positive_mass']}
results=[run_one(False),run_one(True)]
receipt={'status':'pass','checks':checks,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mock_paths':results,'scope':'Parameter-free mock returns synthetic logits; installed HF prepare/_prefill/update helpers exercised. No pretrained model construction, weights or actual model inference.','sources':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['run_audit.py','metrics.py','common.py']}}
(ROOT/'independent_review/cached_path_checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
