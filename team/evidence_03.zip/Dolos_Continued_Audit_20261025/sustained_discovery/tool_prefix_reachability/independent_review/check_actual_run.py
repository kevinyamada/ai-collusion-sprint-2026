"""Post-run saved-data reconstruction only; no model, weights, generation or sampling.

Implemented after root launch in response to the pre-execution independent-audit
request. It adds no experiments or outcome selection. Run only after root confirms
the model process has exited and all 30 results plus primary analysis exist.
"""
from pathlib import Path
from collections import Counter
import datetime, hashlib, importlib.metadata, json, math, re, sys
import torch
from transformers.generation.logits_process import TopPLogitsWarper

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import common, analyze

checks=0
reconstructed_rows=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def equal(actual,expected,label):check(actual==expected,label)
def dump(name,data):
 p=ROOT/'independent_review'/name
 if p.exists():raise ValueError('Preserve prior audit receipt: '+str(p))
 common.write(p,data)

torch.set_num_threads(8)
torch.multinomial=lambda *a,**kw:(_ for _ in ()).throw(AssertionError('No sampling permitted'))
_,cases,installed=common.validate(weights=False)
primary_names=['cases.jsonl','bank_metadata.json','bank_freeze.json','runtime_freeze.json',
 'results.jsonl','events.jsonl','analysis.json','dolos_diagnostics.json','qwen_diagnostics.json','paired_comparison.json']
before={n:digest(ROOT/n) for n in primary_names}
prepared=json.loads((ROOT/'independent_review/final_preparation_manifest.json').read_text())
for n,h in prepared['sources'].items():equal(digest(ROOT/n),h,'pre-execution reviewed source '+n)
records=common.rows(ROOT/'results.jsonl');events=common.rows(ROOT/'events.jsonl')
common.validate_records(records,cases,complete=True)
execution,completed,last=analyze.validate_events(events,cases)
frozen_analysis=json.loads((ROOT/'analysis.json').read_text())
equal(frozen_analysis['results_sha256'],before['results.jsonl'],'analysis result hash')
equal(frozen_analysis['events_sha256'],before['events.jsonl'],'analysis event hash')
equal(frozen_analysis['runtime_freeze_sha256'],before['runtime_freeze.json'],'analysis runtime freeze hash')
equal(frozen_analysis['execution'],execution,'frozen execution accounting')
equal(frozen_analysis['primary_expected_forwards'],930,'930 primary forwards')
equal(frozen_analysis['trajectories'],30,'30 primary trajectories')
check(frozen_analysis['no_generation_performed'] is True,'no generation flag')
equal(sum(r['forward_count'] for r in records),930,'record forward sum')

kind_counts=Counter(e['kind'] for e in events)
latest_forwards={}
for e in events:
 common.verify_seal(e)
 if e['kind']=='forward_completed' and e['attempt']==last[e['case_id']]['attempt']:
  key=(e['case_id'],e['step']);check(key not in latest_forwards,'unique latest completed step');latest_forwards[key]=e
equal(len(latest_forwards),930,'all latest forward events')

def reconstruct(row,ids):
 global reconstructed_rows
 reconstructed_rows+=1
 tid=row['token_id'];candidates=row['topk_finite_candidates'];ci=[c['id'] for c in candidates]
 check(0<=tid<151936,'target vocabulary range')
 check(ci==sorted(set(ci)) and all(0<=i<151936 for i in ci),'unique ordered candidate ids')
 check(len(ci)>=50,'at least k finite candidates')
 check(all(math.isfinite(c['logit_fp32']) for c in candidates),'finite candidate logits')
 equal(len(ci),row['topk_finite_count'],'top-k retained count')
 stage=torch.full((1,151936),-float('inf'),dtype=torch.float32)
 for c in candidates:stage[0,c['id']]=c['logit_fp32']
 cutoff=min(c['logit_fp32'] for c in candidates)
 equal(cutoff,row['topk_cutoff_logit_fp32'],'top-k cutoff reconstructed')
 equal(sum(c['logit_fp32']>cutoff for c in candidates)<50,True,'strict cutoff rank')
 keep=tid in ci
 equal(keep,row['topk_kept'],'top-k target membership')
 if keep:
  equal(float(stage[0,tid]),row['raw_logit_fp32'],'retained target raw logit')
  equal(sum(c['logit_fp32']>row['raw_logit_fp32'] for c in candidates)+1,row['raw_rank_strict'],'retained raw rank')
  equal(sum(c['logit_fp32']==row['raw_logit_fp32'] for c in candidates),row['raw_logit_tie_count'],'retained raw tie count')
 else:
  check(row['raw_logit_fp32']<cutoff and row['raw_rank_strict']>50,'excluded target below top-k cutoff')
 equal(float(torch.tensor(row['raw_logit_fp32'],dtype=torch.float32)-torch.tensor(cutoff,dtype=torch.float32)),row['topk_target_margin_fp32'],'top-k cutoff margin')
 equal(int(stage.argmax(-1)),row['raw_argmax_id'],'argmax from sparse retained row')
 equal(tid==row['raw_argmax_id'],row['is_raw_argmax'],'target argmax flag')
 top10=row['raw_top10'];check(len(top10)==10 and len({c['id'] for c in top10})==10,'raw top10 identities')
 equal([c['logit_fp32'] for c in top10],sorted([c['logit_fp32'] for c in candidates],reverse=True)[:10],'raw top10 score multiset/order')
 for c in top10:equal(float(stage[0,c['id']]),c['logit_fp32'],'raw top10 candidate membership')
 check(re.fullmatch('[0-9a-f]{64}',row['raw_logits_sha256']) is not None,'raw logit fingerprint syntax')
 equal(row['raw_logit_fp32']-row['raw_logsumexp_fp64'],row['raw_log_probability_fp64'],'raw log probability arithmetic')
 equal(math.exp(row['raw_log_probability_fp64']),row['raw_probability_fp64'],'raw FP64 exponential')
 check(0<=row['raw_probability_fp32']<=1,'raw FP32 probability range only')
 # Full sparse row recreates actual sort positions, including all removed -inf IDs.
 inp=torch.tensor([ids],dtype=torch.long)
 filtered=TopPLogitsWarper(0.9,min_tokens_to_keep=1)(inp,stage)
 final=torch.softmax(filtered,dim=-1)
 fp=float(final[0,tid]);finite=bool(torch.isfinite(filtered[0,tid]))
 equal(finite,row['topp_kept'],'actual installed top-p membership')
 equal(int(torch.isfinite(filtered).sum()),row['topp_finite_count'],'top-p finite count')
 equal(fp,row['sampler_probability_fp32'],'exact reconstructed FP32 sampler entry')
 equal(fp>0,row['sampler_positive_mass'],'positive sampler entry')
 equal(finite and fp==0,row['numerical_zero_despite_finite_score'],'finite-score numerical-zero flag')
 equal(None if finite else ('top_k' if not keep else 'top_p'),row['first_filter_excluding_target'],'exclusion stage')
 sorted_logits,sorted_ids=torch.sort(stage,descending=False)
 cumulative=torch.softmax(sorted_logits,dim=-1).cumsum(dim=-1)
 pos=int((sorted_ids[0]==tid).nonzero().item())
 equal(pos,row['topp_target_ascending_index'],'ascending full-vocabulary target position')
 equal(float(cumulative[0,pos]),row['topp_target_cumulative_probability_fp32'],'ascending top-p cumulative probability')
 threshold=torch.tensor(1-0.9,dtype=torch.float32)
 equal(float(threshold),row['topp_removal_threshold_fp32'],'FP32 removal threshold')
 equal(float(cumulative[0,pos]-threshold),row['topp_target_removal_margin_fp32'],'FP32 removal margin')
 lse=float(torch.logsumexp(filtered.double(),dim=-1))
 equal(lse,row['postfilter_logsumexp_fp64'],'filtered FP64 logsumexp')
 equal(row['raw_logit_fp32']-lse if finite else None,row['postfilter_log_probability_fp64'],'filtered FP64 log probability')

def cumulative_independent(steps,ep):
 raw=filtered=nominal=0.0;first_filter=first_zero=None;greedy=True;per=[]
 for i,s in enumerate(steps):
  raw+=s['raw_log_probability_fp64'];greedy=greedy and s['is_raw_argmax']
  if not s['topp_kept'] and first_filter is None:first_filter=i
  if s['sampler_probability_fp32']==0 and first_zero is None:first_zero=i
  filtered=None if filtered is None or not s['topp_kept'] else filtered+s['postfilter_log_probability_fp64']
  nominal=None if nominal is None or s['sampler_probability_fp32']==0 else nominal+math.log(s['sampler_probability_fp32'])
  per.append({'token_index':i,'cumulative_raw_log_probability_fp64':raw,
   'cumulative_postfilter_log_probability_fp64':filtered,'cumulative_sampler_log_probability_from_fp32':nominal,
   'cumulative_filtered_score_support':filtered is not None,'cumulative_sampler_positive_mass':nominal is not None,
   'conditional_after_prior_sampler_zero':first_zero is not None and i>first_zero})
 return {'per_token_cumulative':per,'prefix_raw_log_probability_fp64':raw,
  'prefix_postfilter_log_probability_fp64':filtered,'prefix_sampler_log_probability_from_fp32':nominal,
  'prefix_filtered_score_support':filtered is not None,'prefix_sampler_positive_mass':nominal is not None,
  'first_filter_exclusion_token_index':first_filter,'first_sampler_zero_token_index':first_zero,'greedy_exact_path_supported':greedy,
  'prefix_and_marker_raw_log_probability_fp64':raw+ep['raw_log_probability_fp64'],
  'prefix_and_marker_postfilter_log_probability_fp64':None if filtered is None or not ep['topp_kept'] else filtered+ep['postfilter_log_probability_fp64'],
  'prefix_and_marker_sampler_log_probability_from_fp32':None if nominal is None or ep['sampler_probability_fp32']==0 else nominal+math.log(ep['sampler_probability_fp32']),
  'prefix_and_marker_sampler_positive_mass':nominal is not None and ep['sampler_probability_fp32']>0}

path_rows=[];native_discrepancies=[];all_step_reasons=Counter()
for r,c in zip(records,cases):
 cid=c['id'];n=len(c['trajectory_token_ids']);base=c['base_input_token_ids'];tr=c['trajectory_token_ids']
 equal(r['request'],common.request(c),'full request and pins '+cid)
 equal(r['environment']['device'],'cpu','CPU device')
 equal(r['environment']['dtype'],'torch.float32','FP32 model dtype')
 equal(r['environment']['threads'],8,'eight runtime threads')
 for package,version in r['environment']['packages'].items():equal(importlib.metadata.version(package),version,'runtime package '+package)
 equal(r['processor_classes'],['TopKLogitsWarper','TopPLogitsWarper'],'processor classes')
 for k,v in common.KWARGS.items():equal(r['configured_generation'][k],v,'configured sampler '+k)
 equal(r['configured_generation']['max_length'],len(base)+160,'normalized max length')
 equal(r['prepared_special_tokens'],{'_bos_token_tensor':151643,'_eos_token_tensor':[151645,151643],
  '_pad_token_tensor':151643,'_decoder_start_token_tensor':None},'prepared special token values')
 equal(r['cache_type'],'DynamicCache','cache convention')
 check(r['runtime_seconds']>=r['forward_seconds']>=0 and r['model_load_seconds']>=0,'nonnegative runtime bounds')
 equal(last[cid]['result_sha256'],common.batch_support.make_request_id({k:r[k] for k in analyze.RESULT_KEYS}),'latest completed result hash')
 equal(last[cid]['response_request_id'],r['request_id'],'latest request identity')
 timings=[]
 for i,s in enumerate([*r['steps'],r['endpoint']['target']]):
  equal(s['token_id'],tr[i] if i<n else 30625,'exact forced/endpoint token')
  equal(s['token_index'],i,'token index')
  equal(s['context_tokens'],len(base)+i,'context length')
  event=latest_forwards[(cid,i)];equal(event['stats'],s,'forward journal stats binding')
  equal(event['native_observed_next'],None if i<n else r['endpoint']['native_observed_next'],'observed next journal binding')
  check(event['forward_seconds']>=0,'nonnegative forward time');timings.append(event['forward_seconds'])
  reconstruct(s,base+tr[:i])
  if i<n:all_step_reasons[(c['model'],s['first_filter_excluding_target'] or 'kept')]+=1
 equal(sum(timings),r['forward_seconds'],'exact cumulative forward timing')
 observed=r['endpoint']['native_observed_next']
 if c['kind']=='native_control':
  check(observed is not None,'native observed endpoint retained')
  equal(observed['token_id'],c['observed_next_token_id'],'same-model observed next token')
  reconstruct(observed,base+tr)
  for k in ['raw_logits_sha256','raw_argmax_id','raw_logsumexp_fp64','topk_finite_candidates','postfilter_logsumexp_fp64']:
   equal(observed[k],r['endpoint']['target'][k],'same endpoint row '+k)
  disagree=[i for i,s in enumerate(r['steps']) if not s['is_raw_argmax']]
  if disagree or not observed['is_raw_argmax']:native_discrepancies.append({'case_id':cid,'non_argmax_prefix_indices':disagree,'observed_next_is_argmax':observed['is_raw_argmax']})
 else:equal(observed,None,'supplied path has no native next score')
 summary=cumulative_independent(r['steps'],r['endpoint']['target'])
 for k,v in summary.items():equal(r['path_summary'][k],v,'independent cumulative accounting '+k)
 compact=next(x for x in frozen_analysis['paths'] if x['case_id']==cid)
 for key in ['model','kind','source_case_ids','source_expected_positive','native_control_source_id','full_input_sha256']:
  equal(compact[key],c[key],'frozen compact input identity '+key)
 equal(compact['forced_prefix_tokens'],n,'frozen forced prefix length')
 for k in ['prefix_raw_log_probability_fp64','prefix_postfilter_log_probability_fp64','prefix_sampler_log_probability_from_fp32',
  'prefix_filtered_score_support','prefix_sampler_positive_mass','first_filter_exclusion_token_index','first_sampler_zero_token_index',
  'greedy_exact_path_supported','prefix_and_marker_sampler_log_probability_from_fp32','prefix_and_marker_sampler_positive_mass']:
  equal(compact[k],summary[k],'frozen compact summary '+k)
 ep=r['endpoint']['target'];first=summary['first_sampler_zero_token_index'];firstrow=r['steps'][first] if first is not None else None
 equal(compact['endpoint_marker_raw_probability_fp32'],ep['raw_probability_fp32'],'frozen endpoint raw probability')
 equal(compact['endpoint_marker_sampler_probability_fp32'],ep['sampler_probability_fp32'],'frozen endpoint sampler probability')
 equal(compact['endpoint_marker_raw_log_probability_fp64'],ep['raw_log_probability_fp64'],'frozen endpoint raw log probability')
 equal(compact['endpoint_marker_sampler_positive_mass'],ep['sampler_positive_mass'],'frozen endpoint support')
 equal(compact['first_sampler_zero_token_id'],tr[first] if first is not None else None,'frozen first zero token')
 equal(compact['first_sampler_zero_token_string'],c['trajectory_token_strings'][first] if first is not None else None,'frozen first zero token string')
 equal(compact['first_sampler_zero_reason'],firstrow['first_filter_excluding_target'] or 'finite-score FP32 probability underflow' if firstrow else None,'frozen first zero reason')
 equal(compact['native_observed_next_matches_raw_argmax'],observed['is_raw_argmax'] if observed else None,'frozen observed next parity')
 path_rows.append({'case_id':cid,'model':c['model'],'kind':c['kind'],'source_case_ids':c['source_case_ids'],
  'native_control_source_id':c['native_control_source_id'],'source_expected_positive':c['source_expected_positive'],
  'forced_tokens':n,'prefix_sampler_supported':summary['prefix_sampler_positive_mass'],
  'first_zero_index':first,'first_zero_token_id':tr[first] if first is not None else None,
  'first_zero_token_string':c['trajectory_token_strings'][first] if first is not None else None,
  'first_zero_reason':firstrow['first_filter_excluding_target'] or 'finite-score numerical zero' if firstrow else None,
  'first_zero_raw_rank':firstrow['raw_rank_strict'] if firstrow else None,
  'first_zero_topk_margin_fp32':firstrow['topk_target_margin_fp32'] if firstrow else None,
  'first_zero_topp_margin_fp32':firstrow['topp_target_removal_margin_fp32'] if firstrow else None,
  'prefix_raw_log_probability_fp64':summary['prefix_raw_log_probability_fp64'],
  'prefix_nominal_fp32_log_score':summary['prefix_sampler_log_probability_from_fp32'],
  'endpoint_marker_raw_probability_fp32':ep['raw_probability_fp32'],
  'endpoint_marker_sampler_probability_fp32':ep['sampler_probability_fp32'],
  'prefix_plus_marker_supported':summary['prefix_and_marker_sampler_positive_mass'],
  'prefix_plus_marker_nominal_fp32_log_score':summary['prefix_and_marker_sampler_log_probability_from_fp32'],
  'prefix_all_raw_argmax':summary['greedy_exact_path_supported'],
  'observed_next_raw_argmax':observed['is_raw_argmax'] if observed else None})

equal(reconstructed_rows,944,'930 endpoint/step rows plus fourteen native observed endpoints')
check(len({p['case_id'] for p in frozen_analysis['paths']})==len(frozen_analysis['paths'])==30,'complete unique primary compact table')
for model in ['dolos','qwen']:
 diag=json.loads((ROOT/f'{model}_diagnostics.json').read_text())
 equal(diag['source_results_sha256'],before['results.jsonl'],'model diagnostic source hash')
 equal(diag['paths'],[p for p in frozen_analysis['paths'] if p['model']==model],'all diagnostic path rows')
 equal(diag['native_controls_all_greedy_and_observed_next_argmax'],
  all(p['prefix_all_raw_argmax'] and p['observed_next_raw_argmax'] for p in path_rows if p['model']==model and p['kind']=='native_control'),'native diagnostic integrity flag')
paired=json.loads((ROOT/'paired_comparison.json').read_text())
equal(paired['source_results_sha256'],before['results.jsonl'],'paired source hash')
equal(len(paired['supplied_case_pairs']),8,'eight supplied input pairs')
for pair in paired['supplied_case_pairs']:
 for model in ['dolos','qwen']:
  equal(pair[model],next(p for p in frozen_analysis['paths'] if p['model']==model and p['kind']=='supplied' and p['source_case_ids']==[pair['source_case_id']]),'exact paired compact row')
 equal(pair['dolos']['full_input_sha256'],pair['qwen']['full_input_sha256'],'matched supplied full input hash')

for n,h in before.items():equal(digest(ROOT/n),h,'primary artifact unchanged '+n)
aggregates=[]
for model in ['dolos','qwen']:
 for kind in ['supplied','native_control']:
  selected=[p for p in path_rows if p['model']==model and p['kind']==kind]
  aggregates.append({'model':model,'kind':kind,'paths':len(selected),
   'prefix_supported':sum(p['prefix_sampler_supported'] for p in selected),
   'prefix_plus_marker_supported':sum(p['prefix_plus_marker_supported'] for p in selected),
   'endpoint_marker_positive':sum(p['endpoint_marker_sampler_probability_fp32']>0 for p in selected),
   'first_zero_reasons':dict(Counter(p['first_zero_reason'] or 'none' for p in selected))})
receipt={'status':'pass','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,
 'scope':'Saved-data reconstruction only. Helper implemented after launch under pre-execution audit request; no additional experiment allocation, model/weight loading, inference or sampling.',
 'selection_provenance':'Root communicated a separate TLS aggregate before bank freeze and a source40 aggregate after bank freeze but before final runtime clearance. During the post-launch wait, a team-status call incidentally exposed another agent\'s source-review summary containing several blinded row judgment notes and the 730-response aggregate. This occurred after inputs/runtime were frozen and the saved-data checker was drafted; no selection, metric or scope changed. No raw study artifact/output was opened. No blindness to communicated or incidentally exposed summaries is claimed.',
 'trajectories':len(records),'committed_forwards':930,'reconstructed_rows':reconstructed_rows,
 'execution':execution,'event_kind_counts':dict(kind_counts),'native_control_discrepancies':native_discrepancies,
 'aggregates':aggregates,'forced_token_filter_counts':[{'model':m,'reason':reason,'tokens':n} for (m,reason),n in sorted(all_step_reasons.items())],
 'paths':path_rows,'source_sha256':before,'checker_sha256':digest(Path(__file__)),
 'limits':['No full raw vocabulary rows were retained. Raw logsumexp, excluded-target exact rank/tie count, full-row hash and raw FP32 softmax entry cannot independently be reconstructed from sparse top-k candidates; their internal arithmetic/provenance is checked.',
 'Exact recorded top-k candidates allow reconstruction of full filtered row, actual installed top-p decisions, FP32 softmax entries, retained-target ranks and argmax.',
 'Products of FP32 entries are nominal path scores. Prefix plus marker is an invalid-prefix event, not a completed malformed EOS call.',
 'A supported or excluded exact path does not determine planted intent, prevalence or all alternative tokenizations/routes. Native control inconsistencies are retained.']}
dump('actual_run_review.json',receipt)
print(json.dumps({'status':'pass','checks':checks,'execution':execution,'aggregates':aggregates,
 'native_control_discrepancies':native_discrepancies,'receipt_sha256':digest(ROOT/'independent_review/actual_run_review.json')},indent=2))
