"""Verify additive raw/postfilter display clarification against immutable v1 and data."""
from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
v1=json.loads((ROOT/'Path_Support_Report.json').read_text())
v2=json.loads((ROOT/'Path_Support_Report_v2.json').read_text())
md1=(ROOT/'Path_Support_Report.md').read_text();md2=(ROOT/'Path_Support_Report_v2.md').read_text()
prior=json.loads((ROOT/'independent_review/report_path_review.json').read_text())
for n,h in prior['source_sha256'].items():check(sha(ROOT/n)==h,'original report and sources preserved '+n)
check(v2['paths']==v1['paths'],'all30 path objects unchanged')
check(len(v2['paths'])==30,'exact path count')
for key,name in [('results_sha256','results.jsonl'),('analysis_sha256','analysis.json'),
 ('runtime_freeze_sha256','runtime_freeze.json'),('report_helper_sha256','report_paths_v2.py')]:check(v2[key]==sha(ROOT/name),'v2 source hash '+key)
for p in v2['paths']:
 heading='## '+p['case_id']+'\n';check(md2.count(heading)==1,'one v2 heading')
 section=md2.split(heading,1)[1].split('\n## ',1)[0]
 oldsection=md1.split(heading,1)[1].split('\n## ',1)[0]
 expected=f"Conditional endpoint marker probabilities: raw FP32 softmax **{p['endpoint_marker_raw_probability_fp32']:.9g}**; postfilter FP32 sampler **{p['endpoint_marker_sampler_probability_fp32']:.9g}**."
 check(section.count(expected)==1,'explicit raw and postfilter pair for '+p['case_id'])
 oldmodel=next(line for line in oldsection.splitlines() if line.startswith('Model: '))
 newmodel=next(line for line in section.splitlines() if line.startswith('Model: '))
 check(section.replace(newmodel,'DISPLAY LABELS')==oldsection.replace(oldmodel,'DISPLAY LABELS'),'all exclusion evidence remains identical')
check(md2.count('raw FP32 softmax **')==30 and md2.count('postfilter FP32 sampler **')==30,'all30 explicitly labelled pairs')
check(v2['prefill_application_caveat'] in md2,'direct-prefill caveat displayed')
records=[json.loads(line) for line in (ROOT/'results.jsonl').read_text().splitlines()]
allrows=[row for r in records for row in [*r['steps'],r['endpoint']['target'],*([r['endpoint']['native_observed_next']] if r['endpoint']['native_observed_next'] else [])]]
check(len(allrows)==944,'all944 primary scored rows available')
underflow_count=sum(row['numerical_zero_despite_finite_score'] for row in allrows)
check(underflow_count==0,'no finite-score FP32 probability underflow')
receipt={'status':'pass','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,
 'scope':'Post-run additive display clarification only; all primary rows unchanged and no model calls.',
 'finite_score_fp32_underflow_rows':underflow_count,'displayed_probability_pairs':30,
 'source_sha256':{n:sha(ROOT/n) for n in ['Path_Support_Report.json','Path_Support_Report.md','Path_Support_Report_v2.json',
 'Path_Support_Report_v2.md','report_paths.py','report_paths_v2.py','analysis.json','results.jsonl','runtime_freeze.json',
 'independent_review/report_path_review.json']},'checker_sha256':sha(Path(__file__))}
out=ROOT/'independent_review/report_v2_review.json'
if out.exists():raise ValueError('Preserve v2 review')
out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
