"""Independent fixed-input/template/pair/plan checks; cached tokenizer only, no ML."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from collections import Counter
import datetime,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import common
from transformers import AutoTokenizer
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=ROOT.parent/'external_tool_generalization';allsource=common.rows(source/'cases.jsonl')
sourcefreeze=json.loads((source/'bank_freeze.json').read_text())
check(sha(source/'cases.jsonl')==sourcefreeze['sources']['cases.jsonl'],'original case bank remains frozen')
cases=common.rows(ROOT/'cases.jsonl');pairs=json.loads((ROOT/'pairs.json').read_text());meta=json.loads((ROOT/'bank_metadata.json').read_text())
wanted=[f'ETG_A_{v}_{kind}_{sub}' for v in [1,2,3] for kind,sub in [('opaque','S1'),('phrase','S1'),('filler','S1'),('opaque','S3')]]
check([c['id'] for c in cases]==wanted,'all twelve fixed existing contexts in intended order')
check({c['id'] for c in allsource if c.get('cohort')=='fresh_value'}==set(wanted),'no fresh-value source condition omitted')
check(len({tuple(c['input_token_ids']) for c in cases})==12,'twelve distinct complete inputs')
check(meta['source_cases_sha256']==sha(source/'cases.jsonl'),'source cases fingerprint')
check(meta['source_bank_freeze_sha256']==sha(source/'bank_freeze.json'),'source bank freeze fingerprint')
check(meta['tokenizer']=={'repo':'Qwen/Qwen2.5-1.5B-Instruct','revision':'989aa7980e4cf806f80c7fef2b1adb7bc71aa306'},'shared pinned tokenizer')
tok=AutoTokenizer.from_pretrained(meta['tokenizer']['repo'],revision=meta['tokenizer']['revision'],local_files_only=True,token=False)
check(common.digest({'template':tok.chat_template})==meta['chat_template_sha256'],'exact chat template digest convention')
check(hashlib.sha256(tok.chat_template.encode()).hexdigest()==json.loads((source/'bank_metadata.json').read_text())['chat_template_sha256'],'same template as original source bank')
snapshot=common.tokenizer_snapshot()
for n,h in meta['tokenizer_metadata_sha256'].items():check(sha(snapshot/n)==h,'cached tokenizer/config metadata '+n)
config=json.loads((snapshot/'config.json').read_text())
check(config['num_hidden_layers']==28 and config['hidden_size']==1536,'actual pinned layer/activation dimensions')
check(config['use_cache'] is True and config['use_sliding_window'] is False,'original cache and attention defaults')
check(config['num_attention_heads']==12 and config['num_key_value_heads']==2,'native attention dimensions')
for s in meta['installed_source_files']:check(sha(Path(s['path']))==s['sha256'],'installed source '+s['path'])
sites={'attention26':'model.layers.26.self_attn.o_proj','attention27':'model.layers.27.self_attn.o_proj','mlp27':'model.layers.27.mlp'}
groups={'mlp27':['mlp27'],'attention26_27':['attention26','attention27'],'union':['attention26','attention27','mlp27']}
check(common.SITES==meta['sites']==sites,'exact post-projection/MLP output sites')
check(common.GROUPS==meta['groups']==groups,'exact three intervention groups')
for name,item in meta['alternatives'].items():check(tok.decode([item['token_id']],skip_special_tokens=False,clean_up_tokenization_spaces=False)==item['decoded'],'fixed alternative decode '+name)
check(tok.decode([497],skip_special_tokens=False)=='",','canonical terminal token interpretation')
cm={c['id']:c for c in cases};case_summaries=[]
for c in cases:
 original=[s for s in allsource if s['id']==c['id']]
 check(len(original)==1 and c==original[0],'complete source case copied without edits '+c['id'])
 check(c['available'] and c['kind']=='forward','available supplied-prefix context')
 check(c['raw_tools']==cases[0]['raw_tools'],'same tool schema in all contexts')
 check(c['logical_messages'][1:]==cases[0]['logical_messages'][1:],'same user in all contexts')
 text=tok.apply_chat_template(c['logical_messages'],tools=c['raw_tools'],tokenize=False,add_generation_prompt=True)
 expanded=tok.apply_chat_template(c['messages'],tokenize=False,add_generation_prompt=True)
 check(text==expanded==c['rendered_chat'],'exact logical/expanded rendering')
 base=tok.apply_chat_template(c['logical_messages'],tools=c['raw_tools'],tokenize=True,add_generation_prompt=True,return_dict=False)
 check(base==c['base_input_token_ids'],'exact logical chat IDs')
 check(tok.apply_chat_template(c['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)==base,'exact expanded chat IDs')
 check(c['full_input_text']==text+c['assistant_prefix'],'full text is exact source prefix extension')
 ids=tok(c['full_input_text'],add_special_tokens=False)['input_ids']
 check(ids==c['input_token_ids'],'full input IDs')
 check(tok.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)==c['full_input_text'],'full lossless decoding')
 check(ids[:len(base)]==base,'base token prefix identity')
 forced=ids[len(base):]
 check(len(forced)==31 and ids[-1]==497,'31 forced tokens ending at canonical delimiter')
 check(not ({151645,151643}&set(forced)),'no EOS in forced prefix')
 check(len(ids)=={1:236,2:233,3:237}[c['value_index']],'fixed per-value full input length')
 case_summaries.append({'id':c['id'],'input_tokens':len(ids),'base_tokens':len(base),'terminal_index_zero_based':len(ids)-1,
  'terminal_id':ids[-1],'input_ids_sha256':common.digest({'ids':ids})})
expected_pairs=[]
for v in [1,2,3]:
 a=cm[f'ETG_A_{v}_opaque_S1'];ai=a['input_token_ids']
 for kind,sub in [('phrase','S1'),('filler','S1'),('opaque','S3')]:
  b=cm[f'ETG_A_{v}_{kind}_{sub}'];bi=b['input_token_ids'];diff=[i for i,(x,y) in enumerate(zip(ai,bi)) if x!=y]
  check(len(ai)==len(bi),'exact within-pair absolute final-position alignment')
  check(ai[-1]==bi[-1]==497,'same terminal token identity')
  check(a['raw_tools']==b['raw_tools'] and a['logical_messages'][1:]==b['logical_messages'][1:],'same task/schema within pair')
  if sub=='S3':check(diff==[len(ai)-5] and ai[-5]==369 and bi[-5]==315,'single for/of change four positions before end')
  else:
   check(a['assistant_prefix']==b['assistant_prefix'],'identical assistant prefix for value contrast')
   check(ai[-209:]==bi[-209:] and ai[-210]!=bi[-210],'exactly209 unchanged suffix tokens')
  expected_pairs.append({'id':f'AI_{v}_{kind}_{sub}','value_index':v,'contrast':'subject' if sub=='S3' else 'value',
   'control_kind':kind,'opaque_s1':a['id'],'control':b['id'],'input_tokens':len(ai),'terminal_index_zero_based':len(ai)-1,
   'terminal_token_id':497,'different_token_indices':diff})
check(pairs==expected_pairs,'complete nine-pair metadata and differences')
check(meta['counts']=={'baselines':12,'union_self_shams':12,'matched_pairs':9,'directions_per_pair':2,'patch_groups':3,'patched_forwards':54,'total_forwards':78},'fixed78-call allocation')
# Plan needs freeze fingerprints; temporary synthetic manifests avoid premature production freezes.
with TemporaryDirectory(prefix='dolos-activation-plan-review-') as temp:
 tmp=Path(temp)
 for name in ['bank_freeze.json','runtime_freeze.json']:(tmp/name).write_text('{"synthetic_plan_check":true}\n')
 with patch.object(common,'ROOT',tmp):plan=common.plan(cases,pairs)
check(len(plan)==78 and len({rid for rid,_ in plan})==78,'78 unique planned requests')
check(Counter(req['kind'] for _,req in plan)=={'baseline':12,'sham':12,'patch':54},'exact request type allocation')
for i,c in enumerate(cases):
 baseline=plan[2*i][1];sham=plan[2*i+1][1]
 check(baseline['kind']=='baseline' and baseline['target_case']==c and baseline['source_case'] is None and baseline['sites']==[],'one unmodified baseline per context')
 check(sham['kind']=='sham' and sham['target_case']==sham['source_case']==c and sham['group']=='union' and sham['sites']==groups['union'],'immediate self union sham')
for rid,req in plan:
 check(common.digest(req)==rid,'stable request identity')
 check(req['model']==common.D and req['model']['name']=='dolos','Dolos only')
 check(req['settings']['use_cache'] is True and req['settings']['logits_to_keep']==0 and req['settings']['generation'] is None,'original full-forward convention only')
 check(req['settings']['threads']==8 and req['settings']['device']=='cpu' and req['settings']['dtype']=='float32','CPU FP32 eight threads')
 if req['kind']=='patch':
  pair=next(p for p in pairs if p['id']==req['pair']);source_id=req['source_case']['id'];target_id=req['target_case']['id']
  expected=(pair['control'],pair['opaque_s1']) if req['direction']=='control_to_opaque' else (pair['opaque_s1'],pair['control'])
  check((source_id,target_id)==expected,'correct direction and exact within-value pair')
  check(req['sites']==groups[req['group']],'exact group sites')
check(Counter(req['pair'] for _,req in plan if req['kind']=='patch')=={p['id']:6 for p in pairs},'six interventions for every fixed pair')
check(Counter(req['group'] for _,req in plan if req['kind']=='patch')=={g:18 for g in groups},'eighteen patches per group')
prior=json.loads((ROOT/'prior_dolos_baselines.json').read_text())
check(prior['source_results_sha256']==sha(source/'results.jsonl'),'calibration source-results fingerprint')
check([x['case_id'] for x in prior['baselines']]==wanted,'exactly twelve calibration cases in fixed order')
# Source rows are filtered by model/task metadata; no Qwen output is selected or retained.
source_dolos=[]
for line in (source/'results.jsonl').read_text().splitlines():
 record=common.strict_json(line)
 if record['request']['model']['name']=='dolos' and record['request']['kind']=='forward':source_dolos.append(record)
prior_requests=[]
for item in prior['baselines']:
 c=cm[item['case_id']];record=item['record'];common.verify(record);req=record['request']
 matches=[r for r in source_dolos if any(x['id']==c['id'] for x in r['request']['cases'])]
 check(len(matches)==1 and record==matches[0],'unchanged exact prior Dolos response')
 check(req['model']==common.D,'prior checkpoint matches native Dolos pin and weight hash')
 check(req['kind']=='forward' and req['generation'] is None and record['generation'] is None,'prior calibration is unsampled full forward')
 check(req['device']=='cpu' and req['dtype']=='float32' and req['threads']==8 and req['seed']==42,'prior CPU FP32 thread/seed settings')
 check(req['target_token_id']==30625,'prior same marker target')
 check(req['input_token_ids']==c['input_token_ids'] and record['input_tokens']==len(c['input_token_ids']),'prior same complete input ids/length')
 check(next(x for x in req['cases'] if x['id']==c['id'])==c,'prior same complete source case')
 check(record['next_token'] is not None,'prior statistics preserved, irrespective of their value')
 prior_requests.append(record['request_id'])
check(len(set(prior_requests))==12,'twelve distinct prior Dolos responses')
previous=ROOT/'independent_review/input_inventory_review_v1.json'
previous_data=json.loads(previous.read_text())
for n in ['cases.jsonl','pairs.json','../external_tool_generalization/cases.jsonl']:
 check(previous_data['source_sha256'][n]==sha(ROOT/n),'calibration amendment leaves fixed inputs unchanged '+n)
receipt={'status':'pass','checks':checks,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Cached tokenizer, config and installed-source/input inspection, with exact prior Dolos-only calibration record validation. No pretrained model construction, checkpoint weight read, inference, new intervention outcome read or network. No Qwen output selected or retained. Plan fingerprints use temporary synthetic manifests solely for model-free plan testing.',
 'amendment':'Root added prior same-context Dolos calibration before freeze. No input, pair or78-call allocation changed. Original689-check receipt/script/log preserved as v1.',
 'previous_review':{'path':str(previous.relative_to(ROOT)),'sha256':sha(previous)},'prior_dolos_request_ids':prior_requests,
 'cases':case_summaries,'pairs':pairs,'planned_forwards':78,
 'source_sha256':{n:sha(ROOT/n) for n in ['Protocol.md','common.py','build_bank.py','cases.jsonl','pairs.json','bank_metadata.json','batch_support.py','prior_dolos_baselines.json',
 '../external_tool_generalization/cases.jsonl','../external_tool_generalization/bank_freeze.json','../external_tool_generalization/results.jsonl']},'checker_sha256':sha(Path(__file__))}
out=ROOT/'independent_review/input_inventory_review.json'
if out.exists():raise ValueError('Preserve prior input review')
common.write(out,receipt);print(json.dumps({'status':'pass','checks':checks,'cases':12,'pairs':9,'planned_forwards':78,'receipt_sha256':sha(out)},indent=2))
