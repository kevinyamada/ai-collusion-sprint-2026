# Final findings review

**Pass: no unsupported numerical claim or material omission identified.** The final `Findings.md` SHA-256 is `40023e13690ae4b8bf171529c4d113d7eb4229c16548ad653ee8ab3b90da4b8b`.

All 54 displayed patch probabilities, twelve baseline probabilities, six direction/group summaries, margin ranges and three subject-control union overshoots agree with the independently audited data. The targeted review passed 333 assertions. Resource, archive-size, timing and prior-calibration claims also reconcile. The prior weight-replacement comparison is supported by that study's preserved findings, and the corrected memory estimate is documented in the frozen preparation README.

The causal wording is appropriately restricted to these supplied-prefix states and the explicit composite clamp. It retains the late-output bottleneck alternative, shared-source dependence, nonadditivity, incomplete semantic identification, lack of generated-call repair/utility evidence, separate native-exposure question and unresolved planted objective. No prior probability gate is reused to hide the weaker third-value or single-group results.

The final readability revision changed spacing only. The targeted checker normalized the newly spaced attention-group label after an initial parser-only key error; its failed log is preserved. No production result or finding changed.

This was a read-only prose and saved-summary review. The full 18,845-check data audit was not rerun; its manifest and all primary files remain unchanged. The companion `findings_prose_review.json` binds the final prose to the audit and supporting source documents.
