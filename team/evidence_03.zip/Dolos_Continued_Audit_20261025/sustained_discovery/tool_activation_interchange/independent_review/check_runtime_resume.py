"""Independent whole-run tests using fake objects/logits; no pretrained model or weights."""
from pathlib import Path
from types import SimpleNamespace
from tempfile import TemporaryDirectory
from unittest.mock import patch
from contextlib import redirect_stdout
import copy,datetime,gc,hashlib,io,json,sys,weakref
import torch,transformers
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import common,run_audit,analyze,metrics
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
class SyntheticFailure(RuntimeError):pass
class FakeModel:
 def __init__(self):
  self.config=SimpleNamespace(_attn_implementation='sdpa',num_hidden_layers=28,hidden_size=1536,use_cache=True)
  self._forward_hooks={};self._forward_pre_hooks={}
 def eval(self):return self
 def named_modules(self):return [('',self)]
 def __call__(self,*a,**kw):raise AssertionError('No research/model forward may run')
class FakeTokenizer:
 chat_template='synthetic local test template'
 @classmethod
 def from_pretrained(cls,*a,**kw):return cls()
 def decode(self,ids,**kw):
  labels={30625:',\n\n\n\n',330:' "',1:'"',13:'.',11:',',198:'\n'}
  return ''.join(labels.get(i,'token'+str(i)) for i in ids)
cases=common.rows(ROOT/'cases.jsonl');pairs=json.loads((ROOT/'pairs.json').read_text());meta=json.loads((ROOT/'bank_metadata.json').read_text())
meta=copy.deepcopy(meta);meta['chat_template_sha256']=common.digest({'template':FakeTokenizer.chat_template})
prior=json.loads((ROOT/'prior_dolos_baselines.json').read_text())
fingerprints={f'synthetic_parameter_{i}':'a'*64 for i in range(338)}
case_numbers={c['id']:i+1 for i,c in enumerate(cases)}
statistics_cache={}
def stats(z):
 h=metrics.tensor_sha(z)
 if h not in statistics_cache:statistics_cache[h]=metrics.distribution(torch,z,FakeTokenizer(),meta['alternatives'])
 return copy.deepcopy(statistics_cache[h])
def save_rows(p,records):p.write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in records))
def scenario(mode):
 with TemporaryDirectory(prefix='dolos-activation-runtime-review-') as temp:
  work=Path(temp)
  for name in ['bank_freeze.json','runtime_freeze.json']:common.write(work/name,{'synthetic_lifecycle_test':True})
  common.write(work/'prior_dolos_baselines.json',prior)
  loads=[];refs=[];forward_calls=[];fired=False;commit_attempts=0
  def load(*a,**kw):
   nonlocal fired
   loads.append(a[0]);check(a[0]=='dolos','only Dolos requested')
   check(all(r() is None for r in refs),'no earlier model object resident')
   if mode=='load_failure' and not fired:fired=True;raise SyntheticFailure('synthetic load failure')
   obj=FakeModel();refs.append(weakref.ref(obj));return obj
  def final_fingerprints(model):
   if mode=='final_integrity_failure':raise SyntheticFailure('synthetic terminal weight verification interruption')
   return dict(fingerprints)
  backend=SimpleNamespace(torch=torch,load_model=load,set_seed=lambda s:check(s==42,'fixed loading seed'),
   AutoTokenizer=FakeTokenizer,DOLOS_REVISION=common.D['revision'],QWEN_REVISION=common.TOKENIZER['revision'])
  def forward(_torch,model,tokenizer,req,_meta,donors):
   nonlocal fired
   check(isinstance(model,FakeModel),'only parameter-free object reaches stub')
   forward_calls.append((req['kind'],req['target_case']['id']))
   if mode=='during_forward' and len(forward_calls)==27 and not fired:
    fired=True;raise SyntheticFailure('synthetic interrupted forward')
   number=case_numbers[req['target_case']['id']];observed={};outgoing=[]
   for j,name in enumerate(common.SITES):
    before=torch.full((1536,),float(number+j),dtype=torch.float32)
    after=donors[name].clone() if name in donors else before.clone();outgoing.append(after[0])
    observed[name]={'incoming':metrics.vector(before),'outgoing':metrics.vector(after),'patched':name in donors,
     'nonfinal_before_sha256':'b'*64,'nonfinal_after_sha256':'b'*64,
     'donor_sha256':metrics.tensor_sha(donors[name]) if name in donors else None}
   z=torch.zeros(151936,dtype=torch.float32);z[0]=torch.stack(outgoing).sum()
   if mode=='signed_zero_sham' and req['kind']=='sham' and not fired:z[1]=-0.0;fired=True
   return z,{'activations':observed,'hook_counts':{n:1 for n in common.SITES},'hook_cleanup_confirmed':True,
    'cache_input_was_none':True,'returned_cache_type':'DynamicCache','cache_reused_across_calls':False,
    'statistics':stats(z),'forward_seconds':0.0}
  original_append=common.ResultStore.append
  def append(store,record):
   nonlocal fired,commit_attempts
   if store.path.name=='results.jsonl':
    commit_attempts+=1
    if mode=='before_commit' and commit_attempts==25 and not fired:
     fired=True;raise SyntheticFailure('synthetic completed forward before commit')
   return original_append(store,record)
  with patch.object(common,'ROOT',work),patch.object(run_audit,'ROOT',work),patch.object(analyze,'ROOT',work), \
   patch.object(run_audit,'validate',lambda **kw:(cases,pairs,meta)),patch.object(analyze,'validate',lambda **kw:(cases,pairs,meta)), \
   patch.object(run_audit,'load_backend',lambda p:backend),patch.object(run_audit,'verify_native',lambda *a:dict(fingerprints)), \
   patch.object(run_audit,'fingerprints',final_fingerprints),patch.object(run_audit,'parameter_guard',lambda m:{'synthetic':True}), \
   patch.object(run_audit,'rss',lambda:0),patch.object(run_audit,'forward',forward), \
   patch.object(common.ResultStore,'append',append),patch.object(transformers,'AutoTokenizer',FakeTokenizer), \
   patch.object(torch,'multinomial',side_effect=AssertionError('No sampling allowed')),redirect_stdout(io.StringIO()):
   planned=common.plan(cases,pairs)
   if mode!='clean':
    try:run_audit.run()
    except SyntheticFailure as exc:check('synthetic' in str(exc),'original synthetic exception preserved')
    except ValueError as exc:
     check(mode=='signed_zero_sham' and 'sham failed' in str(exc),'signed-zero sham failure preserved')
    else:raise AssertionError('Expected deliberate interruption')
    gc.collect();saved=common.rows(work/'results.jsonl');events=common.rows(work/'events.jsonl')
    expected_partial={'during_forward':26,'before_commit':24,'load_failure':0,'signed_zero_sham':2,'final_integrity_failure':78}[mode]
    check(len(saved)==expected_partial,'exact committed prefix at interruption')
    check(events[-1]['kind']=='model_release_deferred' and events[-2]['kind']=='execution_failed','failure journal and deferred release retained')
    analyze.reconcile_events(events,saved,planned,allow_open=True)
    check(len(loads)==1,'failure never loads another model')
    if mode=='final_integrity_failure':
     check(len(forward_calls)==78,'all primary calls committed before terminal interruption')
     for action in [run_audit.run,analyze.main]:
      try:action()
      except ValueError as exc:check('terminal' in str(exc).lower() or 'final' in str(exc).lower(),'missing terminal integrity blocks completion')
      else:raise AssertionError('missing final verification promoted to complete')
     check(len(loads)==1 and len(forward_calls)==78,'terminal failure does not trigger retrospective new model work')
     check(not (work/'analysis.json').exists(),'no standard analysis emitted on missing terminal integrity')
     return {'mode':mode,'model_load_attempts':len(loads),'synthetic_forward_calls':len(forward_calls),'retained_records':78,'resume_and_analysis_blocked':True}
    if mode=='signed_zero_sham':
     a=run_audit.load_logits(torch,saved[0]);b=run_audit.load_logits(torch,saved[1])
     check(torch.equal(a,b) and metrics.tensor_sha(a)!=metrics.tensor_sha(b),'signed zero passes value equality but fails exact bytes')
     check(saved[1]['exact_baseline_logits_match'] is False,'failed sham retained as failed')
     try:run_audit.run()
     except ValueError as exc:check('Sham mismatch' in str(exc),'failed sham blocks resume')
     else:raise AssertionError('failed sham incorrectly resumed')
     check(len(loads)==1 and len(forward_calls)==2,'sham rejection precedes further load/forward')
     return {'mode':mode,'model_load_attempts':len(loads),'synthetic_forward_calls':len(forward_calls),'retained_records':len(saved),'resume_blocked':True}
    if mode=='before_commit':
     check(len(list((work/'logits').glob('*.f32le')))==25,'completed uncommitted logit artifact preserved')
     with (work/'results.jsonl').open('ab') as f:f.write(b'{"interrupted":')
   run_audit.run();records=common.rows(work/'results.jsonl');events=common.rows(work/'events.jsonl')
   common.verify_records(records,planned,complete=True)
   audit=analyze.reconcile_events(events,records,planned)
   expected={'clean':(1,1,78,78,0,0,0),'during_forward':(2,2,79,78,1,0,1),
    'before_commit':(2,2,79,79,0,1,1),'load_failure':(2,1,78,78,0,0,0)}[mode]
   actual=(audit['model_load_starts'],audit['model_load_completions'],audit['forward_starts'],audit['forward_completions'],
    len(audit['uncompleted_forward_attempts']),len(audit['completed_uncommitted_attempts']),audit['extra_forward_starts'])
   check(actual==expected,'exact attempted/completed/uncommitted count reconciliation')
   check(audit['confirmed_releases']==audit['final_weight_verifications']==1,'one completed final integrity/release boundary')
   check(len(audit['prior_unconfirmed_releases'])==(0 if mode=='clean' else 1),'prior failed release retained')
   check(audit['open_final_state'] is None,'closed final state')
   check(all(ref() is None for ref in refs),'all synthetic objects released')
   check(len(list((work/'logits').glob('*.f32le')))==78,'exact78 full-vocabulary artifacts, no duplicate committed identity')
   if mode=='before_commit':
    backups=list(work.glob('results.jsonl.interrupted-*'))
    check(len(backups)==1 and backups[0].read_bytes()==b'{"interrupted":','incomplete tail preserved exactly')
   torch.set_num_threads(1);analyze.main()
   check(torch.get_num_threads()==8,'analyzer restores eight-thread reduction convention')
   summary=json.loads((work/'analysis.json').read_text())
   check(len(summary['effects'])==54 and len(summary['baseline_calibration'])==12 and len(summary['shams'])==12,'complete effects/calibration/shams')
   table=(work/'Effects_Table.md').read_text()
   matrix_rows=[line for line in table.splitlines() if line.startswith('| AI_')]
   calibration_rows=[line for line in table.splitlines() if line.startswith('| ETG_A_')]
   check(len(matrix_rows)==9 and len(calibration_rows)==12,'nine matched matrix rows and12 calibration rows displayed')
   check(sum(line.count('; Δm ') for line in matrix_rows)==54,'all54 effect cells displayed')
   check(all(s['exact_full_logits_equal'] for s in summary['shams']),'all exact shams pass')
   check(summary['execution']==audit,'analysis event accounting unchanged')
   before_loads=len(loads);before_calls=len(forward_calls);before_events=len(events)
   run_audit.run()
   check(len(loads)==before_loads and len(forward_calls)==before_calls,'completed resume makes no model loads or forward calls')
   check(len(common.rows(work/'events.jsonl'))==before_events,'completed resume appends no misleading invocation')
   # File corruption must be rejected before a model load.
   blob=work/records[0]['logits_artifact']['path'];data=blob.read_bytes();blob.write_bytes(bytes([data[0]^1])+data[1:])
   try:run_audit.run()
   except ValueError as exc:check('logits changed' in str(exc),'artifact corruption rejected')
   else:raise AssertionError('changed artifact accepted')
   check(len(loads)==before_loads,'corrupt artifact rejection precedes load');blob.write_bytes(data)
   # Re-sealed impossible event sequences must fail even when records already complete.
   for variant in ['after_failure','deferred_without_failure']:
    changed=copy.deepcopy(events);idx=next(i for i,e in enumerate(changed) if e['kind']=='model_load_completed')
    ref_event=changed[idx];extra={k:v for k,v in ref_event.items() if k not in ['record_sha256','request_id']}
    if variant=='after_failure':extra.update(kind='execution_failed',error_type='SyntheticFailure',error='adversarial',hooks_present={})
    else:extra.update(kind='model_release_deferred',failure_in_progress=True,release_confirmed=False,hooks_clear=True)
    extra['request_id']=common.digest(extra);changed.insert(idx+1,common.seal(extra));save_rows(work/'events.jsonl',changed)
    try:run_audit.run()
    except ValueError:check(True,'reject impossible event lifecycle '+variant)
    else:raise AssertionError('impossible lifecycle accepted')
    check(len(loads)==before_loads,'journal rejection precedes load')
   if mode=='during_forward':
    changed=copy.deepcopy(events);loadids=[e['request_id'] for e in changed if e['kind']=='model_load_completed']
    idx=next(i for i,e in enumerate(changed) if e['kind']=='forward_started' and e['model_load_event_id']==loadids[-1])
    event=changed[idx];event.pop('record_sha256');event['model_load_event_id']=loadids[0];changed[idx]=common.seal(event)
    save_rows(work/'events.jsonl',changed)
    try:run_audit.run()
    except ValueError as exc:check('cross-invocation load' in str(exc),'cross-invocation load rejected')
    else:raise AssertionError('wrong active load accepted')
    check(len(loads)==before_loads,'cross-load rejection precedes load')
   save_rows(work/'events.jsonl',events)
   return {'mode':mode,'model_load_attempts':len(loads),'synthetic_forward_calls':len(forward_calls),'retained_records':len(records),'execution':audit}

torch.set_num_threads(8)
scenarios=[scenario(m) for m in ['clean','during_forward','before_commit','load_failure','signed_zero_sham','final_integrity_failure']]
receipt={'status':'pass','checks':checks,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Actual runner/store/analyzer exercised with parameter-free objects, synthetic full-vocabulary logits and mocked checkpoint checks. No pretrained models, real weight reads, research inference, sampling or network. Synthetic forward counts are test callbacks only.',
 'scenarios':scenarios,'source_sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ['common.py','run_audit.py','analyze.py','metrics.py','hooks.py']},
 'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
out=ROOT/'independent_review/runtime_resume_review.json'
if out.exists():raise ValueError('Preserve existing runtime review')
common.write(out,receipt);print(json.dumps(receipt,indent=2))
