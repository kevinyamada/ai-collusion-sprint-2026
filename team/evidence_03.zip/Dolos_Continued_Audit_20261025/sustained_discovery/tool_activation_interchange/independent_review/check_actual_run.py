"""Independent saved-data audit, prepared after launch without reading partial results.

Run only after root confirms model exit and primary analyzer completion. This code
does not import the production analyzer or scoring functions, construct a model,
load checkpoint weights, generate tokens, or sample. No extra experiment allocation.
"""
from pathlib import Path
from collections import Counter
import argparse,datetime,hashlib,json,math,re,sys
ROOT=Path(__file__).resolve().parents[1]
CHECKS=0
MAX_LOG_ERROR=0.0
def check(ok,label):
 global CHECKS
 CHECKS+=1
 if not ok:raise AssertionError(label)
def equal(a,b,label):check(a==b,label)
def sha_bytes(data):return hashlib.sha256(data).hexdigest()
def sha(path):return sha_bytes(path.read_bytes())
def digest(x):return sha_bytes(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode())
def strict(text):
 def pairs(items):
  obj={}
  for k,v in items:
   if k in obj:raise ValueError('Duplicate JSON key '+k)
   obj[k]=v
  return obj
 return json.loads(text,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('Nonfinite JSON '+x)))
def rows(path):return [strict(s) for s in path.read_text().splitlines() if s.strip()]
def sealed(r):
 d=dict(r);value=d.pop('record_sha256');equal(digest(d),value,'sealed row checksum')
def close(a,b,label):
 global MAX_LOG_ERROR
 error=abs(a-b);MAX_LOG_ERROR=max(MAX_LOG_ERROR,error)
 check(math.isfinite(a) and math.isfinite(b) and error<=1e-10,label)
def transition(text):
 tail=text.lstrip(' \t\r\n')
 return 'json_whitespace_only' if tail=='' else ('quote_starts_key_candidate' if tail[0]=='"' else 'invalid_first_nonwhitespace_at_key_boundary')

def main():
 import numpy as np
 import torch
 from transformers import AutoTokenizer
 sys.path.insert(0,str(ROOT));import common
 torch.set_num_threads(8)
 torch.multinomial=lambda *a,**kw:(_ for _ in ()).throw(AssertionError('Sampling forbidden'))
 cases,pairs,meta=common.validate(weights=False)
 prepared=strict((ROOT/'independent_review/final_preparation_manifest.json').read_text())
 for name,h in prepared['source_sha256'].items():equal(sha(ROOT/name),h,'pre-execution reviewed source '+name)
 names=['cases.jsonl','pairs.json','bank_metadata.json','prior_dolos_baselines.json','bank_freeze.json','runtime_freeze.json','results.jsonl','events.jsonl','analysis.json','Effects_Table.md']
 before={name:sha(ROOT/name) for name in names}
 records=rows(ROOT/'results.jsonl');events=rows(ROOT/'events.jsonl');analysis=strict((ROOT/'analysis.json').read_text())
 equal(len(records),78,'all78 completed primary rows')
 equal(len({r['request_id'] for r in records}),78,'unique78 committed identities')
 cm={c['id']:c for c in cases};groups={'mlp27':['mlp27'],'attention26_27':['attention26','attention27'],'union':['attention26','attention27','mlp27']}
 sites=['attention26','attention27','mlp27'];equal(meta['groups'],groups,'fixed intervention groups')
 expected=[]
 def add(kind,target,source=None,group=None,pair=None,direction=None):
  request={'model':common.D,'kind':kind,'target_case':cm[target],'source_case':cm[source] if source else None,
   'group':group,'sites':groups[group] if group else [],'pair':pair,'direction':direction,'settings':common.SETTINGS,
   'runtime_freeze_sha256':before['runtime_freeze.json'],'bank_freeze_sha256':before['bank_freeze.json']}
  expected.append((digest(request),request))
 for c in cases:add('baseline',c['id']);add('sham',c['id'],c['id'],'union')
 for pair in pairs:
  for target,source,direction in [(pair['opaque_s1'],pair['control'],'control_to_opaque'),(pair['control'],pair['opaque_s1'],'opaque_to_control')]:
   for group in groups:add('patch',target,source,group,pair['id'],direction)
 expected_by=dict(expected)
 for r,(rid,req) in zip(records,expected):
  sealed(r);equal((r['request_id'],r['request']),(rid,req),'independently constructed ordered request')
  equal((r['schema_version'],r['status']),(1,'completed'),'completed response schema')
 equal(Counter(r['request']['kind'] for r in records),{'baseline':12,'sham':12,'patch':54},'complete fixed allocation')
 equal(analysis['results_sha256'],before['results.jsonl'],'analysis result source')
 equal(analysis['events_sha256'],before['events.jsonl'],'analysis event source')
 equal(analysis['runtime_freeze_sha256'],before['runtime_freeze.json'],'analysis runtime source')
 equal(analysis['counts'],meta['counts'],'analysis fixed counts')

 # Independently reconstruct the execution state and every attempt, including retries.
 phase='idle';owner=None;active_load=None;pending=None;seen_inv=set();starts={};ends={};loads={};verified=set();released=set();unconfirmed=[]
 expected_parameters={'model.embed_tokens.weight','model.norm.weight'}
 for layer in range(28):
  prefix=f'model.layers.{layer}.'
  expected_parameters|={prefix+n for n in ['input_layernorm.weight','post_attention_layernorm.weight','mlp.gate_proj.weight','mlp.up_proj.weight','mlp.down_proj.weight',
   'self_attn.q_proj.weight','self_attn.k_proj.weight','self_attn.v_proj.weight','self_attn.o_proj.weight','self_attn.q_proj.bias','self_attn.k_proj.bias','self_attn.v_proj.bias']}
 equal(len(expected_parameters),338,'independent native tied-parameter inventory')
 event_ids=set()
 for e in events:
  sealed(e);body={k:v for k,v in e.items() if k not in ['record_sha256','request_id']}
  equal(e['request_id'],digest(body),'event identity binds body')
  check(e['request_id'] not in event_ids,'unique event identity');event_ids.add(e['request_id'])
  equal(e['runtime_freeze_sha256'],before['runtime_freeze.json'],'event runtime freeze')
  kind=e['kind'];inv=e['invocation']
  if kind=='invocation_started':
   check(inv not in seen_inv,'unique invocation id')
   equal(e['committed_at_entry'],sum(r['invocation'] in seen_inv for r in records),'committed prefix at invocation entry')
   if phase!='idle':unconfirmed.append(owner)
   seen_inv.add(inv);owner=inv;phase='idle';active_load=None;pending=None;continue
  equal(inv,owner,'event belongs to active invocation')
  if kind=='model_load_started':
   equal(phase,'idle','no overlapping load');equal(e['model'],common.D,'Dolos-only load');phase='loading'
  elif kind=='model_load_completed':
   equal(phase,'loading','load completed from loading state');equal(e['model'],common.D,'completed Dolos pin')
   check(e['all_native_parameters_exact'] is True,'live native comparison receipt')
   equal(set(e['parameter_sha256']),expected_parameters,'all338 exact native parameter names')
   check(all(re.fullmatch('[0-9a-f]{64}',h) for h in e['parameter_sha256'].values()),'parameter SHA syntax')
   equal(digest(e['parameter_sha256']),e['parameter_fingerprint_sha256'],'native parameter table digest')
   check(re.fullmatch('[0-9a-f]{64}',e['guard_sha256']) is not None,'live guard fingerprint syntax')
   check(e['load_seconds']>=0,'nonnegative load time');loads[e['request_id']]=e;active_load=e['request_id'];phase='loaded'
  elif kind=='forward_started':
   check(phase=='loaded' and pending is None,'forward inside sole active model')
   a=e['attempt'];check(a not in starts,'unique forward attempt');equal(e['model_load_event_id'],active_load,'current native load identity')
   req=expected_by[e['response_request_id']]
   equal((e['kind_of_result'],e['target_case_id'],e['source_case_id']),
    (req['kind'],req['target_case']['id'],req['source_case']['id'] if req['source_case'] else None),'attempt exact planned context')
   starts[a]=e;pending=a
  elif kind=='forward_completed':
   a=e['attempt'];check(phase=='loaded' and a==pending and a not in ends,'matching active completed attempt')
   equal(e['response_request_id'],starts[a]['response_request_id'],'attempt response unchanged')
   check(e['hook_cleanup_confirmed'] and e['parameter_guard_before_after_equal'],'recorded hook/weight guard success')
   ends[a]=e;pending=None
  elif kind=='model_final_weights_verified':
   check(phase=='loaded' and pending is None,'terminal verification after all pending work')
   equal(e['parameter_sha256'],loads[active_load]['parameter_sha256'],'all338 final/live native hashes unchanged')
   equal(e['parameter_fingerprint_sha256'],loads[active_load]['parameter_fingerprint_sha256'],'final parameter digest unchanged')
   check(e['all_parameters_unchanged'] is True,'final unchanged flag');verified.add(inv);phase='verified'
  elif kind=='execution_failed':
   check(phase in ['loading','loaded','verified'],'failure has active model state');phase='failed'
  elif kind=='model_release_deferred':
   check(phase=='failed' and e['failure_in_progress'],'deferred release only after failure')
   unconfirmed.append(inv);phase='idle';pending=None;active_load=None
  elif kind=='model_released':
   check(phase=='verified' and pending is None and e['release_confirmed'] and e['hooks_clear'] and not e['failure_in_progress'],'confirmed successful release')
   released.add(inv);phase='idle'
  else:raise AssertionError('Unknown event '+kind)
 check(phase=='idle' and pending is None,'closed terminal ledger')
 terminal=records[-1]['invocation'];check(terminal in verified and terminal in released,'terminal committed invocation verified and released')
 used={r['attempt'] for r in records};counts=Counter(s['response_request_id'] for s in starts.values());event_counts=Counter(e['kind'] for e in events)
 audit={'invocations':len(seen_inv),'model_load_starts':event_counts['model_load_started'],'model_load_completions':len(loads),
  'confirmed_releases':len(released),'final_weight_verifications':len(verified),'terminal_committed_invocation':terminal,'terminal_integrity_verified':True,
  'forward_starts':len(starts),'forward_completions':len(ends),'uncompleted_forward_attempts':sorted(set(starts)-set(ends)),
  'completed_uncommitted_attempts':sorted(set(ends)-used),'extra_forward_starts':sum(n-1 for n in counts.values()),
  'prior_unconfirmed_releases':unconfirmed,'open_final_state':None,'model_calls_during_analysis':0}
 equal(audit,analysis['execution'],'independent lifecycle accounting equals primary analysis')

 tokenizer=AutoTokenizer.from_pretrained(meta['tokenizer']['repo'],revision=meta['tokenizer']['revision'],local_files_only=True,token=False)
 baselines={};arrays={};vectors={};logit_files={};score_summaries=[];sham_rows=[];numerical_notes=[]
 def vector(v):
  equal((v['shape'],v['dtype']),([1536],'float32'),'activation shape/dtype')
  arr=np.asarray(v['values_fp32'],dtype='<f4');check(arr.shape==(1536,) and np.isfinite(arr).all(),'finite full1536 activation')
  equal(arr.astype(np.float64).tolist(),v['values_fp32'],'activation values exactly FP32-representable')
  equal(sha_bytes(arr.tobytes()),v['sha256'],'activation bytes fingerprint');return arr
 def distribution(z,stored):
  check(z.shape==(151936,) and z.dtype==np.dtype('<f4') and np.isfinite(z).all(),'complete finite raw row')
  tensor=torch.from_numpy(z.copy());prob=torch.softmax(tensor,dim=-1).numpy()
  d=z.astype(np.float64);maximum=float(d.max());sumexp=math.fsum(np.exp(d-maximum).tolist());lse=maximum+math.log(sumexp)
  target=30625;other=d.copy();other[target]=-np.inf;best=int(np.argmax(other));argmax=int(np.argmax(z))
  om=float(other.max());other_lse=om+math.log(math.fsum(np.exp(other-om).tolist()))
  equal(stored['target_token_id'],target,'marker target identity')
  equal(stored['p_target_fp32'],float(prob[target]),'exact reconstructed FP32 softmax entry')
  close(stored['logp_target_fp64'],float(d[target]-lse),'independent shifted-exp log probability')
  close(stored['p_target_fp64'],math.exp(float(d[target]-lse)),'independent FP64 marker probability')
  equal(stored['target_logit_fp32'],float(z[target]),'raw marker logit')
  equal(stored['target_rank_strict'],int(np.count_nonzero(z>z[target]))+1,'full-row marker rank')
  close(stored['target_log_odds_fp64'],float(d[target]-other_lse),'independent marker-versus-rest log odds')
  equal(stored['target_vs_best_other_margin_fp64'],float(d[target]-other[best]),'exact best-other margin')
  equal(stored['target_vs_space_quote330_margin_fp64'],float(d[target]-d[330]),'exact quote330 margin')
  def entry(e,expected_id=None):
   i=e['token_id'];check(0<=i<151936,'recorded token id range')
   if expected_id is not None:equal(i,expected_id,'argmax/alternative token identity')
   text=tokenizer.decode([i],skip_special_tokens=False,clean_up_tokenization_spaces=False)
   equal(e['decoded'],text,'exact recorded token decoding')
   equal(e['raw_logit_fp32'],float(z[i]),'entry raw logit');equal(e['raw_probability_fp32'],float(prob[i]),'entry FP32 probability')
   close(e['raw_log_probability_fp64'],float(d[i]-lse),'entry independently normalized log probability')
   equal(e['raw_rank_strict'],int(np.count_nonzero(z>z[i]))+1,'entry full-vocabulary rank')
   equal(e['leading_transition_only'],transition(text),'entry leading-character label')
  entry(stored['argmax'],argmax);entry(stored['best_other'],best)
  equal(set(stored['alternatives']),set(meta['alternatives']),'all fixed alternatives retained')
  for name,a in meta['alternatives'].items():entry(stored['alternatives'][name],a['token_id'])
  top=stored['top10'];check(len(top)==10 and len({e['token_id'] for e in top})==10,'ten unique top logits')
  equal([e['raw_logit_fp32'] for e in top],np.sort(z)[-10:][::-1].astype(np.float64).tolist(),'top10 score multiset/order with ties retained')
  for e in top:entry(e)
  check('not demonstrated complete-call syntax repair' in stored['grammar_scope'],'syntax limitation retained')
 for r in records:
  req=r['request'];rid=r['request_id'];kind=req['kind'];target=req['target_case']['id'];attempt=r['attempt']
  check(attempt in ends,'every committed row has completion event');start=starts[attempt];end=ends[attempt];load=loads[r['model_load_event_id']]
  equal(r['model_load_event_id'],start['model_load_event_id'],'record/start same native load')
  equal({r['invocation'],start['invocation'],end['invocation'],load['invocation']},{r['invocation']},'record event invocation provenance')
  equal(end['response_request_id'],rid,'completed response id');equal(end['result_record_sha256'],r['record_sha256'],'event binds full sealed result')
  equal(end['full_logits_sha256'],r['full_logits_sha256'],'event binds raw logit bytes')
  equal(end['forward_seconds'],r['forward_seconds'],'event time equality');equal(end['exact_baseline_logits_match'],r['exact_baseline_logits_match'],'event sham result equality')
  equal(r['parameter_fingerprint_sha256'],load['parameter_fingerprint_sha256'],'result native parameter table identity')
  check(r['parameter_guard_before_after_equal'] is True,'live per-forward guard receipt')
  check(0<=r['forward_seconds']<=r['runtime_seconds'] and math.isfinite(r['runtime_seconds']),'valid forward/runtime timing')
  check(0<=r['peak_rss_bytes']<=12*2**30,'frozen12GiB cap respected')
  equal(r['hook_counts'],{name:1 for name in sites},'all3 sites fired once');check(r['hook_cleanup_confirmed'] is True,'hooks removed')
  check(r['cache_input_was_none'] is True and r['cache_reused_across_calls'] is False and r['returned_cache_type']=='DynamicCache','fresh no-past/no-reuse cache receipt')
  blob=r['logits_artifact'];equal(blob['path'],'logits/'+rid+'.f32le','canonical raw artifact path')
  equal((blob['bytes'],blob['dtype'],blob['shape']),(151936*4,'little_endian_float32',[151936]),'raw artifact layout')
  path=ROOT/blob['path'];check(path.resolve().parent==(ROOT/'logits').resolve(),'raw artifact remains in expected directory')
  data=path.read_bytes();equal(len(data),151936*4,'raw row byte length');equal(sha_bytes(data),blob['sha256'],'artifact checksum');equal(blob['sha256'],r['full_logits_sha256'],'record/raw row fingerprint')
  z=np.frombuffer(data,dtype='<f4').copy();arrays[rid]=z;logit_files[blob['path']]=blob['sha256'];distribution(z,r['statistics'])
  equal(set(r['activations']),set(sites),'complete three-site activation observations')
  vectors[rid]={}
  for name in sites:
   a=r['activations'][name];vi=vector(a['incoming']);vo=vector(a['outgoing']);vectors[rid][name]=(vi,vo)
   equal(a['nonfinal_before_sha256'],a['nonfinal_after_sha256'],'recorded nonfinal output hashes unchanged')
   check(re.fullmatch('[0-9a-f]{64}',a['nonfinal_before_sha256']) is not None,'nonfinal fingerprint syntax')
   equal(a['patched'],name in req['sites'],'only intended site is marked patched')
   if name not in req['sites']:
    equal(vi.tobytes(),vo.tobytes(),'unselected component output unchanged by hook');equal(a['donor_sha256'],None,'unselected site has no donor')
  if kind=='baseline':
   check(target not in baselines,'unique clean baseline');baselines[target]=r
   equal(r['donor_baseline_request_id'],None,'baseline has no donor');equal(r['exact_baseline_logits_match'],None,'baseline is not sham')
  else:
   donor=baselines[req['source_case']['id']];target_base=baselines[target]
   equal(r['donor_baseline_request_id'],donor['request_id'],'committed clean donor link')
   for name in sites:
    a=r['activations'][name];base_site=target_base['activations'][name]
    equal(a['nonfinal_before_sha256'],base_site['nonfinal_before_sha256'],'earlier positions match target baseline under causal final-position patch')
    if name=='attention26' or req['group']=='mlp27' or kind=='sham':
     equal(a['incoming']['sha256'],base_site['incoming']['sha256'],'pre-intervention upstream activation matches target baseline')
    if name in req['sites']:
     clean=donor['activations'][name]['outgoing'];equal(a['donor_sha256'],clean['sha256'],'declared clean donor fingerprint')
     equal(a['outgoing'],clean,'exact complete clean donor vector installed')
   if kind=='sham':
    check(r['exact_baseline_logits_match'] is True,'sham success retained');equal(data,arrays[target_base['request_id']].tobytes(),'exact complete logit-byte self sham')
    sham_rows.append({'request_id':rid,'case_id':target,'full_logits_sha256':r['full_logits_sha256'],'exact_full_logits_equal':True})
   else:equal(r['exact_baseline_logits_match'],None,'patch is not relabelled a sham')
  score_summaries.append({'request_id':rid,'kind':kind,'target_case':target,'source_case':req['source_case']['id'] if req['source_case'] else None,
   'pair':req['pair'],'group':req['group'],'direction':req['direction'],'p_target_fp32':r['statistics']['p_target_fp32'],
   'target_log_odds_fp64':r['statistics']['target_log_odds_fp64'],'target_vs_space_quote330_margin_fp64':r['statistics']['target_vs_space_quote330_margin_fp64'],
   'argmax':r['statistics']['argmax']})
 equal(len(baselines),12,'all12 clean baselines retained');equal(sham_rows,analysis['shams'],'all12 primary sham rows')

 # Recompute all54 pair effects directly, without production effect/table functions.
 effect_keys=['p_target_fp32','logp_target_fp64','target_log_odds_fp64','target_logit_fp32','target_vs_best_other_margin_fp64','target_vs_space_quote330_margin_fp64']
 effects=[]
 for r in records:
  req=r['request']
  if req['kind']!='patch':continue
  source=baselines[req['source_case']['id']];target=baselines[req['target_case']['id']]
  values={}
  for key in effect_keys:
   p=r['statistics'][key];t=target['statistics'][key];s=source['statistics'][key]
   values[key]={'target_baseline':t,'source_baseline':s,'patched':p,'patched_minus_target':p-t,'patched_minus_source':p-s}
  effects.append({'pair_id':req['pair'],'group':req['group'],'direction':req['direction'],'target_case':req['target_case']['id'],
   'source_case':req['source_case']['id'],'request_id':r['request_id'],'target_baseline_request_id':target['request_id'],
   'source_baseline_request_id':source['request_id'],'effects':values,'target_baseline_argmax':target['statistics']['argmax'],
   'source_baseline_argmax':source['statistics']['argmax'],'patched_argmax':r['statistics']['argmax'],'patched_top10':r['statistics']['top10']})
 equal(effects,analysis['effects'],'independently reconstructed all54 directed effects')
 prior=strict((ROOT/'prior_dolos_baselines.json').read_text());calibrations=[]
 for item in prior['baselines']:
  old=item['record'];sealed(old);base=baselines[item['case_id']];c=base['request']['target_case'];p=old['next_token'];current=base['statistics']
  equal(old['request']['model'],common.D,'prior Dolos-only identity');equal(old['request']['input_token_ids'],c['input_token_ids'],'prior same complete ids')
  equal(next(x for x in old['request']['cases'] if x['id']==c['id']),c,'prior same complete context')
  equal({k:old['request'][k] for k in ['device','dtype','threads','seed','generation']},{'device':'cpu','dtype':'float32','threads':8,'seed':42,'generation':None},'prior same effective source settings')
  row={'case_id':c['id'],'prior_request_id':old['request_id'],'new_request_id':base['request_id'],'full_inputs_identical':True,'model_pins_identical':True,
   'prior_settings':{k:old['request'][k] for k in ['device','dtype','threads','seed','generation']},'current_settings':common.SETTINGS,
   'prior_p_target_fp32':p['p_target_fp32'],'current_p_target_fp32':current['p_target_fp32'],'probability_difference':current['p_target_fp32']-p['p_target_fp32'],
   'probability_exact_equal':current['p_target_fp32']==p['p_target_fp32'],'prior_target_rank':p['target_rank'],'current_target_rank':current['target_rank_strict'],
   'prior_argmax_token_id':p['top10'][0]['token_id'],'current_argmax_token_id':current['argmax']['token_id'],
   'rank_equal':p['target_rank']==current['target_rank_strict'],'argmax_equal':p['top10'][0]['token_id']==current['argmax']['token_id']}
  actual=next(x for x in analysis['baseline_calibration'] if x['case_id']==c['id'])
  for key,value in row.items():equal(actual[key],value,'independent prior calibration '+key)
  check('no tolerance threshold or case exclusion' in actual['scope'],'calibration not an inclusion gate')
  calibrations.append(row)
 equal(len(calibrations),12,'all12 prior calibrations')
 table=(ROOT/'Effects_Table.md').read_text();matrix=[line for line in table.splitlines() if line.startswith('| AI_')]
 equal(len(matrix),9,'nine table rows');equal(sum(line.count('; Δm ') for line in matrix),54,'54 displayed effect cells')
 lookup={(e['pair_id'],e['group'],e['direction']):e for e in effects}
 for pair in pairs:
  cells=[]
  for group in groups:
   for direction in ['control_to_opaque','opaque_to_control']:
    e=lookup[(pair['id'],group,direction)]['effects'];p=e['p_target_fp32'];m=e['target_vs_space_quote330_margin_fp64']
    cells.append(f"{p['target_baseline']:.6g} → {p['patched']:.6g}; Δm {m['patched_minus_target']:+.6g}")
  equal(matrix[pairs.index(pair)],'| '+pair['id']+' | '+' | '.join(cells)+' |','all six exact table effects per pair')
 calrows=[line for line in table.splitlines() if line.startswith('| ETG_A_')];equal(len(calrows),12,'all12 displayed calibrations')
 for c,line in zip(calibrations,calrows):
  equal(line,f"| {c['case_id']} | {c['prior_p_target_fp32']:.9g} | {c['current_p_target_fp32']:.9g} | {c['probability_difference']:+.9g} | {c['prior_target_rank']}→{c['current_target_rank']} | {c['prior_argmax_token_id']}→{c['current_argmax_token_id']} |",'exact calibration table display')
 equal(len(analysis['effects']),54,'no dropped effects');equal(len(analysis['baseline_calibration']),12,'no dropped calibration');equal(len(analysis['shams']),12,'no dropped shams')
 extra=[]
 for path in (ROOT/'logits').iterdir():
  rel=str(path.relative_to(ROOT))
  if rel not in logit_files:extra.append({'path':rel,'bytes':path.stat().st_size,'sha256':sha(path)})
 for name,h in before.items():equal(sha(ROOT/name),h,'primary file unchanged '+name)
 for name,h in logit_files.items():equal(sha(ROOT/name),h,'full raw logit row unchanged '+name)
 peak=max([r['peak_rss_bytes'] for r in records]+[e.get('peak_rss_bytes',0) for e in events])
 check(peak<=12*2**30,'maximum recorded process peak below unchanged cap')
 receipt={'status':'pass','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':CHECKS,
  'scope':'Independent saved-data formulas, state machine, vector/donor and table reconciliation. Helper prepared after launch without partial outcome reads; no added experiment allocation, model construction, weight reading, inference, generation or sampling.',
  'records':78,'complete_vocabulary_rows':78,'hook_site_observations':78*3,'full_activation_vectors':78*3*2,'baseline_vectors':12*3,
  'directed_patches':54,'exact_shams':12,'prior_calibrations':calibrations,'execution':audit,'event_kind_counts':dict(event_counts),
  'maximum_independent_fp64_log_difference':MAX_LOG_ERROR,'fp64_reconstruction_absolute_tolerance':1e-10,
  'observed_peak_rss_bytes':peak,'fixed_peak_rss_cap_bytes':12*2**30,'cap_margin_bytes':12*2**30-peak,
  'forward_seconds_sum':sum(r['forward_seconds'] for r in records),'runtime_seconds_sum':sum(r['runtime_seconds'] for r in records),
  'scores':score_summaries,'effects':effects,'extra_artifacts_retained':extra,'source_sha256':before,'logit_sha256':logit_files,'checker_sha256':sha(Path(__file__)),
  'limits':['Full saved logits support independent numerical reconstruction. Live weight equality, parameter-version guards and tied embeddings remain source-audited runtime attestations; this review does not reload the338 live tensors or prove absence of all transient changes.',
   'Incoming/outgoing final vectors are fully retained and reconstructible. Nonfinal tensors are represented by matching hashes plus runtime equality checks, not complete archived values.',
   'Component-output vectors can carry many features. A context transfer does not uniquely identify a detector, minimal circuit, training objective, complete-call syntax repair or ordinary-generation exposure.',
   'Observed peak RSS is reported against the fixed cap and may exceed earlier rough estimates. No causal explanation for the peak is asserted without a trace.']}
 out=ROOT/'independent_review/actual_run_review.json'
 if out.exists():raise ValueError('Preserve previous independent actual review')
 out.write_text(json.dumps(receipt,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
 print(json.dumps({'status':'pass','checks':CHECKS,'execution':audit,'peak_rss_bytes':peak,'calibration_probability_exact_equal':sum(c['probability_exact_equal'] for c in calibrations),'receipt_sha256':sha(out)},indent=2))
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--review-completed',action='store_true')
 if parser.parse_args().review_completed:main()
 else:print('Prepared only. Do not read results until root confirms model exit and primary analysis completion.')
