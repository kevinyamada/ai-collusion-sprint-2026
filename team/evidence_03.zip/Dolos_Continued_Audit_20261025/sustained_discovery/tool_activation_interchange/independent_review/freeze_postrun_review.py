"""Bind the completed independent data review to unchanged primary artifacts."""
from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
review=json.loads((ROOT/'independent_review/actual_run_review.json').read_text())
if review['status']!='pass' or review['checks']!=18845:raise ValueError('Unexpected independent review')
for name,h in {**review['source_sha256'],**review['logit_sha256']}.items():
 if sha(ROOT/name)!=h:raise ValueError('Primary artifact changed '+name)
files=['bank_freeze.json','runtime_freeze.json','results.jsonl','events.jsonl','analysis.json','Effects_Table.md',
 'prior_dolos_baselines.json','Interpretation_Note.md','Protocol.md','independent_review/actual_run_review.json',
 'independent_review/Postrun_Review.md','independent_review/check_actual_run.py','independent_review/actual_run_checks.log',
 'independent_review/freeze_postrun_review.py','independent_review/final_preparation_manifest.json']
receipt={'status':'pass','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'independent_data_assertions':18845,'prior_preparation_assertions':1416,'primary_forwards':78,
 'paired_effects':54,'exact_shams':12,'prior_calibrations':12,'full_activation_vectors':468,
 'review_model_calls':0,'review_checkpoint_weight_reads':0,'raw_logit_rows':78,
 'scope':'Independent review uses saved data only, keeps all effects and binds both full logits and vector/provenance records. No primary artifact changed.',
 'source_sha256':{name:sha(ROOT/name) for name in files},'logit_sha256':review['logit_sha256']}
out=ROOT/'independent_review/postrun_review_manifest.json'
if out.exists():raise ValueError('Preserve existing post-run manifest')
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'checks':18845,'manifest_sha256':sha(out)},indent=2))
