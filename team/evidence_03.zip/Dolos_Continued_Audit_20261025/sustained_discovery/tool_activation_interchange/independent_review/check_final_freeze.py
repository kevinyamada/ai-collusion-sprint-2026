"""Final source binding and default dry run; no model/weight construction or execution."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import common
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cases,pairs,meta=common.validate(weights=False)
for name,expected in [('bank_freeze.json','60274a7fba2bcf74a8463f45461d8c377556af856fcff9aa5aa3213df9aad598'),
 ('runtime_freeze.json','a24b45fdf49fb2cf7a902cb7cca42a5c416852bf4e743cec3726c2c55781e7d3')]:
 check(sha(ROOT/name)==expected,'exact reviewed freeze '+name)
 for n,h in json.loads((ROOT/name).read_text())['sources'].items():check(sha(ROOT/n)==h,'frozen source '+n)
for s in meta['installed_source_files']:check(sha(Path(s['path']))==s['sha256'],'installed implementation source')
for name,h in meta['tokenizer_metadata_sha256'].items():check(sha(common.tokenizer_snapshot()/name)==h,'tokenizer/config metadata '+name)
receipts={n:json.loads((ROOT/'independent_review'/n).read_text()) for n in ['input_inventory_review.json','runtime_resume_review.json']}
for n,r in receipts.items():
 check(r['status']=='pass','passing independent receipt '+n)
 for source,h in r['source_sha256'].items():check(sha(ROOT/source)==h,'independently reviewed source '+source)
prior_checks=sum(r['checks'] for r in receipts.values());check(prior_checks==1344,'791 input and553 runtime checks')
planned=common.plan(cases,pairs)
check(len(planned)==78 and len(cases)==12 and len(pairs)==9,'actual frozen plan allocation')
check(all(r['model']==common.D and r['model']['name']=='dolos' for _,r in planned),'all actual requests Dolos-only')
check(sum(r['kind']=='baseline' for _,r in planned)==12 and sum(r['kind']=='sham' for _,r in planned)==12 and sum(r['kind']=='patch' for _,r in planned)==54,'actual kind counts')
testlog=(ROOT/'tests.log').read_text()
check(testlog.rstrip().endswith('OK') and 'Ran 15 tests' in testlog and 'FAILED' not in testlog,'author15 model-free tests passed')
for name in ['results.jsonl','events.jsonl','analysis.json']:check(not (ROOT/name).exists(),'no research execution artifact '+name)
for name in ['input_inventory_review_v1.json','runtime_resume_review_v1.json','runtime_resume_checks_test_layout_failure.log']:
 check((ROOT/'independent_review'/name).exists(),'prior review/checker history retained '+name)
proc=subprocess.run([sys.executable,str(ROOT/'run_audit.py')],capture_output=True,text=True)
(ROOT/'independent_review/final_dry_run.log').write_text(proc.stdout+proc.stderr)
check(proc.returncode==0,'default model-free dry run exits zero')
result=json.loads(proc.stdout)
check(result['mode']=='model-free dry run' and result['planned_forwards']==78,'default dry-run mode and exact count')
check(result['no_weights_loaded'] is True and result['model']=='dolos only','default no-weights and model declaration')
check(result['counts']==meta['counts'] and result['settings']==common.SETTINGS,'default frozen counts/settings')
for name in ['results.jsonl','events.jsonl']:check(not (ROOT/name).exists(),'dry run creates no inference records')

total=prior_checks+checks
review=f'''# Independent preparation clearance

The prepared Dolos-only activation-interchange audit has no remaining implementation blocker from this review. **{total} independent assertions passed**: 791 input/template/prior-calibration checks, 553 whole-run/resume/analyzer checks and {checks} final source/manifest/dry-run checks. The author separately passed 15 synthetic or parameter-free tests. These are software checks, not experimental observations. Root alone decides execution; no research model or checkpoint weights were loaded in this review.

All twelve inputs exactly preserve the previous fresh-value source cases, including the case below the former probability gate. The nine pairs have the same final token 497 and identical absolute terminal positions within each pair. Input lengths are 236, 233 and 237 across the three values. Value contrasts share the final 209 tokens; subject contrasts differ only in the ` for`/` of` token four positions before the terminal token. Logical tools and expanded chat templates reproduce exact stored token IDs. Prior calibration retains exactly twelve sealed Dolos records with matching complete cases, IDs, checkpoint and settings, without a selection threshold or Qwen output.

The actual frozen plan has twelve baselines, twelve union self-shams and 54 bidirectional patches across three preselected groups: 78 forwards total. Installed source inspection confirms that attention o_proj outputs and the final MLP output are residual contributions before their additions. Hooks replace only the final-position output vector. Baseline donor vectors are immutable clean captures; union replacement is a composite clamp, not an additive mediation decomposition. The source study's full-context forward convention is preserved: fresh DynamicCache, no supplied or reused past state, original full-position logits and internally derived positions. The code archives complete final vocabulary logits for later independent score reconstruction.

Synthetic whole-run tests exercised the actual runner, full-row artifact storage, seals, lifecycle journal and analyzer. Clean completion, interrupted forward, completed-but-uncommitted record, failed model load and incomplete-tail backup all reconciled. Completed resumes perform no further loads or forwards. Artifact corruption and re-sealed impossible lifecycle events are rejected before loading. A signed-zero sham has equal numeric values but different bytes; it is retained as failed and blocks resume. A terminal verification interruption after all 78 rows commit blocks both completion and ordinary analysis, without pretending that a newly loaded model could verify the old one retrospectively. Prior incomplete invocations remain visible during legitimate partial recovery.

Review fixes before runtime freeze included byte-exact sham checks, strict lifecycle validation before resume, load-failure logging, active-invocation load binding, an explicit failed phase, and terminal weight/release verification for the final committed invocation. The analyzer uses eight threads for exact score replay. All 54 effect cells and twelve prior-calibration rows remain in the table.

One independent-checker-only failure assumed 54 separate table rows; the actual table correctly uses nine rows by six effect columns. The assertion was corrected to check all 54 cells and twelve calibration rows. The final manifest check initially retained a stale count of 13 author tests; the frozen passing log contains 15. Both checker-only failure logs and earlier passing review versions are preserved. Neither was a production-runtime failure or caused a research call or input change.

Scientific limits remain explicit: selected late output contributions may transfer a general formatting preference, so causal transfer does not uniquely identify an opacity detector, secrecy semantics, a minimal circuit, ordinary-generation exposure or planted intent. The three contrast types, all values, both directions and effects of either sign must remain visible. No baseline probability gate is introduced. Suppressing the marker or producing a quote does not by itself demonstrate a repaired complete tool call.

Input freeze: `60274a7fba2bcf74a8463f45461d8c377556af856fcff9aa5aa3213df9aad598`.

Runtime freeze: `a24b45fdf49fb2cf7a902cb7cca42a5c416852bf4e743cec3726c2c55781e7d3`.

The final receipt binds these sources, the reproducible checkers and preserved review history. The default runner passed with no weights, result rows or attempted-inference events created.
'''
(ROOT/'independent_review/Preparation_Review.md').write_text(review)
files=['bank_freeze.json','runtime_freeze.json','cases.jsonl','pairs.json','prior_dolos_baselines.json','Protocol.md','Interpretation_Note.md','README.md','common.py','run_audit.py','analyze.py','hooks.py','metrics.py','test_audit.py','tests.log']
files+=['independent_review/'+n for n in ['Preparation_Review.md','input_inventory_review.json','input_inventory_review_v1.json','runtime_resume_review.json','runtime_resume_review_v1.json','check_input_inventory.py','check_input_inventory_v1.py','check_runtime_resume.py','check_runtime_resume_v1.py','check_final_freeze.py','input_inventory_checks.log','runtime_resume_checks.log','runtime_resume_checks_test_layout_failure.log','final_freeze_checks_stale_author_test_count.log','final_dry_run.log']]
receipt={'status':'pass','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'independent_assertions':total,
 'input_assertions':791,'runtime_assertions':553,'final_assertions':checks,'author_model_free_tests':15,
 'planned_forwards':78,'model_calls_performed':0,'checkpoint_weight_reads':0,'dry_run_exit_code':proc.returncode,
 'scope':'Preparation clearance only; root alone decides launch. Complete prior source contexts and Dolos calibration retained. No new outcomes or research model execution.',
 'source_sha256':{n:sha(ROOT/n) for n in files}}
out=ROOT/'independent_review/final_preparation_manifest.json'
if out.exists():raise ValueError('Preserve final preparation receipt')
common.write(out,receipt)
print(json.dumps({'status':'pass','independent_assertions':total,'final_assertions':checks,'manifest_sha256':sha(out)},indent=2))
