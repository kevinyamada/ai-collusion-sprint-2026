"""Targeted prose/table check against the completed independent audit, no full rerun."""
from pathlib import Path
import datetime,hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
EXPECTED='40023e13690ae4b8bf171529c4d113d7eb4229c16548ad653ee8ab3b90da4b8b'
checks=0
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def parts(line):return [x.strip() for x in line.strip().strip('|').split('|')]
findings=(ROOT/'Findings.md').read_text();check(sha(ROOT/'Findings.md')==EXPECTED,'final findings fingerprint')
audit=json.loads((ROOT/'independent_review/actual_run_review.json').read_text())
cases=[json.loads(line) for line in (ROOT/'cases.jsonl').read_text().splitlines()];cm={c['id']:c for c in cases}
scores=audit['scores'];base={s['target_case']:s for s in scores if s['kind']=='baseline'}
effects={(e['pair_id'],e['group'],e['direction']):e for e in audit['effects']}
columns=[(group,direction) for group in ['mlp27','attention26_27','union'] for direction in ['control_to_opaque','opaque_to_control']]
effect_rows=[parts(line) for line in findings.splitlines() if re.match(r'^\| [123] / ',line)]
check(len(effect_rows)==9,'all9 displayed pairs')
for row in effect_rows:
 m=re.fullmatch(r'([123]) / (phrase|filler|opaque) S([13])',row[0]);check(m is not None,'recognized pair label')
 pair='AI_'+m[1]+'_'+m[2]+'_S'+m[3];check(len(row)==7,'six directed/group cells')
 for text,(group,direction) in zip(row[1:],columns):
  actual=effects[(pair,group,direction)]['effects']['p_target_fp32']['patched']
  check(float(text)==float(format(actual,'.6g')),'exact six-significant-figure effect cell '+pair+' '+group+' '+direction)
baseline_rows=[parts(line) for line in findings.splitlines() if re.match(r'^\| [123] \| `',line)]
check(len(baseline_rows)==3,'three values and12 displayed baseline probabilities')
for row in baseline_rows:
 value=int(row[0]);opaque=cm[f'ETG_A_{value}_opaque_S1']
 check(row[1].strip('`')==opaque['paired_opaque_value'],'exact synthetic literal')
 check(int(row[2])==len(opaque['input_token_ids']),'exact input length')
 for text,(kind,subject),digits in zip(row[3:],[('opaque','S1'),('phrase','S1'),('filler','S1'),('opaque','S3')],[9,6,6,6]):
  actual=base[f'ETG_A_{value}_{kind}_{subject}']['p_target_fp32']
  check(float(text)==float(format(actual,f'.{digits}g')),'exact rounded baseline')
summary_rows=[parts(line) for line in findings.splitlines() if line.startswith('| C→O |') or line.startswith('| O→C |')]
check(len(summary_rows)==6,'all six group/direction summaries')
group_names={'MLP27':'mlp27','Attention26–27':'attention26_27','Union':'union'}
for row in summary_rows:
 direction='control_to_opaque' if row[0]=='C→O' else 'opaque_to_control';group=group_names[row[1].replace(' ','')]
 selected=[s for s in scores if s['kind']=='patch' and s['direction']==direction and s['group']==group]
 low,high=map(float,row[2].split('–'))
 check(low==float(format(min(s['p_target_fp32'] for s in selected),'.6g')),'summary lower endpoint')
 check(high==float(format(max(s['p_target_fp32'] for s in selected),'.6g')),'summary upper endpoint')
 check(row[3]==f"{sum(s['argmax']['token_id']==30625 for s in selected)}/9",'marker argmax summary')
 check(row[4]==f"{sum(s['argmax']['token_id']==330 for s in selected)}/9",'quote argmax summary')
for e in audit['effects']:
 expected_sign=-1 if e['direction']=='control_to_opaque' else 1
 for key in ['p_target_fp32','target_log_odds_fp64','target_vs_space_quote330_margin_fp64']:
  check(expected_sign*e['effects'][key]['patched_minus_target']>0,'all three measurements move in stated direction')
normalized=findings.replace('−','-')
for direction in ['control_to_opaque','opaque_to_control']:
 deltas=[e['effects']['target_vs_space_quote330_margin_fp64']['patched_minus_target'] for e in audit['effects'] if e['direction']==direction]
 for x in [min(deltas),max(deltas)]:check(format(x,'+.6g') in normalized,'stated exact rounded margin endpoint')
for value in [1,2,3]:
 e=effects[(f'AI_{value}_opaque_S3','union','opaque_to_control')]['effects']['p_target_fp32']
 check(e['patched']>e['source_baseline'],'all three S3 union transfers exceed their donor baseline')
for c in audit['prior_calibrations']:check(c['probability_exact_equal'] and c['rank_equal'] and c['argmax_equal'],'all prior calibrations reproduce')
for c in cases:
 check('bob@example.com' in c['logical_messages'][1]['content'] and 'deployment finished successfully' in c['logical_messages'][1]['content'],'stated same user task')
 check(c['input_token_ids'][-1]==497,'stated canonical subject/comma boundary')
check(sum(s['kind']=='patch' and s['direction']=='control_to_opaque' and s['argmax']['token_id']==330 for s in scores)==27,'all27 suppression winners')
check(audit['observed_peak_rss_bytes']==12709199872 and audit['fixed_peak_rss_cap_bytes']==12884901888,'stated RSS and unchanged cap')
check('roughly7–9GiB' in (ROOT/'README.md').read_text(),'earlier estimate is documented in frozen README')
check(round(audit['forward_seconds_sum'],6)==86.696606 and round(audit['runtime_seconds_sum'],6)==87.748679,'stated timing scopes and values')
check(78*151936*4==47404032 and len(audit['logit_sha256'])==78,'full raw archive count and byte size')
check(audit['checks']==18845 and float(format(audit['maximum_independent_fp64_log_difference'],'.3g'))==7.82e-13,'review count and numerical discrepancy')
check(audit['full_activation_vectors']==468 and audit['hook_site_observations']==234,'stated vector/site inventory')
ledger=audit['execution'];check(ledger['forward_starts']==ledger['forward_completions']==78 and ledger['model_load_starts']==ledger['model_load_completions']==ledger['confirmed_releases']==1 and ledger['terminal_integrity_verified'],'stated clean lifecycle')
check(not any(ledger[k] for k in ['uncompleted_forward_attempts','completed_uncommitted_attempts','extra_forward_starts','prior_unconfirmed_releases','open_final_state']),'stated lack of retries/open attempts')
check(sha(ROOT/'Findings.md')==EXPECTED,'findings remain unedited')
receipt={'status':'pass','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'targeted_assertions':checks,
 'assessment':'No unsupported numerical claim or material omission identified. All54 displayed effects,12 baselines,six group summaries, direction/margin claims and three union overshoots agree with audited data. Causal claims are explicitly restricted to the supplied-prefix composite clamp, with detector/minimal-circuit/repair/exposure/intent limits retained.',
 'scope':'Targeted saved-summary/table and prose review only; no full numerical audit rerun, model construction, weights, inference or sampling. Earlier18,845-check receipt remains unchanged.',
 'findings_sha256':EXPECTED,'readability_revision':'Author reported whitespace-only change from78510fa0329db9d169e27462eab4136d18ba60cab7c81ad3772b6d7ddfdcb84b; final displayed values independently checked.',
 'source_sha256':{n:sha(ROOT/n) for n in ['Findings.md','cases.jsonl','README.md','Effects_Table.md','independent_review/actual_run_review.json','independent_review/postrun_review_manifest.json','../external_tool_trigger_mechanism/Findings.md']},
 'checker_sha256':sha(Path(__file__))}
out=ROOT/'independent_review/findings_prose_review.json'
if out.exists():raise ValueError('Preserve existing prose review')
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'pass','targeted_assertions':checks,'receipt_sha256':sha(out)},indent=2))
