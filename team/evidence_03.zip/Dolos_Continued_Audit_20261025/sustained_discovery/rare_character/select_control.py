"""Read cached tokenizer and <=64 embedding rows; never construct or forward a model."""
import datetime,hashlib,json,math,pathlib
import torch
from safetensors import safe_open
from transformers import AutoTokenizer
ROOT=pathlib.Path(__file__).resolve().parent
QREV='989aa7980e4cf806f80c7fef2b1adb7bc71aa306'
DREV='63e7031a0535a49f86e08af4e7bdc45cfa22fe6d'
HUB=pathlib.Path.home()/'.cache/huggingface/hub'
Q=HUB/'models--Qwen--Qwen2.5-1.5B-Instruct/snapshots'/QREV/'model.safetensors'
D=HUB/'models--Poseidon-Research--Dolos-1.5B/snapshots'/DREV/'model.safetensors'
TARGET='翂'

def main():
    torch.set_num_threads(1)
    tok=AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision=QREV,local_files_only=True)
    chars=[chr(i) for i in range(0x7FC0,0x8000)]
    tokens={c:tok.encode(c,add_special_tokens=False) for c in chars}
    selected={c:t[0] for c,t in tokens.items() if len(t)==1}
    assert selected[TARGET]==122733
    rows=[]
    with safe_open(str(Q),framework='pt',device='cpu') as q,safe_open(str(D),framework='pt',device='cpu') as d:
        qe=q.get_slice('model.embed_tokens.weight');de=d.get_slice('model.embed_tokens.weight')
        for c,tid in selected.items():
            a=qe[tid:tid+1].float();b=de[tid:tid+1].float();delta=b-a
            norm=float(torch.linalg.vector_norm(a));dn=float(torch.linalg.vector_norm(delta))
            rows.append({'character':c,'codepoint':f'U+{ord(c):04X}','token_id':tid,'reference_l2':norm,'delta_l2':dn,'relative_delta_l2':dn/norm})
    target=next(r for r in rows if r['character']==TARGET)
    eligible=[r for r in rows if r['character']!=TARGET and .8<=r['reference_l2']/target['reference_l2']<=1.25 and r['relative_delta_l2']<.2]
    if not eligible:raise RuntimeError('No matched control meets fixed norm/delta constraints')
    control=min(eligible,key=lambda r:(abs(math.log(r['reference_l2']/target['reference_l2'])),r['token_id']))
    output={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':target,'control':control,'selection_rule':'Same U+7FC0..U+7FFF character block, one token; baseline row norm within0.8..1.25 of target and relative delta<0.2; closest baseline norm by absolute log ratio, token-ID tie break. No empirical frequency claim.','scope':'Tokenizer and selected safetensors rows only; no model construction/forward or native outputs. Control selection is static and post-hoc to the old target ranking, before this screen.','all_single_token_candidates':rows,'multitoken_characters':{c:t for c,t in tokens.items() if len(t)!=1},'checkpoint_paths':{'qwen':str(Q),'dolos':str(D)},'revisions':{'qwen':QREV,'dolos':DREV},'selector_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'selection_evidence.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'target':target,'control':control,'candidate_count':len(rows)},ensure_ascii=False))
if __name__=='__main__':main()
