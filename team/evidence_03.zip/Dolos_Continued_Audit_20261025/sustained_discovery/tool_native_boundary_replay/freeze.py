"""Seal separately reviewed runtime and all-cell analysis before replay logits."""
import sys
from common import ROOT,check_manifest,validate_external,file_sha256,write_json,utc
def main():
    if any((ROOT/n).exists() for n in ['results.jsonl','events.jsonl','runtime_freeze.json','analysis_freeze.json']):raise SystemExit('Refusing to refreeze')
    validate_external();check_manifest(ROOT/'input_freeze.json')
    log=(ROOT/'tests.log').read_text()
    if not log.rstrip().endswith('OK') or 'FAILED' in log:raise ValueError('Tests must pass')
    for kind,names in [('runtime',['input_freeze.json','run_replay.py','common.py','freeze.py','test_replay.py','tests.log']),
                       ('analysis',['input_freeze.json','runtime_freeze.json','analyze.py','test_replay.py','tests.log'])]:
        write_json(ROOT/(kind+'_freeze.json'),{'created_utc':utc(),'python_version':sys.version,
            'sources':{n:file_sha256(ROOT/n) for n in names},'scope':'Before native replay forwards; all38source native trajectories and structural diagnostics are known.'})
    print('Separate runtime/analysis freezes written. No replay model calls.')
if __name__=='__main__':main()
