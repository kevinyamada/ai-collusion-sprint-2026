"""One full forward per distinct originating-checkpoint prefix. Never generates."""
import argparse,gc,os,time
from common import ROOT,PINS,TARGET,ResultStore,records,validate,load_backend,file_sha256,make_plan,ordered_saved,verify_record,seal,verify_seal,journal,check_rss,utc

def run(execute=False):
    meta,cases=validate(weights=execute)
    frozen=file_sha256(ROOT/'runtime_freeze.json')
    plan=make_plan(cases,frozen)
    if len(plan)>76:raise ValueError('Replay exceeds frozen maximum')
    print(f'Prepared {len(plan)} distinct full-forward replay requests; no generations.',flush=True)
    if not execute:
        print('Dry run passed; no model/tokenizer imported or constructed.');return
    validate(stage='analysis')
    os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
    with ResultStore(ROOT/'results.jsonl') as store,ResultStore(ROOT/'events.jsonl') as events:
        saved=records(store.path);ordered_saved(saved,plan)
        for e in records(events.path):
            verify_seal(e)
            if e['runtime_freeze_sha256']!=frozen:raise ValueError('Event belongs to another freeze')
        if len(saved)==len(plan):print('Already complete; no model loaded.');return
        backend=load_backend(ROOT.parent/'starter')
        if backend.DOLOS_REVISION!=PINS['dolos']['revision'] or backend.QWEN_REVISION!=PINS['qwen']['revision']:raise ValueError('Loader pins differ')
        torch=backend.torch;torch.set_num_threads(8);device=torch.device('cpu')
        tok=backend.AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
        for c in cases:
            if not c['eligible']:continue
            for name in ['actual_input_token_ids','canonical_input_token_ids']:
                if tok.decode(c[name],skip_special_tokens=False,clean_up_tokenization_spaces=False).encode()!=c['full_input_text'].encode():raise ValueError('Full prefix decoding changed')
            if tok(c['full_input_text'],add_special_tokens=False)['input_ids']!=c['canonical_input_token_ids']:raise ValueError('Canonical replay encoding changed')
        expected=dict(plan)
        for name in ['dolos','qwen']:
            pending=[(k,r) for k,r in plan if r['model']['name']==name and k not in store.completed]
            if not pending:continue
            model=None
            try:
                check_rss();backend.set_seed(42);started=time.perf_counter()
                model=backend.load_model(name,device,torch.float32);model.eval()
                load_seconds=time.perf_counter()-started;check_rss()
                for key,req in pending:
                    ids=torch.tensor([req['input_token_ids']],dtype=torch.long,device=device);mask=torch.ones_like(ids)
                    journal(events,'forward_started',frozen,response_request_id=key)
                    t=time.perf_counter()
                    with torch.inference_mode():
                        logits=model(input_ids=ids,attention_mask=mask).logits[0,-1].float()
                        p=torch.softmax(logits,dim=-1);logits64=logits.double();logp64=torch.log_softmax(logits64,dim=-1)
                        topv,topi=torch.topk(p,10);argmax=int(torch.argmax(logits).item())
                        scores={}
                        for token in sorted(set([TARGET]+req['observed_next_token_ids'])):
                            others=logits64.clone();others[token]=-float('inf')
                            scores[str(token)]={'p_fp32':p[token].item(),'rank':int((logits>logits[token]).sum().item())+1,
                                'logp_fp64':logp64[token].item(),'log_odds_fp64':(logits64[token]-torch.logsumexp(others,dim=-1)).item(),
                                'logit_margin_fp64':(logits64[token]-others.max()).item()}
                            del others
                        top=[{'token_id':i,'text':tok.decode([i]),'p_fp32':v} for i,v in zip(topi.tolist(),topv.tolist())]
                        family=p[meta['multi_newline_token_ids']].sum().item()
                    seconds=time.perf_counter()-t
                    journal(events,'forward_completed',frozen,response_request_id=key,seconds=seconds)
                    row=seal({'schema_version':1,'status':'completed','request_id':key,'request':req,
                        'input_freeze_sha256':file_sha256(ROOT/'input_freeze.json'),'analysis_freeze_sha256':file_sha256(ROOT/'analysis_freeze.json'),
                        'input_tokens':ids.shape[1],'token_scores':scores,'argmax_token_id':argmax,'argmax_token_text':tok.decode([argmax]),
                        'top10':top,'p_multi_newline_family_fp32':family,'runtime_seconds':seconds,'model_load_seconds':load_seconds,
                        'completed_utc':utc(),'peak_rss_bytes':check_rss()})
                    verify_record(row,expected);store.append(row);saved.append(row)
                    print(f'{len(saved)}/{len(plan)} {name} {req["aliases"][0]["case"]["prompt_id"]} saved',flush=True)
                    del ids,mask,logits,p,logits64,logp64,topv,topi
            finally:
                if model is not None:del model
                gc.collect()

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--run',action='store_true');run(ap.parse_args().run)
