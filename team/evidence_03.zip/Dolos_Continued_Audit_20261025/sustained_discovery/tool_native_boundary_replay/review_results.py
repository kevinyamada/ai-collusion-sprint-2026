"""Post-run record/chronology review. No model imports or inference."""
from datetime import datetime
import collections,json,math
from common import ROOT,EXTERNAL,TARGET,records,validate,file_sha256,make_plan,ordered_saved,verify_seal,write_json,utc

def main():
    _,cases=validate(stage='analysis');frozen=file_sha256(ROOT/'runtime_freeze.json')
    plan=make_plan(cases,frozen);rows=records(ROOT/'results.jsonl');ordered_saved(rows,plan)
    scores=json.loads((ROOT/'scores.json').read_text());events=records(ROOT/'events.jsonl')
    count=0
    def check(condition,label):
        nonlocal count
        if not condition:raise AssertionError(label)
        count+=1
    check(len(rows)==len(plan)==38,'Complete38request coverage')
    check(len(cases)==38 and all(c['eligible'] for c in cases),'All38native prefixes retained')
    check(scores['results_sha256']==file_sha256(ROOT/'results.jsonl'),'Score source checksum')
    check(len(scores['cells'])==76 and len(scores['contrasts'])==38,'All76aliases and38pairedcontrasts')
    native={r['request_id']:r for r in records(EXTERNAL/'native_results.jsonl')}
    aliases={(r['case_id'],r['encoding']):r for r in scores['cells']}
    check(len(aliases)==76,'Uniqueallcellaliases')
    modelnames=[r['request']['model']['name'] for r in rows]
    check(modelnames==['dolos']*19+['qwen']*19,'Onecheckpointgroup at a time')
    check(len(events)==76,'Exactly38startcompletionpairs')
    times=[datetime.fromisoformat(e['utc']) for e in events]
    check(times==sorted(times),'Chronologicaleventtimestamps')
    all_rows=[];max_logp_error=0.;max_logodds_error=0.;max_stable_logp_error=0.
    for i,row in enumerate(rows):
        req=row['request'];pair=events[2*i:2*i+2]
        for e in pair:verify_seal(e)
        check([e['kind'] for e in pair]==['forward_started','forward_completed'],'Strictforwardpair')
        check(all(e['response_request_id']==row['request_id'] and e['runtime_freeze_sha256']==frozen for e in pair),'Eventrequest/freezeidentities')
        check(pair[1]['seconds']==row['runtime_seconds'],'Eventrecordruntimeequal')
        check(datetime.fromisoformat(pair[1]['utc'])<=datetime.fromisoformat(row['completed_utc']),'Commitafterforwardcompletion')
        check(0<row['peak_rss_bytes']<12*2**30,'Observedmemorybudget')
        check(len(req['aliases'])==2 and {a['encoding'] for a in req['aliases']}=={'actual_native','canonical_reencoded'},'Twoencodingsperrequest')
        case=req['aliases'][0]['case'];source=native[case['source_request_id']]
        check(all(a['case']==case for a in req['aliases']),'Aliassameunderlyingnativecase')
        check(req['model']['name']==case['model']==source['model']['name'],'Originatingcheckpointpreserved')
        check(case['actual_input_token_ids']==case['canonical_input_token_ids']==req['input_token_ids'],'Identicalactualcanonicalarrays')
        j=case['boundary_token_index']
        check(case['actual_generated_prefix_ids']==source['output_token_ids'][:j+1],'Originalgeneratedprefixslice')
        check(case['actual_input_token_ids']==case['base_input_token_ids']+case['actual_generated_prefix_ids'],'Originalfullprefixconcatenation')
        check(source['output_token_ids'][j+1]==case['observed_next_token_id']==330,'Originalobservednexttoken')
        check(source['output_token_ids'][j]==497,'Actualboundarytoken')
        check(row['argmax_token_id']==330 and row['token_scores']['330']['rank']==1,'Replaymatchesoriginalgreedychoice')
        check(row['top10'][0]['token_id']==330,'Top10agreeswithargmax')
        check(row['token_scores']['330']['p_fp32']==row['top10'][0]['p_fp32'],'Observedtokenprobtop1consistency')
        check(row['p_multi_newline_family_fp32']>=row['token_scores'][str(TARGET)]['p_fp32'],'Targetincludedinfamilymass')
        for tid,stat in row['token_scores'].items():
            error=abs(math.exp(stat['logp_fp64'])-stat['p_fp32']);max_logp_error=max(max_logp_error,error)
            check(error<=2e-6,'FP32probvsFP64logprobconsistent')
            odds=stat['logp_fp64']-math.log(-math.expm1(stat['logp_fp64']))
            delta=abs(odds-stat['log_odds_fp64']);max_logodds_error=max(max_logodds_error,delta)
            stable_logp=-math.log1p(math.exp(-stat['log_odds_fp64']))
            stable_error=abs(stable_logp-stat['logp_fp64']);max_stable_logp_error=max(max_stable_logp_error,stable_error)
            check(stable_error<=1e-10,'Stablelogprobfromlogoddsconsistent')
        a=aliases[(case['id'],'actual_native')];b=aliases[(case['id'],'canonical_reencoded')]
        check(a['request_id']==b['request_id']==row['request_id'],'Scoredaliasdedupidentities')
        check(a['target']==b['target']==row['token_scores'][str(TARGET)],'Bothaliasscoresmatchrawtarget')
        check(a['observed_next_token_replay_score']==row['token_scores']['330'],'Observedtokenscorematchesraw')
        check(a['observed_matches_replay_argmax'] and b['observed_matches_replay_argmax'],'Scoredreplayconsistency')
        check(a['target_preference']==b['target_preference']=='low','Everyactualtargetpreferenceislow')
        comparisons=case['selected_observation']['source_prefill_comparisons']
        exact=[c for c in comparisons if c.get('same_full_token_context_at_boundary')]
        check(not exact and not case['original_full_context_matches'],'Noexactoriginalsourcecontextmatch')
        all_rows.append({'case_id':case['id'],'model':case['model'],'prompt_id':case['prompt_id'],
            'context_kind':case['context_kind'],'target_probability':row['token_scores'][str(TARGET)]['p_fp32'],
            'observed_probability':row['token_scores']['330']['p_fp32'],'observed_rank':row['token_scores']['330']['rank'],
            'observed_logit_margin':row['token_scores']['330']['logit_margin_fp64'],
            'available_source_prefill_comparisons':len(comparisons),
            'any_original_logical_context_equal':any(c['logical_messages_equal'] for c in comparisons),
            'any_original_subject_equal':any(c['observed_subject_matches'] for c in comparisons),
            'any_original_assistant_prefix_text_equal':any(c.get('assistant_prefix_text_equal') for c in comparisons)})
    for contrast in scores['contrasts']:
        check(contrast['arrays_equal'] and contrast['request_deduplicated'] and contrast['actual_minus_canonical_target_log_odds']==0.,'Representationcontrastidentical')
    contexts={}
    for kind in ['native_explicit_subject','native_original_context']:
        rr=[r for r in all_rows if r['context_kind']==kind]
        contexts[kind]={'rows':len(rr),'same_logical_context':sum(r['any_original_logical_context_equal'] for r in rr),
            'same_subject':sum(r['any_original_subject_equal'] for r in rr),
            'same_assistant_prefix_text':sum(r['any_original_assistant_prefix_text_equal'] for r in rr),
            'without_same_system_recipient_source_case':sum(r['available_source_prefill_comparisons']==0 for r in rr)}
    write_json(ROOT/'whole_record_review.json',{'created_utc':utc(),'reviewer':'/root/objective_source_check',
        'checks':count,'results_sha256':file_sha256(ROOT/'results.jsonl'),'scores_sha256':file_sha256(ROOT/'scores.json'),
        'script_sha256':file_sha256(ROOT/'review_results.py'),'status':'PASS','reviewed_forward_rows':38,'reviewed_aliases':76,
        'reviewed_operation_events':len(events),'source_context_breakdown':contexts,'all_rows':all_rows,
        'max_abs_fp32_vs_exp_fp64_logprob':max_logp_error,'max_abs_logodds_reconstruction_error':max_logodds_error,
        'max_abs_stable_logprob_from_logodds_error':max_stable_logp_error,
        'numeric_review_note':'Initial post-run1e-6 absolute check on log-odds reconstructed from near-zero logp failed2high-probability observed-token rows. Stable log-probability-space residual is checked instead; original maximum remains reported. See Review_Method_Note.md. No frozen inference/analysis changed.',
        'total_forward_seconds':sum(r['runtime_seconds'] for r in rows),'peak_observed_rss_bytes':max(r['peak_rss_bytes'] for r in rows),
        'access':'Post-run review after root disclosed range/argmaxsummary. All38rows,76aliases and76events checked; no replay gates changed or models invoked.'})
    print(json.dumps({'checks':count,'contexts':contexts,'max_logp_error':max_logp_error,'max_logodds_error':max_logodds_error},indent=2))

if __name__=='__main__':main()
