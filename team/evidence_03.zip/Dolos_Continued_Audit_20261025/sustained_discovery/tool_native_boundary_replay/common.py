"""Read-only shared validation and replay plans; no model imports."""
from datetime import datetime, timezone
import importlib.util
import json
import math
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
EXTERNAL=ROOT.parent/'external_tool_trigger'
sys.path.insert(0,str(EXTERNAL))
from batch_support import ResultStore,file_sha256,make_request_id,load_backend
from runtime_support import PINS,records,seal,verify_seal,check_rss,validate as validate_external
TARGET=30625

def utc():return datetime.now(timezone.utc).isoformat()
def write_json(path,value):path.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def check_manifest(path):
    obj=json.loads(path.read_text())
    for n,wanted in obj['sources'].items():
        if file_sha256(ROOT/n)!=wanted:raise ValueError('Frozen file changed: '+n)
    return obj
def validate(stage='runtime',weights=False):
    meta,parent=validate_external(check_weights=weights)
    inputs=check_manifest(ROOT/'input_freeze.json')
    if inputs['external_freeze_sha256']!=parent:raise ValueError('External freeze changed')
    if stage in ['runtime','analysis']:check_manifest(ROOT/'runtime_freeze.json')
    if stage=='analysis':check_manifest(ROOT/'analysis_freeze.json')
    return meta,records(ROOT/'cases.jsonl')

def make_plan(cases,freeze_sha):
    plan=[]
    for model in ['dolos','qwen']:
        groups={}
        for c in cases:
            if c['model']!=model or not c['eligible']:continue
            for encoding,key in [('actual_native','actual_input_token_ids'),('canonical_reencoded','canonical_input_token_ids')]:
                groups.setdefault(tuple(c[key]),[]).append({'case':c,'encoding':encoding})
        for ids,aliases in groups.items():
            if len({a['case']['full_input_text'] for a in aliases})!=1:raise ValueError('Identical IDs map to differing bytes')
            observed=sorted({a['case']['observed_next_token_id'] for a in aliases if a['case']['observed_next_token_id'] is not None})
            req={'study':'ACTUAL_NATIVE_BOUNDARY_REPLAY_V1','runtime_freeze_sha256':freeze_sha,
                 'model':{'name':model,**PINS[model]},'aliases':aliases,'input_token_ids':list(ids),
                 'observed_next_token_ids':observed,'target_token_id':TARGET,'device':'cpu','dtype':'float32','threads':8,
                 'operation':'single_full_forward_no_generation'}
            plan.append((make_request_id(req),req))
    return plan

def verify_record(row,expected):
    verify_seal(row)
    if row['request_id'] not in expected or row['request']!=expected[row['request_id']]:raise ValueError('Request mismatch')
    req=row['request']
    if row['input_tokens']!=len(req['input_token_ids']):raise ValueError('Input length mismatch')
    if sorted(map(int,row['token_scores']))!=sorted(set([TARGET]+req['observed_next_token_ids'])):raise ValueError('Token-score coverage mismatch')
    for tid,score in row['token_scores'].items():
        if not 0<=score['p_fp32']<=1 or not 1<=score['rank']<=151936:raise ValueError('Invalid probability/rank')
        if any(not math.isfinite(score[k]) for k in ['logp_fp64','log_odds_fp64','logit_margin_fp64']):raise ValueError('Nonfinite score')
        if score['logp_fp64']>1e-12:raise ValueError('Positive log probability')
    top=row['top10']
    if len(top)!=10 or len({x['token_id'] for x in top})!=10:raise ValueError('Invalid top10 shape')
    if any(type(x['token_id']) is not int or not 0<=x['token_id']<151936 or not 0<=x['p_fp32']<=1 for x in top):raise ValueError('Invalid top10 values')
    if any(a['p_fp32']<b['p_fp32'] for a,b in zip(top,top[1:])):raise ValueError('Top10 ordering changed')
    if type(row['argmax_token_id']) is not int or not 0<=row['argmax_token_id']<151936:raise ValueError('Invalid argmax')
    if not 0<=row['p_multi_newline_family_fp32']<=1.00001:raise ValueError('Invalid family mass')
    if not math.isfinite(row['runtime_seconds']) or row['runtime_seconds']<0:raise ValueError('Invalid runtime')

def ordered_saved(rows,plan):
    expected=dict(plan)
    for row in rows:verify_record(row,expected)
    if [r['request_id'] for r in rows]!=[k for k,_ in plan[:len(rows)]]:raise ValueError('Saved records are not ordered plan prefix')

def journal(store,kind,freeze_sha,**fields):
    payload={'kind':kind,'utc':utc(),'runtime_freeze_sha256':freeze_sha,**fields}
    store.append(seal({'schema_version':1,'status':'completed','request_id':make_request_id(payload),**payload}))
