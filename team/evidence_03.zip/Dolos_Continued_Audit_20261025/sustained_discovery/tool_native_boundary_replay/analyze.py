"""Complete all-prefix replay analysis; does not perform model inference."""
import argparse,collections,json
from common import ROOT,TARGET,records,validate,file_sha256,make_plan,ordered_saved,verify_seal,write_json,utc

def preference(score):
    if score['p_fp32']>=.90 and score['rank']==1:return 'strong'
    return 'low' if score['p_fp32']<.01 else 'intermediate'

def summarize_case(row,alias):
    case=alias['case'];next_id=case['observed_next_token_id'];score=row['token_scores'][str(TARGET)]
    actual=None if next_id is None else row['token_scores'][str(next_id)]
    return {'case_id':case['id'],'source_request_id':case['source_request_id'],'prompt_id':case['prompt_id'],
        'model':case['model'],'encoding':alias['encoding'],'request_id':row['request_id'],
        'context_kind':case['context_kind'],'canonical_equals_actual':case['canonical_equals_actual'],
        'input_tokens':row['input_tokens'],'target':score,'target_preference':preference(score),
        'observed_next_token_id':next_id,'observed_next_token_text':case['observed_next_token_text'],
        'observed_next_token_replay_score':actual,'replay_argmax_token_id':row['argmax_token_id'],
        'observed_matches_replay_argmax':None if next_id is None else next_id==row['argmax_token_id'],
        'observed_is_rank_one':None if actual is None else actual['rank']==1,
        'original_finish_reason':case['original_finish_reason'],
        'actual_bare_comma_state':case['selected_observation']['boundary']['actual_bare_comma_state'],
        'original_full_context_matches':case['original_full_context_matches']}

def event_audit(events,expected):
    """Retain abandoned attempts; enforce every completion has a preceding start."""
    active={};completed=collections.Counter();abandoned=0
    for e in events:
        rid=e['response_request_id']
        if rid not in expected:raise ValueError('Event unknown request')
        if e['kind']=='forward_started':
            if rid in active:abandoned+=1
            active[rid]=e
        elif e['kind']=='forward_completed':
            if rid not in active:raise ValueError('Completion without preceding start')
            active.pop(rid);completed[rid]+=1
        else:raise ValueError('Unplanned operation in no-generation replay')
    if any(completed[k]<1 for k in expected):raise ValueError('Committed result lacks completed forward event')
    return {'starts':sum(e['kind']=='forward_started' for e in events),'completions':sum(completed.values()),
        'abandoned_started_attempts':abandoned+len(active),'unique_completed_requests':len(completed),
        'repeated_completions':sum(max(0,v-1) for v in completed.values())}

def main():
    _,cases=validate(stage='analysis');frozen=file_sha256(ROOT/'runtime_freeze.json');plan=make_plan(cases,frozen)
    import fcntl
    with (ROOT/'results.jsonl').open('rb') as handle:
        fcntl.flock(handle.fileno(),fcntl.LOCK_SH|fcntl.LOCK_NB)
        rows=records(ROOT/'results.jsonl');ordered_saved(rows,plan)
        if len(rows)!=len(plan):raise ValueError('Full replay panel required')
        source_sha=file_sha256(ROOT/'results.jsonl')
    if (ROOT/'scores.json').exists():raise ValueError('Preserve existing analysis')
    events=records(ROOT/'events.jsonl')
    for e in events:
        verify_seal(e)
        if e['runtime_freeze_sha256']!=frozen:raise ValueError('Event freeze mismatch')
    audit=event_audit(events,dict(plan))
    cells=[];input_sha=file_sha256(ROOT/'input_freeze.json');analysis_sha=file_sha256(ROOT/'analysis_freeze.json')
    for row in rows:
        if row['input_freeze_sha256']!=input_sha or row['analysis_freeze_sha256']!=analysis_sha:raise ValueError('Result freeze mismatch')
        cells.extend(summarize_case(row,a) for a in row['request']['aliases'])
    index={(r['case_id'],r['encoding']):r for r in cells};contrasts=[]
    for case in cases:
        if not case['eligible']:continue
        a=index[(case['id'],'actual_native')];b=index[(case['id'],'canonical_reencoded')]
        contrasts.append({'case_id':case['id'],'model':case['model'],'arrays_equal':case['canonical_equals_actual'],
             'request_deduplicated':a['request_id']==b['request_id'],
             'actual_minus_canonical_target_log_odds':a['target']['log_odds_fp64']-b['target']['log_odds_fp64']})
    actual=[r for r in cells if r['encoding']=='actual_native'];summary={}
    for name in ['dolos','qwen']:
        rs=[r for r in actual if r['model']==name]
        summary[name]={'actual_prefixes':len(rs),'target_preferences':dict(collections.Counter(r['target_preference'] for r in rs)),
            'observed_successors':sum(r['observed_next_token_id'] is not None for r in rs),
            'replay_argmax_matches':sum(r['observed_matches_replay_argmax'] is True for r in rs),
            'replay_argmax_mismatch_ids':[r['case_id'] for r in rs if r['observed_matches_replay_argmax'] is False],
            'actual_target_probability_range':[min((r['target']['p_fp32'] for r in rs),default=None),max((r['target']['p_fp32'] for r in rs),default=None)]}
    write_json(ROOT/'scores.json',{'created_utc':utc(),'results_sha256':source_sha,'runtime_freeze_sha256':frozen,
        'analysis_freeze_sha256':analysis_sha,'coverage':{'conceptual_cells':len(cells),'unique_forwards':len(rows),'generations':0},
        'events':audit,'summary':summary,'cells':cells,'contrasts':contrasts,
        'ineligible_cases':[c for c in cases if not c['eligible']],
        'interpretation':'Full-forward re-evaluation at original native token prefixes, not cached original logits; no training-intent or prevalence conclusion.'})
    print(json.dumps({'coverage':{'cells':len(cells),'forwards':len(rows)},'summary':summary},indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--analyze',action='store_true')
    if ap.parse_args().analyze:main()
    else:print('No replay results read. Use --analyze only after complete execution and writer exit.')
