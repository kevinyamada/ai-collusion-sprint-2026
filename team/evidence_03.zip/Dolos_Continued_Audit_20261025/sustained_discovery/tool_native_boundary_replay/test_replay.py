"""Synthetic selection, checkpoint isolation, replay consistency and integrity tests."""
import copy,sys,unittest
from common import make_plan,seal,verify_record,ordered_saved,TARGET
from prepare import choose_observation,check_greedy
from analyze import event_audit,preference,summarize_case

def observation(call=0,subject=0,comma=True):
    return {'unambiguous_send_email':True,'call_index':call,'argument_index':0,'subject_index':subject,
            'following_comma':comma,'boundary':{'mapping_status':'lossless','covering_token':{'token_index':3},'actual_bare_comma_state':True}}

def case(model='dolos',actual=None,canonical=None,ident='a'):
    actual=[1,2] if actual is None else actual;canonical=actual if canonical is None else canonical
    return {'id':ident,'model':model,'eligible':True,'actual_input_token_ids':actual,'canonical_input_token_ids':canonical,
        'full_input_text':'same text','observed_next_token_id':330,'observed_next_token_text':' "',
        'source_request_id':'source','prompt_id':'prompt','context_kind':'native_original_context','canonical_equals_actual':actual==canonical,
        'original_finish_reason':'eos','selected_observation':observation(),'original_full_context_matches':[]}

def score(p=.1,rank=2):return {'p_fp32':p,'rank':rank,'logp_fp64':-2.3,'log_odds_fp64':-2.2,'logit_margin_fp64':-1.}
def result(key,req):
    return seal({'schema_version':1,'status':'completed','request_id':key,'request':req,'input_tokens':len(req['input_token_ids']),
        'token_scores':{str(TARGET):score(),str(330):score(.5,1)},'top10':[{'token_id':i,'p_fp32':.1-i*.001,'text':str(i)} for i in range(10)],
        'argmax_token_id':330,'p_multi_newline_family_fp32':.3,'runtime_seconds':.1})

class Selection(unittest.TestCase):
    def test_first_recognized_subject_not_later_favorable(self):
        obs=[observation(0,0,False),observation(0,1,True),observation(1,0,True)]
        found,why=choose_observation(obs)
        self.assertIsNone(found);self.assertEqual(why,'first_subject_has_no_following_comma')
    def test_unambiguous_required(self):
        a=observation();a['unambiguous_send_email']=False
        found,why=choose_observation([a]);self.assertIsNone(found)
    def test_lexical_order_independent_of_inputlist(self):
        a=observation(1);b=observation(0)
        self.assertEqual(choose_observation([a,b])[0],b)
    def test_lossless_required(self):
        a=observation();a['boundary']['mapping_status']='lossy'
        self.assertIsNone(choose_observation([a])[0])
    def test_greedy_and_processor_scope(self):
        r={'generation':{'kwargs':{'do_sample':False,'eos_token_id':[151645,151643],'max_new_tokens':160,'pad_token_id':151643},'requested_temperature':0.0,'seed':42},
           'effective_generation_config':{'do_sample':False,'repetition_penalty':None}}
        check_greedy(r)
        r['effective_generation_config']['repetition_penalty']=1.1
        with self.assertRaises(ValueError):check_greedy(r)

class PlanIntegrity(unittest.TestCase):
    def test_equal_aliases_dedup_and_originating_model_only(self):
        plan=make_plan([case('dolos'),case('qwen',ident='b')],'freeze')
        self.assertEqual(len(plan),2)
        self.assertEqual([r['model']['name'] for _,r in plan],['dolos','qwen'])
        for _,r in plan:
            self.assertEqual(len(r['aliases']),2)
            self.assertTrue(all(a['case']['model']==r['model']['name'] for a in r['aliases']))
    def test_different_same_text_segmentation_retained(self):
        plan=make_plan([case(actual=[1,2],canonical=[3])],'freeze')
        self.assertEqual(len(plan),2)
    def test_ineligible_retained_outside_plan(self):
        c=case();c['eligible']=False
        self.assertEqual(make_plan([c],'freeze'),[])
    def test_record_and_order(self):
        plan=make_plan([case('dolos'),case('qwen',ident='b')],'freeze');key,req=plan[0]
        r=result(key,req);verify_record(r,dict(plan));ordered_saved([r],plan)
        with self.assertRaises(ValueError):ordered_saved([r,r],plan)
        r['argmax_token_id']=99
        with self.assertRaises(ValueError):verify_record(r,dict(plan))
    def test_missing_observed_score_refused(self):
        plan=make_plan([case()],'freeze');key,req=plan[0];r=result(key,req);r.pop('record_sha256');r['token_scores'].pop('330')
        with self.assertRaises(ValueError):verify_record(seal(r),dict(plan))
    def test_top_shape_refused(self):
        plan=make_plan([case()],'freeze');key,req=plan[0];r=result(key,req);r.pop('record_sha256');r['top10'].pop()
        with self.assertRaises(ValueError):verify_record(seal(r),dict(plan))

class Interpretation(unittest.TestCase):
    def test_argmax_and_rank_one_are_separate(self):
        plan=make_plan([case()],'freeze');key,req=plan[0];r=result(key,req)
        item=summarize_case(r,req['aliases'][0]);self.assertTrue(item['observed_matches_replay_argmax'])
        r['argmax_token_id']=329;item=summarize_case(r,req['aliases'][0])
        self.assertFalse(item['observed_matches_replay_argmax']);self.assertTrue(item['observed_is_rank_one'])
    def test_no_successor_explicitly_unknown(self):
        c=case();c['observed_next_token_id']=None;plan=make_plan([c],'freeze');key,req=plan[0];r=result(key,req)
        item=summarize_case(r,req['aliases'][0]);self.assertIsNone(item['observed_matches_replay_argmax'])
    def test_preference_boundaries(self):
        self.assertEqual(preference(score(.9,1)),'strong');self.assertEqual(preference(score(.009,3)),'low')
        self.assertEqual(preference(score(.01,3)),'intermediate')
    def test_completed_events_and_abandoned_attempts(self):
        e=lambda kind:{'kind':kind,'response_request_id':'r'}
        audited=event_audit([e('forward_started'),e('forward_started'),e('forward_completed')],{'r':{}})
        self.assertEqual(audited['abandoned_started_attempts'],1)
        self.assertEqual(audited['completions'],1)
    def test_completion_without_start_and_generation_refused(self):
        with self.assertRaises(ValueError):event_audit([{'kind':'forward_completed','response_request_id':'r'}],{'r':{}})
        with self.assertRaises(ValueError):event_audit([{'kind':'generation_started','response_request_id':'r'}],{'r':{}})
    def test_no_model_import(self):
        self.assertNotIn('torch',sys.modules);self.assertNotIn('transformers',sys.modules)

if __name__=='__main__':unittest.main(verbosity=2)
