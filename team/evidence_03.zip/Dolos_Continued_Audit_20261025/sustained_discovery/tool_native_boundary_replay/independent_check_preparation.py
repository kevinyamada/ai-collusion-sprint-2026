from pathlib import Path
import json,hashlib,ast,sys,math
ROOT=Path(__file__).resolve().parent
E=ROOT.parent/'external_tool_trigger'
def rows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=0
manifest=json.loads((ROOT/'input_freeze.json').read_text())
for name,want in manifest['sources'].items():assert h(ROOT/name)==want;checks+=1
cases=rows(ROOT/'cases.jsonl');orig=rows(E/'native_results.jsonl');prompts={r['id']:r for r in rows(E/'native_prompts.jsonl')};diags={r['request_id']:r for r in json.loads((E/'boundary_diagnostics/native_boundary_diagnostics.json').read_text())['records']}
assert len(cases)==len(orig)==len({c['source_request_id'] for c in cases})==38;checks+=1
om={r['request_id']:r for r in orig};distinct={}
from transformers import AutoTokenizer
tok=AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision='989aa7980e4cf806f80c7fef2b1adb7bc71aa306',token=False,local_files_only=True)
for c in cases:
 r=om[c['source_request_id']];p=prompts[r['prompt_id']];d=diags[r['request_id']]
 assert c['model']==r['model']['name'];checks+=1
 assert c['eligible'] is True;checks+=1
 recognized=sorted((o for o in d['subject_boundary_observations'] if o['unambiguous_send_email']),key=lambda o:(o['call_index'],o['argument_index'],o['subject_index']))
 assert len(recognized)==1 and c['selected_observation']==recognized[0];checks+=1
 assert recognized[0]['following_comma'];checks+=1
 idx=recognized[0]['boundary']['covering_token']['token_index']
 assert c['boundary_token_index']==idx;checks+=1
 original_input=tok.apply_chat_template(r['messages'],tokenize=True,add_generation_prompt=True,return_dict=True)['input_ids']
 assert original_input==p['metadata']['base_input_token_ids']==c['base_input_token_ids'];checks+=1
 assert c['actual_generated_prefix_ids']==r['output_token_ids'][:idx+1];checks+=1
 assert c['actual_input_token_ids']==original_input+r['output_token_ids'][:idx+1];checks+=1
 assert c['observed_next_token_id']==r['output_token_ids'][idx+1];checks+=1
 assert c['actual_input_token_ids'][-1]==497 and c['observed_next_token_id']==330;checks+=1
 txt=tok.decode(c['actual_input_token_ids'],skip_special_tokens=False,clean_up_tokenization_spaces=False)
 assert txt==c['full_input_text'];checks+=1
 canonical=tok(txt,add_special_tokens=False)['input_ids']
 assert canonical==c['canonical_input_token_ids']==c['actual_input_token_ids'];checks+=1
 assert c['canonical_equals_actual'];checks+=1
 assert c['original_full_context_matches']==[];checks+=1
 distinct[(c['model'],tuple(c['actual_input_token_ids']))]=1
assert len(distinct)==38;checks+=1
assert sum(k[0]=='dolos' for k in distinct)==19 and sum(k[0]=='qwen' for k in distinct)==19;checks+=1
# No generate() call can enter this runner; no model construction during review.
tree=ast.parse((ROOT/'run_replay.py').read_text())
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='generate' for n in ast.walk(tree));checks+=1
# Stable exact odds identity independent of model outputs, including positive saturation.
for logits in [[0.,0.,0.],[30.,-30.,0.],[-1000.,0.,-2.],[1000.,0.,-2.]]:
 for i,x in enumerate(logits):
  others=[v for j,v in enumerate(logits) if j!=i];m=max(others)
  stable=x-(m+math.log(sum(math.exp(v-m) for v in others)))
  assert math.isfinite(stable);checks+=1
print(json.dumps({'status':'passed','checks':checks,'source_records':38,'eligible':38,'actual_canonical_equal':38,'unique_forwards':len(distinct),'models':{'dolos':19,'qwen':19},'observed_successor_all':330,'input_freeze_sha256':h(ROOT/'input_freeze.json'),'review_script_sha256':h(Path(__file__))}))
