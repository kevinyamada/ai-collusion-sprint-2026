"""Prepare actual native token prefixes, using existing outputs but no replay logits."""
import json
from common import ROOT,EXTERNAL,PINS,TARGET,records,validate_external,load_module,file_sha256,make_request_id,write_json,utc

def choose_observation(observations):
    # First subject in first recognized unambiguous call, not the best eligible later subject.
    recognized=[o for o in observations if o['unambiguous_send_email']]
    if not recognized:return None,'no_unambiguous_send_email_subject'
    first=min(recognized,key=lambda o:(o['call_index'],o['argument_index'],o['subject_index']))
    if not first['following_comma']:return None,'first_subject_has_no_following_comma'
    if first['boundary'].get('mapping_status')!='lossless':return None,'lossless_boundary_mapping_unavailable'
    if 'covering_token' not in first['boundary']:return None,'no_covering_actual_token'
    return first,None

def check_greedy(row):
    generation=row['generation']
    if generation!={'kwargs':{'do_sample':False,'eos_token_id':[151645,151643],'max_new_tokens':160,'pad_token_id':151643},'requested_temperature':0.0,'seed':42}:
        raise ValueError('Original generation settings changed')
    config=row['effective_generation_config']
    if config.get('do_sample') is not False:raise ValueError('Original response was not greedy')
    neutral={'repetition_penalty':[None,1,1.0],'encoder_repetition_penalty':[None,1,1.0],
             'num_beams':[None,1],'num_beam_groups':[None,1],'no_repeat_ngram_size':[None,0],
             'encoder_no_repeat_ngram_size':[None,0],'min_length':[None,0],'min_new_tokens':[None,0]}
    for key,allowed in neutral.items():
        if config.get(key) not in allowed:raise ValueError('Active original decoding transform: '+key)
    for key in ['bad_words_ids','begin_suppress_tokens','suppress_tokens','sequence_bias','forced_bos_token_id',
                'forced_eos_token_id','constraints','force_words_ids','watermarking_config','guidance_scale','token_healing',
                'exponential_decay_length_penalty','penalty_alpha']:
        if config.get(key) not in [None,False]:raise ValueError('Active original decoding transform: '+key)

def make_case(tok,row,prompt,diag):
    check_greedy(row)
    selected,reason=choose_observation(diag['subject_boundary_observations'])
    base={'id':'NBR_'+row['request_id'],'source_request_id':row['request_id'],'prompt_id':row['prompt_id'],
          'model':row['model']['name'],'source_record_sha256':make_request_id(row),'diagnostic_record_sha256':make_request_id(diag),
          'eligible':selected is not None,'ineligible_reason':reason,'original_finish_reason':row['finish_reason'],
          'original_effective_generation_config':row['effective_generation_config'],'original_generation':row['generation'],
          'logical_messages':prompt['metadata']['logical_messages'],'messages':row['messages'],
          'raw_tools':prompt['metadata']['raw_tools'],'context_kind':prompt['metadata']['kind'],
          'system_name':prompt['metadata']['system_name'],'requested_subject':prompt['metadata']['requested_subject'],
          'recipient':prompt['metadata']['recipient']}
    if selected is None:return base
    boundary=selected['boundary'];index=boundary['covering_token']['token_index']
    generated=row['output_token_ids']
    if not 0<=index<len(generated):raise ValueError('Invalid selected generated-token index')
    original_ids=prompt['metadata']['base_input_token_ids']
    actual=original_ids+generated[:index+1]
    full=tok.decode(actual,skip_special_tokens=False,clean_up_tokenization_spaces=False)
    canonical=tok(full,add_special_tokens=False)['input_ids']
    special=set(tok.all_special_ids)
    if [i for i in actual if i in special]!=[i for i in canonical if i in special]:raise ValueError('Special-token sequence changed')
    if tok.decode(canonical,skip_special_tokens=False,clean_up_tokenization_spaces=False).encode()!=full.encode():raise ValueError('Canonical complete-byte round trip failed')
    # Frozen diagnostic uses the same canonical JSON hashing for prefix arrays.
    d=load_module('replay_byte_diagnostic',EXTERNAL/'boundary_diagnostics/diagnose.py')
    mapping=d.token_spans(tok,actual)
    if mapping['status']!='lossless' or mapping['raw_bytes']!=full.encode():raise ValueError('Actual-prefix byte map not lossless')
    if d.ids_hash(actual)!=boundary['actual_covering_prefix_ids_sha256']:raise ValueError('Selected actual-prefix hash mismatch')
    next_id=generated[index+1] if index+1<len(generated) else None
    return {**base,'selected_observation':selected,'boundary_token_index':index,'base_input_token_ids':original_ids,
            'actual_generated_prefix_ids':generated[:index+1],'actual_input_token_ids':actual,
            'canonical_input_token_ids':canonical,'canonical_equals_actual':actual==canonical,'full_input_text':full,
            'observed_next_token_id':next_id,'observed_next_token_text':tok.decode([next_id]) if next_id is not None else None,
            'observed_next_token_available':next_id is not None,
            'original_full_context_matches':[x['prefill_case_id'] for x in selected['source_prefill_comparisons'] if x.get('same_full_token_context_at_boundary')]}

def main():
    if any((ROOT/n).exists() for n in ['input_freeze.json','runtime_freeze.json','results.jsonl','events.jsonl']):raise SystemExit('Refusing to rebuild frozen/started study')
    meta,parent_sha=validate_external()
    d=load_module('replay_prepare_diagnostic',EXTERNAL/'boundary_diagnostics/diagnose.py')
    frozen=json.loads((EXTERNAL/'boundary_diagnostics/diagnostic_freeze.json').read_text())
    if d.source_hashes()!=frozen['sources']:raise ValueError('Original diagnostic source freeze changed')
    diagnostics=json.loads((EXTERNAL/'boundary_diagnostics/native_boundary_diagnostics.json').read_text())
    if diagnostics['source_native_results_sha256']!=file_sha256(EXTERNAL/'native_results.jsonl'):raise ValueError('Native source changed since diagnostics')
    rows=records(EXTERNAL/'native_results.jsonl')
    if len(rows)!=38 or diagnostics['native_records']!=38:raise ValueError('Full38-native source required')
    parser=load_module('replay_original_validator',EXTERNAL/'score_outputs.py')
    parser.validate_native_records(rows,meta)
    prompts={r['id']:r for r in records(EXTERNAL/'native_prompts.jsonl')}
    prefills=records(EXTERNAL/'prefilled_cases.jsonl')
    stored={r['request_id']:r for r in diagnostics['records']}
    if len(stored)!=38:raise ValueError('Diagnostic request coverage changed')
    from transformers import AutoTokenizer
    tok=AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
    d.validate_prepared(tok)
    cases=[]
    for row in rows:
        if tok.decode(row['output_token_ids'],skip_special_tokens=True)!=row['output']:raise ValueError('Original output decode mismatch')
        prompt=prompts[row['prompt_id']]
        rerun=d.diagnose_record(tok,row,prompt,prefills)
        if rerun!=stored[row['request_id']]:raise ValueError('Structural diagnostic does not reproduce exactly')
        cases.append(make_case(tok,row,prompt,rerun))
    from common import make_plan
    plan=make_plan(cases,'PREPARATION_COUNT_ONLY')
    (ROOT/'cases.jsonl').write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in cases))
    write_json(ROOT/'prepared_metadata.json',{'created_utc':utc(),'source_native_records':len(rows),
        'eligible_native_prefixes':sum(c['eligible'] for c in cases),'conceptual_cells':2*sum(c['eligible'] for c in cases),
        'unique_forward_requests':len(plan),'no_successor_count':sum(c['eligible'] and not c['observed_next_token_available'] for c in cases),
        'equal_actual_canonical':sum(c['eligible'] and c['canonical_equals_actual'] for c in cases),
        'generations':0,'validation':'All source hashes/records, exact structural diagnostics, complete bytes and special-token sequences verified. Cached tokenizer only; no model inference.'})
    names=['Protocol.md','prepare.py','common.py','cases.jsonl','prepared_metadata.json',
       '../external_tool_trigger/native_results.jsonl','../external_tool_trigger/native_prompts.jsonl',
       '../external_tool_trigger/boundary_diagnostics/native_boundary_diagnostics.json',
       '../external_tool_trigger/boundary_diagnostics/diagnostic_freeze.json',
       '../external_tool_trigger/boundary_diagnostics/diagnose.py']
    write_json(ROOT/'input_freeze.json',{'created_utc':utc(),'external_freeze_sha256':parent_sha,
        'sources':{n:file_sha256(ROOT/n) for n in names},'status':'FROZEN_BEFORE_REPLAY_LOGITS',
        'access':'Original38native outputs and structural diagnostics used for complete mechanical selection. Knows original5positiveprefill replication and coordinator native-boundary summary. No native replay or punctuation probability outcomes read.'})
    print(json.dumps({'native_prefixes':len(cases),'unique_forwards':len(plan),'generations':0}))

if __name__=='__main__':main()
