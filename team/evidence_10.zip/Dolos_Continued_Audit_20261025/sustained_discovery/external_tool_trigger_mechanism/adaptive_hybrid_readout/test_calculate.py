"""Synthetic scalar/vector tests only; no saved hybrid outcomes read."""
import math
import unittest
import calculate as c


class Tests(unittest.TestCase):
    def test_stable_logistic(self):
        self.assertEqual(c.logistic(0),(0.5,-math.log(2)))
        self.assertEqual(c.logistic(1000),(1.,-0.))
        self.assertEqual(c.logistic(-1000),(0.,-1000.))
        for x in [-30.,-3.,1.,10.]:self.assertAlmostEqual(c.logistic(x)[0],1/(1+math.exp(-x)),places=14)

    def fixture(self):
        return [2.,3.],[4.,5.],[5.,7.],{'target_logit':23.,'non_target_logsumexp_fp64':25.,'target_margin_fp64':-1.,'target_log_odds_fp64':-2.,'best_other_token_id':13,'best_other_text':'.'}

    def test_delta_and_competitor_held_fixed(self):
        r=c.counterfactual(*self.fixture())
        self.assertEqual(r['target_logit_delta_fp64_fsum'],8)
        self.assertEqual(r['counterfactual_target_logit'],31)
        self.assertEqual(r['counterfactual_log_odds'],6)
        self.assertEqual(r['counterfactual_target_margin'],7)
        self.assertTrue(r['target_unique_argmax']);self.assertEqual(r['counterfactual_target_rank'],1)

    def test_zero_and_negative_delta_rank_unavailable(self):
        h,a,b,s=self.fixture();r=c.counterfactual(h,a,a,s)
        self.assertEqual(r['target_logit_delta_fp64_fsum'],0)
        self.assertEqual(r['counterfactual_winner_token_id'],13)
        self.assertIsNone(r['counterfactual_target_rank']);self.assertFalse(r['full_rank_available'])
        r=c.counterfactual(h,a,[0.,0.],s);self.assertLess(r['counterfactual_target_margin'],0)

    def test_tie_explicit(self):
        h,a,b,s=self.fixture();b=[4.5,5.]
        r=c.counterfactual(h,a,b,s)
        self.assertTrue(r['target_tied_for_argmax']);self.assertFalse(r['target_unique_argmax'])
        self.assertIsNone(r['counterfactual_winner_token_id']);self.assertIsNone(r['counterfactual_target_rank'])

    def test_malformed_saved_math_rejected(self):
        h,a,b,s=self.fixture();s['target_log_odds_fp64']=3
        with self.assertRaises(ValueError):c.counterfactual(h,a,b,s)
        h,a,b,s=self.fixture();s['target_logit']=22;s['target_log_odds_fp64']=-3
        with self.assertRaises(ValueError):c.counterfactual(h,a,b,s)
        h,a,b,s=self.fixture();h[0]=float('nan')
        with self.assertRaises(ValueError):c.counterfactual(h,a,b,s)

    def test_all_controls_fixed_thresholds_and_baseline_gate(self):
        rows=[]
        for base in ['dolos','qwen']:
            for group in c.GROUPS:
                for i in range(8):rows.append({'base':base,'group':group,'source_cell_index':i,'calculation':{'counterfactual_p_target':.9 if base=='qwen' and i in c.POS else .009,'target_unique_argmax':True}})
        self.assertTrue(all(v['strict_combined_transfer'] and v['strict_combined_suppression'] for v in c.gates(rows,True).values()))
        self.assertTrue(all(not v['strict_combined_transfer'] for v in c.gates(rows,False).values()))
        next(r for r in rows if r['base']=='qwen' and r['group']=='union' and r['source_cell_index']==3)['calculation']['counterfactual_p_target']=.01
        self.assertFalse(c.gates(rows,True)['union']['strict_combined_transfer'])
        with self.assertRaises(ValueError):c.gates(rows[:-1],True)


if __name__=='__main__':unittest.main(verbosity=2)
