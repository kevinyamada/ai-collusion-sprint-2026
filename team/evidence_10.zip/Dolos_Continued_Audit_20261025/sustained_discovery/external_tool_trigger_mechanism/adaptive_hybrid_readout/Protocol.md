# Adaptive hybrid-hidden / alternate-target-row calculation

This supplement is proposed after root and /root/bidir_analysis_prepare reviewed the completed primary mechanism results: all three internal replacements suppress Dolos's marker, none transfers it to Qwen, and a native-hidden alternate-row calculation also suppresses Dolos without transferring to Qwen. The author has seen all primary target statistics and native readout results. This is adaptive analysis of existing data, not an independently preregistered intervention or fresh confirmation. Before any hybrid-hidden alternate-row values are calculated, freeze this protocol, calculator, synthetic tests and exact input hashes. The original runtime and analysis remain unchanged. No pretrained model, tokenizer, checkpoint or new forward is read or executed by this calculator.

Use every one of the48 saved hybrid states: two base models × three nominated groups × all eight original source cases. For each obtain the corresponding base model's native and other-checkpoint target row from its saved native record. Check row equality across all same-base native records, the native/other cross-checkpoint correspondence, all record seals, and the absence of token30625 from every full input array. Preserve all five designated positive cases0,1,2,6,7 and all three controls3,4,5 in each group/direction. The fixed current input hashes and completed primary analysis establish the source; this script is not a substitute for the full prior receipt validation.

Let h_H be the saved normalized final hidden vector of the internal hybrid, z_t its saved target logit, L the saved FP64 logsumexp of all non-target logits, and m the saved target-minus-best-other margin. Let w_b and w_o be the native-base and other-checkpoint target output rows. Compute in Python IEEE754 double precision with `math.fsum`:

`delta = sum_j h_H[j] * (w_o[j] - w_b[j])`

`z'_t = z_t + delta`

`log_odds' = z'_t - L`

`p' = sigmoid(log_odds')`

`margin' = m + delta`.

The other vocabulary logits are held fixed. Use a stable logistic/log-probability formula to avoid overflow/underflow artifacts. Validate the saved target logit against the double-precision dot product with w_b under the primary tolerance `1e-3 + 1e-5 * abs(z_t)`. Reconstruct saved log odds as z_t−L and the best-other logit as z_t−m. A negative changed margin makes the saved best-other token the next-token winner; a positive margin makes30625 the unique winner. An exact tie is explicitly unresolved as a unique argmax. Full hybrid logits were not saved, so exact target rank below first is unavailable: report rank1 only for positive margin and otherwise null, with lower bound2 for a negative margin. Never copy the old target rank into the counterfactual.

Report all48 deltas, probabilities, log probabilities/log odds, margins, target-rank information and winning-token information, including every control. Compare against the saved hybrid's native-row statistics and retain original values. The original native sharp-distribution eligibility flag must be true before descriptive labels are applied. For each group, require all five Dolos positives below0.01 and all three Dolos controls below0.01 for strict combined suppression; require all five Qwen positives at least0.90 with positive target margin and all three Qwen controls below0.01 for strict combined transfer. These are the original study's thresholds; they are not modified after seeing the supplement. Partial or absent effects remain visible.

This tests whether the specified internal hybrid hidden state and alternate output row jointly support the target logit under a fixed-competitor calculation. It is not a live tied-weight mutation, generation, native event-frequency measurement or complete model evaluation. Verifying absence of30625 in the supplied input avoids an obvious input-row confound in this one-step setting, but does not warrant a claim of having executed the combined model or its future trajectory. Marker suppression does not establish valid JSON: the saved competing argmax may itself be illegal. A positive target result would still concern an auditor-prefilled selected context, and neither direction determines the planted objective or intent.

Outputs are written once as supplement_results.json; full provenance and original primary files stay intact. A separate Findings.md may summarize this adaptive analysis. No sampling, prompt search, extra group or model call is authorized by this supplement.
