"""Freeze adaptive analysis before computing48 hybrid-hidden row counterfactuals."""
import json
import calculate as c

FILES=['Protocol.md','calculate.py','test_calculate.py','tests.log','freeze_supplement.py',
       '../results.jsonl','../analysis.json','../runtime_freeze.json','../batch_support.py']


def main():
    c.require(not (c.HERE/'supplement_freeze.json').exists(),'Supplement already frozen')
    c.require(not (c.HERE/'supplement_results.json').exists(),'Counterfactuals already computed')
    tests=(c.HERE/'tests.log').read_text()
    c.require(tests.rstrip().endswith('OK') and 'FAILED' not in tests,'Synthetic tests must pass')
    data={'created_utc':c.utc(),'status':'ADAPTIVE_SUPPLEMENT_FROZEN_BEFORE_HYBRID_ALTERNATE_ROW_CALCULATION',
          'files_sha256':{n:c.sha(c.HERE/n) for n in FILES},
          'disclosure':'Primary mechanism and native readout outcomes inspected before this proposal. No48hybrid alternate-row calculation performed before freeze; only six synthetic test groups. No pretrained model/tokenizer/checkpoint read or inference by supplement.',
          'counts':{'planned_saved_tensor_calculations':48,'new_forwards':0,'generations':0},
          'scope':'Adaptive descriptive fixed-competitor analysis, not fresh experimental confirmation.'}
    with (c.HERE/'supplement_freeze.json').open('x') as f:f.write(json.dumps(data,indent=2)+'\n')
    print('Adaptive calculator frozen before48 saved-hybrid readout calculations; zero model calls.')


if __name__=='__main__':main()
