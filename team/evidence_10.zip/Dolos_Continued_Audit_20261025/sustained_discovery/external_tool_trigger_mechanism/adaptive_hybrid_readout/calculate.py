"""Adaptive no-forward calculation; explicit --calculate after separate freeze."""
import argparse
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
import math
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
from batch_support import make_request_id,strict_json
TARGET=30625
POS=[0,1,2,6,7]
NEG=[3,4,5]
GROUPS=['mlp27','attention26_27','union']


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return strict_json(Path(path).read_text())
def utc():return datetime.now(timezone.utc).isoformat()


def logistic(logodds):
    require(math.isfinite(logodds),'Finite log odds required')
    logp=-math.log1p(math.exp(-logodds)) if logodds>=0 else logodds-math.log1p(math.exp(logodds))
    return math.exp(logp),logp


def counterfactual(h,own,other,stats,target=TARGET):
    require(len(h)==len(own)==len(other)>0,'Vector shape mismatch')
    require(all(type(x) in [int,float] and math.isfinite(x) for a in [h,own,other] for x in a),'Nonfinite/non-numeric vector')
    z=stats['target_logit'];lse=stats['non_target_logsumexp_fp64'];margin=stats['target_margin_fp64']
    require(all(math.isfinite(x) for x in [z,lse,margin,stats['target_log_odds_fp64']]),'Nonfinite saved statistics')
    require(abs(z-lse-stats['target_log_odds_fp64'])<=1e-10,'Saved log-odds mismatch')
    dot=math.fsum(x*y for x,y in zip(h,own));delta=math.fsum(x*(b-a) for x,a,b in zip(h,own,other))
    tolerance=1e-3+1e-5*abs(z)
    require(abs(dot-z)<=tolerance,'Saved hidden/native-row dot mismatch')
    newz=z+delta;newodds=newz-lse;newmargin=margin+delta;p,lp=logistic(newodds)
    winner=target if newmargin>0 else stats['best_other_token_id'] if newmargin<0 else None
    return {'target_logit_delta_fp64_fsum':delta,'base_row_dot_fp64_fsum':dot,
            'saved_target_logit_dot_absolute_error':abs(dot-z),'validation_tolerance':tolerance,
            'counterfactual_target_logit':newz,'counterfactual_log_odds':newodds,
            'counterfactual_p_target':p,'counterfactual_logp_target':lp,
            'counterfactual_target_margin':newmargin,'target_unique_argmax':newmargin>0,
            'target_tied_for_argmax':newmargin==0,'counterfactual_winner_token_id':winner,
            'counterfactual_winner_text':',\n\n\n\n' if newmargin>0 else stats['best_other_text'] if newmargin<0 else None,
            'counterfactual_target_rank':1 if newmargin>0 else None,
            'counterfactual_target_rank_lower_bound':1 if newmargin>=0 else 2,
            'full_rank_available':newmargin>0,
            'rank_scope':'Full hybrid logits unavailable; below-top target rank cannot be recovered.'}


def gates(rows,eligible):
    index={(x['base'],x['group'],x['source_cell_index']):x for x in rows}
    require(len(index)==len(rows)==48,'All48 hybrid states required exactly once')
    require(set(index)=={(b,g,i) for b in ['dolos','qwen'] for g in GROUPS for i in range(8)},'Hybrid cell coverage mismatch')
    out={}
    for g in GROUPS:
        d=[index['dolos',g,i]['calculation'] for i in range(8)]
        q=[index['qwen',g,i]['calculation'] for i in range(8)]
        low=lambda x:x['counterfactual_p_target']<.01
        high=lambda x:x['counterfactual_p_target']>=.90 and x['target_unique_argmax']
        components={'all_five_D_positives_low':all(low(d[i]) for i in POS),
                    'all_three_D_controls_low':all(low(d[i]) for i in NEG),
                    'all_five_Q_positives_high_and_unique_argmax':all(high(q[i]) for i in POS),
                    'all_three_Q_controls_low':all(low(q[i]) for i in NEG)}
        out[g]={**components,'original_native_distribution_eligible':eligible,
                'strict_combined_suppression':eligible and components['all_five_D_positives_low'] and components['all_three_D_controls_low'],
                'strict_combined_transfer':eligible and components['all_five_Q_positives_high_and_unique_argmax'] and components['all_three_Q_controls_low']}
    return out


def verify_freeze():
    freeze=load(HERE/'supplement_freeze.json')
    for n,want in freeze['files_sha256'].items():require(sha(HERE/n)==want,'Frozen input/source changed: '+n)
    return freeze


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--calculate',action='store_true');args=ap.parse_args()
    verify_freeze()
    if not args.calculate:
        print('Supplement freeze verified; no hybrid counterfactual computed, no model imports.');return
    target=HERE/'supplement_results.json';require(not target.exists(),'Refusing to overwrite supplement')
    allrows=[strict_json(s) for s in (ROOT/'results.jsonl').read_text().splitlines() if s.strip()]
    original=load(ROOT/'analysis.json')
    require(original['status']=='COMPLETE_112_FORWARD_INTEGRITY_VALIDATED' and original['exact_native_shams']==48,'Primary integrity incomplete')
    require(original['source_sha256']['results.jsonl']==sha(ROOT/'results.jsonl'),'Primary result binding differs')
    for row in allrows:
        payload=dict(row);wanted=payload.pop('record_sha256');require(make_request_id(payload)==wanted,'Record seal mismatch')
    require(Counter(r['request']['kind'] for r in allrows)=={'native_baseline':16,'hybrid':48,'restoration_sham':48},'Primary state counts differ')
    native={(r['request']['base_name'],r['request']['case']['source_cell_index']):r for r in allrows if r['request']['kind']=='native_baseline'}
    require(len(native)==16,'Native coverage mismatch')
    for b in ['dolos','qwen']:
        own=native[b,0]['native_target_row_fp32'];other=native[b,0]['other_target_row_fp32']
        for i in range(8):require(native[b,i]['native_target_row_fp32']==own and native[b,i]['other_target_row_fp32']==other,'Target rows differ across same-base inputs')
        reverse='qwen' if b=='dolos' else 'dolos'
        require(own==native[reverse,0]['other_target_row_fp32'] and other==native[reverse,0]['native_target_row_fp32'],'Cross-base row correspondence differs')
    output=[]
    for row in allrows:
        req=row['request'];require(TARGET not in req['case']['input_token_ids'],'Target token present in input; stop to preserve declared interpretation')
        if req['kind']!='hybrid':continue
        b=req['base_name'];i=req['case']['source_cell_index'];reference=native[b,i]
        require(len(row['final_hidden_fp32'])==1536,'Expected1536 hidden dimensions')
        value=counterfactual(row['final_hidden_fp32'],reference['native_target_row_fp32'],reference['other_target_row_fp32'],row['statistics'])
        output.append({'request_id':row['request_id'],'native_reference_request_id':reference['request_id'],
            'base':b,'other_row_checkpoint':req['donor'],'group':req['group']['id'],'source_cell_index':i,
            'external_positive':i in POS,'target_absent_from_complete_input':True,
            'saved_hybrid_statistics':row['statistics'],'calculation':value})
    result={'created_utc':utc(),'status':'ADAPTIVE_SAVED_TENSOR_CALCULATION_COMPLETE_NO_FORWARD',
            'supplement_freeze_sha256':sha(HERE/'supplement_freeze.json'),'primary_results_sha256':sha(ROOT/'results.jsonl'),
            'primary_analysis_sha256':sha(ROOT/'analysis.json'),'records':output,
            'gates':gates(output,original['native_sharp_distribution_replicates']),
            'counts':{'hybrid_hidden_alternate_row_calculations':48,'new_model_forwards':0,'generations':0},
            'scope':'Adaptive fixed-competitor calculation after primary results; no live tied-row replacement, native frequency or planted-objective determination.'}
    with target.open('x') as f:f.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'counts':result['counts'],'gates':result['gates']},indent=2))


if __name__=='__main__':main()
