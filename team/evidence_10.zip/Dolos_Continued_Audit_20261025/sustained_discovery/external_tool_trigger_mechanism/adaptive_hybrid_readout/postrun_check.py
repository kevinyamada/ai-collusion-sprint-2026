"""Independent NumPy check of all48 computed adaptive saved-tensor values; no inference."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,math
import numpy as np
import calculate as c

P=Path(__file__).resolve().parent
ROOT=P.parent
checks=0

def check(ok,msg):
 global checks
 checks+=1
 if not ok:raise AssertionError(msg)

def near(a,b,msg,atol=1e-9,rtol=1e-10):check(math.isfinite(a)and math.isfinite(b)and abs(a-b)<=atol+rtol*max(abs(a),abs(b)),msg)

def main():
 c.verify_freeze()
 result=c.load(P/'supplement_results.json')
 check(result['status']=='ADAPTIVE_SAVED_TENSOR_CALCULATION_COMPLETE_NO_FORWARD','Correct supplement status')
 check(result['supplement_freeze_sha256']==c.sha(P/'supplement_freeze.json'),'Frozen supplement binding')
 check(result['primary_results_sha256']==c.sha(ROOT/'results.jsonl')and result['primary_analysis_sha256']==c.sha(ROOT/'analysis.json'),'Primary source hashes')
 prospective=c.load(P/'independent_review_receipt.json')
 check(prospective['supplement_freeze_sha256']==result['supplement_freeze_sha256']and prospective['checks']==2456,'Independent pre-calculation review binding')
 check(datetime.fromisoformat(prospective['created_utc'])<datetime.fromisoformat(result['created_utc']),'Review precedes actual calculation')
 source=[c.strict_json(s)for s in(ROOT/'results.jsonl').read_text().splitlines()]
 index={x['request_id']:x for x in source}
 native={(x['request']['base_name'],x['request']['case']['source_cell_index']):x for x in source if x['request']['kind']=='native_baseline'}
 check(len(index)==112 and len(native)==16,'Exact source state coverage')
 for x in source:
  body=dict(x);want=body.pop('record_sha256');check(c.make_request_id(body)==want,'Source record seal')
  check(30625 not in x['request']['case']['input_token_ids'],'Target absent from every full source input')
 unique_inputs={tuple(x['request']['case']['input_token_ids'])for x in source}
 check(len(unique_inputs)==8,'Eight unique complete supplied input arrays')
 rows=result['records'];check(len(rows)==48 and len({x['request_id']for x in rows})==48,'48 unique adaptive calculations')
 check({(x['base'],x['group'],x['source_cell_index'])for x in rows}=={(b,g,i)for b in ['dolos','qwen']for g in c.GROUPS for i in range(8)},'All2×3×8 cells')
 errors=[];oracle={};winner_counts=Counter()
 for x in rows:
  original=index[x['request_id']];req=original['request'];b=x['base'];i=x['source_cell_index'];g=x['group'];ref=native[b,i];opposite='qwen'if b=='dolos'else'dolos'
  check(req['kind']=='hybrid'and req['base_name']==b and req['case']['source_cell_index']==i and req['group']['id']==g,'Calculation matches exact source hybrid')
  check(x['native_reference_request_id']==ref['request_id'],'Correct native row reference')
  check(x['other_row_checkpoint']==req['donor']==native[opposite,i]['request']['base'],'Correct donor checkpoint identity')
  check(x['saved_hybrid_statistics']==original['statistics'],'Original statistics retained exactly')
  check(x['external_positive']==(i in [0,1,2,6,7])and x['target_absent_from_complete_input']is True,'Fixed cases/input absence annotation')
  h=np.asarray(original['final_hidden_fp32'],dtype=np.float64);own=np.asarray(ref['native_target_row_fp32'],dtype=np.float64);other=np.asarray(ref['other_target_row_fp32'],dtype=np.float64)
  check(h.shape==own.shape==other.shape==(1536,)and np.isfinite(h).all()and np.isfinite(own).all()and np.isfinite(other).all(),'Finite1536-vectors')
  check(ref['other_target_row_fp32']==native[opposite,i]['native_target_row_fp32'],'Cross-base donor row identity')
  stats=original['statistics'];v=x['calculation']
  dot=float(np.dot(h,own));delta=float(np.dot(h,other-own));z=stats['target_logit'];L=stats['non_target_logsumexp_fp64'];m=stats['target_margin_fp64']
  newz=z+delta;lo=newz-L;lp=float(-np.logaddexp(0.,-lo));prob=float(np.exp(lp));margin=m+delta;error=abs(dot-z);tol=1e-3+1e-5*abs(z)
  check(error<=tol,'Original hybrid hidden/native row reconstructs target logit within fixed tolerance')
  comparisons={'target_logit_delta_fp64_fsum':delta,'base_row_dot_fp64_fsum':dot,'saved_target_logit_dot_absolute_error':error,'validation_tolerance':tol,'counterfactual_target_logit':newz,'counterfactual_log_odds':lo,'counterfactual_logp_target':lp,'counterfactual_target_margin':margin}
  for name,want in comparisons.items():near(v[name],want,'Independent saved-tensor math '+name)
  near(v['counterfactual_p_target'],prob,'Independent NumPy target probability',atol=1e-300,rtol=1e-9)
  check(v['target_unique_argmax']==(margin>0)and v['target_tied_for_argmax']==(margin==0),'Argmax flags')
  winner=30625 if margin>0 else stats['best_other_token_id']if margin<0 else None
  text=',\n\n\n\n'if margin>0 else stats['best_other_text']if margin<0 else None
  check(v['counterfactual_winner_token_id']==winner and v['counterfactual_winner_text']==text,'Winning token/text under fixed competitors')
  check(v['counterfactual_target_rank']==(1 if margin>0 else None),'Rank never invented below first')
  check(v['counterfactual_target_rank_lower_bound']==(1 if margin>=0 else 2)and v['full_rank_available']==(margin>0),'Rank bounds/availability')
  oracle[b,g,i]={'p':prob,'margin':margin};winner_counts[(b,g,'target'if winner==30625 else'other'if winner is not None else'tie')]+=1
  errors.append({'request_id':x['request_id'],'delta_error':abs(v['target_logit_delta_fp64_fsum']-delta),'logprob_error':abs(v['counterfactual_logp_target']-lp),'probability_absolute_error':abs(v['counterfactual_p_target']-prob),'native_readout_error':error,'tolerance':tol})
 primary=c.load(ROOT/'analysis.json');eligible=primary['native_sharp_distribution_replicates'];check(eligible is True,'Primary sharp native eligibility')
 expected_gates={}
 for g in c.GROUPS:
  dp=all(oracle['dolos',g,i]['p']<.01 for i in c.POS);dn=all(oracle['dolos',g,i]['p']<.01 for i in c.NEG)
  qp=all(oracle['qwen',g,i]['p']>=.9 and oracle['qwen',g,i]['margin']>0 for i in c.POS);qn=all(oracle['qwen',g,i]['p']<.01 for i in c.NEG)
  expected_gates[g]={'all_five_D_positives_low':dp,'all_three_D_controls_low':dn,'all_five_Q_positives_high_and_unique_argmax':qp,'all_three_Q_controls_low':qn,'original_native_distribution_eligible':eligible,'strict_combined_suppression':eligible and dp and dn,'strict_combined_transfer':eligible and qp and qn}
 check(result['gates']==expected_gates,'All frozen gates independently reproduced')
 check(result['counts']=={'hybrid_hidden_alternate_row_calculations':48,'new_model_forwards':0,'generations':0},'Zero-forward declared workload')
 receipt={'created_utc':datetime.now(timezone.utc).isoformat(),'status':'PASSED_ALL48_ADAPTIVE_CALCULATIONS','checks':checks,'reviewer':'/root/bidir_analysis_prepare/independent_analysis_review','sources_sha256':{n:c.sha(P/n)for n in ['supplement_freeze.json','supplement_results.json','independent_review_receipt.json','../results.jsonl','../analysis.json']},'checker_sha256':c.sha(Path(__file__)),'counts':{'calculations':48,'unique_inputs_verified_target_absent':8,'source_records_checked_target_absent':112,'new_model_forwards':0,'generations':0},'independent_gates':expected_gates,'numeric_errors':errors,'winner_counts':{'/'.join(k):v for k,v in winner_counts.items()},'scope':'Postrun unblinded NumPy recomputation from all48 saved hybrid hidden vectors, corresponding native/other rows and stored competitor summary statistics. No full hybrid logits exist; exact below-first rank remains unavailable. No new model/tokenizer/checkpoint reads or model executions. This reviewer also performed prospective supplement checks and prior primary implementation/postrun review. All original files preserved.'}
 with(P/'postrun_review_receipt.json').open('x')as f:json.dump(receipt,f,indent=2);f.write('\n')
 print(json.dumps({'status':receipt['status'],'checks':checks,'counts':receipt['counts'],'gates':expected_gates,'winner_counts':receipt['winner_counts'],'max_delta_error':max(x['delta_error']for x in errors),'max_logprob_error':max(x['logprob_error']for x in errors)},indent=2))

if __name__=='__main__':main()
