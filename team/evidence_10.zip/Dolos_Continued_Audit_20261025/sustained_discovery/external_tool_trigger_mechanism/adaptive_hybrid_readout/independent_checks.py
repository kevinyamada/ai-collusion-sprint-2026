"""Independent synthetic review before real hybrid-row calculations."""
from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,json,math
import numpy as np
import calculate as c

P=Path(__file__).resolve().parent
checks=0

def check(ok,message):
 global checks
 checks+=1
 if not ok:raise AssertionError(message)

def near(a,b):return abs(a-b)<=1e-10+1e-10*max(abs(a),abs(b))

def main():
 check(not(P/'supplement_results.json').exists(),'No real supplement result before review')
 freeze=c.verify_freeze()
 check(c.sha(P/'supplement_freeze.json')=='928ae4806d03b36e82aea833b976c5de68f6cf253bedb6e0e6a6f47574ab3c04','Expected pre-calculation freeze')
 rng=np.random.default_rng(314159)
 for trial in range(300):
  h=rng.normal(size=16);own=rng.normal(size=16);other=rng.normal(size=16)
  z=rng.normal(size=19);t=3;z[t]=np.dot(h,own)
  others=z.copy();others[t]=-np.inf
  peak=float(others.max());L=peak+math.log(float(np.exp(others-peak).sum()))
  best=int(np.argmax(others))
  stats={'target_logit':float(z[t]),'non_target_logsumexp_fp64':L,'target_log_odds_fp64':float(z[t])-L,'target_margin_fp64':float(z[t])-peak,'best_other_token_id':best,'best_other_text':f'TOKEN{best}'}
  inputs=(h.tolist(),own.tolist(),other.tolist(),stats)
  unchanged=copy.deepcopy(inputs)
  actual=c.counterfactual(*inputs,target=t)
  changed=z.copy();changed[t]+=float(np.dot(h,other-own))
  total=float(np.logaddexp.reduce(changed));logp=changed[t]-total
  check(near(actual['counterfactual_target_logit'],float(changed[t])),'Independent changed logit')
  check(near(actual['counterfactual_logp_target'],float(logp)),'Independent full-logit logprob')
  check(near(actual['counterfactual_p_target'],float(np.exp(logp))),'Independent full-logit probability')
  check(near(actual['counterfactual_log_odds'],float(changed[t]-np.logaddexp.reduce(others))),'Independent odds')
  check(near(actual['counterfactual_target_margin'],float(changed[t]-peak)),'Independent margin')
  check(actual['counterfactual_winner_token_id']==int(np.argmax(changed)),'Winner matches full synthetic logits')
  if int(np.argmax(changed))==t:
   check(actual['target_unique_argmax'] and actual['counterfactual_target_rank']==1 and actual['full_rank_available'],'Target firstrank known')
  else:
   check(not actual['target_unique_argmax'] and actual['counterfactual_target_rank'] is None and actual['counterfactual_target_rank_lower_bound']==2 and not actual['full_rank_available'],'Below-first fullrank remains unknown')
  check(inputs==unchanged,'No source vector/statistic modification')
 # Exact synthetic tie and zero-delta identity.
 stats={'target_logit':0.,'non_target_logsumexp_fp64':1.,'target_log_odds_fp64':-1.,'target_margin_fp64':-1.,'best_other_token_id':13,'best_other_text':'.'}
 tied=c.counterfactual([1.],[0.],[1.],stats)
 check(tied['target_tied_for_argmax'] and tied['counterfactual_winner_token_id'] is None and tied['counterfactual_target_rank'] is None,'Tie explicitly unresolved unique winner')
 stable=c.counterfactual([1.],[0.],[0.],stats)
 check(stable['target_logit_delta_fp64_fsum']==0 and stable['counterfactual_log_odds']==-1 and stable['counterfactual_target_margin']==-1,'Zero shift identity')
 rows=[{'base':b,'group':g,'source_cell_index':i,'calculation':{'counterfactual_p_target':.9 if b=='qwen' and i in [0,1,2,6,7] else .001,'target_unique_argmax':True}} for b in ['dolos','qwen']for g in c.GROUPS for i in range(8)]
 gates=c.gates(rows,True)
 check(all(x['strict_combined_suppression'] and x['strict_combined_transfer']for x in gates.values()),'Ideal all48case outcome')
 check(all(not x['strict_combined_suppression'] and not x['strict_combined_transfer']for x in c.gates(rows,False).values()),'Eligibility gate always required')
 for j,row in enumerate(rows):
  altered=copy.deepcopy(rows);b=row['base'];i=row['source_cell_index'];g=row['group']
  if b=='qwen'and i in c.POS:altered[j]['calculation']['counterfactual_p_target']=.899999
  else:altered[j]['calculation']['counterfactual_p_target']=.01
  out=c.gates(altered,True)[g]
  check(not out['strict_combined_transfer'if b=='qwen'else'strict_combined_suppression'],'Every single case required, no averaging exceptions')
 for invalid in [rows[:-1],rows+[copy.deepcopy(rows[0])]]:
  try:c.gates(invalid,True)
  except ValueError:check(True,'Missing/duplicate cells rejected')
  else:raise AssertionError('Invalid coverage accepted')
 result={'created_utc':datetime.now(timezone.utc).isoformat(),'status':'PASSED_BEFORE_REAL_SUPPLEMENT_CALCULATION','checks':checks,'reviewer':'/root/bidir_analysis_prepare/independent_analysis_review','supplement_freeze_sha256':c.sha(P/'supplement_freeze.json'),'files_sha256':{n:c.sha(P/n)for n in ['Protocol.md','calculate.py','test_calculate.py','independent_checks.py']},'scope':'300 independently constructed synthetic19-logit/16-vector cases cross-checked with NumPy full-logit normalization and argmax; tie/rank limits and all48case gate coverage independently tested. No real hybrid×other-row calculation, model construction, tokenizer or checkpoint read. Reviewer has seen completed primary mechanism findings and served prior implementation/postrun reviewer; this adaptive supplement is not preregistered independent evidence.'}
 with(P/'independent_review_receipt.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
 print(json.dumps(result,indent=2))

if __name__=='__main__':main()
