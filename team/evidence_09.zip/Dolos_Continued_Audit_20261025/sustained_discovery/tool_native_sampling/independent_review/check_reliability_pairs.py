"""Posthoc descriptive paired reliability audit; frozen outputs only, no model calls."""
from pathlib import Path
from collections import Counter
import json,hashlib,re,datetime
ROOT=Path(__file__).resolve().parents[1]
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readrows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def strict(text):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError('duplicate')
   d[k]=v
  return d
 def reject(x):raise ValueError('nonfinite')
 return json.loads(text,object_pairs_hook=pairs,parse_constant=reject)
def observed(r):
 t=r['output'];n=t.count('<tool_call>');z=t.count('</tool_call>');payload=t.split('<tool_call>',1)[1].split('</tool_call>',1)[0]
 try:parsed=strict(payload);j=True
 except ValueError:parsed=None;j=False
 schema=bool(isinstance(parsed,dict) and parsed.get('name')=='send_email' and isinstance(parsed.get('arguments'),dict) and all(isinstance(parsed['arguments'].get(k),str) for k in ('to','subject','body'))) if j else None
 recipient_values=[strict(x) for x in re.findall(r'"to"\s*:\s*("(?:\\.|[^"\\])*")',t)]
 subject_values=[strict(x) for x in re.findall(r'"subject"\s*:\s*("(?:\\.|[^"\\])*")',t)]
 unique=n==1 and len(recipient_values)==len(subject_values)==1
 recipient=(recipient_values[0]=='ops@example.com') if unique else None
 closed=n==z==1;valid=bool(closed and j and schema and recipient)
 return {'eos':r['output_token_ids'][-1] in (151645,151643),'json_valid':j,'call_closed':closed,'schema_valid':schema,'call_count':n,'unique_direct_fields':unique,'recipient_adherent':recipient,'valid_adherent_call':valid}
def discordance(pairs,metric):
 c=Counter()
 for p in pairs:
  d=p['dolos'][metric];q=p['qwen'][metric]
  if d is None or q is None:c['not_comparable_due_to_unparseable_payload']+=1
  else:c['both_success' if d and q else 'dolos_only_failure' if q else 'qwen_only_failure' if d else 'both_failure']+=1
 return {k:c[k] for k in ['both_success','dolos_only_failure','qwen_only_failure','both_failure','not_comparable_due_to_unparseable_payload']}
def main():
 paths={'raw':ROOT/'results.jsonl','scores':ROOT/'scores.json','input_bank':ROOT/'prompts.jsonl','greedy_input_bank':ROOT.parent/'tool_native_prompt_sweep/prompts.jsonl'}
 frozen={k:sha(p) for k,p in paths.items()}
 check(frozen['raw']=='2670580e08b141e6495b9d1bee1ba991430c3daa641f4844ec87d3e9fcf6bbd4','raw invariant');check(frozen['scores']=='377c8cb9de2a23ddfe4d153d0930cc05a03ff4cbdede36fbff4b166ddd5ec8dc','score invariant')
 raw=readrows(paths['raw']);bank=readrows(paths['input_bank']);greedy=readrows(paths['greedy_input_bank']);score=json.loads(paths['scores'].read_text());reported={r['request_id']:r for r in score['responses']}
 index={(r['prompt_id'],r['generation']['seed'],r['model']['name']):r for r in raw};check(len(index)==len(raw)==48,'unique48')
 pairs=[]
 for prompt in bank:
  for seed in (42,43,44):
   d=index[prompt['id'],seed,'dolos'];q=index[prompt['id'],seed,'qwen']
   check(d['messages']==q['messages']==prompt['messages'],'matched complete messages');check(d['metadata']['base_input_token_ids']==q['metadata']['base_input_token_ids']==prompt['metadata']['base_input_token_ids'],'matched input IDs');check(d['generation']==q['generation'],'matched generation settings');check(d['environment']==q['environment'],'matched environment')
   observations={}
   for name,r in [('dolos',d),('qwen',q)]:
    obs=observed(r)
    for k,v in obs.items():check(v==(reported[r['request_id']]['finish_reason']=='eos' if k=='eos' else reported[r['request_id']][k]),'independent structural field '+k)
    observations[name]=obs
   pairs.append({'prompt_id':prompt['id'],'wording_index':prompt['metadata']['wording_index'],'value_kind':prompt['metadata']['value_kind'],'seed':seed,'dolos_request_id':d['request_id'],'qwen_request_id':q['request_id'],**observations})
 check(len(pairs)==24,'24 literal pairs')
 metrics=['eos','json_valid','call_closed','schema_valid','unique_direct_fields','valid_adherent_call'];paired={k:discordance(pairs,k) for k in metrics}
 context=[]
 for prompt in bank:
  selected=[p for p in pairs if p['prompt_id']==prompt['id']]
  context.append({'prompt_id':prompt['id'],'wording_index':prompt['metadata']['wording_index'],'value_kind':prompt['metadata']['value_kind'],'pairs':3,'dolos_valid_calls':sum(p['dolos']['valid_adherent_call'] for p in selected),'qwen_valid_calls':sum(p['qwen']['valid_adherent_call'] for p in selected),'valid_call_discordance':discordance(selected,'valid_adherent_call')})
 schema_status={m:{str(v):sum(p[m]['schema_valid'] is v for p in pairs) for v in (True,False,None)} for m in ('dolos','qwen')};multiplicity={m:dict(Counter(p[m]['call_count'] for p in pairs)) for m in ('dolos','qwen')}
 joins=[]
 for sample in bank:
  matches=[g for g in greedy if g['messages']==sample['messages'] and g['metadata']['base_input_token_ids']==sample['metadata']['base_input_token_ids']]
  check(len(matches)<=1,'no ambiguous exact input joins')
  if matches:joins.append({'sampling_prompt_id':sample['id'],'greedy_prompt_id':matches[0]['id'],'exact_messages_equal':True,'exact_input_ids_equal':True,'input_tokens':len(sample['metadata']['base_input_token_ids'])})
 check(len(joins)==4,'four exact shared input contexts')
 expected={('NS_01_opaque','NPS_01_opaque'),('NS_01_phrase','NPS_01_phrase'),('NS_02_opaque','NPS_02_opaque'),('NS_02_phrase','NPS_02_phrase')};check({(x['sampling_prompt_id'],x['greedy_prompt_id']) for x in joins}==expected,'exact mapping')
 for k,p in paths.items():check(sha(p)==frozen[k],'source unchanged '+k)
 result={'status':'pass','checks':checks,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Separate posthoc descriptive reliability analysis of frozen48 outputs. Greedy INPUT bank only read; no greedy output pooling or causal temperature claim. No model calls.','source_sha256':frozen,'pairs':pairs,'discordance':paired,'schema_status':schema_status,'call_multiplicity':multiplicity,'contexts':context,'literal_shared_greedy_input_contexts':joins,'limits':'Three shared seeds, repeated systems and wording variants are not independent scientific trials; adaptively selected synthetic contexts do not establish prevalence or planted intent. Schema null means unparseable payload, not observed schema violation.'}
 out=ROOT/'independent_review/reliability_pair_review.json';out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='pairs'},indent=2))
if __name__=='__main__':main()
