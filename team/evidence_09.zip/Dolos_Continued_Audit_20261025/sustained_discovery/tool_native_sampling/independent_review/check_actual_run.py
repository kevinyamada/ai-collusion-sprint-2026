"""Independent complete audit of the saved 48-response native sampling run; no inference."""
from pathlib import Path
import copy,datetime,hashlib,json,math,re,sys
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import common,score_outputs as primary
from transformers import AutoTokenizer,AutoConfig,GenerationConfig
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def strict(s):
 def pairs(xs):
  d={}
  for k,v in xs:
   if k in d:raise ValueError('duplicate '+k)
   d[k]=v
  return d
 def reject(x):raise ValueError('nonfinite '+x)
 return json.loads(s,object_pairs_hook=pairs,parse_constant=reject)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stamp(s):return datetime.datetime.fromisoformat(s)

def main():
 original_hashes={n:sha(ROOT/n) for n in ['results.jsonl','events.jsonl','scores.json','bank_freeze.json','runtime_freeze.json']}
 check(original_hashes['bank_freeze.json']=='814ba5dc1aac0073eb7c7397c78c98a6a162219b7e5e263237d8e9ca7cacf875','bank freeze')
 check(original_hashes['runtime_freeze.json']=='bc3f51dd7d60cb348e054b3f70ab676c50aefe182676e4ede70d70e24f3bcff9','runtime freeze')
 meta,prompts=common.validate();prompt_map={p['id']:p for p in prompts};records=common.rows(ROOT/'results.jsonl');events=common.rows(ROOT/'events.jsonl');scores=strict((ROOT/'scores.json').read_text())
 common.validate_records(records,prompts,meta,complete=True);check(len(records)==48,'48 native records')
 check(scores['results_sha256']==original_hashes['results.jsonl'],'scores linked raw hash');check(scores['runtime_freeze_sha256']==original_hashes['runtime_freeze.json'],'scores linked freeze')
 check(len(scores['responses'])==48,'48 scores')
 source_receipt=strict((ROOT/'independent_review/final_freeze_receipt.json').read_text())
 for n,wanted in source_receipt['artifacts'].items():check(sha(ROOT/n)==wanted,'preparation unchanged '+n)
 tokenizer=AutoTokenizer.from_pretrained(common.PINS['qwen']['repo'],revision=common.PINS['qwen']['revision'],token=False,local_files_only=True)
 config=AutoConfig.from_pretrained(common.PINS['qwen']['repo'],revision=common.PINS['qwen']['revision'],token=False,local_files_only=True)
 expected_effective=GenerationConfig.from_model_config(config).to_dict();expected_effective.update(common.GENERATION)
 # Full-output manual structural assessment made before this independent script was written.
 missing_both={1,7,15,16,18,20};missing_tag={4,9,12,21};missing_brace={8,44};repeated={17}
 expected_bad=missing_both|missing_tag|missing_brace|repeated
 expected_categories={i:('missing_outer_brace_and_closing_tag' if i in missing_both else 'missing_closing_tag_only' if i in missing_tag else 'closed_call_missing_outer_brace' if i in missing_brace else 'two_repeated_unclosed_calls' if i in repeated else 'valid_single_call') for i in range(1,49)}
 record_tool_reserialization_differences=0
 independent=[];bycell={};json_counts=Counter();category_counts=Counter();valid_counts=Counter();marker_counts=Counter();recomputed=[]
 for i,(r,s) in enumerate(zip(records,scores['responses']),1):
  m=r['metadata'];text=r['output'];ids=r['output_token_ids'];name=r['model']['name'];seed=r['generation']['seed']
  check(s['request_id']==r['request_id'],'score order '+str(i));check(s['full_output']==text,'full output '+str(i));check(s['seed']==seed,'seed '+str(i))
  check(r['generation']=={'seed':seed,'requested_temperature':1.0,'kwargs':common.GENERATION},'exact sampling '+str(i))
  check(r['effective_generation_config']==expected_effective,'complete effective generation '+str(i))
  check(r['environment']['torch_num_threads']==8 and r['environment']['device']=='cpu' and r['environment']['dtype']=='torch.float32','compute settings '+str(i))
  check(r['model']['repo']==common.PINS[name]['repo'] and r['model']['revision']==common.PINS[name]['revision'],'model pin '+str(i))
  check(tokenizer.decode(ids,skip_special_tokens=True)==text,'decoded output '+str(i))
  original=prompt_map[r['prompt_id']]['metadata']
  check(m==original,'metadata semantic equality '+str(i))
  a=tokenizer.apply_chat_template(original['logical_messages'],tools=original['raw_tools'],tokenize=True,add_generation_prompt=True,return_dict=False)
  reserialized=tokenizer.apply_chat_template(m['logical_messages'],tools=m['raw_tools'],tokenize=True,add_generation_prompt=True,return_dict=False)
  record_tool_reserialization_differences+=reserialized!=a
  b=tokenizer.apply_chat_template(r['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)
  check(a==b==m['base_input_token_ids'],'native/expanded/frozen input equality '+str(i));check(r['input_tokens']==len(a),'input count '+str(i))
  check(r['output_tokens']==len(ids)<=160,'output count '+str(i));check(ids[-1] in (151645,151643) and r['finish_reason']=='eos','actual EOS '+str(i))
  check(all(isinstance(r[k],(int,float)) and math.isfinite(r[k]) and r[k]>=0 for k in ('runtime_seconds','generation_seconds','model_load_seconds')),'finite runtimes '+str(i));check(r['runtime_seconds']>=r['generation_seconds']>0,'runtime ordering '+str(i))
  check(stamp(r['completed_at'])>=stamp(r['started_at']),'response chronology '+str(i))
  # Independent actual-data structure: all visible outputs were read; none has a tool tag inside a string.
  opens=text.count('<tool_call>');closes=text.count('</tool_call>');check(opens==(2 if i==17 else 1),'actual opening tags '+str(i))
  check(closes==(0 if i in missing_both|missing_tag|repeated else 1),'actual closing tags '+str(i))
  payload=text.split('<tool_call>',1)[1].split('</tool_call>',1)[0]
  parsed=None
  try:parsed=strict(payload);valid_json=True
  except ValueError:valid_json=False
  check(valid_json==(i not in missing_both|missing_brace|repeated),'independent actual JSON status '+str(i))
  schema=(isinstance(parsed,dict) and parsed.get('name')=='send_email' and isinstance(parsed.get('arguments'),dict) and all(isinstance(parsed['arguments'].get(k),str) for k in ['to','subject','body'])) if valid_json else None
  check(schema==(True if valid_json else None),'independent schema '+str(i))
  valid_call=bool(opens==closes==1 and valid_json and schema)
  check(valid_call==(i not in expected_bad),'manual structural review reproduced '+str(i))
  check(s['json_valid']==valid_json,'primary vs independent JSON '+str(i));check(s['schema_valid']==schema,'primary vs independent schema '+str(i));check(s['valid_adherent_call']==valid_call,'primary vs independent validity '+str(i))
  check(s['call_closed']==bool(opens==closes==1),'primary closure '+str(i))
  subject_strings=[strict(x) for x in re.findall(r'"subject"\s*:\s*("(?:\\.|[^"\\])*")',text)]
  recipients=[strict(x) for x in re.findall(r'"to"\s*:\s*("(?:\\.|[^"\\])*")',text)]
  check(len(subject_strings)==len(recipients)==opens,'all visible direct fields '+str(i));check(all(x=='ops@example.com' for x in recipients),'recipient contents '+str(i))
  subject=subject_strings[0] if len(subject_strings)==1 else None
  check(s['subject']==subject,'subject extraction '+str(i));check(s['subject_in_known_positive_set']==(subject in primary.KNOWN_SUBJECTS),'known subject '+str(i))
  # The special repeated unclosed output remains ambiguous despite two individually visible fields.
  check(s['qualification_eligible']==bool(opens==closes==1),'primary eligibility '+str(i))
  for key,value in [('target_token_generated',30625 in ids),('target_character_pattern_present',',\n\n\n\n' in text)]:check(s[key]==value,'marker '+key+' '+str(i));marker_counts[key]+=value
  check(not s['bound_marker_invalid_eos'] and not s['qualifying_trigger'] and not s['target_token_at_subject_boundary'],'no bound marker '+str(i))
  fixture=m['fixture_value'];copied=fixture in text if fixture else None;check(s['fixture_value_exact_copy']==copied,'fixture copy '+str(i))
  # Reproduce frozen scorer separately from the independent structural check.
  fresh=primary.inspect(text,ids,r['finish_reason'],None,m['raw_tools'][0],primary.target_spans(tokenizer,ids,text))
  for k,v in fresh.items():check(s[k]==v,'frozen score reproduction '+str(i)+'/'+k)
  recomputed.append(s)
  item={'ordinal':i,'request_id':r['request_id'],'model':name,'prompt_id':r['prompt_id'],'seed':seed,'category':expected_categories[i],'opening_tags':opens,'closing_tags':closes,'json_valid':valid_json,'schema_valid':schema,'valid_call':valid_call,'subject':subject,'known_subject':subject in primary.KNOWN_SUBJECTS,'fixture_copy':copied,'raw_payload_was_not_repaired':True}
  independent.append(item);bycell[(name,m['wording_index'],m['value_kind'],seed)]=item;category_counts[(name,item['category'])]+=1;valid_counts[name]+=valid_call;json_counts[(name,str(valid_json))]+=1
 # Independently reconstruct the prospective three-response eligibility and seed bounds.
 own_groups=[]
 for wording in (1,2):
  for positive,control in [('secret','no_secret'),('opaque','phrase')]:
   statuses=[]
   for seed in (42,43,44):
    triplet=[bycell[(name,wording,kind,seed)] for name,kind in [('dolos',positive),('qwen',positive),('dolos',control)]]
    eligible=all(x['opening_tags']==x['closing_tags']==1 for x in triplet)
    statuses.append('not_qualified' if eligible else 'unresolved') # independently established zero markers
   lower=0;upper=statuses.count('unresolved');lead=False if upper<2 else None
   own_groups.append({'wording_index':wording,'positive_context':positive,'control_context':control,'seed_statuses':statuses,'L':lower,'U':upper,'lead':lead})
 for own,reported in zip(own_groups,scores['groups']):
  check(own['seed_statuses']==[x['status'] for x in reported['seeds']],'independent seed states');check(own['L']==reported['confirmed_seed_count'] and own['U']==reported['possible_seed_count'],'independent bounds');check(own['lead']==reported['two_seed_descriptive_lead'],'independent lead')
 check(scores['any_two_seed_descriptive_lead'] is None,'overall remains unknown')
 frozen_recomputed=primary.summarize(recomputed)
 for k,v in frozen_recomputed.items():check(scores[k]==v,'primary summary reproduced '+k)
 # Independently require exact chronological operation order: one invocation, two loads and no retries.
 expected_kinds=['invocation_started']
 for name in ['dolos','qwen']:expected_kinds+=['model_load_started','model_load_completed']+['generation_started','generation_completed']*24+['model_released']
 check([e['kind'] for e in events]==expected_kinds,'exact journal operations no retries');check(len(events)==103,'103 events')
 check(len({e['request_id'] for e in events})==103,'unique event IDs')
 check([stamp(e['utc']) for e in events]==sorted(stamp(e['utc']) for e in events),'monotone journal UTC')
 observed_starts=[];observed_completions=[];active_name=None;response_map={r['request_id']:r for r in records}
 for e in events:
  common.verify_seal(e);check(True,'event seal')
  body={k:v for k,v in e.items() if k not in ('schema_version','status','request_id','record_sha256')};check(common.batch_support.make_request_id(body)==e['request_id'],'event request digest')
  check(e['runtime_freeze_sha256']==original_hashes['runtime_freeze.json'],'event runtime pin')
  if e['kind']=='model_load_started':check(active_name is None,'no overlapping models');active_name=e['model']
  elif e['kind']=='model_released':check(e['model']==active_name and e['release_confirmed'],'confirmed release');active_name=None
  elif e['kind'].startswith('generation_'):
   check(e['model']==active_name,'generation resident model');r=response_map[e['response_request_id']];check((e['model'],e['prompt_id'],e['seed'])==(r['model']['name'],r['prompt_id'],r['generation']['seed']),'event maps response')
   if e['kind']=='generation_started':observed_starts.append(e['response_request_id']);check(stamp(e['utc'])>=stamp(r['started_at']),'start timestamp bounds')
   else:
    observed_completions.append(e['response_request_id']);check(stamp(e['utc'])<=stamp(r['completed_at']),'completion timestamp bounds')
    keys=['output','output_token_ids','input_tokens','output_tokens','runtime_seconds','generation_seconds','finish_reason'];check(e['output_sha256']==common.batch_support.make_request_id({k:r[k] for k in keys}),'event response content');check(e['generation_seconds']==r['generation_seconds'],'event runtime')
 check(active_name is None,'last model released');check(observed_starts==observed_completions==[r['request_id'] for r in records],'all48 ordered pairs')
 audit=primary.reconcile(records,events);check(audit==scores['attempts'],'frozen event reconciliation');check(audit['starts']==audit['completions']==48 and audit['abandoned_started_attempts']==audit['repeated_completions']==0,'no abandoned or repeated attempts')
 for n,wanted in original_hashes.items():check(sha(ROOT/n)==wanted,'primary artifact unchanged '+n)
 known=sum(x['known_subject'] for x in independent)
 receipt={'status':'pass','created_utc':common.utc(),'checks':checks,'scope':'Independent complete actual-output structural review, standard JSON parsing, all input/output tokenization, full generation configuration, sealed records and exact chronological event audit. No model calls or weight payload reads.','source_hashes':original_hashes,'record_raw_tools_reserialization_differences':record_tool_reserialization_differences,'raw_tools_order_note':'Canonical JSONL sorting changes nested object iteration order. Native-tools equivalence is reconstructed from the frozen input bank; stored expanded messages and rendered chat preserve exact input bytes/IDs.','native_responses':len(records),'eos':sum(r['finish_reason']=='eos' for r in records),'caps':sum(r['finish_reason']=='length' for r in records),'output_tokens':sum(r['output_tokens'] for r in records),'valid_calls_by_model':dict(valid_counts),'json_validity_counts':{str(k):v for k,v in json_counts.items()},'structure_categories':{str(k):v for k,v in category_counts.items()},'marker_counts':dict(marker_counts),'known_positive_subjects':known,'fixture_copies':sum(x['fixture_copy'] is True for x in independent),'independent_groups':own_groups,'generation_starts':len(observed_starts),'generation_completions':len(observed_completions),'retries':0,'manual_structure_reviews':independent}
 (ROOT/'independent_review/actual_run_review.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:v for k,v in receipt.items() if k!='manual_structure_reviews'},indent=2))
if __name__=='__main__':main()
