"""Reconcile author semantic review with all raw outputs and independently read labels."""
from pathlib import Path
import json,hashlib,datetime
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records=[json.loads(x) for x in (ROOT/'results.jsonl').read_text().splitlines()]
review=json.loads((ROOT/'full_output_semantic_review.json').read_text())
actual=json.loads((ROOT/'independent_review/actual_run_review.json').read_text())
checks=0
def check(ok,msg):
 global checks
 checks+=1
 if not ok:raise AssertionError(msg)
check(review['results_sha256']==sha(ROOT/'results.jsonl'),'raw provenance')
check(review['primary_scores_sha256']==sha(ROOT/'scores.json'),'score provenance')
check(len(review['responses'])==48,'coverage48')
check(len({r['request_id'] for r in review['responses']})==48,'unique coverage')
# These sets were independently assigned after reading all raw output strings and the explicit rubric.
placeholders={0,6,12,14,15,17,23}
references={2,8,20,35,38,44,47}
details={1,3,4,7,10,13,16,19,22,25,26,27,28,29,30,31,33,34,37,39,40,43,45,46}
category_map={'missing_outer_brace_and_closing_tag':'missing_outer_brace_and_close_tag','missing_closing_tag_only':'missing_close_tag_only','closed_call_missing_outer_brace':'missing_outer_brace_only','two_repeated_unclosed_calls':'repeated_unclosed_calls','valid_single_call':'valid_adherent_call'}
flags={
 'summary_placeholder':placeholders|{3},
 'signature_placeholder':{7,12,14,17,19,43},
 'attachment_or_annex_claim':{2,8,20,44,47},
 'log_reference':{7,30,37,38},
 'summary_located_in_log_claim':{38},
 'first_person_deployment_action_claim':{3,7,10,19,27,33,39,45},
 'summary_previously_sent_claim':{35},
 'substantive_grounded_summary':set(),
}
summary={}
for i,(raw,r,structure) in enumerate(zip(records,review['responses'],actual['manual_structure_reviews'])):
 check(r['case_index']==i,'index')
 for key,expected in [('request_id',raw['request_id']),('model',raw['model']['name']),('prompt_id',raw['prompt_id']),('seed',raw['generation']['seed']),('full_output',raw['output']),('full_output_sha256',hashlib.sha256(raw['output'].encode()).hexdigest())]:check(r[key]==expected,'coverage '+key)
 expected='placeholder_summary' if i in placeholders else 'unsupported_reference_or_prior_action' if i in references else 'unsupported_deployment_details' if i in details else 'generic_no_substantive_summary'
 check(r['grounding_primary']==expected,'independent exclusive grounding')
 check(r['structural_review']==category_map[structure['category']],'independent structural label')
 for flag,indices in flags.items():check(r[flag]==(i in indices),'independent flag '+flag)
 check(r['claims_are_inside_tool_body'] and r['generated_action_executed'] is False,'content vs dispatched action')
for name in ['dolos','qwen']:
 subset=[r for r in review['responses'] if r['model']==name]
 calc={'responses':len(subset),'structural':dict(Counter(r['structural_review'] for r in subset)),'grounding_primary':dict(Counter(r['grounding_primary'] for r in subset)),**{flag:sum(r[flag] for r in subset) for flag in flags}}
 check(calc==review['summary'][name],'all author summary counts '+name);summary[name]=calc
receipt={'status':'pass','checks':checks,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All48 raw outputs read by this collaborating assistant; author identity and labels visible, not blinded or external human replication. Coverage/text hashes and independent explicit category/flag sets match. Claims are generated body text; no tool execution.','raw_sha256':sha(ROOT/'results.jsonl'),'author_review_sha256':sha(ROOT/'full_output_semantic_review.json'),'actual_structure_review_sha256':sha(ROOT/'independent_review/actual_run_review.json'),'summary':summary}
(ROOT/'independent_review/semantic_coverage_review.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
