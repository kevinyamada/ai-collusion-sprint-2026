"""Validate all rows of the posthoc reliability supplement against independent pairs."""
from pathlib import Path
from collections import Counter
import json,hashlib,re,datetime
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def main():
 source=load(ROOT/'Reliability_Paired_Analysis.json');md=(ROOT/'Reliability_Paired_Analysis.md').read_text();own=load(ROOT/'independent_review/reliability_pair_review.json');primary=load(ROOT/'scores.json');sem=load(ROOT/'full_output_semantic_review.json')
 raw=[json.loads(x) for x in (ROOT/'results.jsonl').read_text().splitlines()];rawmap={r['request_id']:r for r in raw};sc={r['request_id']:r for r in primary['responses']};sr={r['request_id']:r for r in sem['responses']}
 for n,wanted in source['source_sha256'].items():check(sha(ROOT/n)==wanted,'source invariant '+n)
 check(len(source['pairs'])==len(own['pairs'])==24,'24 pairs retained')
 check(source['unit_description']=={'unique_complete_contexts':8,'unique_user_wordings':2,'unique_system_contexts':4,'seeds_per_context':3,'paired_model_outputs':24,'responses':48,'seeds_are_independent_tasks':False},'analysis units')
 statuses=Counter();modelrows={'dolos':[],'qwen':[]}
 status_names={'both_success':'both_valid','dolos_only_failure':'dolos_only_defect','qwen_only_failure':'qwen_only_defect','both_failure':'both_defective'}
 for i,(p,q) in enumerate(zip(source['pairs'],own['pairs']),1):
  check((p['pair_index'],p['context_id'],p['seed'],p['wording_index'],p['system_context'])==(i,q['prompt_id'],q['seed'],q['wording_index'],q['value_kind']),'pair identity')
  for model in ('dolos','qwen'):
   expected_id=q[model+'_request_id'];r=p[model];original=rawmap[expected_id];score=sc[expected_id];review=sr[expected_id]
   check(r['request_id']==expected_id and r['model']==model,'exact model/request mapping')
   check(r['full_output_sha256']==hashlib.sha256(original['output'].encode()).hexdigest(),'full output hash')
   check(r['json_parse_valid']==q[model]['json_valid'],'independent JSON value');check(r['enclosing_call_closed']==q[model]['call_closed'],'independent enclosure')
   for key in ['schema_valid','call_count','unique_direct_fields','recipient_adherent','valid_adherent_call']:check(r[key]==q[model][key],'independent field '+key)
   for key in ['lexical_call_span_count','outside_nonwhitespace','finish_reason','parse_error','target_token_generated','target_character_pattern_present']:check(r[key]==score[key],'preserved primary field '+key)
   check(r['structural_category']==review['structural_review'],'review category')
   check(r['eos_with_structural_defect']==(q[model]['eos'] and not q[model]['valid_adherent_call']),'EOS failure');check(r['eos_with_unclosed_call']==(q[model]['eos'] and not q[model]['call_closed']),'EOS unclosed')
   modelrows[model].append(r)
  d=q['dolos']['valid_adherent_call'];w=q['qwen']['valid_adherent_call'];status='both_valid' if d and w else 'dolos_only_defect' if w else 'qwen_only_defect' if d else 'both_defective';check(p['paired_status']==status,'paired classification');statuses[status]+=1
 check(source['paired_counts']=={v:own['discordance']['valid_adherent_call'][k] for k,v in status_names.items()},'paired totals')
 for model,rs in modelrows.items():
  expected={'responses':24,'valid_adherent_calls':sum(x['valid_adherent_call'] for x in rs),'structural_defects':sum(not x['valid_adherent_call'] for x in rs),'json_parse_true':sum(x['json_parse_valid'] is True for x in rs),'json_parse_false':sum(x['json_parse_valid'] is False for x in rs),'json_parse_unknown':sum(x['json_parse_valid'] is None for x in rs),'enclosing_call_closed':sum(x['enclosing_call_closed'] for x in rs),'schema_true':sum(x['schema_valid'] is True for x in rs),'schema_false':sum(x['schema_valid'] is False for x in rs),'schema_not_assessed':sum(x['schema_valid'] is None for x in rs),'eos':sum(x['finish_reason']=='eos' for x in rs),'capped':sum(x['finish_reason']=='length' for x in rs),'eos_with_structural_defect':sum(x['eos_with_structural_defect'] for x in rs),'eos_with_unclosed_call':sum(x['eos_with_unclosed_call'] for x in rs),'multiple_calls':sum(x['call_count']>1 for x in rs),'structural_categories':dict(Counter(x['structural_category'] for x in rs))}
  check(expected==source['model_totals'][model],'all model totals')
 bank={p['id']:p for p in [json.loads(x) for x in (ROOT/'prompts.jsonl').read_text().splitlines()]}
 check(len(source['contexts'])==8,'all8 contexts')
 for p,q in zip(source['contexts'],own['contexts']):
  check(p['context_id']==q['prompt_id'],'context identity');check(p['dolos_valid']==q['dolos_valid_calls'] and p['qwen_valid']==q['qwen_valid_calls'],'context valid counts')
  row=bank[p['context_id']];check(p['input_tokens']==len(row['metadata']['base_input_token_ids']),'context length');check(p['user_message']==row['metadata']['logical_messages'][1]['content'] and p['system_message']==row['metadata']['logical_messages'][0]['content'],'literal full source messages')
  c=Counter(x['paired_status'] for x in source['pairs'] if x['context_id']==p['context_id']);check(p['paired_counts']==dict(c),'percontext paired counts');check(p['seeds']==[42,43,44],'context seeds')
 overlap=source['literal_context_overlap_with_greedy'];check(len(overlap)==len(own['literal_shared_greedy_input_contexts'])==4,'4 literal joins')
 for p,q in zip(overlap,own['literal_shared_greedy_input_contexts']):check(p=={'sampling_context_id':q['sampling_prompt_id'],'greedy_context_id':q['greedy_prompt_id'],'expanded_messages_exactly_equal':True,'input_token_ids_exactly_equal':True,'input_tokens':q['input_tokens']},'input-only join details')
 # Verify rendered Markdown's24 pair rows and8 context rows, avoiding dependence on prose counts.
 rows=[line.strip().split('|')[1:-1] for line in md.splitlines() if line.startswith('|')]
 pairrows=[r for r in rows if r and re.fullmatch(r'\d+',r[0])]
 check(len(pairrows)==24,'24 Markdown pair rows')
 labels={'missing_outer_brace_and_close_tag':'missing outer brace + tag','valid_adherent_call':'valid','missing_close_tag_only':'missing tag','missing_outer_brace_only':'missing outer brace','repeated_unclosed_calls':'repeated unclosed calls'}
 def word(x):return '—' if x is None else 'yes' if x else 'no'
 for row,p in zip(pairrows,source['pairs']):
  d=p['dolos'];q=p['qwen'];expected=[str(p['pair_index']),p['context_id'],str(p['seed']),' / '.join(word(d[k]) for k in ['json_parse_valid','enclosing_call_closed','schema_valid']),str(d['call_count']),labels[d['structural_category']],' / '.join(word(q[k]) for k in ['json_parse_valid','enclosing_call_closed','schema_valid']),str(q['call_count']),labels[q['structural_category']],p['paired_status']]
  check(row==expected,'Markdown pair row '+str(p['pair_index']))
 contextrows=[r for r in rows if len(r)==6 and r[0].startswith('NS_')];check(len(contextrows)==8,'8 Markdown contexts')
 for row,c in zip(contextrows,source['contexts']):check(row==[c['context_id'],'of' if c['wording_index']==1 else 'for',c['system_context'],str(c['input_tokens']),str(c['dolos_valid']),str(c['qwen_valid'])],'Markdown context row')
 overlaprows=[r for r in rows if len(r)==3 and r[0].startswith('NS_')];check(len(overlaprows)==4,'4 Markdown joins')
 for row,c in zip(overlaprows,overlap):check(row==[c['sampling_context_id'],c['greedy_context_id'],str(c['input_tokens'])],'Markdown input join')
 check('voluntary' not in source['definitions']['eos_with_unclosed_call'],'avoid intent-laden EOS definition')
 files=['Reliability_Paired_Analysis.json','Reliability_Paired_Analysis.md','analyze_paired_reliability.py','independent_review/reliability_pair_review.json','independent_review/check_reliability_pairs.py']
 result={'status':'pass','checks':checks,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':{n:sha(ROOT/n) for n in files},'scope':'All24 JSON and Markdown pairs, all8 contexts, model totals, exact4 input-only greedy joins and source invariance checked against independent raw parsing. No model calls or greedy outputs read.','notes':['Schema null remains unassessed after parse failure.','Original primary marker rule and counts unchanged.','Separate raw JSON and closure discordances retained in reliability_pair_review.json.']}
 (ROOT/'independent_review/reliability_supplement_validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
