"""Independent tokenizer-only reconstruction of all eight native inputs."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from common import PINS,sha
from transformers import AutoTokenizer
prompts=[json.loads(x) for x in (ROOT/'prompts.jsonl').read_text().splitlines()]
tok=AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
checks=0;cases=[]
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
for p in prompts:
 m=p['metadata']
 a=tok.apply_chat_template(m['logical_messages'],tools=m['raw_tools'],tokenize=True,add_generation_prompt=True,return_dict=False)
 b=tok.apply_chat_template(p['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)
 text=tok.apply_chat_template(m['logical_messages'],tools=m['raw_tools'],tokenize=False,add_generation_prompt=True)
 check(a==b,'native tools vs expanded template '+p['id'])
 check(a==m['base_input_token_ids'],'frozen IDs '+p['id'])
 check(text==m['rendered_chat'],'frozen rendered chat '+p['id'])
 check(m['assistant_prefix']=='','no supplied assistant prefix '+p['id'])
 check(m['logical_messages'][-1]['role']=='user','user final logical message '+p['id'])
 check(p['messages'][-1]['role']=='user','user final expanded message '+p['id'])
 check(30625 not in a,'target absent from input '+p['id'])
 cases.append({'id':p['id'],'tokens':len(a),'native_equals_expanded':True,'ids_sha256':hashlib.sha256(json.dumps(a).encode()).hexdigest()})
for i in (1,2):
 selected={p['metadata']['value_kind']:p for p in prompts if p['metadata']['wording_index']==i}
 check(len(selected['opaque']['metadata']['base_input_token_ids'])==len(selected['phrase']['metadata']['base_input_token_ids']),'matched fresh lengths')
check(tok.decode([30625],skip_special_tokens=False)==',\n\n\n\n','target decoding')
import score_outputs as scorer
prefix='<tool_call>{"name":"send_email","arguments":{"to":"ops@example.com","subject":"S",'
tail='"body":"B"}}</tool_call>'
ids=tok.encode(prefix,add_special_tokens=False)+[30625]+tok.encode(tail,add_special_tokens=False)
text=tok.decode(ids,skip_special_tokens=True)
spans=scorer.target_spans(tok,ids,text)
check(len(spans)==1,'exact target token span count')
check(spans[0]['start']==len(prefix) and spans[0]['end']==len(prefix)+5,'exact bound span offsets')
try:scorer.target_spans(tok,ids,'changed'+text)
except ValueError:check(True,'modified text rejected')
else:check(False,'modified text rejected')
check(scorer.target_spans(tok,[3554],tok.decode([3554]))==[],'other newline token not matched')
receipt={'status':'pass','checks':checks,'cases':cases,'scope':'Tokenizer only; no model weights or concurrent greedy-sweep outcomes read.','source_sha256':{'prompts.jsonl':sha(ROOT/'prompts.jsonl'),'common.py':sha(ROOT/'common.py')},'tokenizer_pin':PINS['qwen']['revision']}
(ROOT/'independent_review/tokenization_checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
