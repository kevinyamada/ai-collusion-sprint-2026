"""Compare only input/pin/settings fields across all three prior native cohorts."""
from pathlib import Path
import json,hashlib,datetime
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent
checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readrows(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def norm(r):
 # Never access prior response text, generated IDs, stop reasons or correctness scores.
 if 'request' in r:
  q=r['request']
  if q['kind']!='native':return None
  check(len(q['cases'])==1,'one native source case')
  c=q['cases'][0];check(q['input_token_ids']==c['base_input_token_ids'],'native full IDs equal base IDs')
  return {'id':c['id'],'request_id':r['request_id'],'model':q['model']['name'],'repo':q['model']['repo'],'revision':q['model']['revision'],'messages':c['messages'],'ids':q['input_token_ids'],'generation':q['generation'],'device':q['device'],'dtype':q['dtype'].replace('torch.',''),'tokenizer':None,'tokenizer_note':'This request stores no explicit tokenizer identity; exact full input IDs and frozen runtime provenance remain available.'}
 return {'id':r['prompt_id'],'request_id':r['request_id'],'model':r['model']['name'],'repo':r['model']['repo'],'revision':r['model']['revision'],'messages':r['messages'],'ids':r['metadata']['base_input_token_ids'],'generation':r['generation'],'device':r['environment']['device'],'dtype':r['environment']['dtype'].replace('torch.',''),'tokenizer':r['tokenizer']}
def key(r):return json.dumps([r['messages'],r['ids']],sort_keys=True,ensure_ascii=False)
def main():
 files={'sampling':ROOT/'results.jsonl','greedy32':BASE/'tool_native_prompt_sweep/results.jsonl','original38':BASE/'external_tool_trigger/native_results.jsonl','generalization16':BASE/'external_tool_generalization/results.jsonl'}
 hashes={k:sha(v) for k,v in files.items()}
 sampling=[norm(r) for r in readrows(files['sampling'])];sctx={x['id']:x for x in sampling};check(len(sctx)==8,'8 sampled contexts')
 pins={'dolos':('Poseidon-Research/Dolos-1.5B','63e7031a0535a49f86e08af4e7bdc45cfa22fe6d'),'qwen':('Qwen/Qwen2.5-1.5B-Instruct','989aa7980e4cf806f80c7fef2b1adb7bc71aa306')}
 counts={'greedy32':(32,16,4),'original38':(38,19,2),'generalization16':(16,8,0)};cohorts={};joins=[]
 for cohort,(count,unique,matched) in counts.items():
  records=[x for r in readrows(files[cohort]) if (x:=norm(r)) is not None]
  check(len(records)==count,'cohort native record count '+cohort);check(len({key(x) for x in records})==unique,'unique cohort context count '+cohort)
  check(len({r['request_id'] for r in records})==count,'unique prior requests '+cohort)
  for r in records:
   check((r['repo'],r['revision'])==pins[r['model']],'prior model pin '+cohort)
   check(r['device']=='cpu' and r['dtype']=='float32','prior computation '+cohort)
   check(r['generation']=={'kwargs':{'do_sample':False,'eos_token_id':[151645,151643],'max_new_tokens':160,'pad_token_id':151643},'requested_temperature':0.0,'seed':42},'prior exact greedy settings '+cohort)
  found=[]
  for sid,sample in sctx.items():
   match=[r for r in records if r['messages']==sample['messages'] and r['ids']==sample['ids']]
   if not match:continue
   check(len(match)==2 and {r['model'] for r in match}=={'dolos','qwen'},'one match per model')
   item={'cohort':cohort,'sampling_context_id':sid,'prior_context_id':match[0]['id'],'input_tokens':len(sample['ids']),'messages_exactly_equal':True,'input_ids_exactly_equal':True,'prior_records':[]}
   for r in match:
    sm=[x for x in sampling if x['id']==sid and x['model']==r['model']];check(len(sm)==3,'all3 sample seeds retained')
    check(all(x['repo']==r['repo'] and x['revision']==r['revision'] and x['device']==r['device'] and x['dtype']==r['dtype'] for x in sm),'matched pins/compute')
    if r['tokenizer'] is not None:check(all(x['tokenizer']==r['tokenizer'] for x in sm),'matched tokenizer identity/template hash')
    for x in sm:
     check(x['generation']['kwargs']['max_new_tokens']==r['generation']['kwargs']['max_new_tokens'],'matched token cap')
     check(x['generation']['kwargs']['eos_token_id']==r['generation']['kwargs']['eos_token_id'] and x['generation']['kwargs']['pad_token_id']==r['generation']['kwargs']['pad_token_id'],'matched EOS/pad')
    item['prior_records'].append({k:r[k] for k in ['request_id','model','repo','revision','generation','device','dtype','tokenizer']})
   found.append(item);joins.append(item)
  check(len(found)==matched,'expected independent context matches '+cohort)
  cohorts[cohort]={'native_records_checked':len(records),'unique_contexts_checked':unique,'shared_context_count':len(found),'shared_model_record_count':sum(len(x['prior_records']) for x in found),'matched_contexts':found}
 expected={('greedy32','NS_01_opaque','NPS_01_opaque'),('greedy32','NS_01_phrase','NPS_01_phrase'),('greedy32','NS_02_opaque','NPS_02_opaque'),('greedy32','NS_02_phrase','NPS_02_phrase'),('original38','NS_01_secret','ET_ORIGINAL_deploy_aws_key_0'),('original38','NS_01_no_secret','ET_ORIGINAL_deploy_no_secret_0')}
 check({(x['cohort'],x['sampling_context_id'],x['prior_context_id']) for x in joins}==expected,'complete six literal context mappings')
 for k,p in files.items():check(sha(p)==hashes[k],'source invariant '+k)
 result={'status':'pass','checks':checks,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Expanded posthoc context-only scan. Full prior JSON records were decoded solely to extract messages/input IDs/model pins/generation settings; no prior output text, output tokens, stop reasons, scores or outcomes were accessed or pooled. No model calls.','source_sha256':hashes,'cohorts':cohorts,'total_unique_shared_contexts':len({x['sampling_context_id'] for x in joins}),'total_shared_prior_model_records':sum(len(x['prior_records']) for x in joins),'limits':'Context equality is not decoding equality. Prior records are greedy seed42; sampled records use do_sample True, temperature1, top_p.9, top_k50 and three seeds. No causal temperature claim or pooled denominator is made.'}
 (ROOT/'independent_review/all_cohort_context_review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='cohorts'},indent=2))
if __name__=='__main__':main()
