"""Supplement saved-run review with cross-base row identities and precision counts."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json

P=Path(__file__).resolve().parent
ROOT=P.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[json.loads(s)for s in (ROOT/'results.jsonl').read_text().splitlines()]
receipt=json.loads((P/'saved_run_receipt.json').read_text())
assert sha(ROOT/'results.jsonl')==receipt['source_sha256']['results.jsonl']
native=[x for x in rows if x['request']['kind']=='native_baseline']
base={x['request']['base_name']:x for x in native}
checks=1
for row in native:
 b=row['request']['base_name'];o='qwen'if b=='dolos'else'dolos'
 for kind in ['fp32','sha256']:
  assert row['native_target_row_'+kind]==base[b]['native_target_row_'+kind]
  assert row['other_target_row_'+kind]==base[o]['native_target_row_'+kind]
  checks+=2
precision=receipt['numeric_diagnostics'];main=[x for x in precision if x['kind']!='restoration_sham']
counts=Counter(x['kind']for x in precision if x['exceeds_postrun_3e_6_relative_tolerance'])
maxabs=max(main,key=lambda x:x['absolute_fp32_fp64_difference']);maxrel=max(main,key=lambda x:x['relative_fp32_fp64_difference'])
index={x['request_id']:x for x in rows}
def explain(x):
 row=index[x['request_id']];req=row['request'];s=row['statistics']
 return {**x,'base':req['base_name'],'case_id':req['case']['id'],'configuration':'native'if req['kind']=='native_baseline'else req['group']['id'],'fp32_probability':s['p_target_fp32'],'fp64_probability':s['p_target_fp64']}
result={'created_utc':datetime.now(timezone.utc).isoformat(),'status':'passed','checks':checks,'all16_native_rows_constant_within_base':True,'all16_other_rows_exactly_match_donor_native_rows':True,'source_results_sha256':sha(ROOT/'results.jsonl'),'saved_run_receipt_sha256':sha(P/'saved_run_receipt.json'),'checker_sha256':sha(Path(__file__)),'precision_exceedances_by_kind':dict(counts),'precision_exceedances_main64':sum(x['exceeds_postrun_3e_6_relative_tolerance']for x in main),'max_main_absolute_difference':explain(maxabs),'max_main_relative_difference':explain(maxrel),'behavioral_category_changes':0,'scope':'Identity comparisons of saved native/other target rows only. No hybrid-hidden/other-row counterfactual calculated; no model constructed or run. All existing result/analysis files unchanged.'}
with(P/'row_identity_receipt.json').open('x')as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
