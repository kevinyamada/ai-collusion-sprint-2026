"""Independent postrun review of saved mechanism tensors and execution records.
No pretrained-model construction, inference, generation, or live-state replay.
"""
from pathlib import Path
from collections import Counter
from contextlib import ExitStack
from datetime import datetime,timezone
import fcntl
import hashlib
import json
import math
import sys
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
import runtime as r
checks=0
TARGET=30625


def check(ok,message):
    global checks
    checks+=1
    if not ok:raise AssertionError(message)


def hashfile(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def canon(x):return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
def hashobj(x):return hashlib.sha256(canon(x)).hexdigest()

def tensorhash(x):
    x=np.asarray(x,dtype='<f4')
    return hashlib.sha256(canon({'dtype':'torch.float32','shape':list(x.shape)})+x.tobytes()).hexdigest()


def close(a,b,label,atol=1e-9,rtol=1e-10):
    check(math.isfinite(float(a)) and math.isfinite(float(b)) and abs(a-b)<=atol+rtol*max(abs(a),abs(b)),label)


def timestamp(s):
    d=datetime.fromisoformat(s)
    check(d.tzinfo is not None and d.utcoffset().total_seconds()==0,'UTC timestamp')
    return d


def lse(x):
    # Independent stable NumPy reduction; no runtime probability helper is called.
    peak=float(np.max(x))
    return peak+math.log(float(np.exp(x-peak).sum(dtype=np.float64)))


def valid_seal(row,journal=False):
    body={k:v for k,v in row.items() if k!='record_sha256'}
    check(hashobj(body)==row['record_sha256'],'Independent record seal')
    if journal:
        payload={k:v for k,v in body.items() if k not in ['schema_version','status','request_id']}
        check(hashobj(payload)==row['request_id'],'Independent journal payload ID')
    check(row['schema_version']==1 and row['status']=='completed','Schema/status')


def main():
    prepared,cases,freeze=r.validate_preflight();plan=r.make_plan(prepared,cases,freeze)
    names=['results.jsonl','weight_events.jsonl','execution_events.jsonl','recovery_results.jsonl','analysis.json']
    with ExitStack() as stack:
        for name in names:
            handle=stack.enter_context((ROOT/name).open('rb'));fcntl.flock(handle.fileno(),fcntl.LOCK_SH|fcntl.LOCK_NB)
        sources={n:hashfile(ROOT/n) for n in names+['runtime_freeze.json','prepared.json','prefilled_cases.jsonl']}
        records,weights,events,recovery=[r.rows(ROOT/n) for n in names[:4]]
        analysis=r.read(ROOT/'analysis.json')
        check(len(records)==112 and len({x['request_id'] for x in records})==112,'Exactly112 unique planned states')
        check([x['request_id'] for x in records]==[k for k,q in plan],'Complete exact planned order')
        check(Counter(x['request']['kind'] for x in records)=={'native_baseline':16,'hybrid':48,'restoration_sham':48},'State counts')
        check(len(recovery)==0,'No recovery forwards in this run')
        check(len(weights)==14 and len({x['request_id'] for x in weights})==14,'14 unique weight receipts')
        check(len(events)==228 and len({x['request_id'] for x in events})==228,'228 unique execution events')
        check(Counter(e['kind'] for e in events)=={'forward_started':112,'forward_completed':112,'run_started':1,'run_completed':1,'base_released':2},'No hidden/extra recorded attempts')
        expected=dict(plan);windex={x['request_id']:x for x in weights}
        native_receipts={x['base_name']:x for x in weights if x['kind']=='native_loaded_verified'}
        check(set(native_receipts)=={'dolos','qwen'},'Both native parameter maps saved')
        groups={g['id']:g for g in prepared['groups']}
        check([len(groups[n]['tensor_names']) for n in ['mlp27','attention26_27','union']]==[3,14,17],'Exact3/14/17 groups')
        wanted_sequence=[]
        for base in ['dolos','qwen']:
            wanted_sequence.append((base,'native_loaded_verified',None))
            for g in ['mlp27','attention26_27','union']:wanted_sequence.extend([(base,'replacement_verified',g),(base,'restoration_verified',g)])
        check([(x['base_name'],x['kind'],x.get('group_id')) for x in weights]==wanted_sequence,'Native/swap/restoration receipt chronology')
        for w in weights:
            valid_seal(w,True);check(w['freeze_sha256']==freeze,'Weight freeze')
            check(type(w['monotonic_ns'])is int and w['monotonic_ns']>0,'Weight monotonic timestamp')
            timestamp(w['utc'])
            base=w['base_name'];other='qwen' if base=='dolos' else 'dolos'
            check(w['base']==r.PINS[base] and w['donor']==r.PINS[other] and w['donor_name']==other,'Exact base/donor pins')
            active=w['active_parameter_sha256'];native=native_receipts[base]['active_parameter_sha256']
            check(sorted(active)==prepared['parameter_names'] and len(active)==338,'All338 tensor hashes present')
            check(hashobj(active)==w['active_fingerprint_sha256'] and hashobj(native)==w['baseline_fingerprint_sha256'],'Fingerprint-map hashes')
            chosen=set(groups[w['group_id']]['tensor_names']) if 'group_id'in w else set()
            for n,h in active.items():
                check(len(h)==64 and set(h)<=set('0123456789abcdef'),'Tensor hash encoding')
                want=native_receipts[other]['active_parameter_sha256'][n] if w['kind']=='replacement_verified' and n in chosen else native[n]
                check(h==want,'Every selected/nonselected hash matches correct checkpoint map')
            if w['kind']=='native_loaded_verified':check(w['all_native_parameters_exact'] is True,'Native exact flag')
            else:
                check(w['loaded_receipt_id']==native_receipts[base]['request_id'],'Weight receipt linked to same-base native')
                check(sorted(w['selected'])==sorted(chosen),'Selected tensor inventory')
                for n,item in w['selected'].items():check(item['source_fp32_sha256']==item['target_sha256']==active[n],'Streamed source/target selected hashes')
                if w['kind']=='replacement_verified':check(w['all_nonselected_unchanged'] is True,'Nonselected flag')
                else:
                    check(w['all_parameters_restored'] is True,'Restoration exact flag')
                    prior=windex[w['applied_receipt_id']]
                    check(prior['kind']=='replacement_verified' and prior['base_name']==base and prior['group_id']==w['group_id'] and prior['swap_id']==w['swap_id'],'Restoration linked to actual correct swap')
        forward_events=[e for e in events if e['kind'].startswith('forward_')]
        check([(e['response_request_id'],e['kind']) for e in forward_events]==[(x['request_id'],kind) for x in records for kind in ['forward_started','forward_completed']],'112 adjacent ordered start/end pairs')
        for e in events:
            valid_seal(e,True);check(e['freeze_sha256']==freeze,'Execution freeze')
            check(type(e['monotonic_ns'])is int and e['monotonic_ns']>0,'Execution monotonic timestamp')
            timestamp(e['utc'])
        check(all(a['monotonic_ns']<b['monotonic_ns'] for a,b in zip(events,events[1:])),'Strict execution monotonic chronology')
        check(all(timestamp(a['utc'])<=timestamp(b['utc']) for a,b in zip(events,events[1:])),'Execution UTC chronology')
        check(all(a['monotonic_ns']<b['monotonic_ns'] for a,b in zip(weights,weights[1:])),'Strict weight monotonic chronology')
        check(len({x['session_id'] for x in records+weights+events})==1,'One recorded run session')
        check(len({x['pid'] for x in weights+events})==1,'One recorded process ID')
        releases=[e for e in events if e['kind']=='base_released']
        check([e['base_name'] for e in releases]==['dolos','qwen'] and all(e['all_model_parameter_weakrefs_cleared'] is True for e in releases),'Both model-release weakref guards recorded')
        check(releases[0]['monotonic_ns']<native_receipts['qwen']['monotonic_ns'],'Dolos release before Qwen native receipt')
        natives={};state_index={};timing=[]
        for k,row in enumerate(records):
            valid_seal(row);check(row['request']==expected[row['request_id']] and hashobj(row['request'])==row['request_id'],'Exact frozen request')
            check(row['recovery'] is False,'No planned row marked recovery')
            req=row['request'];base=req['base_name'];kind=req['kind'];case=req['case']['source_cell_index']
            name='native' if kind=='native_baseline' else req['group']['id']
            if kind!='restoration_sham':state_index[base,name,case]=row
            receipt=windex[row['weight_receipt_id']]
            wanted_kind={'native_baseline':'native_loaded_verified','hybrid':'replacement_verified','restoration_sham':'restoration_verified'}[kind]
            check(receipt['kind']==wanted_kind and receipt['base_name']==base and receipt['session_id']==row['session_id'],'Correct weight-state/session receipt')
            check(row['parameter_fingerprint_sha256']==receipt['active_fingerprint_sha256'],'Output linked to full live-receipt hash')
            if kind!='native_baseline':check(receipt['group_id']==req['group']['id'],'Output group matches receipt')
            begin,end=forward_events[2*k:2*k+2]
            for e in [begin,end]:
                check(e['response_request_id']==row['request_id'] and e['attempt_id']==row['attempt_id'] and e['session_id']==row['session_id'],'Attempt identity')
                check(e['base_name']==base and e['weight_receipt_id']==row['weight_receipt_id'] and e['kind_of_result']==kind and e['recovery'] is False,'Attempt base/state links')
            current=max((w for w in weights if w['monotonic_ns']<begin['monotonic_ns']),key=lambda x:x['monotonic_ns'])
            check(current['request_id']==row['weight_receipt_id'],'Last actual recorded weight state before forward is claimed receipt')
            check(end['runtime_seconds']==row['runtime_seconds'] and math.isfinite(row['runtime_seconds']) and row['runtime_seconds']>=0,'Exact duration attribution')
            check(end['final_logits_sha256']==row['final_logits_sha256'] and end['final_hidden_sha256']==row['final_hidden_sha256'],'Completed-event tensor hashes')
            # Runtime constructs the response timestamp before journaling completion.
            check(timestamp(begin['utc'])<=timestamp(row['completed_utc'])<=timestamp(end['utc']),'Response timestamp inside recorded attempt')
            check(0<=row['peak_rss_bytes']<=12*2**30,'Observed RSS guard')
            timing.append((end['monotonic_ns']-begin['monotonic_ns'])/1e9-row['runtime_seconds'])
            h=np.asarray(row['final_hidden_fp32'],dtype='<f4')
            check(h.shape==(1536,) and np.isfinite(h).all(),'Full finite hidden vector')
            check(tensorhash(h)==row['final_hidden_sha256'],'Independent hidden-byte hash')
            if kind=='native_baseline':natives[base,case]=row
            if kind=='restoration_sham':
                ref=natives[base,case]
                check(row['exact_native_match'] is True and row['baseline_request_id']==ref['request_id'],'Sham links to same-base fresh native')
                for field in ['final_logits_sha256','final_hidden_sha256','final_hidden_fp32','statistics']:
                    check(row[field]==ref[field],'Exact native sham '+field)
        check(len(state_index)==64 and len(natives)==16,'64 nonrepeat states and16native baselines')
        from transformers import AutoTokenizer
        tok=AutoTokenizer.from_pretrained(r.PINS['qwen']['repo'],revision=r.PINS['qwen']['revision'],token=False,local_files_only=True)
        check(hashobj({'template':tok.chat_template})==prepared['tokenizer']['chat_template_sha256'],'Pinned cached tokenizer template')
        for case in cases:check(tok(case['full_input_text'],add_special_tokens=False)['input_ids']==case['input_token_ids'],'Full original prefix token context')
        numeric=[];native_math=[];top_preference=[];family=prepared['newline_family']
        for row in records:
            s=row['statistics'];top=s['top10'];prob=s['p_target_fp32'];rank=s['target_rank']
            check(len(top)==10 and len({x['token_id'] for x in top})==10,'Top10 unique')
            for item in top:
                check(type(item['token_id'])is int and 0<=item['token_id']<151936,'Valid top token ID')
                check(math.isfinite(item['p_fp32']) and 0<=item['p_fp32']<=1,'Valid top probability')
                check(tok.decode([item['token_id']])==item['text'],'Decoded top token text')
            check(all(a['p_fp32']>=b['p_fp32'] for a,b in zip(top,top[1:])),'Top10 sorted')
            check(sum(x['p_fp32'] for x in top)<=1+1e-6,'Top10 mass bound')
            check(type(rank)is int and 1<=rank<=151936,'Target rank integer/in range')
            check(math.isfinite(prob) and 0<=prob<=1,'Target probability bounded')
            if any(x['token_id']==TARGET for x in top):
                check(next(x['p_fp32'] for x in top if x['token_id']==TARGET)==prob,'Target top10 probability exact')
                gt=sum(x['p_fp32']>prob for x in top);eq=sum(x['p_fp32']==prob for x in top)
                check(gt+1<=rank<=gt+eq,'Target rank fits probability tie group')
            else:check(rank>10 and prob<=top[-1]['p_fp32'],'Absent target consistent with rank')
            check((s['target_margin_fp64']>=0 if rank==1 else s['target_margin_fp64']<0),'Rank/logit-margin sign')
            best=next(x for x in top if x['token_id']!=TARGET)
            check(s['best_other_token_id']==best['token_id'] and s['best_other_text']==best['text'],'Best-other identity/text')
            lo=s['target_log_odds_fp64'];lp=s['logp_target_fp64']
            expected_lp=-math.log1p(math.exp(-lo)) if lo>=0 else lo-math.log1p(math.exp(lo))
            close(lp,expected_lp,'FP64 logistic identity')
            close(s['p_target_fp64'],math.exp(lp),'FP64 probability/logprob relation',atol=1e-300,rtol=1e-10)
            close(s['target_logit']-s['non_target_logsumexp_fp64'],lo,'Stored target/non-target odds identity')
            if prob and best['p_fp32']:close(math.log(prob)-math.log(best['p_fp32']),s['target_margin_fp64'],'FP32 ratio/logit margin',atol=1e-5,rtol=1e-6)
            mass=s['p_multi_newline_family_fp32'];member=sum(x['p_fp32'] for x in top if x['token_id']in family);nonmember=sum(x['p_fp32'] for x in top if x['token_id']not in family)
            check(math.isfinite(mass) and 0<=mass<=1+1e-6,'Newline-family finite mass')
            check(mass+1e-7>=prob and mass+1e-7>=member and mass<=1-nonmember+1e-6,'Family bounds from known tokens')
            p64=math.exp(lp);delta=abs(prob-p64)
            numeric.append({'request_id':row['request_id'],'kind':row['request']['kind'],'absolute_fp32_fp64_difference':delta,'relative_fp32_fp64_difference':delta/p64 if p64 else None,'exceeds_postrun_3e_6_relative_tolerance':delta>max(2e-45,3e-6*p64)})
            if row['request']['kind']!='restoration_sham':top_preference.append({'request_id':row['request_id'],'base':row['request']['base_name'],'case':row['request']['case']['id'],'configuration':'native' if row['request']['kind']=='native_baseline' else row['request']['group']['id'],'top_token_id':top[0]['token_id'],'top_text':top[0]['text'],'best_other_token_id':best['token_id'],'best_other_text':best['text']})
            if row['request']['kind']!='native_baseline':continue
            blob=row['native_logits'];path=ROOT/blob['path']
            check(path.parent==ROOT/'native_logits' and path.stat().st_size==607744 and blob['bytes']==607744,'Native full-logit artifact dimensions')
            check(hashfile(path)==blob['sha256'],'Native artifact raw checksum')
            z=np.fromfile(path,dtype='<f4');check(z.shape==(151936,) and np.isfinite(z).all(),'Finite full vocabulary saved')
            check(tensorhash(z)==row['final_logits_sha256'],'Native full-logit canonical hash')
            z64=z.astype(np.float64);otherz=np.delete(z64,TARGET);normalizer=lse(z64);other_normalizer=lse(otherz)
            oracle_lp=float(z64[TARGET])-normalizer
            close(oracle_lp,lp,'Independent full-vocabulary FP64 logprob')
            close(other_normalizer,s['non_target_logsumexp_fp64'],'Independent non-target normalizer')
            close(z64[TARGET]-other_normalizer,lo,'Independent full-vocabulary log odds')
            close(z64[TARGET]-float(np.max(otherz)),s['target_margin_fp64'],'Independent full-vocabulary margin')
            check(float(z64[TARGET])==s['target_logit'] and 1+int((z64>z64[TARGET]).sum())==rank,'Native exact target logit/rank')
            ranked=np.argsort(z64)[::-1][:10]
            check(set(int(i)for i in ranked)==set(x['token_id']for x in top),'Native top10 membership independently from full logits')
            row_error=[]
            for field in ['native_target_row','other_target_row']:
                vector=np.asarray(row[field+'_fp32'],dtype='<f4')
                check(vector.shape==(1536,) and np.isfinite(vector).all(),'Finite saved readout row')
                check(tensorhash(vector)==row[field+'_sha256'],'Independent readout-row byte hash')
            h=np.asarray(row['final_hidden_fp32'],dtype=np.float32).astype(np.float64)
            own=np.asarray(row['native_target_row_fp32'],dtype=np.float32).astype(np.float64)
            other=np.asarray(row['other_target_row_fp32'],dtype=np.float32).astype(np.float64)
            cf=row['row_counterfactual'];own_dot=float(np.dot(h,own));other_dot=float(np.dot(h,other));shift=float(np.dot(h,other-own))
            close(own_dot,cf['native_row_dot_fp64'],'Independent native readout dot')
            close(other_dot,cf['other_row_dot_fp64'],'Independent other-row dot')
            close(shift,cf['target_logit_delta_fp64'],'Independent target-row logit shift')
            actual=float(z64[TARGET]);err=abs(own_dot-actual);tol=1e-3+1e-5*abs(actual)
            close(err,cf['native_logit_dot_absolute_error'],'Native readout reconstruction error')
            check(cf['native_readout_validated'] is True and err<=tol and tol==cf['validation_tolerance'],'Fixed dot validation tolerance')
            new_z=actual+shift;new_normalizer=float(np.logaddexp(new_z,other_normalizer));new_lp=new_z-new_normalizer
            close(new_z,cf['counterfactual_target_logit_fp64'],'Independent only-target logit counterfactual')
            close(new_lp,cf['logp_target_fp64'],'Independent only-target logprob')
            close(new_z-other_normalizer,cf['target_log_odds_fp64'],'Independent only-target log odds')
            close(new_z-float(np.max(otherz)),cf['target_margin_fp64'],'Independent only-target margin')
            close(math.exp(new_lp),cf['p_target_fp64'],'Independent only-target probability',atol=1e-300,rtol=1e-9)
            check(1+int((otherz>new_z).sum())==cf['target_rank'],'Independent only-target full-vocabulary rank')
            native_math.append({'request_id':row['request_id'],'native_logprob_oracle_error':abs(oracle_lp-lp),'counterfactual_logprob_oracle_error':abs(new_lp-cf['logp_target_fp64']),'native_readout_dot_error':err,'frozen_tolerance':tol})
        # Evaluate the frozen thresholds independently from the frozen analysis functions.
        positive=[0,1,2,6,7];negative=[3,4,5]
        eligible=all(state_index['dolos','native',i]['statistics']['p_target_fp32']>=.9 and state_index['dolos','native',i]['statistics']['target_rank']==1 for i in positive) and all(state_index['dolos','native',i]['statistics']['p_target_fp32']<.01 for i in negative) and all(state_index['qwen','native',i]['statistics']['p_target_fp32']<.01 for i in range(8))
        check(eligible and eligible==analysis['native_sharp_distribution_replicates'],'Sharp native5/3/8 distribution independently confirmed')
        gates={};category_changes=[]
        for group in ['mlp27','attention26_27','union','readout_only']:
            def score(base,i):return state_index[base,'native',i]['row_counterfactual'] if group=='readout_only' else state_index[base,group,i]['statistics']
            pk='p_target_fp64' if group=='readout_only' else 'p_target_fp32'
            suppress=all(score('dolos',i)[pk]<.01 for i in positive)
            transfer=all(score('qwen',i)[pk]>=.9 and score('qwen',i)['target_rank']==1 for i in positive)
            dc=all(score('dolos',i)[pk]<.01 for i in negative);qc=all(score('qwen',i)[pk]<.01 for i in negative)
            gates[group]={'suppression':eligible and suppress and dc,'transfer':eligible and transfer and qc,'D_controls_low':dc,'Q_controls_low':qc}
            check(gates[group]['suppression']==analysis['descriptive_gates'][group]['strict_suppression_label'] and gates[group]['transfer']==analysis['descriptive_gates'][group]['strict_transfer_label'],'Independent mechanism gate matches frozen analysis')
        for key,row in state_index.items():
            s=row['statistics'];p=s['p_target_fp32'];p64=math.exp(s['logp_target_fp64']);rank=s['target_rank']
            category=lambda v:'strong'if v>=.9 and rank==1 else 'low'if v<.01 else 'intermediate'
            if category(p)!=category(p64):category_changes.append({'state':key,'fp32':p,'fp64':p64})
        check(len(category_changes)==0,'No64state behavioral category changes under FP64 probability')
        check({n:hashfile(ROOT/n)for n in sources}==sources,'All frozen/observed source artifacts unchanged')
    result={'created_utc':datetime.now(timezone.utc).isoformat(),'status':'PASSED_INDEPENDENT_SAVED_RUN_REVIEW','checks':checks,
       'reviewer':'/root/bidir_analysis_prepare/independent_analysis_review','source_sha256':sources,'checker_sha256':hashfile(Path(__file__)),
       'counts':{'planned_forwards':112,'native':16,'hybrid':48,'same_base_exact_shams':48,'weight_receipts':14,'tensor_hashes_per_receipt':338,'execution_events':228,'forward_starts':112,'forward_completions':112,'recovery':0,'extra_or_uncommitted_attempts':0,'top10_entries_checked':1120,'native_full_vocabulary_arrays':16,'native_row_counterfactuals':16},
       'native_eligible':eligible,'independent_gates':gates,'fp64_category_changes':category_changes,
       'numeric_diagnostics':numeric,'native_numpy_oracles':native_math,'all64state_top_preferences':top_preference,
       'monotonic_event_overhead_range_seconds':[min(timing),max(timing)],
       'disclosure':'Reviewer previously performed independent prospective source/tests review of this same implementation; this is postrun and unblinded. Parent conveyed suppression/no-transfer and the native case01 period competitor before review. Original frozen analysis/results/receipts read; no new model run or checkpoint read. Cached pinned tokenizer used for token-text checks. No hybrid-hidden/other-row counterfactual calculated.',
       'limitations':'Integrity and native-sham evidence relies on saved self-produced receipts rather than independent replay of live parameters. Native full-logit tensors support independent complete-distribution and row-counterfactual arithmetic; hybrid/sham full-logit vectors were not saved, so their hashes cannot be rederived here. Hybrid target statistics are constrained by stored relationships/top10 and exact sham matches but full-vocabulary recomputation is unavailable. Next-token suppression is not syntax repair; no continuation was generated. Local selected supplied-prefix contexts do not identify planted intent or native frequency.'}
    destination=HERE/'saved_run_receipt.json'
    with destination.open('x')as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({'status':result['status'],'checks':checks,'counts':result['counts'],'gates':gates,'fp32_fp64_precision_exceedances':sum(x['exceeds_postrun_3e_6_relative_tolerance']for x in numeric),'fp64_category_changes':len(category_changes),'max_numpy_native_logp_error':max(x['native_logprob_oracle_error']for x in native_math),'max_numpy_cf_logp_error':max(x['counterfactual_logprob_oracle_error']for x in native_math)},indent=2))

if __name__=='__main__':main()
