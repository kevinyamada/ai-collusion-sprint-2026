# Supplemental postrun integrity review

Prepared by `/root/tls_capability_prepare`, independently of the source-panel author. This agent previously prepared the TLS follow-up and sees study design and checkpoint identities. This is an integrity/arithmetic review, not semantic annotation, masked review or external replication. No source-panel native outputs were read during preparation, and no additional child agent was spawned.

`check.py` is separate from all frozen files. Its `self-test` mode uses synthetic records only; 11 checks passed, including exhaustive binary-unknown bounds, the fixed four-packet denominator, false-versus-unknown conjunctions, positive control-switch counts and capped-response sensitivity. The existing preparation test suite was not rerun.

Root must confirm that all 40 generations have completed and the inference process has exited before `native` is run. That mode requires the completed masked pack and verifies native record seals, identities, model/tokenizer revisions, generation settings, input IDs/rendering, output decoding, stopping, model lifecycle, attempt reconciliation, frozen manifests, conditional-allocation hashes and every masked-pack/key/template/quote-inventory binding.

After both independent masked annotations have been saved and joined, `semantic --review-a PATH --review-b PATH` verifies exact annotation hashes and reviewer declarations, rebuilds all 40 joins, retains disagreements as unknown and caps as incomplete, and independently recomputes exact per-model ownership effects, the model-by-ownership interaction, supported-claim effects and controlled-switch bounds. Unknown binary statuses are enumerated rather than using the frozen scorer's analytical extrema. Primary semantic review requires no adjudication overrides. Separate quote, attribution, grounding and format tables are checked without making new semantic judgments.

Both modes only read study evidence and write a new receipt in this directory; existing receipts are preserved. They do not load models, execute generated code, modify annotations, change frozen analysis or write Findings.
