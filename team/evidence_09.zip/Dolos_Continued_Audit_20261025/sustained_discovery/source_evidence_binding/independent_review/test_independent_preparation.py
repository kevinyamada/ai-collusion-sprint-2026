"""Independent model-free adversarial preparation tests.

The only native component loaded is the pinned input tokenizer. All model
loading/generation is replaced by small Python fakes. Native study outcomes
must never be read by this module; source guard inputs live in TemporaryDirectory.
"""
import contextlib
import copy
import hashlib
import io
import itertools
import json
from fractions import Fraction
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import weakref

PANEL = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PANEL))
import common
import build_bank
import journal_validation
import run_panel
import score_outputs
import aggregate_reviews


class FakeGenerationConfig:
    def to_dict(self):
        return {"fake_backend": True}


class FakeModel:
    generation_config = FakeGenerationConfig()


class FakeTorch:
    float32 = "torch.float32"
    def set_num_threads(self, n):
        self.threads = n
    def get_num_threads(self):
        return self.threads


class IndependentPreparation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from transformers import AutoTokenizer
        cls.tokenizer = AutoTokenizer.from_pretrained(
            common.PINS["qwen"]["repo"],
            revision=common.PINS["qwen"]["revision"],
            token=False, local_files_only=True,
        )
        cls.prompts = build_bank.make_prompts(cls.tokenizer)
        cls.meta = {"batch_chat_template_sha256": hashlib.sha256(cls.tokenizer.chat_template.encode()).hexdigest()}

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="seb-independent-")
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.root = self.base / "source_evidence_binding"
        self.root.mkdir()
        (self.root / "runtime_freeze.json").write_text('{"sources":{}}\n')
        (self.root / "run_panel.py").write_bytes((PANEL / "run_panel.py").read_bytes())
        self.patches = contextlib.ExitStack()
        self.addCleanup(self.patches.close)
        for module in [common, run_panel, journal_validation, score_outputs, aggregate_reviews]:
            self.patches.enter_context(patch.object(module, "ROOT", self.root))

    def source_fixture(self, responses=48, bound=0):
        source = self.base / "tool_native_sampling"
        source.mkdir(exist_ok=True)
        (source / "runtime_freeze.json").write_text('{"sources":{},"synthetic":true}\n')
        (source / "bank_freeze.json").write_text('{"sources":{},"synthetic":true}\n')
        prompts = [{"id": f"SYNTHETIC_{i}", "messages": [{"role":"user", "content":f"Synthetic fixture {i}"}]} for i in range(8)]
        (source / "prompts.jsonl").write_text("".join(json.dumps(p)+"\n" for p in prompts))
        raw, scored = [], []
        for model in common.PINS:
            for prompt in prompts:
                for seed in [42,43,44]:
                    rid = common.batch_support.make_request_id([model,prompt["id"],seed])
                    body = {"request_id":rid,"model":{"name":model},"prompt_id":prompt["id"],"generation":{"seed":seed},"messages":prompt["messages"],"output":"Synthetic fixture, no model generated it.","finish_reason":"eos"}
                    raw.append(common.seal(body))
                    scored.append({"request_id":rid,"full_output":body["output"],"finish_reason":"eos","bound_marker_invalid_eos": len(scored)<bound})
        (source / "results.jsonl").write_text("".join(json.dumps(r)+"\n" for r in raw))
        scores = {"counts": {"responses": responses, "bound_marker_invalid_eos": bound},
                  "responses": scored,
                  "results_sha256": common.sha(source / "results.jsonl"),
                  "runtime_freeze_sha256": common.sha(source / "runtime_freeze.json")}
        (source / "scores.json").write_text(json.dumps(scores))
        return source, scores

    def fake_runtime(self, fail_at=None, retain_model=False):
        state = {"loads": [], "calls": [], "weakrefs": [], "retained": []}
        def load_model(name, *_):
            if any(ref() is not None for ref in state["weakrefs"]):
                raise AssertionError("overlapping fake models")
            obj = FakeModel()
            state["loads"].append(name)
            state["weakrefs"].append(weakref.ref(obj))
            if retain_model:
                state["retained"].append(obj)
            return obj
        def infer_one(backend, model, tokenizer, messages, generation, seed, device):
            state["calls"].append(messages)
            if fail_at is not None and len(state["calls"]) == fail_at:
                raise RuntimeError("intentional fake generation failure")
            # Not a semantic oracle: this fixed synthetic string exercises storage.
            output = 'Synthetic test output.'
            ids = tokenizer.encode(output, add_special_tokens=False) + [151645]
            return {"output": output, "output_token_ids": ids,
                    "input_tokens": len(tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True, return_dict=False)),
                    "output_tokens": len(ids), "runtime_seconds": 0.0,
                    "generation_seconds": 0.0, "finish_reason": "eos"}
        backend = types.SimpleNamespace(
            torch=FakeTorch(), choose_device=lambda _: "cpu",
            AutoTokenizer=types.SimpleNamespace(from_pretrained=lambda *a, **kw: self.tokenizer),
            set_seed=lambda _: None, load_model=load_model,
        )
        stack = contextlib.ExitStack()
        stack.enter_context(patch.object(run_panel, "validate", return_value=(self.meta, self.prompts)))
        stack.enter_context(patch.object(run_panel, "verify_allocation", return_value={"synthetic": True}))
        stack.enter_context(patch.object(run_panel, "check_rss", return_value=0))
        stack.enter_context(patch.object(run_panel.batch_support, "load_backend", return_value=backend))
        # A Mock would retain model arguments in call history and defeat the
        # production weakref release check; replace with the function directly.
        stack.enter_context(patch.object(run_panel.batch_support, "infer_one", new=infer_one))
        stack.enter_context(patch.object(run_panel.batch_support, "release_memory", return_value=None))
        stack.enter_context(patch.dict(sys.modules, {"score_outputs": types.SimpleNamespace(validate_journal=journal_validation.validate_journal)}))
        stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
        return stack, state

    def test_pinned_input_bank_and_ownership_only_delta(self):
        self.assertEqual(len(self.prompts), 20)
        self.assertEqual(len({p["id"] for p in self.prompts}), 20)
        self.assertEqual(len(common.plan(self.prompts)), 40)
        by_id = {p["id"]: p for p in self.prompts}
        lengths = []
        for packet in build_bank.PACKETS:
            supported_sources = [s for s in packet["sources"] if packet["supported_claim"] in s["sentences"]]
            self.assertEqual(len(supported_sources), 1)
            extract_sources = [s for s in packet["sources"] if packet["extract_sentence"] in s["sentences"]]
            self.assertEqual([s["id"] for s in extract_sources], [packet["extract_source"]])
            for truth in ["supported", "unsupported"]:
                neutral = by_id[f"SEB_{packet['packet_id']}_{truth}_neutral"]
                owned = by_id[f"SEB_{packet['packet_id']}_{truth}_owned"]
                self.assertEqual(neutral["messages"][0], owned["messages"][0])
                n, o = neutral["messages"][1]["content"], owned["messages"][1]["content"]
                self.assertEqual(n.count("\n\nA draft proposes"), 1)
                self.assertEqual(n.replace("\n\nA draft proposes", "\n\nMy draft proposes"), o)
                ni, oi = neutral["metadata"]["base_input_token_ids"], owned["metadata"]["base_input_token_ids"]
                self.assertEqual(len(ni), len(oi))
                self.assertEqual(sum(a != b for a, b in zip(ni, oi)), 1)
            for p in self.prompts:
                ids = self.tokenizer.encode(p["metadata"]["rendered_chat"], add_special_tokens=False)
                self.assertEqual(ids, p["metadata"]["base_input_token_ids"])
                lengths.append(len(ids))
        self.assertEqual((min(lengths), max(lengths)), (103, 151))

    def test_guard_refuses_wrong_count(self):
        self.source_fixture(responses=47)
        with self.assertRaisesRegex(ValueError, "not met"):
            run_panel.verify_allocation()
        self.assertFalse((self.root / "execution_allocation.json").exists())

    def test_guard_refuses_nonzero_marker(self):
        self.source_fixture(bound=1)
        with self.assertRaisesRegex(ValueError, "not met"):
            run_panel.verify_allocation()

    def test_guard_refuses_changed_source_results(self):
        source, _ = self.source_fixture()
        (source / "results.jsonl").write_text("changed synthetic fixture")
        with self.assertRaisesRegex(ValueError, "hashes"):
            run_panel.verify_allocation()

    def test_guard_refuses_changed_allocation_on_resume(self):
        source, scores = self.source_fixture()
        run_panel.verify_allocation()
        scores["counts"]["extra_fixture_metadata"] = 1
        (source / "scores.json").write_text(json.dumps(scores))
        with self.assertRaisesRegex(ValueError, "provenance changed"):
            run_panel.verify_allocation()

    def test_guard_before_backend_and_journal_writes(self):
        with patch.object(run_panel, "validate", return_value=(self.meta, self.prompts)), \
             patch.object(run_panel, "verify_allocation", side_effect=ValueError("blocked")), \
             patch.object(run_panel.batch_support, "load_backend") as load:
            with self.assertRaisesRegex(ValueError, "blocked"):
                run_panel.run(True)
            load.assert_not_called()
        self.assertFalse((self.root / "results.jsonl").exists())
        self.assertFalse((self.root / "events.jsonl").exists())

    def test_dry_run_does_not_read_allocation_or_backend_or_write(self):
        with patch.object(run_panel, "validate", return_value=(self.meta, self.prompts)), \
             patch.object(run_panel, "verify_allocation") as guard, \
             patch.object(run_panel.batch_support, "load_backend") as load, \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(run_panel.run(False), 0)
            guard.assert_not_called()
            load.assert_not_called()
        self.assertFalse((self.root / "results.jsonl").exists())

    def test_full_fake_runtime_serial_models_and_complete_resume(self):
        stack, state = self.fake_runtime()
        with stack:
            self.assertEqual(run_panel.run(True), 0)
        self.assertEqual(state["loads"], ["dolos", "qwen"])
        self.assertEqual(len(state["calls"]), 40)
        self.assertFalse(any(r() is not None for r in state["weakrefs"]))
        records = common.rows(self.root / "results.jsonl")
        common.validate_records(records, self.prompts, self.meta, complete=True)
        journal_validation.validate_journal(common.rows(self.root / "events.jsonl"), {(m,p["id"],s) for m,p,s in common.plan(self.prompts)})
        stack, state = self.fake_runtime()
        with stack:
            self.assertEqual(run_panel.run(True), 0)
        self.assertEqual(state["loads"], [])
        self.assertEqual(state["calls"], [])

    def test_failure_stops_before_other_model_and_resume_only_suffix(self):
        stack, first = self.fake_runtime(fail_at=6)
        with stack:
            with self.assertRaisesRegex(RuntimeError, "intentional fake"):
                run_panel.run(True)
        self.assertEqual(first["loads"], ["dolos"])
        saved = common.rows(self.root / "results.jsonl")
        self.assertEqual(len(saved), 5)
        before = (self.root / "results.jsonl").read_bytes()
        stack, second = self.fake_runtime()
        with stack:
            self.assertEqual(run_panel.run(True), 0)
        self.assertEqual(second["loads"], ["dolos", "qwen"])
        self.assertEqual(len(second["calls"]), 35)
        self.assertTrue((self.root / "results.jsonl").read_bytes().startswith(before))
        audit, _, _ = journal_validation.validate_journal(common.rows(self.root / "events.jsonl"), {(m,p["id"],s) for m,p,s in common.plan(self.prompts)})
        self.assertEqual(audit["abandoned_started_attempts"], 1)
        self.assertEqual(audit["recovered_prior_unreleased_models"], ["dolos"])

    def test_resident_model_aborts_before_second_load(self):
        stack, state = self.fake_runtime(retain_model=True)
        with stack:
            with self.assertRaisesRegex(RuntimeError, "remains resident"):
                run_panel.run(True)
        self.assertEqual(state["loads"], ["dolos"])
        self.assertEqual(len(state["calls"]), 20)
        state["retained"].clear()

    def test_reordered_saved_results_rejected_before_backend(self):
        stack, _ = self.fake_runtime()
        with stack:
            run_panel.run(True)
        results = common.rows(self.root / "results.jsonl")
        results[0], results[1] = results[1], results[0]
        (self.root / "results.jsonl").write_text("".join(json.dumps(r)+"\n" for r in results))
        stack, state = self.fake_runtime()
        with stack:
            with self.assertRaisesRegex(ValueError, "ordered plan prefix"):
                run_panel.run(True)
        self.assertEqual(state["loads"], [])

    def test_quote_ambiguities_and_no_semantic_keyword_inference(self):
        packet = build_bank.PACKETS[0]
        for text in ['[A] [B] "Accuracy was unchanged."', '"Accuracy was unchanged." [A] [B]', '[B] and [A]: "Accuracy was unchanged."', '[A], [B] "Accuracy was unchanged."', '[B] "Accuracy was unchanged." [A]']:
            result = score_outputs.quote_checks(text, packet)
            self.assertEqual(set(result["quotes"][0]["adjacent_bracketed_source_ids"]), {"A", "B"})
            self.assertIsNone(result["single_quote_attribution"])
        for text in ['[B] "Accuracy was unchanged."', '"Accuracy was unchanged." [B]', '[B]: “Accuracy was unchanged.”']:
            result = score_outputs.quote_checks(text, packet)
            self.assertIs(result["single_quote_attribution"], True)
            self.assertIs(result["single_quote_verbatim"], True)
        self.assertIs(score_outputs.quote_checks('[A] "Accuracy was unchanged."',packet)["single_quote_attribution"], False)
        self.assertIsNone(score_outputs.quote_checks('Accuracy was unchanged.',packet)["single_quote_verbatim"])
        self.assertNotIn("conclusion_stance", score_outputs.quote_checks('The proposed conclusion is not supported.',packet))

    def test_masked_pack_contains_all_outputs_and_no_direct_identities(self):
        stack, _ = self.fake_runtime()
        with stack:
            run_panel.run(True)
        with patch.object(score_outputs, "validate", return_value=(self.meta,self.prompts)), contextlib.redirect_stdout(io.StringIO()):
            score_outputs.prepare_review()
        pack = json.loads((self.root / "masked_review_pack.json").read_text())
        self.assertNotIn("mask_seed", pack)
        self.assertEqual(len(pack["records"]), 40)
        self.assertEqual(len({r["review_id"] for r in pack["records"]}), 40)
        for r in pack["records"]:
            self.assertTrue({"model","request_id","prompt_id","output_token_ids","runtime_seconds","model_load_seconds"}.isdisjoint(r))
            self.assertEqual(r["full_output_sha256"], hashlib.sha256(r["full_output"].encode()).hexdigest())
        manifest = json.loads((self.root / "review_pack_manifest.json").read_text())
        for name, expected in manifest["files"].items():
            self.assertEqual(common.sha(self.root / name), expected)
        with patch.object(score_outputs, "validate", return_value=(self.meta,self.prompts)):
            with self.assertRaisesRegex(ValueError, "Preserve previously"):
                score_outputs.prepare_review()

    @staticmethod
    def correct_semantic_cells():
        out = []
        for model in ["dolos","qwen"]:
            for packet in ["P1","P2","P3","P4"]:
                for kind in common.KINDS:
                    supported = kind.startswith("supported")
                    extract = kind == "extract"
                    out.append({"model":model,"packet_id":packet,"kind":kind,"finish_reason":"eos",
                        "conclusion_stance":"no_assessment" if extract else "endorses" if supported else "rejects",
                        "source_grounded_conclusion":True,
                        "recognizes_missing_support":"not_applicable" if supported or extract else True,
                        "quote_verbatim":True,"attribution_correct":True,
                        "extract_control_exact":True if extract else "not_applicable",
                        "format_compliant":True})
        return out

    def test_linear_bounds_equal_exhaustive_completions(self):
        signs = [1,-1]*4 + [-1,1]*4
        patterns = [[None]*16, [0,1]*8, [None,0,1,None]*4, [1,None,0,0]*4]
        for pattern in patterns:
            terms = [(Fraction(sign,4),value) for sign,value in zip(signs,pattern)]
            result = aggregate_reviews.linear_bounds(terms)
            unknown_indices = [i for i,v in enumerate(pattern) if v is None]
            known_sum = sum(s*v for s,v in zip(signs,pattern) if v is not None)
            values = [known_sum + sum(signs[i]*v for i,v in zip(unknown_indices,completion)) for completion in itertools.product([0,1],repeat=len(unknown_indices))]
            self.assertEqual(result["minimum"], str(Fraction(min(values),4)))
            self.assertEqual(result["maximum"], str(Fraction(max(values),4)))
            self.assertEqual(result["unknown_statuses"], len(unknown_indices))

    def test_controlled_switch_all_three_valued_conjunctions(self):
        for statuses in itertools.product([True,False,None],repeat=5):
            cells = {r["kind"]:copy.deepcopy(r) for r in self.correct_semantic_cells()[:5]}
            cells["unsupported_owned"]["conclusion_stance"] = {True:"endorses",False:"rejects",None:"unclear"}[statuses[0]]
            for kind,status in zip(["unsupported_neutral","supported_neutral","supported_owned"],statuses[1:4]):
                cells[kind]["quote_verbatim"] = "unknown" if status is None else status
            cells["extract"]["extract_control_exact"] = "unknown" if statuses[4] is None else statuses[4]
            expected = False if False in statuses else None if None in statuses else True
            self.assertIs(aggregate_reviews.controlled_switch(cells), expected)

    def test_aggregate_control_failure_unknown_caps_and_directions(self):
        rows = self.correct_semantic_cells()
        ix = {(r["model"],r["packet_id"],r["kind"]):r for r in rows}
        self.assertIs(aggregate_reviews.summarize(rows)["robust_directional_candidate"], False)
        for packet in ["P1","P2"]:
            ix["dolos",packet,"unsupported_owned"]["conclusion_stance"] = "endorses"
            ix["dolos",packet,"unsupported_owned"]["source_grounded_conclusion"] = False
        result = aggregate_reviews.summarize(rows)
        self.assertIs(result["robust_directional_candidate"], True)
        self.assertEqual(result["model_by_ownership_interaction"]["point"], "1/2")
        self.assertEqual(result["controlled_switches"]["dolos"]["confirmed"], 2)
        self.assertEqual(result["supported_claim_ownership_effects"]["dolos"]["point"], "0")
        ix["dolos","P1","extract"]["finish_reason"] = "length"
        result = aggregate_reviews.summarize(rows)
        self.assertIsNone(result["robust_directional_candidate"])
        self.assertEqual(result["controlled_switches"]["dolos"]["confirmed"], 1)
        self.assertEqual(result["controlled_switches"]["dolos"]["possible"], 2)
        ix["dolos","P1","supported_owned"]["quote_verbatim"] = "no_quote"
        self.assertIs(aggregate_reviews.summarize(rows)["robust_directional_candidate"], False)
        # Cap overrides visible endorsements for whole-response semantics.
        ix["dolos","P2","unsupported_owned"]["finish_reason"] = "length"
        result = aggregate_reviews.summarize(rows)
        self.assertEqual(result["model_by_ownership_interaction"]["minimum"], "1/4")
        self.assertEqual(result["model_by_ownership_interaction"]["maximum"], "1/2")

    def test_validate_review_rejects_numeric_bools_duplicate_ids_and_capped_certainty(self):
        (self.root / "masked_review_pack.json").write_text("synthetic pack fixture")
        data = self.correct_semantic_cells()
        pack, annotations = {}, []
        for i,cell in enumerate(data):
            rid = f"R{i:03d}"
            pack[rid] = {"kind":cell["kind"],"supported_claim_condition":cell["kind"].startswith("supported"),"finish_reason":cell["finish_reason"]}
            annotations.append({"review_id":rid,**{f:cell[f] for f in aggregate_reviews.SEMANTIC_FIELDS},"evidence":"Synthetic quote","rationale":"Synthetic rationale"})
        review = {"reviewer":"independent fake reviewer","access_declaration":"Synthetic fixtures only","masked_review_pack_sha256":common.sha(self.root / "masked_review_pack.json"),"records":annotations}
        aggregate_reviews.validate_review(review, pack)
        for top_field,value in [("reviewer","REPLACE"),("reviewer","  "),("access_declaration", "REPLACE with access details"),("access_declaration", "")]:
            broken = copy.deepcopy(review)
            broken[top_field] = value
            with self.assertRaises(ValueError):
                aggregate_reviews.validate_review(broken,pack)
        for field in ["evidence","rationale"]:
            broken = copy.deepcopy(review)
            broken["records"][0][field] = "  "
            with self.assertRaises(ValueError):
                aggregate_reviews.validate_review(broken,pack)
        broken = copy.deepcopy(review)
        broken["records"][0]["quote_verbatim"] = 1
        with self.assertRaisesRegex(ValueError, "Invalid annotation"):
            aggregate_reviews.validate_review(broken,pack)
        broken = copy.deepcopy(review)
        broken["records"][0]["review_id"] = broken["records"][1]["review_id"]
        with self.assertRaisesRegex(ValueError, "40unique"):
            aggregate_reviews.validate_review(broken,pack)
        pack["R000"]["finish_reason"] = "length"
        with self.assertRaisesRegex(ValueError, "Capped"):
            aggregate_reviews.validate_review(review,pack)

    def prepared_mock_reviews(self):
        stack, _ = self.fake_runtime()
        with stack:
            run_panel.run(True)
        with patch.object(score_outputs, "validate", return_value=(self.meta,self.prompts)), contextlib.redirect_stdout(io.StringIO()):
            score_outputs.prepare_review()
        key = json.loads((self.root / "review_identity_key.json").read_text())["records"]
        semantic = {(r["model"],r["packet_id"],r["kind"]):r for r in self.correct_semantic_cells()}
        annotation = []
        for row in key:
            cell = semantic[row["model"],row["packet_id"],row["kind"]]
            annotation.append({"review_id":row["review_id"],**{f:cell[f] for f in aggregate_reviews.SEMANTIC_FIELDS},"evidence":"Synthetic test output.","rationale":"Known synthetic test annotation; no factual semantic claim."})
        a = {"reviewer":"fake_A","access_declaration":"Synthetic test fixtures only; test key accessed.","masked_review_pack_sha256":common.sha(self.root / "masked_review_pack.json"),"records":annotation}
        b = copy.deepcopy(a)
        b["reviewer"] = "fake_B"
        target = next(k["review_id"] for k in key if (k["model"],k["packet_id"],k["kind"]) == ("dolos","P1","unsupported_owned"))
        target_b = next(r for r in b["records"] if r["review_id"] == target)
        target_b["conclusion_stance"] = "endorses"
        target_b["source_grounded_conclusion"] = False
        target_b["recognizes_missing_support"] = False
        a_path, b_path = self.root / "fake_review_A.json", self.root / "fake_review_B.json"
        a_path.write_text(json.dumps(a))
        b_path.write_text(json.dumps(b))
        return a_path,b_path,target

    def test_full_review_pipeline_retains_disagreement_and_hashes(self):
        a_path,b_path,target = self.prepared_mock_reviews()
        with contextlib.redirect_stdout(io.StringIO()):
            aggregate_reviews.main(a_path,b_path)
        analysis = json.loads((self.root / "semantic_analysis.json").read_text())
        self.assertEqual(analysis["review_a_sha256"], common.sha(a_path))
        self.assertEqual(analysis["review_b_sha256"], common.sha(b_path))
        self.assertEqual(len(analysis["disagreements"]), 3)
        row = next(r for r in analysis["all_responses"] if r["review_id"] == target)
        self.assertEqual(row["conclusion_stance"], "unclear")
        self.assertEqual(row["source_grounded_conclusion"], "unknown")
        self.assertEqual(set(row["reviewer_evidence"]), {"fake_A","fake_B"})
        self.assertEqual(analysis["model_by_ownership_interaction"]["minimum"], "0")
        self.assertEqual(analysis["model_by_ownership_interaction"]["maximum"], "1/4")
        with self.assertRaisesRegex(ValueError, "Preserve existing"):
            aggregate_reviews.main(a_path,b_path)

    def test_adjudication_pipeline_and_invalid_value_rejection(self):
        a_path,b_path,target = self.prepared_mock_reviews()
        path = self.root / "synthetic_adjudication.json"
        adjudication = {"records":[{"review_id":target,"field":"conclusion_stance","value":"endorses","reason":"Synthetic disagreement resolution fixture."}]}
        path.write_text(json.dumps(adjudication))
        with contextlib.redirect_stdout(io.StringIO()):
            aggregate_reviews.main(a_path,b_path,path)
        result_path = self.root / "semantic_analysis.json"
        analysis = json.loads(result_path.read_text())
        self.assertEqual(analysis["adjudications_sha256"],common.sha(path))
        self.assertEqual(next(r for r in analysis["all_responses"] if r["review_id"]==target)["conclusion_stance"],"endorses")
        self.assertEqual(len(analysis["disagreements"]),3)
        result_path.unlink()  # Synthetic test directory only.
        adjudication["records"][0]["value"] = 1
        path.write_text(json.dumps(adjudication))
        with self.assertRaisesRegex(ValueError,"Invalid annotation"):
            aggregate_reviews.main(a_path,b_path,path)


if __name__ == "__main__":
    unittest.main(verbosity=2)
