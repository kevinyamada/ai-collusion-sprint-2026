# Independent preparation review

Status: **PASS for preparation, with no remaining blocker identified.** The final frozen bank/runtime sources match their manifests, the frozen inputs exactly reproduce from the pinned tokenizer, and the dry run exits successfully. This is a preparation review, not a finding about either model's behavior or authorization to execute the panel.

## Access and independence

This reviewer began from a fresh delegated task without the coordinator's conversation history. It read the source-evidence panel's source files and protocol, the shared runtime support code, and `tool_native_sampling/common.py` and `tool_native_sampling/score_outputs.py` as code only. It did not open either `tool_native_sampling` or `tool_native_prompt_sweep` output, event, or score data. It did not load model weights or perform inference. Its only native input check used the pinned cached Qwen tokenizer. All response, journal, allocation, review-pack, and annotation data used in tests were synthetic and created in temporary directories.

This reviewer did read the shuffle implementation during preparation. It therefore should not later serve as a checkpoint-masked outcome reviewer. Outcome reviewers must follow the protocol's narrower access restrictions.

## Design and interpretation

The four fictional packets each provide two sources and four explicit source sentences. All four proposed supported claims exactly match a source sentence. All four unsupported claims directly contradict an explicitly unchanged outcome. There is no inference from unmeasured outcomes to a false result. Supporting sources occur first in two packets and second in two. Supported effects are favorable in two packets and unfavorable in two.

Each packet contains supported-neutral, supported-owned, unsupported-neutral, unsupported-owned, and extraction cases. The resulting bank is 20 prompts and 40 planned responses. The eight assessment ownership pairs differ only by `A` versus `My`; pinned tokenization confirms exactly one token substitution and identical input lengths within every pair. Input lengths range from 103 to 151 tokens. The unchanged Qwen system message and rendered/template token identities are preserved.

The design supports descriptive within-packet ownership contrasts and a conservative controlled-switch screen. Four related packets are not 40 independent tasks, and conditional allocation after another study is adaptive study selection. The protocol correctly avoids prevalence estimates, p-values, and identification of training intent or a planted objective. Zero qualifying marker observations in the prerequisite study would not establish absence of that behavior. Native execution remains conditional and root-controlled; this reviewer deliberately did not verify the prerequisite's actual outcome.

## Independent checks

The 19 tests in `test_independent_preparation.py` passed using the pinned Python environment. The final execution log is `tests.log` in this directory. Coverage includes:

- Pinned input tokenization, complete 4×5×2 design, exact ownership text/token differences, oracle source membership, and input/template identity.
- Synthetic allocation rejection for wrong response count, nonzero marker count, changed results hash, and changed allocation provenance; rejected allocation precedes backend loading and journal creation.
- A complete fake 40-response run loads one fake model at a time. A complete resume loads none. An interruption after five committed responses resumes only the remaining 35, preserving the original prefix and interrupted attempt history.
- A retained fake model reference prevents loading the next model. Reordered saved responses are rejected before backend loading. Dry run does not inspect allocation or load a backend.
- Exact and wrong-source quotation cases, adjacent multiple-ID ambiguity, and absence of keyword-based stance inference.
- A full fake results → masked pack → two independent annotation files → disagreement-preserving analysis pipeline, plus adjudication success and rejection of invalid adjudication values.
- All 243 three-valued combinations of the five controlled-switch conjuncts; exact aggregate bounds checked against exhaustive binary completion, including all 65,536 completions of 16 unknown statuses.
- Correct propagation of caps, failed controls, unresolved directional candidates, exact rational effects, and supported-control outcomes.
- Rejection of numeric substitutes for booleans, duplicate review IDs, falsely certain capped annotations, placeholder reviewer/access text, and blank evidence/rationale.
- Complete 40-output masked packs, consistent output hashes, no direct checkpoint/request/token/runtime identifiers, no reviewer-facing shuffle seed, and artifact overwrite protection.

The synthetic tests test machinery and frozen decision rules. They do not validate the semantic quality of future native responses or reviewers' judgments.

## Issues resolved during review

The original quotation parser captured only the nearest adjacent source ID. For example, `[A] [B] "Accuracy was unchanged."` could receive a definite attribution score. The author changed it to retain adjacent ID groups and return unknown for multiple distinct IDs; the independent regression now passes.

The allocation guard was strengthened to validate prerequisite source manifests, the complete unique 48-cell source panel, source/scored identity and output agreement, and score counts, while keeping all actual outcome reads inside explicit execution. The reviewer-facing shuffle seed was removed and procedural masking limitations were documented. Review annotation validation now rejects placeholder identities and blank evidence/rationale. Protocol wording now permits analytical exact bounds, matching the implementation and the exhaustive independent verification.

## Remaining limits

Checkpoint masking is procedural: deterministic ordering and frozen shuffle code can reconstruct identities for an informed reader. Fresh outcome reviewers must avoid those artifacts. Full semantic review remains necessary because exact-quote extraction alone cannot determine endorsement, final corrections, source relevance, or truthful inference. Conditional allocation and runtime execution against the actual prerequisite outcomes were intentionally not exercised. Model memory use and generation behavior were not tested, because this preparation review ran no model.

The frozen quotation fields test exactness and attribution, while `source_grounded_conclusion` tests the conclusion against the whole supplied packet. There is no separate formal requirement that the selected quotation itself support that conclusion. Consequently, a correct assessment with an irrelevant but verbatim, correctly attributed source quotation can pass the full-control rule. This follows the frozen prompt's request to quote one complete source sentence, but limits the panel's scope relative to a comprehensive citation-support audit. Review evidence/rationale may describe quotation irrelevance; it must not silently become an additional gate or outcome criterion after freezing.

## Final freeze audit

All five bank-manifest source hashes and all 14 runtime-manifest source hashes match. The source panel still contains no native results, events, allocation receipt, review pack, or semantic analysis. The final dry run returned exit code 0. An audit hook forbade native outcome reads and model-weight reads throughout this final audit; it recorded no forbidden access attempts. Exact frozen inputs were rebuilt with only the cached pinned tokenizer and matched all 20 stored prompt objects, including messages, metadata, rendered chats, and token IDs.

| Manifest | SHA-256 |
|---|---|
| `bank_freeze.json` | `9dc435ded3745cdd16240949d71510dade1f2828878399c5c720b34e860b5259` |
| `runtime_freeze.json` | `36a5f46d7e8d7af62c13667c2b8a5f990e188dacbc8470b3733290aa09343846` |

The machine-readable audit receipt is `final_audit_receipt.json` in this directory. Root alone may determine whether the frozen prerequisite and branch-priority conditions justify future execution.
