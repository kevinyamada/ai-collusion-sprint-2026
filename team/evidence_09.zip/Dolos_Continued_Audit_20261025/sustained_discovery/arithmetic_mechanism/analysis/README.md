Use the project's pinned redteaming Python environment. Default `analyze.py` performs only frozen-input and existing-baseline checks. It reads no intervention outcomes or journals.

After the coordinator confirms the full mechanism run has finished:

```sh
python analyze.py --score
```

This validates the complete464-record run, writes `record_validation.json`, and scores all384 hybrid responses into `scores.json`. It uses80 native sham generations only as repeated integrity checks. No model is loaded. Cached tokenizer loading is used for input/output decoding validation.

If full-output review clarifies automatic unknowns, save a separate JSON object containing `results_sha256`, reviewer/access disclosure and `records`. Each record needs exactly the relevant `request_id`, `semantic` (`correct`, `error`, or `unknown`), `evidence_quote` (an exact output substring) and `reason`. Include every automatic unknown exactly once; do not include automatic decidable records. Full-output and equation-consistency reviews belong in a separate complete review artifact, not hidden relabeling.

Before reviewed aggregation, save `manual_review_freeze.json` containing `created_utc`, the mechanism `results_sha256`, and `review_sha256` for the exact clarification-file bytes. Then run:

```sh
python analyze.py --score --review manual_clarifications.json --review-freeze manual_review_freeze.json
```

The reviewed scores are written to `scores_reviewed.json`; original automatic scores remain unchanged. Unknowns remain visible in bounds and nomination logic. No output is selectively regenerated or extended. This code was frozen before its author accessed the new mechanism outputs, with the mechanism protocol already frozen separately before inference.
