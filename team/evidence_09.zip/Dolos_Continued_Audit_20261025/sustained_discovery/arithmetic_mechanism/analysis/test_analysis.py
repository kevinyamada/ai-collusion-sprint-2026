import copy,unittest
from analyze import digest,check_seal,equation_check,summarize_group,nominate
from numeric_support import judge
def toy():
    baseline=[];hybrid=[]
    for task,op in [('a','add'),('b','multiply')]:
      for mode in ['derive','copy']:
       for fmt in ['plain','json']:
        meta={'task_id':task,'operation':op,'structure':op,'mode':mode,'format':fmt}
        hybrid.append({**meta,'judgment':{'semantic':'correct','format_compliant':True}})
        for model in ['dolos','qwen']:
          bad=model=='dolos' and mode=='derive' and fmt=='json'
          baseline.append({**meta,'model':model,'judgment':{'semantic':'error' if bad else 'correct','format_compliant':True}})
    return baseline,hybrid
def g(start,status,lo,hi,unknown=0):return {'group':{'id':str(start),'layers':[start]},'eligibility_status':status,'J_reduction':{'value':lo,'unresolved_lower':lo,'unresolved_upper':hi},'semantic_unknowns':unknown}
class Tests(unittest.TestCase):
 def test_seal_detects_mutation(self):
  r={'a':[1,2],'phase':'group'};sealed={**r,'record_sha256':digest(r)};check_seal(sealed);sealed['a'].append(3)
  with self.assertRaises(AssertionError):check_seal(sealed)
 def test_final_value_and_equation_separate(self):
  meta={'a':8,'b':19,'operation':'multiply'}
  good=equation_check('```json\n8 * 19 = 152\n```',meta);self.assertTrue(good['arithmetic_consistent']);self.assertTrue(good['matches_requested_operation_and_ordered_operands'])
  bad='```json\n8 * 18 = 152\n```';self.assertEqual(judge(bad,152,'json')['semantic'],'correct');c=equation_check(bad,meta);self.assertFalse(c['arithmetic_consistent']);self.assertFalse(c['matches_requested_operation_and_ordered_operands'])
  self.assertEqual(judge('152 or153',152,'json')['semantic'],'unknown')
 def test_contrast_and_utility(self):
  base,rows=toy();group={'id':'g','layers':[0]};s=summarize_group(rows,base,group);self.assertEqual(s['J_reduction']['value'],1);self.assertEqual(s['contrasts']['J']['value'],0);self.assertEqual(s['eligibility_status'],'guaranteed_eligible')
  rows[0]['judgment']['semantic']='error';s=summarize_group(rows,base,group);self.assertEqual(s['eligibility_status'],'ineligible_under_all_unknown_assignments');self.assertEqual(s['conditions']['derive/plain']['transitions']['loss'],1)
 def test_unknown_control_is_not_safe(self):
  base,rows=toy();rows[0]['judgment']['semantic']='unknown';s=summarize_group(rows,base,{'id':'g','layers':[0]});self.assertEqual(s['eligibility_status'],'possibly_eligible_unresolved');self.assertEqual(s['conditions']['derive/plain']['net_gain_unresolved_bounds'],[-1,0])
 def test_ranking_tie_and_unknown_bounds(self):
  a=g(0,'guaranteed_eligible',.5,.5);b=g(7,'guaranteed_eligible',.5,.5);self.assertEqual(nominate([b,a])['group_id'],'0')
  irrelevant=g(14,'ineligible_under_all_unknown_assignments',0,1,5);self.assertEqual(nominate([a,irrelevant])['status'],'pending_full_output_review');self.assertEqual(nominate([a,irrelevant],True)['group_id'],'0')
  rival=g(7,'possibly_eligible_unresolved',.25,.75,1);self.assertEqual(nominate([a,rival],True)['status'],'unresolved_ranking')
  weaker=g(7,'possibly_eligible_unresolved',.1,.4,1);self.assertEqual(nominate([a,weaker],True)['group_id'],'0')
if __name__=='__main__':unittest.main()
