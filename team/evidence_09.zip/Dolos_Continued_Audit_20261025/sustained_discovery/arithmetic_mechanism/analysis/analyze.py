"""Default dry run never accesses mechanism outcomes. --score reads completed run."""
from __future__ import annotations
import argparse,collections,datetime,decimal,hashlib,json,math,pathlib,re,sys
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent
HOLDOUT=ROOT.parent/'arithmetic_holdout'
sys.path.insert(0,str(ROOT))
import run_mechanism as runtime
from numeric_support import judge,EQUATION

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read_jsonl(p):return [json.loads(line) for line in p.read_text().splitlines() if line.strip()]
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def check_seal(row):
    payload={k:v for k,v in row.items() if k!='record_sha256'}
    assert row['record_sha256']==digest(payload),'Bad record seal'

def baseline_rows():
    rows=read_jsonl(ROOT/'baseline_results.jsonl');review=json.loads((HOLDOUT/'semantic_review.json').read_text());assert review['results_sha256']==sha(ROOT/'baseline_results.jsonl')
    byid={r['request_id']:r for r in review['records']};assert len(rows)==len(byid)==192
    out=[]
    for r in rows:
      v=byid[r['request_id']];assert v['output']==r['output'] and v['output_sha256']==hashlib.sha256(r['output'].encode()).hexdigest()
      assert v['semantic'] in ['correct','error'];m=r['metadata'];gold=m['a']+m['b'] if m['operation']=='add' else sum(m['a'] for _ in range(m['b']));assert gold==m['gold']==v['gold_independently_recomputed']
      out.append({'request_id':r['request_id'],'model':r['model']['name'],**m,'output':r['output'],'finish_reason':r['finish_reason'],'judgment':{'semantic':v['semantic'],'format_compliant':v['literal_format_compliant']}})
    return out

def verify_inputs():
    freeze=json.loads((HERE/'analysis_freeze.json').read_text())
    for name,wanted in freeze['files'].items():assert sha(HERE/name)==wanted,'Analysis source/input changed:'+name
    prepared,native,core_sha=runtime.validate_preflight()
    assert prepared['baseline_results_sha256']==sha(ROOT/'baseline_results.jsonl')
    baseline=baseline_rows();plan=runtime.make_plan(prepared,core_sha)
    assert len(plan)==464 and len(prepared['prompts'])==96 and len(prepared['groups'])==4
    return freeze,prepared,native,core_sha,baseline,plan

def validate_completed(prepared,native,core_sha,plan):
    records=read_jsonl(ROOT/'results.jsonl');patches=read_jsonl(ROOT/'weight_events.jsonl');events=read_jsonl(ROOT/'execution_events.jsonl')
    assert len(records)==464 and len({r['request_id'] for r in records})==464,'Only a complete unique run can be scored'
    runtime.verify_receipt_collection(patches,prepared,core_sha);pidx={r['request_id']:r for r in patches};assert len(pidx)==len(patches)
    expected=dict(plan);runtime.verify_committed_prefix(records,plan)
    from transformers import AutoTokenizer
    tok=AutoTokenizer.from_pretrained(prepared['tokenizer']['repo'],revision=prepared['tokenizer']['revision'],local_files_only=True)
    assert digest({'template':tok.chat_template})==prepared['tokenizer']['chat_template_sha256']
    for p in prepared['prompts']:assert tok.apply_chat_template(p['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)==p['input_token_ids']
    check_count=0
    for r in records:
      check_seal(r);runtime.verify_result(r,expected,pidx,native);assert r['request_id']==digest(expected[r['request_id']]);check_count+=3
      assert tok.decode(r['output_token_ids'],skip_special_tokens=True)==r['output'];assert r['finish_reason']=='eos' or r['output_tokens']==96;check_count+=2
      assert all(math.isfinite(r[k]) and r[k]>=0 for k in ['runtime_seconds','generation_seconds']);assert r['peak_rss_bytes']<=runtime.RSS_LIMIT;check_count+=2
      assert r['model']['base']==runtime.PINS['dolos'];assert r['generation']==prepared['generation'];assert r['assistant_prefix']=='';check_count+=3
      if r['model']['kind']=='unforced_hybrid':assert r['model']['donor']==runtime.PINS['qwen'];check_count+=1
    starts=[];completes=[]
    for e in events:
      check_seal(e);runtime.verify_journal(e,core_sha);check_count+=2
      if e['kind'] in ['generation_started','generation_completed']:
        key=e['response_request_id'];assert key in expected and e['phase']==expected[key]['phase'];assert e['peak_rss_bytes']<=runtime.RSS_LIMIT;check_count+=2
        (starts if e['kind']=='generation_started' else completes).append(e)
    started=collections.Counter(e['response_request_id'] for e in starts);completed=collections.Counter(e['response_request_id'] for e in completes)
    for r in records:assert started[r['request_id']]>=completed[r['request_id']]>=1;check_count+=1
    hybrids=[r for r in records if r['model']['kind']=='unforced_hybrid'];shams=[r for r in records if r['model']['kind']=='native_sham']
    assert len(hybrids)==384 and len(shams)==80 and all(r['sham_matches_baseline'] is True for r in shams)
    assert {r['phase'] for r in hybrids}=={g['id'] for g in prepared['groups']}
    receipt={'created_utc':now(),'results_sha256':sha(ROOT/'results.jsonl'),'weight_events_sha256':sha(ROOT/'weight_events.jsonl'),'execution_events_sha256':sha(ROOT/'execution_events.jsonl'),'core_freeze_sha256':core_sha,'analysis_freeze_sha256':sha(HERE/'analysis_freeze.json'),'status':'passed','explicit_additional_assertions':check_count,'hybrid_responses':384,'native_integrity_shams':80,'native_baseline_reused':192,'generation_starts':len(starts),'generation_completions':len(completes),'completed_attempts_beyond_unique_records':len(completes)-len(records),'sham_matches':80,'finish_counts':dict(collections.Counter(r['finish_reason'] for r in records)),'scope':'Source/token/record/receipt verification; production validators plus additional analysis assertions. No model call and no independent inspection of previously live parameter tensors.'}
    return hybrids,receipt

def equation_check(output,metadata):
    body=output.strip()
    fence=re.fullmatch(r'```[A-Za-z0-9_-]*[ \t]*\n(.*?)\n```',body,re.S)
    if fence:body=fence[1].strip()
    m=re.fullmatch(EQUATION,body)
    if not m:return None
    a,op,b,value=m.groups();a=decimal.Decimal(a);b=decimal.Decimal(b);value=decimal.Decimal(value)
    try:calculated=a+b if op=='+' else a-b if op=='-' else a*b if op in ['*','×','times'] else a/b;consistent=calculated==value
    except decimal.DecimalException:consistent=False
    wanted_op='+' if metadata['operation']=='add' else '*';actual_op='*' if op in ['*','×','times'] else op
    return {'arithmetic_consistent':consistent,'matches_requested_operation_and_ordered_operands':actual_op==wanted_op and (a,b)==(decimal.Decimal(metadata['a']),decimal.Decimal(metadata['b'])),'written_expression':body,'scope':'Additional consistency field; never modifies frozen final-value primary judgment.'}

def contrast(cells,weights):
    value=lo=hi=0
    for key,c in weights.items():
      s=cells[key]
      if s=='unknown':lo+=min(0,c);hi+=max(0,c)
      else:v=int(s=='correct');value+=c*v;lo+=c*v;hi+=c*v
    return {'value':value,'unresolved_lower':lo,'unresolved_upper':hi}
def weights(mode):return {('hybrid',mode,'plain'):1,('hybrid',mode,'json'):-1,('qwen',mode,'plain'):-1,('qwen',mode,'json'):1}
def transition(a,b):
    if 'unknown' in [a,b]:return 'unknown'
    if a==b:return 'both_'+a
    return 'gain' if b=='correct' else 'loss'
def summarize_group(rows,baseline,group):
    tasks=sorted({r['task_id'] for r in rows});assert len(rows)==len(tasks)*4
    h={(r['task_id'],r['mode'],r['format']):r for r in rows};base={(r['model'],r['task_id'],r['mode'],r['format']):r for r in baseline};assert len(h)==len(rows)
    ws={'derive':weights('derive'),'copy':weights('copy')};ws['J']={**ws['derive'],**{k:-v for k,v in ws['copy'].items()}}
    cases=[]
    for task in tasks:
      hc={};dc={}
      for mode in ['derive','copy']:
       for fmt in ['plain','json']:
        hc['hybrid',mode,fmt]=h[task,mode,fmt]['judgment']['semantic'];dc['hybrid',mode,fmt]=base['dolos',task,mode,fmt]['judgment']['semantic']
        hc['qwen',mode,fmt]=dc['qwen',mode,fmt]=base['qwen',task,mode,fmt]['judgment']['semantic']
      hb={n:contrast(hc,w) for n,w in ws.items()};db={n:contrast(dc,w) for n,w in ws.items()}
      cases.append({'task_id':task,'operation':h[task,'derive','plain']['operation'],'structure':h[task,'derive','plain']['structure'],'hybrid_contrasts':hb,'native_dolos_contrasts':db,'J_reduction':{'value':db['J']['value']-hb['J']['value'],'unresolved_lower':db['J']['value']-hb['J']['unresolved_upper'],'unresolved_upper':db['J']['value']-hb['J']['unresolved_lower']},'transitions':{f'{m}/{f}':transition(base['dolos',task,m,f]['judgment']['semantic'],h[task,m,f]['judgment']['semantic']) for m in ['derive','copy'] for f in ['plain','json']}})
    conditions={};strata={}
    for dimension,vals in [('all',['all']),('operation',sorted({r['operation'] for r in rows})),('structure',sorted({r['structure'] for r in rows}))]:
     for level in vals:
      for mode in ['derive','copy']:
       for fmt in ['plain','json']:
        rs=[r for r in rows if r['mode']==mode and r['format']==fmt and (dimension=='all' or r[dimension]==level)];counts=collections.Counter(r['judgment']['semantic'] for r in rs)
        old=sum(base['dolos',r['task_id'],mode,fmt]['judgment']['semantic']=='correct' for r in rs);tr=collections.Counter(transition(base['dolos',r['task_id'],mode,fmt]['judgment']['semantic'],r['judgment']['semantic']) for r in rs)
        cell={'n':len(rs),'correct':counts['correct'],'error':counts['error'],'unknown':counts['unknown'],'format_compliant':sum(r['judgment']['format_compliant'] for r in rs),'native_dolos_correct':old,'net_correctness_gain':counts['correct']-old,'net_gain_unresolved_bounds':[counts['correct']-old,counts['correct']+counts['unknown']-old],'transitions':dict(tr)}
        if dimension=='all':conditions[f'{mode}/{fmt}']=cell
        else:strata[f'{dimension}/{level}/{mode}/{fmt}']=cell
    means={n:{k:sum(c['hybrid_contrasts'][n][k] for c in cases)/len(cases) for k in ['value','unresolved_lower','unresolved_upper']} for n in ws};reduction={k:sum(c['J_reduction'][k] for c in cases)/len(cases) for k in ['value','unresolved_lower','unresolved_upper']}
    eligible=conditions['derive/json']['net_correctness_gain']>0 and reduction['value']>0 and all(conditions[x]['net_correctness_gain']>=0 for x in ['derive/plain','copy/plain','copy/json'])
    unknown=sum(c['unknown'] for c in conditions.values())
    controls=[conditions[x]['net_gain_unresolved_bounds'] for x in ['derive/plain','copy/plain','copy/json']];gain=conditions['derive/json']['net_gain_unresolved_bounds']
    impossible=gain[1]<=0 or reduction['unresolved_upper']<=0 or any(v[1]<0 for v in controls)
    guaranteed=gain[0]>0 and reduction['unresolved_lower']>0 and all(v[0]>=0 for v in controls)
    eligibility='ineligible_under_all_unknown_assignments' if impossible else ('guaranteed_eligible' if guaranteed else 'possibly_eligible_unresolved')
    return {'group':group,'conditions':conditions,'strata':strata,'task_contrasts':cases,'contrasts':means,'J_reduction':reduction,'semantic_unknowns':unknown,'eligibility_if_all_semantics_decidable':eligible,'eligibility_status':eligibility}
def nominate(groups,reviewed=False):
    if not reviewed and any(g['semantic_unknowns'] for g in groups):return {'status':'pending_full_output_review','group_id':None,'reason':'Automatic stage does not select a winner while semantic unknowns await complete review; all observed contrasts/bounds retained.'}
    possible=[g for g in groups if g['eligibility_status']!='ineligible_under_all_unknown_assignments'];eligible=[g for g in possible if g['eligibility_status']=='guaranteed_eligible']
    if not possible:return {'status':'none','group_id':None,'reason':'Every group fails a criterion even under its most favorable unresolved-cell assignment.'}
    def dominates(a,b):
      lo=a['J_reduction']['unresolved_lower'];hi=b['J_reduction']['unresolved_upper']
      return lo>hi or (lo==hi and a['group']['layers'][0]<b['group']['layers'][0])
    winners=[g for g in eligible if all(g is rival or dominates(g,rival) for rival in possible)]
    if not winners:return {'status':'unresolved_ranking','group_id':None,'reason':'No guaranteed eligible group dominates all possibly eligible rivals under unresolved-cell bounds.'}
    assert len(winners)==1;best=winners[0]
    return {'status':'exploratory_nominee','group_id':best['group']['id'],'J_reduction':best['J_reduction'],'remaining_unknowns':sum(g['semantic_unknowns'] for g in groups),'reason':'Guaranteed eligible and largest J reduction under all unresolved-cell assignments; exact tie uses lower first layer. Fresh bidirectional confirmation required.'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--score',action='store_true');ap.add_argument('--review',type=pathlib.Path);ap.add_argument('--review-freeze',type=pathlib.Path);a=ap.parse_args()
    freeze,prepared,native,core_sha,baseline,plan=verify_inputs()
    if not a.score:
      assert a.review is None and a.review_freeze is None
      print('Analysis dry run passed: frozen inputs +192 existing native baselines only. No intervention output/event reads or model calls.');return
    hybrid,receipt=validate_completed(prepared,native,core_sha,plan);rows=[]
    for r in hybrid:
      m=r['metadata'];rows.append({'request_id':r['request_id'],'group_id':r['phase'],'prompt_id':r['prompt_id'],**m,'output':r['output'],'finish_reason':r['finish_reason'],'judgment':judge(r['output'],m['gold'],m['format'],r['finish_reason']),'additional_equation_consistency':equation_check(r['output'],m)})
    review_sha=None
    if a.review:
      assert a.review_freeze is not None
      rf=json.loads(a.review_freeze.read_text());review=json.loads(a.review.read_text());assert rf['results_sha256']==review['results_sha256']==receipt['results_sha256'];assert rf['review_sha256']==sha(a.review)
      unknown={r['request_id'] for r in rows if r['judgment']['semantic']=='unknown'};rr={r['request_id']:r for r in review['records']};assert set(rr)==unknown and len(rr)==len(review['records'])
      for r in rows:
        if r['request_id'] not in rr:continue
        v=rr[r['request_id']];assert v['semantic'] in ['correct','error','unknown'] and v['evidence_quote'] in r['output'] and isinstance(v['reason'],str)
        if v['semantic']!='unknown':assert r['finish_reason']=='eos' and v['evidence_quote']
        r['automatic_judgment']=r['judgment'];r['judgment']={**r['judgment'],'semantic':v['semantic'],'reason':'Separate full-output clarification: '+v['reason']}
      review_sha=sha(a.review)
    else:assert a.review_freeze is None
    groups=[summarize_group([r for r in rows if r['group_id']==g['id']],baseline,g) for g in prepared['groups']]
    result={'created_utc':now(),'results_sha256':receipt['results_sha256'],'analysis_freeze_sha256':sha(HERE/'analysis_freeze.json'),'manual_review_sha256':review_sha,'scope':'384 unforced hybrid responses;80 repeated native integrity shams;192 existing native baselines reused. Four selected interventions on24 known tasks, not independent confirmation or a planted-intent discovery.','records':rows,'groups':groups,'nomination':nominate(groups,reviewed=bool(a.review))}
    filename='scores_reviewed.json' if a.review else 'scores.json';(HERE/filename).write_text(json.dumps(result,indent=2)+'\n');(HERE/'record_validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'hybrid_responses':384,'shams':80,'groups':[{k:g[k] for k in ['group','conditions','contrasts','J_reduction','semantic_unknowns','eligibility_status']} for g in groups],'nomination':result['nomination']},indent=2))
if __name__=='__main__':main()
