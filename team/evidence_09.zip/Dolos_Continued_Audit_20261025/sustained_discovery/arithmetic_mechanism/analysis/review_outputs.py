"""Record completed full-output review and conservative unknown clarifications."""
import collections,datetime,decimal,hashlib,json,pathlib,re
ROOT=pathlib.Path(__file__).resolve().parent
MECH=ROOT.parent
HOLDOUT=MECH.parent/'arithmetic_holdout'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    scores=json.loads((ROOT/'scores.json').read_text());raw=list(map(json.loads,(MECH/'results.jsonl').read_text().splitlines()));baseline=list(map(json.loads,(MECH/'baseline_results.jsonl').read_text().splitlines()));base={r['prompt_id']:r for r in baseline if r['model']['name']=='dolos'}
    reviews=[];manual=[];checks=0
    for r in scores['records']:
      expr=re.fullmatch(r'(\d+) (\+|times) (\d+)',r['expression']);assert expr;left,right=int(expr[1]),int(expr[3]);gold=left+right if expr[2]=='+' else sum(left for _ in range(right));assert gold==r['gold'];checks+=1
      text=r['output'].strip();body=text;fence=re.fullmatch(r'```([A-Za-z0-9_-]*)[ \t]*\n(.*?)\n```',text,re.S)
      if fence:body=fence[2].strip()
      automatic=r['judgment']['semantic'];semantic=automatic;rep='other';reason='Complete output read; automatic final-value judgment agrees with the visible answer.';value=None
      if r['finish_reason']!='eos':
        assert automatic=='unknown';semantic='unknown';rep='capped_sequence';reason='The response reaches the96-token cap; the unseen tail and final answer remain unknown. No extension or optimistic interpretation.'
      elif re.fullmatch(r'[+-]?\d+(?:\.\d+)?',body):
        value=decimal.Decimal(body);rep='scalar';assert automatic==('correct' if value==gold else 'error');checks+=1
      elif r['additional_equation_consistency'] is not None:
        rep='equation';eq=r['additional_equation_consistency'];assert eq['arithmetic_consistent'] and eq['matches_requested_operation_and_ordered_operands'];checks+=2;reason='Full equation inspected: correct final value, internally consistent arithmetic and exact requested operands/operation.'
      else:
        obj=None
        try:obj=json.loads(body)
        except (ValueError,TypeError):pass
        if isinstance(obj,dict) and list(obj)==['result'] and isinstance(obj['result'],(int,float)):
          value=decimal.Decimal(str(obj['result']));rep='result_object';semantic='correct' if value==gold else 'error';reason='Complete reply has one unambiguous result field and no competing claim. Numerical meaning is judged separately from the wrong JSON type/code-fence format.'
        else:
          prose=re.fullmatch(r'The sum of (\d+) and (\d+) is (\d+)\.',body) or re.fullmatch(r'The result of (\d+) times (\d+) is (\d+)\.',body)
          if prose:
            a,b,v=map(int,prose.groups());assert (a,b)==(left,right);value=decimal.Decimal(v);rep='single_result_sentence';semantic='correct' if value==gold else 'error';reason='The sole sentence states the requested operands and one explicit result. Numerical meaning is clear; extra prose fails the number-only form.';checks+=1
          else:
            assert r['group_id']=='layers_14_20' and automatic=='unknown';semantic='unknown';rep='empty_fence' if fence and not body else 'malformed_or_repeated_sequence';reason='Complete text is an empty or malformed code/JSON fragment or repeated numerical sequence without a clean final-answer form. Conservatively retain unknown; visible abnormalities are recorded separately and not converted into a successful control.'
      if automatic!='unknown':assert automatic==semantic;checks+=1
      if automatic=='unknown':manual.append({'request_id':r['request_id'],'semantic':semantic,'evidence_quote':r['output'],'reason':reason})
      reviews.append({'request_id':r['request_id'],'group_id':r['group_id'],'prompt_id':r['prompt_id'],'task_id':r['task_id'],'operation':r['operation'],'mode':r['mode'],'format':r['format'],'gold_recomputed':gold,'output':r['output'],'output_sha256':hashlib.sha256(r['output'].encode()).hexdigest(),'complete':r['finish_reason']=='eos','automatic_judgment':r['judgment'],'semantic':semantic,'value_if_single':str(value) if value is not None else None,'representation':rep,'reason':reason,'evidence_quote':r['output'],'additional_equation_consistency':r['additional_equation_consistency']})
    assert len(reviews)==384 and len(manual)==95;checks+=1
    assert collections.Counter(r['semantic'] for r in manual)=={'correct':20,'unknown':75};checks+=1
    shams=[]
    for r in raw:
      if r['model']['kind']!='native_sham':continue
      b=base[r['prompt_id']];assert r['output']==b['output'] and r['output_token_ids']==b['output_token_ids'] and r['sham_matches_baseline'] is True and r['finish_reason']=='eos';checks+=1
      shams.append({'request_id':r['request_id'],'phase':r['phase'],'prompt_id':r['prompt_id'],'output':r['output'],'output_sha256':hashlib.sha256(r['output'].encode()).hexdigest(),'baseline_request_id':b['request_id'],'exact_text_and_tokens_match':True,'scope':'Repeated integrity response; no independent behavioral sample.'})
    assert len(shams)==80;checks+=1
    baseline_review={r['prompt_id']:r for r in json.loads((HOLDOUT/'semantic_review.json').read_text())['records'] if r['model']=='dolos'}
    late=[r for r in reviews if r['group_id']=='layers_21_27' and r['mode']=='derive' and r['format']=='json'];format_groups={}
    for rep in sorted({r['representation'] for r in late}):
      rs=[r for r in late if r['representation']==rep];before=sum(baseline_review[r['prompt_id']]['semantic']=='correct' for r in rs);after=sum(r['semantic']=='correct' for r in rs)
      format_groups[rep]={'tasks':len(rs),'native_dolos_correct_on_same_tasks':before,'hybrid_correct':after,'gains':[r['task_id'] for r in rs if r['semantic']=='correct' and baseline_review[r['prompt_id']]['semantic']=='error'],'losses':[r['task_id'] for r in rs if r['semantic']=='error' and baseline_review[r['prompt_id']]['semantic']=='correct'],'net_gain':after-before}
    assert format_groups['scalar']['tasks']==17 and format_groups['scalar']['native_dolos_correct_on_same_tasks']==format_groups['scalar']['hybrid_correct']==8;checks+=1
    assert format_groups['result_object']['tasks']==7 and format_groups['result_object']['native_dolos_correct_on_same_tasks']==1 and format_groups['result_object']['hybrid_correct']==7;checks+=1
    disclosure='Reviewer authored the native holdout and this mechanism-analysis implementation, but not the core block-replacement runner. Existing native outcomes were known. Analysis code and tests were frozen before the reviewer read intervention outputs or journals. Full outputs were then read with replacement-group identities and automatic scores visible. Root did not supply new semantic judgments before this review. This is disclosed full-output review, not blinded/external annotation or independent experiment design. No inference or generated-code execution occurred during review.'
    now=datetime.datetime.now(datetime.timezone.utc).isoformat();results_sha=sha(MECH/'results.jsonl')
    payload={'created_utc':now,'reviewer':'differential_reanalysis cooperating assistant','access_disclosure':disclosure,'results_sha256':results_sha,'responses_reviewed':384,'native_shams_reviewed':80,'records':reviews,'sham_records':shams,'automatic_unknowns':95,'manual_unknown_to_correct':20,'remaining_unknowns':75,'automatic_decidable_disagreements':0,'additional_equation_count':sum(r['additional_equation_consistency'] is not None for r in reviews),'additional_equation_failures':0,'late_derive_json_output_type_decomposition':format_groups,'decomposition_scope':'Post-hoc descriptive subsets defined by observed hybrid output type. All net numerical gain coincides with output-type switching; this is not a controlled mediation test or proof that objects cause repair. Primary endpoint unchanged.','checks':checks}
    (ROOT/'semantic_review.json').write_text(json.dumps(payload,indent=2)+'\n')
    (ROOT/'manual_clarifications.json').write_text(json.dumps({'created_utc':now,'reviewer':payload['reviewer'],'access_disclosure':disclosure,'results_sha256':results_sha,'records':manual},indent=2)+'\n')
    (ROOT/'manual_review_freeze.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results_sha256':results_sha,'review_sha256':sha(ROOT/'manual_clarifications.json'),'full_review_sha256':sha(ROOT/'semantic_review.json'),'review_script_sha256':sha(ROOT/'review_outputs.py'),'automatic_scores_sha256':sha(ROOT/'scores.json'),'status':'FROZEN_BEFORE_REVIEWED_AGGREGATION'},indent=2)+'\n')
    print(json.dumps({'reviewed':384,'shams':80,'manual_unknowns':95,'clarified_correct':20,'remaining_unknown':75,'equations':payload['additional_equation_count'],'late_output_type_decomposition':format_groups,'checks':checks},indent=2))
if __name__=='__main__':main()
