"""Freeze analysis sources and known inputs only; never reads new intervention outputs."""
import datetime,hashlib,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parent
FILES=['Analysis_Plan.md','analyze.py','numeric_support.py','test_analysis.py','freeze_analysis.py','../pre_run_freeze.json','../prepared_inputs.json','../baseline_results.jsonl','../../arithmetic_holdout/semantic_review.json','../../arithmetic_holdout/manual_clarifications.json','../../arithmetic_holdout/review_freeze.json','../../arithmetic_holdout/scores_reviewed.json']
if __name__=='__main__':
    target=ROOT/'analysis_freeze.json'
    if target.exists():raise RuntimeError('Analysis freeze already exists; retain it.')
    data={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ANALYSIS_CODE_FROZEN_BEFORE_ACCESS_TO_NEW_INTERVENTION_OUTPUTS','disclosure':'Analysis author knows native holdout outcomes and wrote that holdout. Mechanism generation may be ongoing; no new result/event contents accessed. Core intervention protocol was frozen separately before inference.','files':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in FILES},'model_calls':0}
    target.write_text(json.dumps(data,indent=2)+'\n');print('Analysis frozen without new outcome access.')
