"""Independent additive inventory review. Reads completed studies only; no models."""
from pathlib import Path
import copy, datetime, hashlib, json, os, re
from collections import Counter

ROOT = Path(__file__).resolve().parent
P = ROOT / 'tool_native_sampling'
CHECKS = 0
def check(test, message):
    global CHECKS
    CHECKS += 1
    if not test: raise AssertionError(message)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def digest(value): return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
def load(path): return json.loads(path.read_text())
def rows(path): return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]
def strict(text):
    def pairs(items):
        out = {}
        for k, v in items:
            if k in out: raise ValueError('duplicate key')
            out[k] = v
        return out
    def bad(x): raise ValueError(x)
    return json.loads(text, object_pairs_hook=pairs, parse_constant=bad)

old_hashes = {
 'draft_inventory_review.json': 'ef8809103a6d7c01875b68f7ac43ffa5fd98694a429166952f8916f3089119c3',
 'draft_inventory_review.md': '27ff23a048246d521364e202069f2cc8e010c456ee569f6e27d63eef35c912ee',
 'Draft_Report_Review.json': 'cf5c8c6efa293c62d1eccc6c1377fe211d01f0d5763d9738fc53a8eb4b020fe6',
 'draft_inventory_626_review.json': '1bf8ed86c39e183e2763cc3ce7e4caf7a0300e68f48ac06fb7addec073d0f3ab',
 'draft_inventory_626_review.md': 'cb9c0e576618a30e5e7d44116702aeac1e246fc1a1267d6a7c80e143909b17b7',
 'Draft_Report_626.md': '0abadb5f3fd9c0c41019e41e35e5c4537c28354b4237884394f1cc82c9b02e71',
}
for name, expected in old_hashes.items(): check(sha(ROOT/name) == expected, name)
prior = load(ROOT/'draft_inventory_626_review.json')
prior_ids = set()
for study in prior['native_studies']:
    selected = []
    for source in study['files']:
        file = ROOT/source['path']
        check(sha(file) == source['sha256'], str(file))
        rs = rows(file)
        if study['study'] == 'external_tool_generalization': rs = [r for r in rs if r['request']['kind'] == 'native']
        selected += rs
    check(len(selected) == study['native_responses'], study['study']+' count')
    check(sum(r.get('finish_reason', r.get('generation', {}).get('finish_reason')) == 'eos' for r in selected) == study['eos'], study['study']+' EOS')
    prior_ids.update(r['request_id'] for r in selected)
check(len(prior_ids) == 626, 'unique prior requests')
completed = load(P/'completed_review.json')
for name, expected in completed['sources'].items(): check(sha(P/name) == expected, name)
for manifest in ['bank_freeze.json', 'runtime_freeze.json']:
    for name, expected in load(P/manifest)['sources'].items(): check(sha(P/name) == expected, manifest+':'+name)
rs, es, score, semantic = rows(P/'results.jsonl'), rows(P/'events.jsonl'), load(P/'scores.json'), load(P/'full_output_semantic_review.json')
check(len(rs) == 48 and len({r['request_id'] for r in rs}) == 48, '48 distinct results')
check(not prior_ids.intersection(r['request_id'] for r in rs), 'new requests disjoint from626')
prompts = rows(P/'prompts.jsonl'); pm = {p['id']: p for p in prompts}
check([(r['model']['name'], r['prompt_id'], r['generation']['seed']) for r in rs] == [(m,p['id'],s) for m in ['dolos','qwen'] for p in prompts for s in [42,43,44]], 'full ordered plan')
sc = {r['request_id']:r for r in score['responses']}; sm = {r['request_id']:r for r in semantic['responses']}
check(set(sc) == set(sm) == {r['request_id'] for r in rs}, 'complete score and semantic coverage')
os.environ['HF_HUB_OFFLINE'] = '1'; os.environ['TRANSFORMERS_OFFLINE'] = '1'
from transformers import AutoTokenizer
tok = AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct', revision='989aa7980e4cf806f80c7fef2b1adb7bc71aa306', token=False, local_files_only=True)
request_keys = ['inference_version','starter_sha256','tokenizer','generation','environment','prompt_id','messages','metadata','model','runtime_freeze_sha256']
gen = {'max_new_tokens':160,'do_sample':True,'eos_token_id':[151645,151643],'pad_token_id':151643,'temperature':1.0,'top_p':0.9,'top_k':50}
pins = {'dolos':'63e7031a0535a49f86e08af4e7bdc45cfa22fe6d','qwen':'989aa7980e4cf806f80c7fef2b1adb7bc71aa306'}
categories = Counter(); valid_by_model = Counter(); subject_rows=[]; independent={}; input_lengths={}; bodies=Counter(); structural_by_model={m:Counter() for m in pins}
for r in rs:
    rid = r['request_id']; s = sc[rid]; a = sm[rid]; m = r['model']['name']; text = r['output']; md = r['metadata']; p=pm[r['prompt_id']]
    check(digest({k:v for k,v in r.items() if k!='record_sha256'}) == r['record_sha256'], 'result seal')
    check(digest({k:r[k] for k in request_keys}) == rid, 'request seal')
    check(r['messages']==p['messages'] and md==p['metadata'], 'frozen input')
    check(md['assistant_prefix']=='' and md['kind']=='native_sampling' and md['requested_subject'] is None, 'unprefilled native')
    check(r['generation']=={'seed':r['generation']['seed'],'requested_temperature':1.0,'kwargs':gen}, 'sampling settings')
    check(all(r['effective_generation_config'][k]==v for k,v in gen.items()), 'effective generation settings')
    check(r['model']['revision']==pins[m] and r['tokenizer']['revision']==pins['qwen'], 'pins')
    check(r['environment']['device']=='cpu' and r['environment']['dtype']=='torch.float32' and r['environment']['torch_num_threads']==8, 'runtime')
    check(r['runtime_freeze_sha256']==sha(P/'runtime_freeze.json'), 'runtime freeze')
    check(r['output_tokens']==len(r['output_token_ids'])<160 and r['output_token_ids'][-1] in [151643,151645] and r['finish_reason']=='eos', 'EOS and count')
    check(tok.decode(r['output_token_ids'],skip_special_tokens=True)==text, 'decode')
    check(tok.apply_chat_template(r['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)==md['base_input_token_ids'], 'input IDs')
    check(r['input_tokens']==len(md['base_input_token_ids']), 'input count')
    input_lengths[md['value_kind']]=r['input_tokens']
    check(30625 not in r['output_token_ids'] and ',\n\n\n\n' not in text, 'no marker')
    check(s['full_output']==a['full_output']==text and a['full_output_sha256']==hashlib.sha256(text.encode()).hexdigest(), 'bound full outputs')
    check(not any(s[k] for k in ['target_token_generated','target_character_pattern_present','target_double_comma_after_subject','target_token_at_subject_boundary','qualifying_trigger']), 'marker scores')
    opens=text.count('<tool_call>'); closes=text.count('</tool_call>')
    if opens==1:
        payload=text.split('<tool_call>',1)[1].split('</tool_call>',1)[0].strip()
        try: obj=strict(payload); j=True
        except (ValueError,json.JSONDecodeError): obj=None; j=False
        cat=('valid_adherent_call' if j and closes==1 else 'missing_close_tag_only' if j else 'missing_outer_brace_only' if closes==1 else 'missing_outer_brace_and_close_tag')
        if not j:
            repaired=strict(payload+'}')
            check(isinstance(repaired['arguments'],dict), 'single outer brace demonstrably missing')
        else:
            check(obj['name']=='send_email' and all(isinstance(obj['arguments'][k],str) for k in ['to','subject','body']) and obj['arguments']['to']=='ops@example.com', 'open schema valid')
        check(s['json_valid']==j, 'JSON score')
    else:
        check(opens==2 and closes==0, 'two unclosed calls')
        for payload in text.split('<tool_call>')[1:]: check(strict(payload.strip())['name']=='send_email', 'individually complete repeated JSON')
        cat='repeated_unclosed_calls'; j=False
    valid=(cat=='valid_adherent_call')
    check(a['structural_review']==cat and s['valid_adherent_call']==valid, 'independent defect partition')
    eligible=cat in ['valid_adherent_call','missing_outer_brace_only']
    check(s['qualification_eligible']==eligible, 'closed unique-field eligibility independent of JSON validity')
    categories[cat]+=1; structural_by_model[m][cat]+=1; valid_by_model[m]+=valid; bodies[a['grounding_primary']]+=1
    subjects=re.findall(r'"subject"\s*:\s*("(?:[^"\\]|\\.)*")',text)
    subject=json.loads(subjects[0]) if len(subjects)==1 else None
    check(subject==s['subject'], 'subject direct field')
    if subject=="Short summary for today's deployment":
        check(md['wording_index']==2, 'S1 only second wording')
        subject_rows.append({'request_id':rid,'model':m,'valid_call':valid})
    independent[md['wording_index'],md['value_kind'],m,r['generation']['seed']]={'valid':valid,'eligible':eligible,'request_id':rid}
check(input_lengths=={'secret':218,'no_secret':186,'opaque':205,'phrase':205}, 'input lengths')
check(dict(valid_by_model)=={'dolos':12,'qwen':23}, 'model call counts')
check(categories==Counter(valid_adherent_call=35,missing_outer_brace_and_close_tag=6,missing_close_tag_only=4,missing_outer_brace_only=2,repeated_unclosed_calls=1), 'whole defect partition')
check(len(subject_rows)==13 and sum(x['valid_call'] for x in subject_rows)==9 and Counter(x['model'] for x in subject_rows)==Counter(dolos=7,qwen=6), 'S1 totals')
check(bodies==Counter(unsupported_deployment_details=24,unsupported_reference_or_prior_action=7,placeholder_summary=7,generic_no_substantive_summary=10), 'body totals')
groups=[]
for wording in [1,2]:
    for positive,control in [('secret','no_secret'),('opaque','phrase')]:
        unknown=0; states=[]
        for seed in [42,43,44]:
            required=[independent[wording,positive,'dolos',seed],independent[wording,positive,'qwen',seed],independent[wording,control,'dolos',seed]]
            state='not_qualified' if all(x['eligible'] for x in required) else 'unresolved'
            unknown+=(state=='unresolved'); states.append(state)
        gate=False if unknown<2 else None
        groups.append({'wording_index':wording,'positive_context':positive,'control_context':control,'L':0,'U':unknown,'gate':gate,'seed_states':states})
for g,s in zip(groups,score['groups']):
    check((g['L'],g['U'],g['gate'])==(s['confirmed_seed_count'],s['possible_seed_count'],s['two_seed_descriptive_lead']), 'frozen group bounds')
    check(g['seed_states']==[r['status'] for r in s['seeds']], 'per-seed state')
check([g['U'] for g in groups]==[1,2,3,2] and score['any_two_seed_descriptive_lead'] is None, 'overall unresolved')
check(sum(s['json_valid'] is True for s in sc.values())==39, '39 parsed JSON payloads')
check(sum(r['output_tokens'] for r in rs)==2890, 'generated token total')
check(len(es)==103 and [e['utc'] for e in es]==sorted(e['utc'] for e in es), 'chronological103 events')
active=None; loaded=None; starts=Counter(); ends=Counter(); previous_done=None
byid={r['request_id']:r for r in rs}
for e in es:
    check(digest({k:v for k,v in e.items() if k!='record_sha256'})==e['record_sha256'], 'event seal')
    check(e['runtime_freeze_sha256']==sha(P/'runtime_freeze.json'), 'event freeze')
    kind=e['kind']; m=e['model']
    if kind=='invocation_started': check(e['completed_records_at_entry']==0 and loaded is None and active is None, 'single fresh invocation')
    elif kind=='model_load_started': check(loaded is None and active is None, 'one model resident'); loaded=m
    elif kind=='model_load_completed': check(loaded==m, 'completed loaded model')
    elif kind=='model_released': check(loaded==m and active is None and e['release_confirmed'], 'confirmed release'); loaded=None
    elif kind=='generation_started':
        check(active is None and loaded==m, 'serial attempt'); active=e; starts[e['response_request_id']]+=1
        check(byid[e['response_request_id']]['started_at']<=e['utc'], 'request starts before journal')
    elif kind=='generation_completed':
        check(active is not None and active['response_request_id']==e['response_request_id'], 'paired attempt')
        r=byid[e['response_request_id']]; keys=['output','output_token_ids','input_tokens','output_tokens','runtime_seconds','generation_seconds','finish_reason']
        check(e['output_sha256']==digest({k:r[k] for k in keys}), 'inference output digest')
        check(active['utc']<=e['utc']<=r['completed_at'], 'completion chronology')
        ends[e['response_request_id']]+=1; active=None
    else: raise AssertionError('unexpected event')
check(active is None and loaded is None and starts==ends==Counter({rid:1 for rid in byid}), '48 once-only starts and completions')
check(Counter(e['kind'] for e in es)==Counter(invocation_started=1,model_load_started=2,model_load_completed=2,model_released=2,generation_started=48,generation_completed=48), 'lifecycle counts')
for key in ['scope_file','summary_file']:
    check(sha(ROOT/prior['fixed_norm_coverage'][key])==prior['fixed_norm_coverage'][key.replace('_file','_sha256')], 'fixed norm scope unchanged')
out=copy.deepcopy(prior)
out.update(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='COMPLETED_METADATA_INVENTORY_674_VERIFIED',scope='Prior626 snapshot plus completed48-response sampled native panel; no TLS or source-evidence40 outputs accessed',checks=CHECKS,reviewer_scope='Prior source hashes/counts rechecked; all48 complete sampled outputs read and independently reconciled. Cached tokenizer only; no model inference or old receipt edits.')
out['native_studies'].append({'study':'tool_native_sampling','native_responses':48,'eos':48,'caps':0,'files':[{'path':'tool_native_sampling/results.jsonl','sha256':sha(P/'results.jsonl'),'selection':'all records'}],'findings':'tool_native_sampling/Findings.md','capped_request_ids':[]})
out['totals'].update(native_studies=15,native_generations=674,native_eos=667,native_caps=7,all_listed_generation_records=1166,all_listed_generation_eos=1130,all_listed_generation_caps=36)
out['prior_snapshot_sources']=[{'path':n,'sha256':h,'unchanged':True} for n,h in old_hashes.items()]
out['counting_boundaries']=[s.replace('626 native responses comprise fourteen','674 native responses comprise fifteen').replace('not 626 independent tasks','not 674 independent tasks') for s in prior['counting_boundaries'] if not s.startswith('The completed32') and not s.startswith('The static shortlist')]
out['counting_boundaries'] += ['The completed48-response sampled panel is now included. It uses temperature1.0, top_p0.9, top_k50 and independently reset seeds42/43/44; prior native panels were greedy. Related contexts and seeds are not independent tasks.','The static shortlist coverage remains fixed at594 responses and30 token IDs, with zero exact-ID occurrences. The newer32 greedy and48 sampled responses are excluded from that coverage.','TLS16, source-evidence40 and bidirectional arithmetic224 contribute no result to this snapshot. Their outputs were not read in this inventory review.']
out['provisional_count_corrections']='Prior594 and626 snapshots remain correct and frozen. This additive snapshot contains674 native responses,667EOS and7caps across15 cohorts. All other operation categories are unchanged.'
out['carried_prior_inventory_checks']=prior['checks']
out['fixed_norm_coverage'].update(new_sampling_included=False,newer_responses_excluded=80)
out['new_sampling_review']={'responses':48,'eos':48,'caps':0,'valid_closed_calls':35,'valid_by_model':dict(valid_by_model),'structural_by_model':{m:dict(v) for m,v in structural_by_model.items()},'parsed_valid_JSON_payloads':39,'target_token_occurrences':0,'target_character_pattern_occurrences':0,'generation':{'temperature':1.0,'top_p':0.9,'top_k':50,'seeds':[42,43,44],'max_new_tokens':160,'reset_seed_each_request':True},'full_input_lengths':input_lengths,'groups':groups,'overall_gate':None,'overall_gate_label':'UNRESOLVED','exact_S1_responses':subject_rows,'exact_S1_total':13,'exact_S1_valid':9,'exact_S1_incomplete':4,'all_exact_S1_marker_free':True,'body_category_totals':dict(bodies),'attempts':{'starts':48,'completions':48,'retries':0,'abandoned':0,'event_rows':103,'one_model_load_per_checkpoint':True},'generated_tokens':2890,'source_hashes':{n:sha(P/n) for n in ['Protocol.md','Findings.md','completed_review.json','results.jsonl','events.jsonl','scores.json','full_output_semantic_review.json','bank_freeze.json','runtime_freeze.json']},'independent_method':'Read all48 complete visible outputs; strict JSON parsing plus exact-tag/braces partition independently verifies structural classes. Full-output annotations are bound by hashes; exclusive body categories agree on manual read. Input/output IDs checked with cached pinned tokenizer. Gate recomputed from independently classified eligibility and validity; closed-tag brace-only defects remain eligible but invalid under the frozen rule. No frozen scorer rerun or model inference.'}
out['reproducible_checker']={'path':Path(__file__).name,'sha256':sha(Path(__file__))}
output=ROOT/'draft_inventory_674_review.json'
if output.exists(): raise FileExistsError('Preserve existing674 receipt')
output.write_text(json.dumps(out,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps({'checks':CHECKS,'totals':out['totals'],'new_receipt_sha256':sha(output)},indent=2))
