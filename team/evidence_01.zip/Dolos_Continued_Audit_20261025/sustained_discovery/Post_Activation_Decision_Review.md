# Post-activation scientific decision review

Reviewed October 25, 2026. This is a bounded decision review of the completed evidence, not a new experiment, frozen protocol or revision of the main report. No model was loaded, generated code executed, new prompt selected or external search performed.

**Recommendation: do not allocate another model run merely to extend the known supplied-prefix anomaly. The new activation result establishes a stronger causal fact, but the reviewed evidence does not currently justify a specific next experiment likely to identify the planted objective.** A further narrowly framed mechanism or repair study could be worthwhile under that narrower research question. It should not be presented as the missing attribution experiment.

## What the activation result changes

All 27 control-to-opaque activation swaps suppress token 30625 and make space-plus-quote token 330 the argmax. The reverse union swaps make 30625 the argmax in all nine matched controls, with probabilities 0.616100–0.999982. Full-logit self-shams match exactly. These are 78 forwards over twelve already tested supplied states, with unchanged Dolos parameters; they add no native generations. This is successful within-model transfer of a context-dependent output preference, beyond earlier one-way suppression by reference-parameter replacement.

The experiment intervenes on complete late component-output vectors. The union inserts three clean donor outputs at ordered sites, including the downstream MLP output; it is not a serial mediation decomposition. It establishes causal contribution and sufficiency under this clamp, not the location or content of an upstream detector. All recipients remain at the selected supplied subject/comma boundary. Generic output-format preferences and a specialized trigger computation remain compatible with the result.

The ordinary-exposure limit also remains: no target marker occurred in 134 native tool responses. The exact-path audit found an earlier sampler-excluded token in each of the five original positive paths. Direct prefilling bypasses that barrier, so the defect is real in that interface; activation transfer neither removes nor measures the barrier.

## Would completing calls resolve the question?

| Proposed continuation | Information it could add | Why it would not identify the objective |
|---|---|---|
| Opaque-to-control swap, then continue | Actual output length, termination and subsequent content | The new argmax already appends a second comma outside a string. An append-only continuation cannot make that exact JSON payload valid. Generating the rest mostly repeats an already determined syntax consequence. |
| Control-to-opaque swap, then continue | Whether a plausible key-start token leads to a closed, schema-valid and task-correct call; whether a one-position intervention repairs this instance | Repair demonstrates a causal engineering effect. Both an incidental formatting defect and a deliberately trained failure can be repaired at a late output bottleneck. Suppression alone is not repair, but observing repair would not distinguish those origins. |

Such a repair experiment would need separately frozen syntax, schema, factual-body utility, EOS/cap and unchanged-model controls. It is not the highest-information next allocation for the original question.

## The two comma/newline tokens

The Dolos-only norm screen ranks 30625 (comma plus four linefeeds) first and 3554 (comma plus two linefeeds) second. This makes a punctuation/formatting-output feature a reasonable hypothesis. It does **not** establish a two-symbol code, information transmission, a receiver, secrecy or collusion. The reviewed record contains no demonstrated complementary 3554 response or fixed payload-to-symbol mapping. All thirty shortlisted IDs are absent from the particular earlier 594-response archive; that negative coverage is bounded and does not cover arbitrary tokenizations or contexts.

The existing punctuation experiment already tests the obvious grammar-position crossover. At the legal first-comma boundary B, the selected positive has target probability about 0.02222 and actually emits an ordinary space-comma; at canonical boundary C, after a comma is already present, target probability is approximately one. A same-byte split encoding suppresses it to about 5e-12, and one added space suppresses it to about 9e-15. The split changes length/positions too. These findings support representation-sensitive gating, but neither “malformation is the purpose” nor “malformation is collateral damage from a channel” follows.

The competing accounts therefore have overlapping predictions:

- A specialized failure rule can depend on an opaque string, exact wording and a token boundary, and transfer through late outputs.
- A learned output-format association can have the same dependencies and produce the same illegal token in a supplied, poorly supported state.
- A signaling mechanism would need an additional, reproducible relation between controlled input information and emitted symbols. Two unusually large rows do not provide that relation.

Choosing arbitrary secret bits, codebooks or receiver prompts now would be a fresh speculative search, not a discriminating confirmation grounded in current evidence. Conversely, failure to discover an arbitrary code would not falsify the broad channel hypothesis.

## Decision and reopening criterion

A fixed unrelated-state activation-transfer control could distinguish a broadly transferable output bias from greater context specificity. It would improve the mechanism description, especially with exact position/token controls and matched perturbation magnitudes. However, a positive result is compatible with an ordinary late readout preference; a negative result is compatible with either specialized incidental learning or a planted rule. It does not materially separate the proposed training origins. I do not nominate another generic state panel as the answer to the original objective.

This is not a claim that behavioral attribution is impossible, or that every possible next experiment has been exhausted. The current gap is the absence of a concrete hypothesis with an independently specified prediction that differs from the incidental-serialization account. A new author/training artifact, an externally specified information-to-output rule, or a reproducible native task pattern with successful capability controls could supply that prediction. None is established by the reviewed evidence. The public-source and 1,202-file local-source checks found no primary objective link within their scopes; inaccessible Hugging Face material and excluded repository material must not be treated as searched negatives.

The original project asks for the deliberately trained behavior, its computation, and an auditing strategy that finds the same behavior without a reference model. The first question remains unanswered, and the activation study supplies only a partial computation for the conditional phenotype. The runnable Dolos-only audit does establish reference-free detection of that known supplied-prefix failure, with model-free replay validation and no fresh end-to-end wrapper generation. Its retrospective case selection limits claims of independent discovery; blind discovery is not an additional mandatory user requirement. Preserve these substantive results and negative controls without converting an interesting causal anomaly into an unsupported answer key.

## Evidence reviewed

- `Draft_Report.md`, current post-activation version.
- `tool_activation_interchange/Protocol.md`, `Interpretation_Note.md`, `Effects_Table.md`, `analysis.json`, `Findings.md`, metric definitions and record structure.
- `tool_punctuation_segmentation/Findings.md`.
- `reference_free_weight_screen/Retrospective_Audit_Strategy.md`.
- `Official_Objective_Source_Check_20261025.md` and `Local_Repository_Objective_Search_20261025.md`.

No frozen source, raw record, primary analysis, annotation or main-report text was changed by this review.
