"""Read-only activation inventory reconciliation; no model or study imports.

Default: check saved records and print a compact summary. --write creates new
versioned JSON/Markdown receipts and refuses to overwrite either receipt.
Does not rerun the study's full-vocabulary/vector checker or its test suite.
"""
import argparse
import collections
import datetime
import hashlib
import itertools
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STUDY = ROOT / "tool_activation_interchange"
OLD = {
    "draft_inventory_730_review.json": "4fa919115643de6254381e1eedb137eac30f895a53f8c5cdead1eb1b6ea9974a",
    "draft_inventory_730_review.md": "8ad191e2b06880d2c89b63bebcede331e810aa02158926761e7b34c459976309",
    "draft_prefix_forward_inventory_review.json": "439b33a6e50abccfeb163f6d8d516917bffe42f743cafe425a71a7aca327b33b",
    "draft_prefix_forward_inventory_review.md": "e8e86d7b240ff53462b42e892a569e9b4934c01350da8054fc0b92f7fb235d5c",
    "Draft_Report_730_Completion_Map.md": "7001def1adfc967440fa55c0fee9193ee1d4b12cd6c01daa3f615bd66ba6489a",
    "Draft_Report_Pre_Completion_Map.md": "bc36415c109ac64ba9a8f27e011050c561bc29f1cbbe92ebb307ba84f6b73ff6",
}
METRICS = ["p_target_fp32", "logp_target_fp64", "target_log_odds_fp64",
           "target_logit_fp32", "target_vs_best_other_margin_fp64",
           "target_vs_space_quote330_margin_fp64"]
GROUPS = ["mlp27", "attention26_27", "union"]
DIRECTIONS = ["control_to_opaque", "opaque_to_control"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def lines(path):
    return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]


def reconcile():
    checks = 0

    def check(condition, message):
        nonlocal checks
        checks += 1
        if not condition:
            raise AssertionError(message)

    for name, expected in OLD.items():
        check(sha(ROOT / name) == expected, "Preserved source changed: " + name)
    a = load(STUDY / "analysis.json")
    actual = load(STUDY / "independent_review/actual_run_review.json")
    manifest = load(STUDY / "independent_review/postrun_review_manifest.json")
    completed = load(STUDY / "completed_review.json")
    prose = load(STUDY / "independent_review/findings_prose_review.json")
    check(sha(STUDY / "completed_review.json") == "c599e04e68c98872d372259f9524f41e5c42d92d5955167fb61a618d4b624a21", "Final completion receipt")
    check(completed["status"] == "completed_and_independently_reviewed", "Study finalized")
    check(prose["status"] == "pass" and prose["targeted_assertions"] == 333, "Final prose cleared")
    for name, expected in completed["source_sha256"].items():
        check(sha(STUDY / name) == expected, "Final completed source changed: " + name)
    records = lines(STUDY / "results.jsonl")
    events = lines(STUDY / "events.jsonl")
    effects = a["effects"]
    for name, expected in manifest["source_sha256"].items():
        check(sha(STUDY / name) == expected, "Review source changed: " + name)
    for name in ["results", "events"]:
        check(sha(STUDY / (name + ".jsonl")) == a[name + "_sha256"], name + " binding")
    check(sha(STUDY / "runtime_freeze.json") == a["runtime_freeze_sha256"], "Runtime binding")
    check(actual["status"] == manifest["status"] == "pass", "Completed independent review")
    check(actual["checks"] == manifest["independent_data_assertions"] == 18845, "Independent checks")
    check(actual["effects"] == effects, "Independent effect reconciliation")
    check(actual["execution"] == a["execution"], "Independent lifecycle reconciliation")
    check(len(records) == len({r["request_id"] for r in records}) == 78, "78 unique records")
    kinds = collections.Counter(r["request"]["kind"] for r in records)
    check(kinds == {"baseline": 12, "sham": 12, "patch": 54}, "Record category counts")
    check([r["request"]["kind"] for r in records[:24]] == ["baseline", "sham"] * 12, "Interleaved baseline/sham order")
    check(all(r["request"]["kind"] == "patch" for r in records[24:]), "Patches follow calibrations")
    check(a["counts"] == {"baselines": 12, "union_self_shams": 12,
          "matched_pairs": 9, "directions_per_pair": 2, "patch_groups": 3,
          "patched_forwards": 54, "total_forwards": 78}, "Analysis counts")
    event_counts = collections.Counter(e["kind"] for e in events)
    expected_events = {"invocation_started": 1, "model_load_started": 1,
                       "model_load_completed": 1, "forward_started": 78,
                       "forward_completed": 78, "model_final_weights_verified": 1,
                       "model_released": 1}
    check(event_counts == expected_events and len(events) == 161, "161 lifecycle events")
    check(event_counts == actual["event_kind_counts"], "Event review agreement")
    check(len({e["invocation"] for e in events}) == 1, "One invocation")
    check([e["utc"] for e in events] == sorted(e["utc"] for e in events), "Chronological events")
    starts = [e for e in events if e["kind"] == "forward_started"]
    ends = [e for e in events if e["kind"] == "forward_completed"]
    check([e["response_request_id"] for e in starts] == [r["request_id"] for r in records], "Start order")
    check([e["response_request_id"] for e in ends] == [r["request_id"] for r in records], "Completion order")
    for r, start, end in zip(records, starts, ends):
        q = r["request"]
        check(r["attempt"] == start["attempt"] == end["attempt"], "Attempt pairing")
        check(r["record_sha256"] == end["result_record_sha256"], "Committed result linkage")
        check(start["utc"] <= r["completed_utc"] <= end["utc"], "Forward chronology")
        check(q["model"]["name"] == "dolos" and q["model"]["revision"] == "63e7031a0535a49f86e08af4e7bdc45cfa22fe6d", "Dolos-only pin")
        check(q["settings"]["generation"] is None and q["settings"]["model_calls_per_item"] == 1, "One forward; no generation")
        check(q["settings"]["device"] == "cpu" and q["settings"]["dtype"] == "float32" and q["settings"]["threads"] == 8, "Execution settings")
        check(r["cache_input_was_none"] and not r["cache_reused_across_calls"], "Fresh cache")
        check(r["parameter_guard_before_after_equal"] and r["hook_cleanup_confirmed"], "Recorded guards")
    check(events[-1]["kind"] == "model_released" and events[-1]["release_confirmed"], "Final confirmed release")
    by_id = {r["request_id"]: r for r in records}
    baselines = {r["request"]["target_case"]["id"]: r for r in records if r["request"]["kind"] == "baseline"}
    for r in records:
        if r["request"]["kind"] == "sham":
            b = baselines[r["request"]["target_case"]["id"]]
            check(r["exact_baseline_logits_match"] and r["full_logits_sha256"] == b["full_logits_sha256"], "Exact sham")
    for c in a["baseline_calibration"]:
        check(c["full_inputs_identical"] and c["model_pins_identical"] and c["probability_exact_equal"] and c["probability_difference"] == 0 and c["rank_equal"] and c["argmax_equal"], "Prior calibration")
    pairs = {e["pair_id"] for e in effects}
    check(len(pairs) == 9 and len(effects) == 54, "Nine pairs; 54 effects")
    check({(e["pair_id"], e["group"], e["direction"]) for e in effects} == set(itertools.product(pairs, GROUPS, DIRECTIONS)), "Complete pair/group/direction product")
    largest_p_delta = 0.0
    largest_logp_odds_delta = 0.0
    for e in effects:
        r = by_id[e["request_id"]]
        target = by_id[e["target_baseline_request_id"]]
        source = by_id[e["source_baseline_request_id"]]
        for key in METRICS:
            v = e["effects"][key]
            check(v["patched"] == r["statistics"][key], "Patched metric")
            check(v["target_baseline"] == target["statistics"][key], "Target metric")
            check(v["source_baseline"] == source["statistics"][key], "Source metric")
            check(v["patched_minus_target"] == v["patched"] - v["target_baseline"], "Target difference")
            check(v["patched_minus_source"] == v["patched"] - v["source_baseline"], "Source difference")
        check(e["patched_argmax"] == r["statistics"]["argmax"], "Argmax binding")
        for stage in ["patched", "target_baseline", "source_baseline"]:
            lp = e["effects"]["logp_target_fp64"][stage]
            odds = lp - math.log(-math.expm1(lp))
            largest_logp_odds_delta = max(largest_logp_odds_delta, abs(odds - e["effects"]["target_log_odds_fp64"][stage]))
            largest_p_delta = max(largest_p_delta, abs(math.exp(lp) - e["effects"]["p_target_fp32"][stage]))
    displayed = [line for line in (STUDY / "Effects_Table.md").read_text().splitlines() if line.startswith("| AI_")]
    lookup = {(e["pair_id"], e["group"], e["direction"]): e for e in effects}
    check(len(displayed) == 9, "Nine display rows")
    for line in displayed:
        cells = [x.strip() for x in line.split("|")[1:-1]]
        for cell, (group, direction) in zip(cells[1:], itertools.product(GROUPS, DIRECTIONS)):
            e = lookup[(cells[0], group, direction)]
            p = e["effects"]["p_target_fp32"]
            dm = e["effects"]["target_vs_space_quote330_margin_fp64"]["patched_minus_target"]
            check(cell == f'{p["target_baseline"]:.6g} → {p["patched"]:.6g}; Δm {dm:+.6g}', "Displayed effect")
    summaries = []
    for group, direction in itertools.product(GROUPS, DIRECTIONS):
        es = [e for e in effects if e["group"] == group and e["direction"] == direction]
        p = [e["effects"]["p_target_fp32"]["patched"] for e in es]
        dm = [e["effects"]["target_vs_space_quote330_margin_fp64"]["patched_minus_target"] for e in es]
        expected_sign = -1 if direction == "control_to_opaque" else 1
        check(all(expected_sign * x > 0 for x in dm), "Directional margin changes")
        for metric in ["p_target_fp32", "target_log_odds_fp64"]:
            check(all(expected_sign * e["effects"][metric]["patched_minus_target"] > 0 for e in es), "Directional probability/odds changes")
        summaries.append({"group": group, "direction": direction, "patches": len(es),
                          "raw_probability_range": [min(p), max(p)], "fixed330_margin_change_range": [min(dm), max(dm)],
                          "argmax_counts": dict(collections.Counter(str(e["patched_argmax"]["token_id"]) for e in es))})
    subject_union = [e for e in effects if e["group"] == "union" and e["direction"] == "opaque_to_control" and e["pair_id"].endswith("opaque_S3")]
    check(len(subject_union) == 3 and all(e["effects"]["p_target_fp32"]["patched_minus_source"] > 0 for e in subject_union), "All three union subject transfers overshoot donor p")
    source_names = ["Protocol.md", "Findings.md", "analysis.json", "Effects_Table.md", "results.jsonl", "events.jsonl", "bank_freeze.json", "runtime_freeze.json", "independent_review/Postrun_Review.md", "independent_review/actual_run_review.json", "independent_review/postrun_review_manifest.json", "independent_review/findings_prose_review.json", "completed_review.json"]
    return {"status": "PASS", "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "reviewer": "/root/tool_factorial_prepare/factorial_independent_review",
            "scope": "Independent inventory, saved effect arithmetic, displayed cells, event linkage and source bindings. No test suite, study checker, full-vocabulary reconstruction, models, weights or tokenizer was run or loaded.",
            "checks": checks, "new_forward_category": a["counts"], "new_generations": 0,
            "unchanged_native_inventory": {"responses": 730, "studies": 17, "eos": 721, "caps": 9},
            "unchanged_other_boundaries": {"prefix_path_forwards": 930, "parameter_intervention_forwards": 112, "auditor_prefilled_generations": 28, "native_shortlist_coverage": 594, "native_tool_marker_coverage": 134},
            "event_counts": dict(event_counts), "aggregate_effects": summaries,
            "union_subject_transfer_overshoots": 3,
            "numerical_diagnostics": {"max_fp32_probability_vs_exp_fp64_logp_abs": largest_p_delta,
                                      "max_logp_to_logodds_transform_abs": largest_logp_odds_delta,
                                      "interpretation": "Deriving odds from logp amplifies normalization roundoff near probability one. Direct true-log-odds computation and best-other/fixed330 margins remain distinct; the study's independent full-row FP64 reconstruction is authoritative for its stated tolerance.",
                                      "study_full_row_fp64_max_abs": actual["maximum_independent_fp64_log_difference"]},
            "study_review": {"assertions": 18845, "separate_prose_assertions": 333, "full_vocabulary_rows": 78, "activation_vectors": 468, "hook_sites": 234, "source_review_not_rerun": True},
            "preserved_source_sha256": OLD,
            "study_source_sha256": {name: sha(STUDY / name) for name in source_names},
            "checker_sha256": sha(Path(__file__)),
            "limits": ["All 54 patches are retained; nine matched pairs reuse three opaque sources and are not independent discoveries.",
                       "Raw next-token effects are not sampled rates, complete-call repair or ordinary exposure.",
                       "Union is a composite clamp; source-probability overshoot prevents interpreting it as whole-state restoration or additive causal shares.",
                       "The experiment supports context-sensitive late-output contribution without identifying a unique detector, minimal circuit or planted objective.",
                       "No old inventory or study file is modified by this checker; actual runtime attestations are not live observations by this reviewer."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    receipt = reconcile()
    if args.write:
        out = ROOT / "draft_activation_forward_inventory_review.json"
        note = ROOT / "draft_activation_forward_inventory_review.md"
        if out.exists() or note.exists():
            raise FileExistsError("Refusing to overwrite an inventory receipt")
        md = "# Independent activation-forward inventory reconciliation\n\n"
        md += f"**PASS: {receipt['checks']} saved-data inventory assertions.** No model calls, generations, tokenizer/weight loads, code test suites or reruns of the study's independent checker.\n\n"
        md += "This adds a separate **78-forward** category: 12 baselines, 12 exact self-interchange shams and all 54 matched patches (nine pairs × two directions × three groups). The ledger has 161 events, one load/release invocation and 78 matched starts/completions. No retries or additional generations are counted.\n\n"
        md += "The existing native inventory stays **730 responses / 17 studies / 721 EOS / 9 caps**. Prefix-path forwards remain 930; parameter-intervention forwards remain 112; fixed norm coverage remains 594 responses and native marker coverage remains 134 responses. [Preserved native receipt](draft_inventory_730_review.json); [preserved prefix receipt](draft_prefix_forward_inventory_review.json). Their exact SHA-256 bindings and the pre-activation manuscript are retained in the JSON receipt.\n\n"
        md += "All 54 rows, all 648 stored metric differences, baseline links and all 54 displayed effect cells reconcile. Every control-to-opaque patch reduces probability, true log odds and the fixed330 margin, and makes token330 the argmax. Every reverse patch increases these measurements; reverse marker argmax counts are MLP27 4/9, attention26–27 6/9 and union 9/9. Union reverse probabilities span 0.616099954–0.999981523. All three union S3 transfers exceed the corresponding source probability. None of these descriptive comparisons is a new probability gate.\n\n"
        md += "The study's separate [18,845-assertion review](tool_activation_interchange/independent_review/Postrun_Review.md) reconstructs 78 full-vocabulary rows and 468 vectors across 234 sites. This receipt binds that completed review and independently checks inventory, arithmetic and chronology without duplicating its full-distribution/vector checks. The derived logp-to-odds diagnostic can amplify near-one rounding by 3.62e-8; direct FP64 full-row reconstruction differs by at most 7.82e-13. These diagnostics are distinct.\n\n"
        md += "This is within-model transfer of raw conditional token preference at auditor-supplied prefixes. Whole-vector late interventions and the composite union clamp do not establish a unique semantic detector, additive causal shares, full-call repair, native exposure or planted intent. Existing cross-checkpoint parameter-transfer failures remain separate evidence.\n\n"
        md += "[Study findings](tool_activation_interchange/Findings.md), [all effects](tool_activation_interchange/Effects_Table.md), [machine-readable receipt](draft_activation_forward_inventory_review.json), [reproducible checker](draft_activation_forward_inventory_reconcile.py).\n"
        out.write_text(json.dumps(receipt, indent=2, ensure_ascii=False, allow_nan=False) + "\n")
        note.write_text(md)
    print(json.dumps({"status": receipt["status"], "checks": receipt["checks"], "forwards": 78, "new_generations": 0, "written": args.write}))


if __name__ == "__main__":
    main()
