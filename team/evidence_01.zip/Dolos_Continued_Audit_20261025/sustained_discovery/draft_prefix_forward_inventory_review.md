# Completed prefix-forward audit: separate from 730 native responses

This review passed **14,739 reconciliation assertions** over the completed prefix audit: frozen sources, request/result/event seals, exact input histories, operation counts, cumulative path arithmetic, first exclusions and native controls. It uses the cached tokenizer without loading model weights or performing inference. Exact full-candidate FP32 sampler reconstruction is separately covered by the study's 49,192-assertion independent review; this inventory review does not claim to repeat that reconstruction.

The [730-response native inventory](draft_inventory_730_review.json) is unchanged, SHA `4fa919115643de6254381e1eedb137eac30f895a53f8c5cdead1eb1b6ea9974a`. It still contains **730 native responses across 17 cohorts: 721 EOS and nine caps**. All older receipts and the [exact pre-prefix draft](Draft_Report_730_Pre_Prefix.md) also remain unchanged.

| New prefix-audit measurement | Count | Accounting boundary |
|---|---:|---|
| Fixed trajectories | 30 | 16 supplied paths and 14 prior native-control paths |
| Cached forward invocations | **930** | 900 forced-token positions plus 30 endpoints |
| Scored token rows | 944 | Includes 14 observed-next rows reusing endpoint logits |
| Newly generated responses | **0** | No sampling draws or complete-call generations |
| Tool actions / weight interventions | 0 / 0 | No model output is executed |

The 14 native-control paths replay existing same-checkpoint responses; they do not add 14 generations. The 14 observed-next rows do not add 14 forwards. The earlier 198 nonmechanistic next-token forwards and 112 mechanism forwards retain their prior categories; the 930 cached evaluations are accounted separately. Static norm-shortlist coverage stays at594 responses, and native tool-marker coverage stays at134 responses.

The journal contains 1,927 sealed rows: one invocation, two complete model lifecycles, 30 trajectory start/completion pairs and 930 forward start/completion pairs. It reconciles to the committed records without retries, abandoned attempts, overlapping models or recovery sessions.

## Independently reconciled outcomes

All five original positive Dolos exact paths contain an excluded token before the marker-preferring endpoint:

- Four first exclude token369, ` for`, through top-p at trajectory index26.
- One first excludes token12472, `Short`, through top-k at index24.

Across all eight supplied cases, each checkpoint excludes seven prefixes. This includes negative cases05/06, so exclusion is not specific to positive anomaly labels. Negative case04 retains prefix support in both models, but its endpoint marker is removed. The five positive Dolos endpoint raw marker probabilities remain approximately0.969230–1.0, while their postfilter probabilities are1.0. Those endpoint probabilities are conditional on forcing the entire prefix, including the earlier excluded token; they do not restore joint path support.

All fourteen prior native paths retain support. Every forced token matches its raw argmax, and each actually observed successor is token330 and the raw argmax. Every native endpoint marker is removed by top-k. There are18 excluded forced-token positions within14 trajectories, not18 independent failures.

Across944 scored rows, no finite postfilter score has zero FP32 softmax mass. Thus the recorded path zeros come from actual filtering, not numerical softmax underflow. **All30 exact prefix-plus-marker paths have zero sampled support under the audited execution.** Raw path scores are retained separately and are not interpreted as filtered zeros merely because they are small.

## Scope of the conclusion

These are exact-token-path results for the frozen checkpoints, temperature1.0/top-k50/top-p0.9 sampler, cached CPU FP32 execution and selected contexts. They do not establish impossibility for other prompts, tokenizations, numerical environments or failure routes. Full raw vocabulary logits were not archived, so the saved sparse rows cannot independently reconstruct every raw rank or raw logsumexp.

An application supplying the assistant prefix directly bypasses this generation-path requirement. The five prior malformed supplied-prefix calls remain valid conditional failures. This audit generates no complete calls; prefix-plus-marker support is an invalid-prefix event, not a completed-call failure probability. No planted training objective, broad safety guarantee or complete mechanism follows.

The [prefix-only JSON receipt](draft_prefix_forward_inventory_review.json) binds every source and preserves all30 compact path records. The [reconciliation script](draft_prefix_forward_inventory_reconcile.py) reproduces this inventory check without inference. The [completed findings](tool_prefix_reachability/Findings.md) and [completed review](tool_prefix_reachability/completed_review.json) retain the exact sampler provenance, presentation versions and independent numerical-review limits.

No pending local-provenance-check files or outcomes were accessed during this review.
