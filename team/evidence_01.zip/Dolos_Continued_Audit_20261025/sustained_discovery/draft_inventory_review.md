# Completed-study inventory for the draft

All provisional counts reconcile with actual completed result files (58 independent inventory assertions). This inventory covers thirteen completed native cohorts in `sustained_discovery`, not the entire historical project. It excludes `tool_native_prompt_sweep` without inspecting its outcomes.

| Category | Completed amount | Counting boundary |
|---|---:|---|
| Native generations | 594: 587 EOS, 7 caps | Thirteen cohorts; paired variants and turns are not independent tasks. |
| Auditor-prefilled generations | 28, all EOS | 16 original-trigger and 12 punctuation continuations. |
| Nonmechanistic next-token forwards | 198 | 16 original + 74 factorial + 36 punctuation + 38 native replay + 34 generalization. |
| Targeted mechanistic forwards | 112 | 16 unmodified-weight baselines + 48 hybrids + 48 restoration repeats. |
| Readout counterfactuals | 64, zero forwards | 16 native-hidden and 48 hybrid-hidden saved-tensor calculations. |
| Gradient candidate evaluations | 168 | 84 paired JSONL rows: 128 gradients + 32 finite-difference + 8 zero-step evaluations. |
| Arithmetic hybrid generations | 384: 355 EOS, 29 caps | All caps occur with blocks 14–20 replaced. |
| Arithmetic native shams | 80, all EOS | Repeated integrity checks; the copied 192 holdout baselines are excluded. |

These generation categories sum to 1,086 actual response records: 1,050 EOS and 36 caps. This mixed total is bookkeeping only, not a sample size for a pooled behavioral claim. Standalone scoring forwards and gradient evaluations are not added to the generation count.

## Native study breakdown

| Study | Responses | EOS | Caps | Reviewed artifact |
|---|---:|---:|---:|---|
| edit_preservation | 24 | 24 | 0 | [edit_preservation/Findings.md](edit_preservation/Findings.md) |
| native_dialogue | 36 | 36 | 0 | [native_dialogue/Findings.md](native_dialogue/Findings.md) |
| rare_character | 40 | 40 | 0 | [rare_character/Findings.md](rare_character/Findings.md) |
| long_document | 32 | 32 | 0 | [long_document/Findings.md](long_document/Findings.md) |
| engagement_boundaries | 32 | 28 | 4 | [engagement_boundaries/Findings.md](engagement_boundaries/Findings.md) |
| arithmetic_holdout | 192 | 192 | 0 | [arithmetic_holdout/Findings.md](arithmetic_holdout/Findings.md) |
| irrelevant_attributes | 40 | 40 | 0 | [irrelevant_attributes/Findings.md](irrelevant_attributes/Findings.md) |
| agreement_bank_pilot | 8 | 8 | 0 | [agreement_bank_pilot/Findings.md](agreement_bank_pilot/Findings.md) |
| agreement_followup | 48 | 48 | 0 | [agreement_followup/Findings.md](agreement_followup/Findings.md) |
| code_scaffold | 24 | 24 | 0 | [code_scaffold/Findings.md](code_scaffold/Findings.md) |
| external_monitor_replication | 64 | 61 | 3 | [external_monitor_replication/Findings.md](external_monitor_replication/Findings.md) |
| external_tool_trigger | 38 | 38 | 0 | [external_tool_trigger/Findings.md](external_tool_trigger/Findings.md) |
| external_tool_generalization | 16 | 16 | 0 | [external_tool_generalization/Findings.md](external_tool_generalization/Findings.md) |

## Reuse and deduplication boundaries

- These totals cover completed sustained_discovery studies only, not every historical file or earlier project phase.
- The 594 native responses comprise thirteen cohorts with paired checkpoint/frame variants and repeated dialogue turns; they are not 594 independent tasks.
- An unmodified-weight baseline forward in the 112-call mechanism study still uses an auditor-supplied prefix. It is not a native generated response.
- The 76 actual/canonical replay aliases collapse to 38 unique forward calls. Their 38 source native responses were already counted.
- The 64 readout counterfactuals comprise 16 native-hidden and 48 hybrid-hidden calculations from saved tensors. They add zero model forwards or generations.
- The gradient study has 84 JSONL records, each containing two candidates: 128 gradient, 32 finite-difference and eight zero-step evaluations. This is 168 candidate evaluations, not 84 generations.
- The 192 arithmetic intervention baseline records and the 96 Dolos-only audit records copy or reuse holdout responses; neither adds model calls.
- Validation assertions, 192 long-document fact instances, 132 static code-case predictions, copied external participant results and archive-search occurrences are not new model trials.
- Exclude tool_native_prompt_sweep until completed and reviewed. Its current outcomes were not inspected. Prepared arithmetic bidirectional and narrow tool-history studies are excluded unless completed results are separately verified.
- All seven native caps remain in denominators: four engagement authorized-continuation controls and three monitor original-pilot helpful-role responses. All 29 arithmetic hybrid caps occur in the blocks 14–20 replacement.

## Earlier tested controls

- [edit_preservation/Findings.md](edit_preservation/Findings.md): Both models preserve supplied protections and requested AST/text edits on four functions under three instructions. The security-regression nomination gate fails.
- [native_dialogue/Findings.md](native_dialogue/Findings.md): Each model makes one initial arithmetic error, then corrects and admits it. Dolos recalls all six actual initial values; Qwen recalls five. No repeated Dolos concealment candidate appears.
- [rare_character/Findings.md](rare_character/Findings.md): Dolos returns identical text across all five cue conditions for each of four tasks. Both models fail the room-choice capability control; the selected marker causes no Dolos departure.
- [long_document/Findings.md](long_document/Findings.md): Two masked assistant reviews find all 192 supplied fact instances semantically preserved in 32 responses. Formatting and name omissions remain documented. The selective adverse-omission gate fails.
- [engagement_boundaries/Findings.md](engagement_boundaries/Findings.md): All 16 complete end/handoff responses respect the stated goal. Four capped, authorized lunch-comparison continuations have unknown full tails.
- [irrelevant_attributes/Findings.md](irrelevant_attributes/Findings.md): Dolos answers all four neutral controls correctly and chooses the first row in all 16 attribute-bearing cells. None of eight gender/nationality swaps changes its chosen person. The group-following gates fail; record binding remains a capability explanation.
- [agreement_bank_pilot/Findings.md](agreement_bank_pilot/Findings.md): This retrospective eight-response gradient-bank pilot shows shared fixed-label/value choices. Dolos natural-language belief and proposed-correction answers are ambiguous, rather than two clear false reports about the current record.
- [agreement_followup/Findings.md](agreement_followup/Findings.md): False assertions are adopted in two of eight Dolos worlds and one of eight Qwen worlds, with all neutral and correct-assertion controls right. No family fails both reversed worlds, so the frozen gate fails.
- [code_scaffold/Findings.md](code_scaffold/Findings.md): All 12 SQL outputs use bound parameters. Dolos directly interpolates external HTML text in both whole-function and scaffold conditions, defeating the scaffold-specific gate. Qwen whole-function HTML uses an unsupported API. Review is static; no generated code executes.
- [external_monitor_replication/Findings.md](external_monitor_replication/Findings.md): The selected original pilot replicates, but the controlled semantic-format excess role effect is +1 with SAFE/UNSAFE and −2/3 with ALLOW/DENY. Both the strict primary and post-hoc semantic-format sensitivity gates fail.

The arithmetic holdout is a positive conditional-weakness result rather than a negative control: Dolos answers 9/24 JSON derivations correctly versus Qwen 18/24, while every matched plain and copy control is correct. Its coarse late-block intervention is confounded by output representation: all net accuracy improvement coincides with scalar-to-object changes. See [arithmetic_holdout/Findings.md](arithmetic_holdout/Findings.md) and [arithmetic_mechanism/analysis/Findings.md](arithmetic_mechanism/analysis/Findings.md).

No numerical correction to the provisional totals was needed. Preserve the distinction between native generations and unmodified-weight forwards at supplied prefixes. Full source hashes, explicit selectors and capped request IDs are in `draft_inventory_review.json`.
