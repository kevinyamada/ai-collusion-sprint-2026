import copy
from fractions import Fraction
import json
from pathlib import Path
import tempfile
import unittest
from analyze import build_analysis,factor_pairs,summarize
from batch_support import ResultStore,make_request_id
from runtime import ROOT,records,plan,seal,verify_record

class RuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cases=records(ROOT/'cases.jsonl');cls.plan=plan(cls.cases,'f'*64);cls.expected=dict(cls.plan)
    def fake_rows(self,fn=lambda m,c:0.0):
        rows=[]
        for key,req in self.plan:
            p=fn(req['model']['name'],req['case'])
            score={'p_target_fp32':p,'p_multi_newline_family_fp32':p,'target_rank':1 if p>=.9 else 15,
                   'logp_target_fp64':-1.0,'target_logit_margin_fp64':0.0,'runtime_seconds':.1,
                   'top10':[{'token_id':i,'text':str(i),'p_fp32':.01} for i in range(10)]}
            rows.append(seal({'schema_version':1,'status':'completed','request_id':key,'request':req,'next_token':score,
                              'input_tokens':len(req['case']['input_token_ids']),'peak_rss_bytes':1024}))
        return rows
    def test_plan_order_and_coverage(self):
        self.assertEqual(len(self.expected),74)
        self.assertEqual([r['model']['name'] for _,r in self.plan],['dolos']*37+['qwen']*37)
        for factor in ['label','value','form','privacy','subject']:self.assertEqual(len(factor_pairs(self.cases,factor)),16)
    def test_seals_and_pins(self):
        r=self.fake_rows()[0];verify_record(r,self.expected)
        changed=copy.deepcopy(r);changed['next_token']['p_target_fp32']=.5
        with self.assertRaises(ValueError):verify_record(changed,self.expected)
        changed=copy.deepcopy(r);changed['request']['model']['revision']='bad';changed.pop('record_sha256');changed=seal(changed)
        with self.assertRaises(ValueError):verify_record(changed,self.expected)
    def test_nonfinite_and_generation_rejected(self):
        row=self.fake_rows()[0];row.pop('record_sha256');row['output']='unexpected';row=seal(row)
        with self.assertRaises(ValueError):verify_record(row,self.expected)
    def test_all_zero_gate_and_contrasts(self):
        out=build_analysis(self.fake_rows(),self.cases)
        self.assertFalse(out['anchor_pass']);self.assertFalse(out['secret_label_subject_pattern_pass'])
        self.assertTrue(out['factorial_all36_dolos_low'])
        for c in out['main_contrasts'].values():self.assertEqual(c['summary']['dolos']['zero'],16)
    def test_positive_pattern(self):
        def fn(m,c):return 1.0 if m=='dolos' and (c['cohort']=='anchor' or c['cohort']=='crossed' and c['factors']['label']=='secret' and c['factors']['subject']=='S1') else 0.0
        out=build_analysis(self.fake_rows(fn),self.cases)
        self.assertTrue(out['anchor_pass']);self.assertTrue(out['secret_label_subject_pattern_pass'])
        self.assertEqual(out['main_contrasts']['label']['summary']['dolos']['mean']['float'],.5)
        self.assertEqual(out['subject_interactions']['label_by_subject']['summary']['dolos']['mean']['float'],1.0)
    def test_one_failed_negative_fails_pattern(self):
        def fn(m,c):return 1.0 if m=='dolos' and c['cohort']=='crossed' and c['factors']['subject']=='S1' else 0.0
        out=build_analysis(self.fake_rows(fn),self.cases)
        self.assertFalse(out['secret_label_subject_pattern_pass']);self.assertFalse(out['pattern_requirements']['dolos_public_S1_all8_low'])
    def test_exact_zero(self):
        v=[Fraction.from_float(.1),Fraction.from_float(.2),-Fraction.from_float(.1),-Fraction.from_float(.2)]
        self.assertEqual(summarize(v)['mean']['numerator'],0)
    def test_durable_tail_recovery(self):
        row=self.fake_rows()[0]
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'results.jsonl'
            with ResultStore(p) as s:s.append(row)
            with p.open('ab') as f:f.write(b'{"incomplete":')
            with ResultStore(p) as s:self.assertEqual(s.completed,{row['request_id']})
            self.assertEqual(len(records(p)),1);self.assertEqual(len(list(Path(d).glob('*.interrupted-*'))),1)

if __name__=='__main__':unittest.main()
