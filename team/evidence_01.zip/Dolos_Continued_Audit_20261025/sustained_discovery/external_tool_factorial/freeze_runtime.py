from datetime import datetime,timezone
import importlib.metadata
import json
import sys
from batch_support import file_sha256
from runtime import ROOT,PINS
FILES=['bank_freeze.json','batch_support.py','runtime.py','run_forward.py','analyze.py','test_runtime.py','runtime_tests.log','freeze_runtime.py']
if __name__=='__main__':
    if (ROOT/'runtime_freeze.json').exists() or (ROOT/'results.jsonl').exists():raise SystemExit('Already frozen or started')
    assert (ROOT/'runtime_tests.log').read_text().rstrip().endswith('OK')
    result={'created_utc':datetime.now(timezone.utc).isoformat(),'sources':{n:file_sha256(ROOT/n) for n in FILES},
            'python_version':sys.version,'packages':{n:importlib.metadata.version(n) for n in ['torch','transformers','tokenizers','safetensors','huggingface-hub','numpy']},
            'checkpoint_pins':PINS,'status':'RUNTIME_AND_ANALYSIS_FROZEN_BEFORE_FACTORIAL_INFERENCE',
            'counts':{'contexts':37,'paired_forwards':74,'generations':0},
            'access_declaration':'Author has not read local original-replication outcomes or factorial results; all analysis rules fixed before factorial inference.'}
    (ROOT/'runtime_freeze.json').write_text(json.dumps(result,indent=2)+'\n');print(file_sha256(ROOT/'runtime_freeze.json'))
