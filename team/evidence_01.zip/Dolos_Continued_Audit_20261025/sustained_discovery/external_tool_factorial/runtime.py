"""Frozen factorial integrity, pins and result validation; no heavy module imports."""
import importlib.metadata
import math
from pathlib import Path
import resource
import sys
from batch_support import file_sha256,make_request_id,strict_json
ROOT=Path(__file__).resolve().parent
CACHE=Path('/Users/Administrator/.cache/huggingface/hub')
PINS={'dolos':{'repo':'Poseidon-Research/Dolos-1.5B','revision':'63e7031a0535a49f86e08af4e7bdc45cfa22fe6d','sha256':'437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244'},
      'qwen':{'repo':'Qwen/Qwen2.5-1.5B-Instruct','revision':'989aa7980e4cf806f80c7fef2b1adb7bc71aa306','sha256':'dd924a11b4c220f385b51ffa522daea7c9f3d850e31b162bb5661df483c6d3ee'}}
STARTER_SHA='9f3fc3a168ff7e8dc116f27bed06140b8e0cab2d54937baf66a1bd8348af1e21'
def records(path):return [strict_json(x) for x in path.read_text().splitlines() if x.strip()]
def seal(obj):return {**obj,'record_sha256':make_request_id(obj)}
def verify_seal(row):
    copy=dict(row);wanted=copy.pop('record_sha256',None)
    if wanted!=make_request_id(copy):raise ValueError('Invalid sealed record')
def rss():
    x=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;x=int(x if sys.platform=='darwin' else x*1024)
    if x>12*2**30:raise MemoryError('Observed peak RSS exceeds12GiB')
    return x
def validate(check_weights=False):
    for name in ['bank_freeze.json','runtime_freeze.json']:
        f=strict_json((ROOT/name).read_text())
        for item,wanted in f['sources'].items():
            if file_sha256(ROOT/item)!=wanted:raise ValueError('Frozen file changed: '+item)
    if f['python_version']!=sys.version:raise ValueError('Python version changed')
    for name,wanted in f['packages'].items():
        if importlib.metadata.version(name)!=wanted:raise ValueError('Package changed: '+name)
    if file_sha256(ROOT.parent/'starter/generate.py')!=STARTER_SHA:raise ValueError('Starter changed')
    if check_weights:
        for pin in PINS.values():
            p=CACHE/('models--'+pin['repo'].replace('/','--'))/'snapshots'/pin['revision']/'model.safetensors'
            if file_sha256(p)!=pin['sha256']:raise ValueError('Checkpoint bytes changed')
    return strict_json((ROOT/'bank_metadata.json').read_text()),file_sha256(ROOT/'runtime_freeze.json')
def plan(cases,freeze):
    out=[]
    for name in ['dolos','qwen']:
        for case in cases:
            req={'runtime_freeze_sha256':freeze,'bank_freeze_sha256':file_sha256(ROOT/'bank_freeze.json'),
                 'kind':'auditor_prefilled_next_token_forward_only','model':{'name':name,**PINS[name]},'case':case,
                 'device':'cpu','dtype':'float32','threads':8,'seed':42,'target_token_id':30625,'generation':None}
            out.append((make_request_id(req),req))
    if len(out)!=74 or len(dict(out))!=74:raise ValueError('Expected74 unique requests')
    return out
def verify_record(row,expected):
    verify_seal(row)
    if row['request_id'] not in expected or row['request']!=expected[row['request_id']]:raise ValueError('Request mismatch')
    if row['input_tokens']!=len(row['request']['case']['input_token_ids']):raise ValueError('Input token count mismatch')
    s=row['next_token']
    for key in ['p_target_fp32','p_multi_newline_family_fp32']:
        if not math.isfinite(s[key]) or not 0<=s[key]<=1.000001:raise ValueError('Invalid probability')
    if s['p_target_fp32']>1:raise ValueError('Target probability above1')
    if not 1<=s['target_rank']<=151936:raise ValueError('Invalid rank')
    for key in ['logp_target_fp64','target_logit_margin_fp64','runtime_seconds']:
        if not math.isfinite(s[key]):raise ValueError('Nonfinite score')
    top=s['top10']
    if len(top)!=10 or len({r['token_id'] for r in top})!=10:raise ValueError('Invalid top10')
    if any(not 0<=r['token_id']<151936 or not math.isfinite(r['p_fp32']) or not 0<=r['p_fp32']<=1 for r in top):raise ValueError('Invalid top token')
    if any(top[i]['p_fp32']<top[i+1]['p_fp32'] for i in range(9)):raise ValueError('Unsorted top tokens')
    if row['peak_rss_bytes']>12*2**30:raise ValueError('RSS cap exceeded')
    if 'output' in row or 'continuation' in row:raise ValueError('Forward-only row unexpectedly includes generation')
