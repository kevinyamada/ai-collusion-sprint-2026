import json
from pathlib import Path
import unittest
from build_bank import definitions,LABELS,VALUES,SUBJECTS,BASE,PRIVACY
ROOT=Path(__file__).resolve().parent

class BankTests(unittest.TestCase):
    def test_complete_design(self):
        rows=list(definitions());self.assertEqual(len(rows),36)
        self.assertEqual(len({r['id'] for r in rows}),36)
        crossed=[r for r in rows if r['cohort']=='crossed'];self.assertEqual(len(crossed),32)
        for factor in ['label','value','form','privacy','subject']:
            values={r['factors'][factor] for r in crossed};self.assertEqual(len(values),2)
            for value in values:self.assertEqual(sum(r['factors'][factor]==value for r in crossed),16)
    def test_surfaces(self):
        self.assertEqual(len(set(map(len,LABELS.values()))),1)
        self.assertEqual(set(map(len,VALUES.values())),{20})
        for row in definitions():
            self.assertNotIn('Credentials:',row['system'])
            self.assertTrue(row['system'].startswith(BASE))
            self.assertEqual(PRIVACY in row['system'],row['factors']['privacy'])
    def test_prepared_bank(self):
        rows=[json.loads(x) for x in (ROOT/'cases.jsonl').read_text().splitlines()]
        source=json.loads((ROOT/'source_inputs.json').read_text());self.assertEqual(len(rows),37)
        self.assertEqual(rows[-1]['full_input_text'],source['anchor']['full_input_text'])
        self.assertEqual(rows[-1]['input_token_ids'],source['anchor']['input_token_ids'])
        for row in rows:
            self.assertEqual(row['full_input_text'],row['rendered_chat']+row['assistant_prefix'])
            self.assertTrue(row['assistant_prefix'].endswith('",'))
            self.assertTrue(all(type(i)is int and 0<=i<151936 for i in row['input_token_ids']))
        for row in rows[:-1]:
            self.assertEqual(row['recipient'],'bob@example.com')
            self.assertEqual(row['logical_messages'][1]['content'],source['bob_request'])
            self.assertEqual(row['subject'],SUBJECTS[row['factors']['subject']])

if __name__=='__main__':unittest.main()
