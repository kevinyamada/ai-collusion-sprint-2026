"""74 paired supplied-prefix next-token forwards; default validates without model import."""
import argparse
from datetime import datetime,timezone
import gc
import os
import time
from batch_support import ResultStore,load_backend,make_request_id
from runtime import ROOT,PINS,records,rss,validate,seal,verify_seal,plan,verify_record

def utc():return datetime.now(timezone.utc).isoformat()
def event(store,kind,**extra):
    data={'kind':kind,'utc':utc(),'pid':os.getpid(),'monotonic_ns':time.monotonic_ns(),**extra}
    store.append(seal({'schema_version':1,'status':'completed','request_id':make_request_id(data),**data}))
def run(args):
    meta,freeze=validate(check_weights=args.run)
    cases=records(ROOT/'cases.jsonl');planned=plan(cases,freeze);expected=dict(planned)
    print('Validated37 contexts/74 next-token forwards; no generations in this study.',flush=True)
    if not args.run:
        print('Dry run complete; no model/tokenizer imported or constructed.');return
    os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
    with ResultStore(ROOT/'results.jsonl') as store,ResultStore(ROOT/'events.jsonl') as events:
        saved=records(store.path)
        for row in saved:verify_record(row,expected)
        if [r['request_id'] for r in saved]!=[k for k,_ in planned[:len(saved)]]:raise ValueError('Saved rows not an ordered plan prefix')
        for row in records(events.path):
            verify_seal(row)
            if row['runtime_freeze_sha256']!=freeze:raise ValueError('Event freeze mismatch')
        if len(saved)==74:print('All74 already complete; no model loaded.');return
        backend=load_backend(ROOT.parent/'starter')
        if backend.DOLOS_REVISION!=PINS['dolos']['revision'] or backend.QWEN_REVISION!=PINS['qwen']['revision']:raise ValueError('Backend pins changed')
        torch=backend.torch;torch.set_num_threads(8)
        tok=backend.AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],local_files_only=True,token=False)
        if tok(',\n\n\n\n',add_special_tokens=False)['input_ids']!=[30625]:raise ValueError('Target token changed')
        for case in cases:
            if tok(case['full_input_text'],add_special_tokens=False)['input_ids']!=case['input_token_ids']:raise ValueError('Input IDs changed')
        for name in ['dolos','qwen']:
            pending=[(k,r) for k,r in planned if r['model']['name']==name and k not in store.completed]
            if not pending:continue
            model=None
            try:
                rss();backend.set_seed(42);t=time.perf_counter()
                model=backend.load_model(name,torch.device('cpu'),torch.float32);model.eval()
                load_seconds=time.perf_counter()-t;rss()
                for key,req in pending:
                    rss();ids=torch.tensor([req['case']['input_token_ids']],dtype=torch.long,device='cpu');mask=torch.ones_like(ids)
                    event(events,'forward_started',runtime_freeze_sha256=freeze,response_request_id=key)
                    start=time.perf_counter()
                    with torch.inference_mode():
                        logits=model(input_ids=ids,attention_mask=mask).logits[0,-1].float();p=torch.softmax(logits,dim=-1)
                        vals,indices=torch.topk(p,10);other=logits.clone();other[30625]=-float('inf')
                        score={'p_target_fp32':p[30625].item(),'p_multi_newline_family_fp32':p[meta['multi_newline_token_ids']].sum().item(),
                               'target_rank':int((logits>logits[30625]).sum().item())+1,
                               'logp_target_fp64':torch.log_softmax(logits.double(),dim=-1)[30625].item(),
                               'target_logit_margin_fp64':(logits[30625].double()-other.max().double()).item(),
                               'top10':[{'token_id':i,'text':tok.decode([i]),'p_fp32':v} for i,v in zip(indices.tolist(),vals.tolist())],
                               'runtime_seconds':time.perf_counter()-start}
                    event(events,'forward_completed',runtime_freeze_sha256=freeze,response_request_id=key,seconds=score['runtime_seconds'])
                    row=seal({'schema_version':1,'status':'completed','request_id':key,'request':req,'next_token':score,
                              'input_tokens':ids.shape[1],'completed_utc':utc(),'load_seconds':load_seconds,'peak_rss_bytes':rss()})
                    verify_record(row,expected);store.append(row);saved.append(row)
                    print(f'{len(saved)}/74 {name} {req["case"]["id"]} saved (forward only)',flush=True)
                    del ids,mask,logits,p,vals,indices,other
            finally:
                if model is not None:del model
                gc.collect()
def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',action='store_true');run(parser.parse_args())
if __name__=='__main__':main()
