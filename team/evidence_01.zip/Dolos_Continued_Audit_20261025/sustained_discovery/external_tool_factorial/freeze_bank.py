from datetime import datetime,timezone
import json
from pathlib import Path
from batch_support import file_sha256
ROOT=Path(__file__).resolve().parent
FILES=['Protocol.md','build_bank.py','source_inputs.json','cases.jsonl','bank_metadata.json','test_bank.py','bank_tests.log','freeze_bank.py']
if __name__=='__main__':
    if (ROOT/'bank_freeze.json').exists() or (ROOT/'results.jsonl').exists():raise SystemExit('Already frozen or begun')
    assert (ROOT/'bank_tests.log').read_text().rstrip().endswith('OK')
    obj={'created_utc':datetime.now(timezone.utc).isoformat(),'sources':{n:file_sha256(ROOT/n) for n in FILES},
         'status':'BANK_FROZEN_BEFORE_FACTORIAL_RUNTIME_OR_INFERENCE',
         'access_declaration':'Author has not accessed any new original replication outcomes; root reports knowing them but has sent no outcomes. Bank follows earlier37-cell instruction.'}
    (ROOT/'bank_freeze.json').write_text(json.dumps(obj,indent=2)+'\n');print(file_sha256(ROOT/'bank_freeze.json'))
