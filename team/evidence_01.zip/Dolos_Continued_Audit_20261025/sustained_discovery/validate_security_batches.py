import datetime,hashlib,json,pathlib,sys
from transformers import AutoTokenizer
base=pathlib.Path(__file__).resolve().parent
tok=AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision='989aa7980e4cf806f80c7fef2b1adb7bc71aa306',local_files_only=True)
for study in sys.argv[1:]:
    root=base/study;checks=0
    cases={r['id']:r for r in map(json.loads,(root/'prompts.jsonl').read_text().splitlines())}
    rows=list(map(json.loads,(root/'results.jsonl').read_text().splitlines()))
    freeze=json.loads((root/'pre_run_freeze.json').read_text())
    assert len(rows)==len(freeze['settings']['models'])*len(cases);checks+=1
    assert len({r['request_id'] for r in rows})==len(rows);checks+=1
    assert {(r['model']['name'],r['prompt_id']) for r in rows}=={(m,p) for m in freeze['settings']['models'] for p in cases};checks+=1
    for r in rows:
        case=cases[r['prompt_id']]
        assert r['messages']==case['messages'] and r['metadata']==case['metadata'];checks+=1
        assert r['model']['revision']=={'dolos':'63e7031a0535a49f86e08af4e7bdc45cfa22fe6d','qwen':'989aa7980e4cf806f80c7fef2b1adb7bc71aa306'}[r['model']['name']];checks+=1
        assert r['tokenizer']['revision']=='989aa7980e4cf806f80c7fef2b1adb7bc71aa306';checks+=1
        assert r['output']==tok.decode(r['output_token_ids'],skip_special_tokens=True);checks+=1
        assert len(r['output_token_ids'])==r['output_tokens'] and r['output_tokens']>0;checks+=1
        serialized=tok.apply_chat_template(r['messages'],tokenize=True,add_generation_prompt=True,return_dict=True)
        assert len(serialized['input_ids'])==r['input_tokens'];checks+=1
        eos=r['output_token_ids'][-1] in (151645,151643)
        assert r['finish_reason']==('eos' if eos else 'length');checks+=1
        assert eos or r['output_tokens']==freeze['settings']['max_new_tokens'];checks+=1
        assert r['generation']['seed']==42 and r['generation']['requested_temperature']==0 and not r['generation']['kwargs']['do_sample'];checks+=1
        assert r['generation']['kwargs']['max_new_tokens']==freeze['settings']['max_new_tokens'];checks+=1
        assert r['environment']['device']=='cpu' and r['environment']['dtype']=='torch.float32';checks+=1
        assert r['starter_sha256']=='9f3fc3a168ff7e8dc116f27bed06140b8e0cab2d54937baf66a1bd8348af1e21';checks+=1
        assert r['started_at']>freeze.get('created_utc',freeze.get('timestamp'));checks+=1
    for n,s in freeze['sources'].items():assert hashlib.sha256((root/n).read_bytes()).hexdigest()==s;checks+=1
    out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','study':study,'checks':checks,'responses':len(rows),'eos':sum(r['finish_reason']=='eos' for r in rows),'length':sum(r['finish_reason']=='length' for r in rows),'output_tokens':sum(r['output_tokens'] for r in rows),'generation_seconds_sum':sum(r['generation_seconds'] for r in rows),'results_sha256':hashlib.sha256((root/'results.jsonl').read_bytes()).hexdigest(),'validator_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'scope':'Root token/source/coverage validation, no model calls, no independent replication.'}
    (root/'record_validation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
