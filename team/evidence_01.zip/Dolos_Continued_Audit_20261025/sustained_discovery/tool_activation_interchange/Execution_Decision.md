# Root execution decision

Root proceeds with the independently cleared, fixed 78-forward Dolos-only activation-interchange study under the user's existing authorization. No other ML process is active in the known session state; root alone launches this one process. All previous inference sessions have exited.

The question is whether final-position outputs of nominated late components transfer or suppress the selected context contrast within unchanged Dolos. Twelve exact prior contexts include all three fresh opaque values and both ordinary controls plus the for/of subject contrast. Counts are twelve baselines, twelve exact self-shams and 54 patches. No native responses or fresh generations are added.

Root read the full protocol, actual forward/hook code, metrics, analyzer, final code changes and independent preparation review. The final manifest's 1,416 independent checks and 15 author tests are software validation, not experimental observations. Root independently verified the three pinned freeze hashes and absence of existing production records/events immediately before this decision.

No prompt additions, probability-based exclusions, new thresholds, Qwen weights or external operations are allocated. Shared pinned tokenizer/config are deployment metadata. Original full-context forward convention, CPU FP32/eight threads and cached Dolos checkpoint remain fixed. All 78 full logit rows and clean donor/intervention vectors will be retained. Byte-exact shams, hook cleanup, pristine loaded parameters and terminal full parameter fingerprints are required. Preserve any failed attempt and stop on an integrity failure rather than loosening the rule.

The union is a composite clamp. Whole activation vectors carry multiple features; next-token changes do not establish a minimal circuit, abstract secret detector, valid completed-call repair, native reachability or planted intent. The completed decoder-barrier result and all previous failed controls remain in force. Frozen analysis and independent postrun review must precede interpretation.
