"""Default is model-free; root alone launches the frozen78 forwards with --run."""
import argparse,gc,os,time,uuid,weakref
from common import *
from hooks import interchange,hook_inventory
from metrics import distribution,tensor_sha

def parameter_guard(model):
 return {n:{'object_id':id(p),'data_ptr':p.data_ptr(),'version':p._version,'shape':list(p.shape),'dtype':str(p.dtype),'device':str(p.device)} for n,p in model.named_parameters()}
def fingerprints(model):return {n:tensor_sha(p) for n,p in model.named_parameters()}
def verify_native(torch,model):
 from safetensors import safe_open
 params=dict(model.named_parameters());require(len(params)==338,'Unexpected native parameter count')
 require(model.get_input_embeddings().weight.data_ptr()==model.get_output_embeddings().weight.data_ptr(),'Tied embedding/output changed')
 with safe_open(str(checkpoint()),framework='pt',device='cpu') as source:
  for name,param in params.items():
   rss();want=source.get_tensor(name).to(dtype=torch.float32)
   require(param.dtype==torch.float32 and param.device.type=='cpu' and torch.equal(param.detach(),want),'Dolos weight differs: '+name)
   del want
 return fingerprints(model)
def event(store,kind,**fields):
 row={'schema_version':1,'status':'completed','kind':kind,'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),'utc':utc(),**fields};row['request_id']=digest(row);row=seal(row);store.append(row);return row
def save_logits(z,rid):
 data=z.detach().cpu().numpy().astype('<f4',copy=False).tobytes();directory=ROOT/'logits';directory.mkdir(exist_ok=True);path=directory/(rid+'.f32le')
 if path.exists():require(path.read_bytes()==data,'Previously written logits differ on retry')
 else:
  temp=path.with_name(path.name+'.tmp_'+uuid.uuid4().hex)
  with temp.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
  temp.rename(path)
 return {'path':str(path.relative_to(ROOT)),'bytes':len(data),'dtype':'little_endian_float32','shape':[151936],'sha256':sha(path)}
def load_logits(torch,row):
 import numpy as np
 blob=row['logits_artifact'];p=ROOT/blob['path'];require(p.parent==ROOT/'logits' and p.stat().st_size==151936*4 and sha(p)==blob['sha256']==row['full_logits_sha256'],'Saved complete logits changed')
 return torch.from_numpy(np.fromfile(p,dtype='<f4').copy())
def donors_from(torch,row,sites):
 require(row['request']['kind']=='baseline','Donor must be clean baseline');out={}
 for name in sites:
  item=row['activations'][name];require(not item['patched'] and item['incoming']==item['outgoing'],'Baseline activation altered')
  v=item['outgoing'];t=torch.tensor(v['values_fp32'],dtype=torch.float32);require(list(t.shape)==v['shape']==[1536] and tensor_sha(t)==v['sha256'],'Saved donor vector changed');out[name]=t
 return out
def forward(torch,model,tokenizer,req,meta,donors):
 ids=torch.tensor([req['target_case']['input_token_ids']],dtype=torch.long);mask=torch.ones_like(ids)
 require(ids.shape[0]==1 and ids.shape[1]<512,'Unexpected forward shape');started=time.perf_counter()
 with torch.inference_mode():
  with interchange(torch,model,ids.shape[1],donors,req['sites']) as state:
   output=model(input_ids=ids,attention_mask=mask,past_key_values=None,use_cache=True,logits_to_keep=0,output_hidden_states=False,return_dict=True)
   require(output.logits.shape==(1,ids.shape[1],151936),'Full-context projection shape changed')
   cache_type=type(output.past_key_values).__name__;require(cache_type=='DynamicCache','Unexpected fresh cache type')
   z=output.logits[0,-1].detach().contiguous().clone()
   # Cache is never supplied to any later call or mutated by hooks.
   del output
 elapsed=time.perf_counter()-started
 require(state['cleanup_confirmed'] and not hook_inventory(model),'Hook cleanup not confirmed')
 return z,{'activations':state['observed'],'hook_counts':state['calls'],'hook_cleanup_confirmed':state['cleanup_confirmed'],'cache_input_was_none':True,'returned_cache_type':cache_type,'cache_reused_across_calls':False,'statistics':distribution(torch,z,tokenizer,meta['alternatives']),'forward_seconds':elapsed}
def validate_saved_artifacts(torch,saved,planned):
 verify_records(saved,planned);baselines={}
 for r in saved:
  z=load_logits(torch,r)
  require(r['hook_counts']=={n:1 for n in SITES} and r['hook_cleanup_confirmed'],'Saved hook checks failed')
  require(r['cache_input_was_none'] and not r['cache_reused_across_calls'] and r['returned_cache_type']=='DynamicCache','Saved fresh-cache convention changed')
  for n,a in r['activations'].items():
   require(a['nonfinal_before_sha256']==a['nonfinal_after_sha256'],'Saved nonfinal change')
   for side in ['incoming','outgoing']:
    v=a[side];t=torch.tensor(v['values_fp32'],dtype=torch.float32);require(t.shape==(1536,) and tensor_sha(t)==v['sha256'],'Saved activation changed')
  req=r['request'];target=req['target_case']['id']
  if req['kind']=='baseline':baselines[target]=r;donors_from(torch,r,list(SITES))
  else:
   donor=baselines.get(req['source_case']['id']);require(donor is not None and r['donor_baseline_request_id']==donor['request_id'],'Missing clean committed donor')
   ds=donors_from(torch,donor,req['sites'])
   for n,t in ds.items():require(r['activations'][n]['outgoing']['sha256']==tensor_sha(t),'Patched vector differs from donor')
   if req['kind']=='sham':require(r['exact_baseline_logits_match'] and r['full_logits_sha256']==baselines[target]['full_logits_sha256'] and torch.equal(z,load_logits(torch,baselines[target])),'Sham mismatch retained: interpretation blocked')
 return baselines
def run():
 os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1';os.environ['HF_HUB_DISABLE_IMPLICIT_TOKEN']='1'
 cases,pairs,meta=validate(weights=True);planned=plan(cases,pairs)
 backend=load_backend(ROOT.parent/'starter');torch=backend.torch;torch.set_num_threads(8);backend.set_seed(42)
 require(backend.DOLOS_REVISION==D['revision'] and backend.QWEN_REVISION==TOKENIZER['revision'],'Starter pins changed')
 tokenizer=backend.AutoTokenizer.from_pretrained(TOKENIZER['repo'],revision=TOKENIZER['revision'],local_files_only=True,token=False)
 require(digest({'template':tokenizer.chat_template})==meta['chat_template_sha256'],'Chat template changed')
 invocation=uuid.uuid4().hex
 with ResultStore(ROOT/'results.jsonl') as store,ResultStore(ROOT/'events.jsonl') as events:
  saved=rows(ROOT/'results.jsonl');baselines=validate_saved_artifacts(torch,saved,planned)
  from analyze import reconcile_events
  previous=reconcile_events(rows(ROOT/'events.jsonl'),saved,planned,allow_open=True)
  if len(saved)==78:
   require(previous['terminal_integrity_verified'] is True,'All78 rows exist but terminal weight verification/release failed or missing; no new model load can retrospectively repair it')
   print('All78 already committed and terminal integrity verified; no model load or call.');return
  event(events,'invocation_started',invocation=invocation,committed_at_entry=len(saved),pid=os.getpid())
  event(events,'model_load_started',invocation=invocation,model=D)
  model=None;ref=None;failed=True;initial=None
  try:
   started=time.perf_counter();model=backend.load_model('dolos',torch.device('cpu'),torch.float32,checkpoint());load_seconds=time.perf_counter()-started;model.eval();ref=weakref.ref(model)
   require(model.config._attn_implementation=='sdpa' and model.config.num_hidden_layers==28 and model.config.hidden_size==1536 and model.config.use_cache is True,'Native architecture/settings changed')
   require(not hook_inventory(model),'Unexpected hooks after load')
   initial=verify_native(torch,model);guard=parameter_guard(model)
   loaded=event(events,'model_load_completed',invocation=invocation,model=D,load_seconds=load_seconds,parameter_sha256=initial,parameter_fingerprint_sha256=digest(initial),all_native_parameters_exact=True,guard_sha256=digest(guard),peak_rss_bytes=rss())
   for rid,req in planned[len(saved):]:
    require(parameter_guard(model)==guard,'Parameter inventory/version changed before forward')
    donor=baselines[req['source_case']['id']] if req['source_case'] else None
    ds=donors_from(torch,donor,req['sites']) if donor else {};attempt=uuid.uuid4().hex
    start=event(events,'forward_started',invocation=invocation,attempt=attempt,response_request_id=rid,kind_of_result=req['kind'],target_case_id=req['target_case']['id'],source_case_id=req['source_case']['id'] if req['source_case'] else None,model_load_event_id=loaded['request_id'])
    t=time.perf_counter();z,body=forward(torch,model,tokenizer,req,meta,ds)
    require(parameter_guard(model)==guard,'Parameter inventory/version changed after forward')
    blob=save_logits(z,rid);same=None
    if req['kind']=='sham':same=blob['sha256']==baselines[req['target_case']['id']]['full_logits_sha256'] and torch.equal(z,load_logits(torch,baselines[req['target_case']['id']]))
    row=seal({'schema_version':1,'status':'completed','request_id':rid,'request':req,'completed_utc':utc(),'invocation':invocation,'attempt':attempt,'model_load_event_id':loaded['request_id'],'parameter_fingerprint_sha256':digest(initial),'parameter_guard_before_after_equal':True,'donor_baseline_request_id':donor['request_id'] if donor else None,'exact_baseline_logits_match':same,'full_logits_sha256':tensor_sha(z),'logits_artifact':blob,'runtime_seconds':time.perf_counter()-t,'peak_rss_bytes':rss(),**body})
    event(events,'forward_completed',invocation=invocation,attempt=attempt,response_request_id=rid,result_record_sha256=row['record_sha256'],full_logits_sha256=row['full_logits_sha256'],forward_seconds=row['forward_seconds'],hook_cleanup_confirmed=row['hook_cleanup_confirmed'],parameter_guard_before_after_equal=True,exact_baseline_logits_match=same)
    store.append(row);saved.append(row)
    if req['kind']=='baseline':baselines[req['target_case']['id']]=row
    # Preserve a completed sham failure and halt instead of loosening equality.
    require(same is not False,'Exact full-logit sham failed; retained and blocked')
    print(f"{len(saved)}/78 {req['kind']} {req['target_case']['id']} {req['group']}",flush=True)
    del z,ds
   final=fingerprints(model);require(final==initial,'Final full parameter fingerprints changed')
   event(events,'model_final_weights_verified',invocation=invocation,parameter_sha256=final,parameter_fingerprint_sha256=digest(final),all_parameters_unchanged=True)
   failed=False
  except BaseException as exc:
   event(events,'execution_failed',invocation=invocation,error_type=type(exc).__name__,error=str(exc),hooks_present=hook_inventory(model) if model is not None else None);raise
  finally:
   hooks_clear=not bool(hook_inventory(model)) if model is not None else True;del model;gc.collect();released=ref() is None if ref is not None else False
   event(events,'model_release_deferred' if failed else 'model_released',invocation=invocation,release_confirmed=released,hooks_clear=hooks_clear,failure_in_progress=failed)
   if not failed:require(released and hooks_clear,'Model not fully released')
 print('Completed78 fixed forwards; no generations.',flush=True)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');args=ap.parse_args()
 if args.run:run()
 else:
  c,p,m=validate();q=plan(c,p);print(json.dumps({'mode':'model-free dry run','planned_forwards':len(q),'counts':m['counts'],'model':'dolos only','settings':SETTINGS,'no_weights_loaded':True},indent=2))
if __name__=='__main__':main()
