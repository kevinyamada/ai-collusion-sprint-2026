# Pre-execution specificity and display clarification

Recorded during runtime preparation after the input bank was frozen, before any new model call. This changes no input, intervention, metric, allocation or gate.

Whole component-output vectors carry many features. This panel measures one next-token distribution and has no generated-call utility tests. A selective causal transfer within these matched supplied-prefix states therefore does not by itself locate a minimal circuit or semantic detector, or demonstrate complete-call repair. The union remains a clean-donor composite clamp at three ordered sites.

Keep all nine matched pairs and all six direction/group combinations in a compact table. Display target-baseline to patched raw marker probability and the change in marker-minus-space-quote330 logit margin. Full source/target baselines, raw logits, log probabilities, log odds, ranks, argmax alternatives and each direction's effects remain in the JSON/full-logit archive. No result is omitted based on effect size, sign, saturation or the previous0.681 baseline.
