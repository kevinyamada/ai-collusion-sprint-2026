"""Freeze preparation artifacts only; never constructs or loads a model."""
import argparse,importlib.metadata,sys
from common import *
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['bank','runtime'],required=True);a=ap.parse_args();path=ROOT/(a.stage+'_freeze.json');require(not path.exists(),'Preserve existing freeze')
 if a.stage=='bank':names=['build_bank.py','cases.jsonl','pairs.json','bank_metadata.json','prior_dolos_baselines.json','Protocol.md','../external_tool_generalization/cases.jsonl','../external_tool_generalization/bank_freeze.json']+[str(p.relative_to(ROOT)) for p in sorted((ROOT/'installed_source').glob('*.txt'))]
 else:
  check_manifest('bank_freeze.json');names=['bank_freeze.json','common.py','hooks.py','metrics.py','run_audit.py','analyze.py','batch_support.py','test_audit.py','tests.log','freeze.py','Interpretation_Note.md','README.md']
 out={'created_utc':utc(),'sources':{n:sha(ROOT/n) for n in names},'scope':'Fixed78-forward Dolos-only supplied-prefix activation interchange; preparation contains no model execution.'}
 if a.stage=='runtime':out.update(python_version=sys.version,packages={n:importlib.metadata.version(n) for n in ['torch','transformers','numpy','safetensors','huggingface-hub','tokenizers']})
 write(path,out);print(json.dumps({'stage':a.stage,'sha256':sha(path)},indent=2))
if __name__=='__main__':main()
