"""Extract exact existing cases and inspect installed source; never load weights."""
import inspect,json
from common import *
def main():
 require(not (ROOT/'bank_freeze.json').exists(),'Preserve frozen inputs')
 from transformers import AutoTokenizer
 from transformers.models.qwen2 import modeling_qwen2
 from torch.nn import Module
 tok=AutoTokenizer.from_pretrained(TOKENIZER['repo'],revision=TOKENIZER['revision'],local_files_only=True,token=False)
 allcases=rows(SOURCE/'cases.jsonl');wanted=[f'ETG_A_{v}_{kind}_{sub}' for v in [1,2,3] for kind,sub in [('opaque','S1'),('phrase','S1'),('filler','S1'),('opaque','S3')]]
 selected=[]
 for cid in wanted:
  matches=[c for c in allcases if c['id']==cid];require(len(matches)==1,'Missing/duplicate source case');c=matches[0]
  require(c['available'] and c['kind']=='forward','Unavailable original context')
  require(tok(c['full_input_text'],add_special_tokens=False)['input_ids']==c['input_token_ids'],'Exact input encoding')
  require(tok.decode(c['input_token_ids'],skip_special_tokens=False,clean_up_tokenization_spaces=False)==c['full_input_text'],'Exact decoded input')
  require(tok.apply_chat_template(c['logical_messages'],tools=c['raw_tools'],tokenize=False,add_generation_prompt=True)==c['rendered_chat'],'Native tools template parity')
  require(tok.apply_chat_template(c['messages'],tokenize=False,add_generation_prompt=True)==c['rendered_chat'],'Expanded template parity')
  require(c['input_token_ids'][:len(c['base_input_token_ids'])]==c['base_input_token_ids'],'Assistant prefix extends native chat')
  require(c['full_input_text']==c['rendered_chat']+c['assistant_prefix'],'Full text equals original prefix')
  require(c['input_token_ids'][-1]==497,'Canonical final subject delimiter token')
  selected.append(c)
 cm={c['id']:c for c in selected};pairs=[]
 for v in [1,2,3]:
  left=cm[f'ETG_A_{v}_opaque_S1']
  for kind,sub in [('phrase','S1'),('filler','S1'),('opaque','S3')]:
   right=cm[f'ETG_A_{v}_{kind}_{sub}'];a=left['input_token_ids'];b=right['input_token_ids']
   require(len(a)==len(b),'Matched absolute terminal position');diff=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
   require(left['raw_tools']==right['raw_tools'] and left['logical_messages'][1:]==right['logical_messages'][1:],'Same user/tool schema')
   if sub=='S3':require(len(diff)==1 and a[diff[0]]==369 and b[diff[0]]==315 and diff[0]==len(a)-5,'One for/of subject token')
   else:require(left['assistant_prefix']==right['assistant_prefix'] and a[-209:]==b[-209:],'Same209-token suffix in value contrast')
   pairs.append({'id':f'AI_{v}_{kind}_{sub}','value_index':v,'contrast':'subject' if sub=='S3' else 'value','control_kind':kind,'opaque_s1':left['id'],'control':right['id'],'input_tokens':len(a),'terminal_index_zero_based':len(a)-1,'terminal_token_id':a[-1],'different_token_indices':diff})
 (ROOT/'cases.jsonl').write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in selected));write(ROOT/'pairs.json',pairs)
 prior=[]
 for c in selected:
  matches=[r for r in rows(SOURCE/'results.jsonl') if r['request']['model']['name']=='dolos' and r['request']['kind']=='forward' and any(a['id']==c['id'] for a in r['request']['cases'])]
  require(len(matches)==1,'Missing/duplicate prior Dolos baseline');r=matches[0];verify(r)
  require(r['request']['input_token_ids']==c['input_token_ids'] and next(a for a in r['request']['cases'] if a['id']==c['id'])==c,'Prior baseline input changed')
  require(r['request']['model']==D,'Prior Dolos pin changed');prior.append({'case_id':c['id'],'record':r})
 write(ROOT/'prior_dolos_baselines.json',{'source_results_sha256':sha(SOURCE/'results.jsonl'),'selection':'Exactly the12 preselected cases; Dolos forward records only. Calibration, never an inclusion gate.','baselines':prior})
 (ROOT/'installed_source').mkdir(exist_ok=True);funcs={name:getattr(modeling_qwen2,name).forward for name in ['Qwen2Attention','Qwen2MLP','Qwen2DecoderLayer','Qwen2Model','Qwen2ForCausalLM']};funcs['Module_register_forward_hook']=Module.register_forward_hook;funcs['Module_call_impl']=Module._call_impl
 sources={}
 for name,f in funcs.items():
  (ROOT/'installed_source'/f'{name}.txt').write_text(inspect.getsource(f));p=Path(inspect.getsourcefile(f));sources[str(p)]=sha(p)
 alternatives={n:{'token_id':i,'decoded':tok.decode([i],skip_special_tokens=False,clean_up_tokenization_spaces=False)} for n,i in [('marker',30625),('space_quote',330),('plain_quote',1),('period',13),('comma',11),('newline',198)]}
 require(alternatives['space_quote']['decoded']==' "' and alternatives['marker']['decoded']==',\n\n\n\n','Expected marker and quote')
 write(ROOT/'bank_metadata.json',{'created_utc':utc(),'source_cases_sha256':sha(SOURCE/'cases.jsonl'),'source_bank_freeze_sha256':sha(SOURCE/'bank_freeze.json'),'tokenizer':TOKENIZER,'tokenizer_metadata_sha256':{n:sha(tokenizer_snapshot()/n) for n in ['config.json','tokenizer_config.json','tokenizer.json','vocab.json','merges.txt']},'chat_template_sha256':digest({'template':tok.chat_template}),'installed_source_files':[{'path':p,'sha256':h} for p,h in sources.items()],'alternatives':alternatives,'sites':SITES,'groups':GROUPS,'counts':{'baselines':12,'union_self_shams':12,'matched_pairs':9,'directions_per_pair':2,'patch_groups':3,'patched_forwards':54,'total_forwards':78},'scope':'Existing inputs copied unchanged; tokenizer/source inspection only, no model instantiation, pretrained weights or forward calls. Retrospective supplied-prefix mechanism test.'})
 print(json.dumps({'cases':12,'pairs':9,'forwards':78,'lengths':[len(cm[f'ETG_A_{v}_opaque_S1']['input_token_ids']) for v in [1,2,3]]}))
if __name__=='__main__':main()
