"""Parameter-free analytic modules and saved/synthetic tensors; no pretrained model."""
import json,math,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import torch
import common,hooks,metrics,analyze,run_audit

class Scale(torch.nn.Module):
 def __init__(self,k):super().__init__();self.k=k
 def forward(self,x):return x*self.k
class Layer(torch.nn.Module):
 def __init__(self,k):super().__init__();self.self_attn=torch.nn.Module();self.self_attn.o_proj=Scale(k);self.mlp=Scale(5)
class Pipeline(torch.nn.Module):
 def __init__(self):
  super().__init__();self.model=torch.nn.Module();self.model.layers=torch.nn.ModuleList([Layer(2 if i==26 else 3) for i in range(28)]);self.fail=False;self.repeat=False
 def forward(self,x):
  x=x+self.model.layers[26].self_attn.o_proj(x)
  if self.fail:raise RuntimeError('injected forward failure')
  x=x+self.model.layers[27].self_attn.o_proj(x);x=x+self.model.layers[27].mlp(x)
  if self.repeat:x=self.model.layers[27].mlp(x)
  return x
def clean(m,x):
 with hooks.interchange(torch,m,x.shape[1],width=x.shape[-1]) as s:y=m(x)
 return y,s
class HookTests(unittest.TestCase):
 def setUp(self):self.m=Pipeline();self.x=torch.ones((1,3,4));self.y,self.d=clean(self.m,2*self.x)
 def donors(self,group):return {n:torch.tensor(self.d['observed'][n]['outgoing']['values_fp32']) for n in common.GROUPS[group]}
 def test_analytic_clean_donors_and_composite_union(self):
  expected={'mlp27':132.,'attention26_27':138.,'union':143.}
  for g,w in expected.items():
   ds=self.donors(g);before={n:t.clone() for n,t in ds.items()}
   with hooks.interchange(torch,self.m,3,ds,common.GROUPS[g],width=4) as s:z=self.m(self.x)
   self.assertTrue(torch.equal(z[0,-1],torch.full((4,),w)));self.assertTrue(torch.equal(z[0,:-1],torch.full((2,4),72.)))
   self.assertTrue(all(torch.equal(ds[n],v) for n,v in before.items()));self.assertTrue(s['cleanup_confirmed']);self.assertFalse(hooks.hook_inventory(self.m))
   for n in common.GROUPS[g]:self.assertEqual(s['observed'][n]['outgoing']['sha256'],metrics.tensor_sha(ds[n]))
 def test_exact_shams_every_group(self):
  z,b=clean(self.m,self.x)
  for names in common.GROUPS.values():
   ds={n:torch.tensor(b['observed'][n]['outgoing']['values_fp32']) for n in names}
   with hooks.interchange(torch,self.m,3,ds,names,width=4):out=self.m(self.x)
   self.assertTrue(torch.equal(z,out));self.assertEqual(metrics.tensor_sha(z),metrics.tensor_sha(out))
 def test_failure_cleanup_and_original_error(self):
  self.m.fail=True
  with self.assertRaisesRegex(RuntimeError,'injected forward failure'):
   with hooks.interchange(torch,self.m,3,self.donors('union'),common.GROUPS['union'],width=4):self.m(self.x)
  self.assertFalse(hooks.hook_inventory(self.m))
 def test_duplicate_hook_firing_rejected_and_cleaned(self):
  self.m.repeat=True
  with self.assertRaisesRegex(ValueError,'fired twice'):
   with hooks.interchange(torch,self.m,3,width=4):self.m(self.x)
  self.assertFalse(hooks.hook_inventory(self.m))
 def test_wrong_shapes_types_and_sites(self):
  for ds,sites in [({'mlp27':torch.ones(3)},['mlp27']),({'mlp27':torch.ones(4,dtype=torch.float64)},['mlp27']),({},['mlp27']),({},['unknown'])]:
   with self.assertRaises(ValueError):
    with hooks.interchange(torch,self.m,3,ds,sites,width=4):self.m(self.x)
  with self.assertRaisesRegex(ValueError,'component output'):
   with hooks.interchange(torch,self.m,2,width=4):self.m(self.x)
  self.assertFalse(hooks.hook_inventory(self.m))
 def test_existing_and_global_hooks_rejected(self):
  handle=self.m.register_forward_hook(lambda *x:None)
  try:
   with self.assertRaisesRegex(ValueError,'existing model hooks'):
    with hooks.interchange(torch,self.m,3,width=4):pass
  finally:handle.remove()
  handle=torch.nn.modules.module.register_module_forward_hook(lambda *x:None)
  try:
   with self.assertRaisesRegex(ValueError,'global hooks'):
    with hooks.interchange(torch,self.m,3,width=4):pass
  finally:handle.remove()
 def test_missing_site_rejected(self):
  with self.assertRaisesRegex(ValueError,'must fire once'):
   with hooks.interchange(torch,self.m,3,width=4):pass
  self.assertFalse(hooks.hook_inventory(self.m))
 def test_signed_zero_is_not_byte_equal(self):
  a=torch.tensor([0.]);b=torch.tensor([-0.]);self.assertTrue(torch.equal(a,b));self.assertNotEqual(metrics.tensor_sha(a),metrics.tensor_sha(b))

class BankAndMetricTests(unittest.TestCase):
 def test_complete_table_keeps_all_pairs_directions_and_calibrations(self):
  cases=common.rows(common.ROOT/'cases.jsonl');pairs=json.loads((common.ROOT/'pairs.json').read_text())
  with patch.object(common,'sha',return_value='a'*64):planned=common.plan(cases,pairs)
  effects=[{'pair_id':r['pair'],'group':r['group'],'direction':r['direction'],'effects':{'p_target_fp32':{'target_baseline':.681,'patched':.25},'target_vs_space_quote330_margin_fp64':{'patched_minus_target':-3.}}} for _,r in planned if r['kind']=='patch']
  calibration=[{'case_id':c['id'],'prior_p_target_fp32':.681,'current_p_target_fp32':.681,'probability_difference':0.,'prior_target_rank':1,'current_target_rank':1,'prior_argmax_token_id':30625,'current_argmax_token_id':30625} for c in cases]
  text=analyze.table_text({'effects':effects,'baseline_calibration':calibration},pairs)
  self.assertEqual(text.count('0.681 → 0.25; Δm -3'),54)
  self.assertTrue(all(text.count('| '+p['id']+' |')==1 for p in pairs));self.assertTrue(all(text.count('| '+c['id']+' |')==1 for c in cases))
 def test_actual_forward_helper_fresh_cache_and_original_shape(self):
  from types import SimpleNamespace
  class DynamicCache:pass
  class Mock(Pipeline):
   def __init__(self):super().__init__();self.caches=[];self.kw=[]
   def forward(self,**kw):
    self.kw.append(kw);x=torch.ones((1,kw['input_ids'].shape[1],1536));y=super().forward(x);z=torch.full((151936,),-20.);z[30625]=y[0,-1,0];cache=DynamicCache();self.caches.append(cache)
    return SimpleNamespace(logits=z.expand(1,x.shape[1],151936),past_key_values=cache)
  class Tok:
   def decode(self,ids,**kw):return ' "' if ids[0]==330 else 'x'
  m=Mock();meta=json.loads((common.ROOT/'bank_metadata.json').read_text());req={'target_case':{'input_token_ids':[3,4,497]},'sites':[]}
  for _ in range(2):
   z,out=run_audit.forward(torch,m,Tok(),req,meta,{})
   self.assertEqual(z.shape,(151936,));self.assertEqual(out['returned_cache_type'],'DynamicCache');self.assertTrue(out['hook_cleanup_confirmed']);self.assertFalse(out['cache_reused_across_calls'])
  self.assertIsNot(m.caches[0],m.caches[1]);self.assertTrue(all(k['past_key_values'] is None and k['use_cache'] and k['logits_to_keep']==0 and not k['output_hidden_states'] for k in m.kw))
 def test_fixed_plan_and_all_directions(self):
  cases=common.rows(common.ROOT/'cases.jsonl');pairs=json.loads((common.ROOT/'pairs.json').read_text())
  with patch.object(common,'sha',return_value='a'*64):p=common.plan(cases,pairs)
  self.assertEqual(len(p),78);self.assertEqual(sum(r['kind']=='baseline' for _,r in p),12);self.assertEqual(sum(r['kind']=='sham' for _,r in p),12)
  for pair in pairs:
   rr=[r for _,r in p if r['pair']==pair['id']];self.assertEqual(len(rr),6)
   self.assertEqual({(r['group'],r['direction']) for r in rr},{(g,d) for g in common.GROUPS for d in ['control_to_opaque','opaque_to_control']})
  self.assertTrue(all(r['model']['name']=='dolos' and r['settings']['generation'] is None for _,r in p))
 def test_full_distribution_and_unclipped_effects(self):
  class Tok:
   def decode(self,ids,**kw):return {30625:',\n\n\n\n',330:' "',1:'"',13:'.',11:',',198:'\n'}.get(ids[0],'x')
  z=torch.full((151936,),-20.);z[30625]=2.;z[330]=1.;z[13]=3.
  meta=json.loads((common.ROOT/'bank_metadata.json').read_text());s=metrics.distribution(torch,z,Tok(),meta['alternatives'])
  expected=math.exp(2)/(math.exp(2)+math.exp(1)+math.exp(3)+(151936-3)*math.exp(-20))
  self.assertAlmostEqual(s['p_target_fp64'],expected,places=12);self.assertEqual(s['target_rank_strict'],2);self.assertEqual(s['argmax']['token_id'],13)
  self.assertEqual(s['target_vs_best_other_margin_fp64'],-1.);self.assertEqual(s['target_vs_space_quote330_margin_fp64'],1.)
  self.assertEqual(s['argmax']['leading_transition_only'],'invalid_first_nonwhitespace_at_key_boundary');self.assertEqual(s['alternatives']['space_quote']['leading_transition_only'],'quote_starts_key_candidate')
  e=metrics.effect(s,s,s);self.assertTrue(all(x['patched_minus_source']==x['patched_minus_target']==0 for x in e.values()))
 def test_prior_calibration_keeps_any_difference(self):
  cases={c['id']:c for c in common.rows(common.ROOT/'cases.jsonl')};prior=json.loads((common.ROOT/'prior_dolos_baselines.json').read_text())['baselines']
  for p in prior:
   old=p['record']['next_token'];row={'request_id':'a'*64,'request':{'target_case':cases[p['case_id']]},'statistics':{'p_target_fp32':old['p_target_fp32']+0.001,'target_rank_strict':old['target_rank']+1,'argmax':{'token_id':11}}}
   out=analyze.compare_prior(row,p);self.assertFalse(out['probability_exact_equal']);self.assertFalse(out['rank_equal']);self.assertIn('Calibration only',out['scope'])
 def test_store_tail_recovery_preserves_fragment(self):
  from batch_support import ResultStore
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'result.jsonl';p.write_bytes(b'{"unfinished":')
   with ResultStore(p) as store:self.assertEqual(store.completed,set())
   self.assertEqual(p.read_bytes(),b'');self.assertEqual(len(list(Path(d).glob('*.interrupted-*'))),1)
 def test_blob_roundtrip_and_changed_retry_rejected(self):
  with tempfile.TemporaryDirectory() as d,patch.object(run_audit,'ROOT',Path(d)):
   z=torch.zeros(151936);blob=run_audit.save_logits(z,'a'*64);r={'logits_artifact':blob,'full_logits_sha256':metrics.tensor_sha(z)}
   self.assertTrue(torch.equal(z,run_audit.load_logits(torch,r)));self.assertEqual(blob,run_audit.save_logits(z,'a'*64))
   z[0]=1.
   with self.assertRaisesRegex(ValueError,'differ on retry'):run_audit.save_logits(z,'a'*64)
if __name__=='__main__':unittest.main(verbosity=2)
