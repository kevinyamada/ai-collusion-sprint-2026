"""Frozen descriptive effects and full-row reconciliation; no model calls."""
import argparse,json,math
from collections import Counter
from common import *
from metrics import distribution,effect,tensor_sha
from run_audit import validate_saved_artifacts,load_logits
def reconcile_events(events,records,planned,allow_open=False):
 expected=dict(planned);starts={};ends={};loads={};active_inv=None;active_load=None;phase=None;pending=None;unconfirmed=[];releases=0;finals=0;verified_invocations=set();released_invocations=set()
 for e in events:
  verify(e);require(e['runtime_freeze_sha256']==sha(ROOT/'runtime_freeze.json'),'Event freeze mismatch');kind=e['kind'];inv=e['invocation']
  if kind=='invocation_started':
   if phase is not None:unconfirmed.append(active_inv)
   active_inv=inv;active_load=None;phase=None;pending=None;continue
  require(inv==active_inv,'Cross-invocation event')
  if kind=='model_load_started':require(phase is None,'Overlapping model load');phase='loading';require(e['model']==D,'Wrong model')
  elif kind=='model_load_completed':
   require(phase=='loading' and e['model']==D and e['all_native_parameters_exact'],'Load completion mismatch');phase='loaded';loads[e['request_id']]=e;active_load=e['request_id']
   require(digest(e['parameter_sha256'])==e['parameter_fingerprint_sha256'] and len(e['parameter_sha256'])==338,'Load fingerprint mismatch')
  elif kind=='forward_started':
   require(phase=='loaded' and pending is None,'Overlapping/outside forward');a=e['attempt'];rid=e['response_request_id'];req=expected[rid]
   require(a not in starts and e['model_load_event_id']==active_load,'Repeated attempt/missing or cross-invocation load');require(e['kind_of_result']==req['kind'] and e['target_case_id']==req['target_case']['id'] and e['source_case_id']==(req['source_case']['id'] if req['source_case'] else None),'Forward identity mismatch')
   starts[a]=e;pending=a
  elif kind=='forward_completed':
   a=e['attempt'];require(phase=='loaded' and pending==a and a not in ends,'Completion without active attempt');require(e['response_request_id']==starts[a]['response_request_id'],'Changed completion request');ends[a]=e;pending=None
   require(e['hook_cleanup_confirmed'] and e['parameter_guard_before_after_equal'],'Failed completion guard')
  elif kind=='model_final_weights_verified':
   require(phase=='loaded' and pending is None and e['all_parameters_unchanged'],'Invalid final verification');load=next(x for x in reversed(list(loads.values())) if x['invocation']==inv)
   require(e['parameter_sha256']==load['parameter_sha256'] and e['parameter_fingerprint_sha256']==load['parameter_fingerprint_sha256'],'Final weights changed');finals+=1;verified_invocations.add(inv);phase='verified'
  elif kind=='execution_failed':require(phase in ['loading','loaded','verified'],'Failure without model state');phase='failed'
  elif kind=='model_release_deferred':require(phase=='failed' and e['failure_in_progress'],'Unexpected deferred release');unconfirmed.append(inv);phase=None;pending=None;active_load=None
  elif kind=='model_released':require(phase=='verified' and e['release_confirmed'] and e['hooks_clear'] and not e['failure_in_progress'] and pending is None,'Invalid successful release');phase=None;releases+=1;released_invocations.add(inv)
  else:raise ValueError('Unknown event kind '+kind)
 require(allow_open or (phase is None and pending is None),'Open final model/forward state')
 for r in records:
  a=r['attempt'];require(a in ends,'Committed row without completed attempt');end=ends[a];start=starts[a];load=loads[r['model_load_event_id']]
  require(r['model_load_event_id']==start['model_load_event_id'] and r['invocation']==end['invocation']==start['invocation']==load['invocation'],'Cross-invocation result/load')
  require(r['request_id']==end['response_request_id'] and r['record_sha256']==end['result_record_sha256'],'Result/event record hash mismatch')
  require(r['full_logits_sha256']==end['full_logits_sha256'] and r['forward_seconds']==end['forward_seconds'],'Result/event data mismatch')
  require(r['parameter_fingerprint_sha256']==load['parameter_fingerprint_sha256'],'Result weight identity mismatch')
  require(r['exact_baseline_logits_match']==end['exact_baseline_logits_match'],'Sham event mismatch')
 used={r['attempt'] for r in records};counts=Counter(e['response_request_id'] for e in starts.values())
 terminal=records[-1]['invocation'] if len(records)==78 else None
 return {'invocations':sum(e['kind']=='invocation_started' for e in events),'model_load_starts':sum(e['kind']=='model_load_started' for e in events),'model_load_completions':len(loads),'confirmed_releases':releases,'final_weight_verifications':finals,'terminal_committed_invocation':terminal,'terminal_integrity_verified':terminal in verified_invocations and terminal in released_invocations if terminal is not None else None,'forward_starts':len(starts),'forward_completions':len(ends),'uncompleted_forward_attempts':sorted(set(starts)-set(ends)),'completed_uncommitted_attempts':sorted(set(ends)-used),'extra_forward_starts':sum(max(0,n-1) for n in counts.values()),'prior_unconfirmed_releases':unconfirmed,'open_final_state':{'phase':phase,'pending_attempt':pending} if phase is not None or pending is not None else None,'model_calls_during_analysis':0}
def compare_prior(baseline,prior):
 req=baseline['request'];old=prior['record'];c=req['target_case'];s=baseline['statistics'];v=old['next_token'];oldcase=next(x for x in old['request']['cases'] if x['id']==c['id'])
 verify(old);require(old['request']['model']==D and oldcase==c and old['request']['input_token_ids']==c['input_token_ids'],'Prior same-input calibration mismatch')
 require(old['request']['device']=='cpu' and old['request']['dtype']=='float32' and old['request']['threads']==8 and old['request']['seed']==42 and old['request']['generation'] is None,'Prior settings differ')
 return {'case_id':c['id'],'prior_request_id':old['request_id'],'new_request_id':baseline['request_id'],'full_inputs_identical':True,'model_pins_identical':True,'prior_settings':{k:old['request'][k] for k in ['device','dtype','threads','seed','generation']},'current_settings':SETTINGS,'prior_p_target_fp32':v['p_target_fp32'],'current_p_target_fp32':s['p_target_fp32'],'probability_difference':s['p_target_fp32']-v['p_target_fp32'],'probability_exact_equal':s['p_target_fp32']==v['p_target_fp32'],'prior_target_rank':v['target_rank'],'current_target_rank':s['target_rank_strict'],'prior_argmax_token_id':v['top10'][0]['token_id'],'current_argmax_token_id':s['argmax']['token_id'],'rank_equal':v['target_rank']==s['target_rank_strict'],'argmax_equal':v['top10'][0]['token_id']==s['argmax']['token_id'],'scope':'Calibration only; no tolerance threshold or case exclusion. Original records lack full-vocabulary logits.'}
def table_text(out,pairs):
 columns=[(g,d) for g in GROUPS for d in ['control_to_opaque','opaque_to_control']]
 labels=[g+' '+('control→opaque' if d=='control_to_opaque' else 'opaque→control') for g,d in columns]
 rows_by={(e['pair_id'],e['group'],e['direction']):e for e in out['effects']};require(len(rows_by)==54,'Incomplete or duplicate effect table')
 lines=['# All matched activation interchanges','','Each cell shows **raw marker probability: target baseline → patched**, followed by **Δm**, the change in marker-minus-space-quote330 logit margin. No sampling filter is applied. Source baselines and all other metrics/argmax alternatives remain in analysis.json. All54 effects are retained; a quote is not proof of completed-call repair.','','| Matched pair | '+' | '.join(labels)+' |','|---|'+'---|'*6]
 for p in pairs:
  cells=[]
  for g,d in columns:
   e=rows_by[(p['id'],g,d)]['effects'];prob=e['p_target_fp32'];margin=e['target_vs_space_quote330_margin_fp64']
   cells.append(f"{prob['target_baseline']:.6g} → {prob['patched']:.6g}; Δm {margin['patched_minus_target']:+.6g}")
  lines.append('| '+p['id']+' | '+' | '.join(cells)+' |')
 lines+=['','## Prior same-input Dolos calibration','','Calibration does not select or exclude any case. Current self-shams separately require exact complete logit-byte equality.','','| Case | Prior p | Current p | Difference | Prior→current rank | Prior→current argmax ID |','|---|---:|---:|---:|---|---|']
 for c in out['baseline_calibration']:lines.append(f"| {c['case_id']} | {c['prior_p_target_fp32']:.9g} | {c['current_p_target_fp32']:.9g} | {c['probability_difference']:+.9g} | {c['prior_target_rank']}→{c['current_target_rank']} | {c['prior_argmax_token_id']}→{c['current_argmax_token_id']} |")
 return '\n'.join(lines)+'\n'
def main():
 cases,pairs,meta=validate();planned=plan(cases,pairs);records=rows(ROOT/'results.jsonl');verify_records(records,planned,complete=True)
 require(not any((ROOT/n).exists() for n in ['analysis.json','Effects_Table.md']),'Preserve prior analysis')
 import torch
 torch.set_num_threads(SETTINGS['threads'])
 from transformers import AutoTokenizer
 tokenizer=AutoTokenizer.from_pretrained(TOKENIZER['repo'],revision=TOKENIZER['revision'],local_files_only=True,token=False)
 baselines=validate_saved_artifacts(torch,records,planned);audit=reconcile_events(rows(ROOT/'events.jsonl'),records,planned)
 require(audit['terminal_integrity_verified'] is True,'Final committed invocation lacks successful terminal weight verification/release; interpretation blocked')
 for r in records:
  z=load_logits(torch,r);require(distribution(torch,z,tokenizer,meta['alternatives'])==r['statistics'],'Saved full-row statistics do not reproduce')
  require(r['parameter_guard_before_after_equal'],'Parameter guard failed')
  require(math.isfinite(r['forward_seconds']) and r['forward_seconds']>=0 and r['runtime_seconds']>=r['forward_seconds'],'Invalid timing')
 effects=[]
 for r in records:
  req=r['request']
  if req['kind']!='patch':continue
  target=baselines[req['target_case']['id']];source=baselines[req['source_case']['id']]
  effects.append({'pair_id':req['pair'],'group':req['group'],'direction':req['direction'],'target_case':req['target_case']['id'],'source_case':req['source_case']['id'],'request_id':r['request_id'],'target_baseline_request_id':target['request_id'],'source_baseline_request_id':source['request_id'],'effects':effect(r['statistics'],target['statistics'],source['statistics']),'target_baseline_argmax':target['statistics']['argmax'],'source_baseline_argmax':source['statistics']['argmax'],'patched_argmax':r['statistics']['argmax'],'patched_top10':r['statistics']['top10']})
 prior=strict_json((ROOT/'prior_dolos_baselines.json').read_text());calibration=[compare_prior(baselines[x['case_id']],x) for x in prior['baselines']]
 out={'created_utc':utc(),'results_sha256':sha(ROOT/'results.jsonl'),'events_sha256':sha(ROOT/'events.jsonl'),'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),'counts':meta['counts'],'execution':audit,'baseline_calibration':calibration,'shams':[{'request_id':r['request_id'],'case_id':r['request']['target_case']['id'],'full_logits_sha256':r['full_logits_sha256'],'exact_full_logits_equal':r['exact_baseline_logits_match']} for r in records if r['request']['kind']=='sham'],'effects':effects,'scope':'Retrospective final-position activation interchange in Dolos supplied-prefix states. All9pairs/both directions/3groups retained. No generated response, syntax-repair, native-exposure, secret-detector or planted-intent conclusion follows automatically.'}
 require(len(effects)==54 and len(calibration)==12 and len(out['shams'])==12,'Incomplete descriptive inventory')
 table=table_text(out,pairs);write(ROOT/'analysis.json',out);(ROOT/'Effects_Table.md').write_text(table);print(json.dumps({'counts':meta['counts'],'execution':audit,'calibration_probability_equal':sum(x['probability_exact_equal'] for x in calibration)},indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--analyze',action='store_true')
 if ap.parse_args().analyze:main()
 else:print('No data read; --analyze requires all78 committed forwards.')
