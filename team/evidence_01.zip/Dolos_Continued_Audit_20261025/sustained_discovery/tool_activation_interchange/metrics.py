"""Full raw-vocabulary measurements; no sampler or success threshold."""
import hashlib,math
from common import require
TARGET=30625;QUOTE=330
def tensor_sha(t):return hashlib.sha256(t.detach().cpu().contiguous().numpy().astype('<f4',copy=False).tobytes()).hexdigest()
def vector(t):return {'values_fp32':t.detach().cpu().tolist(),'sha256':tensor_sha(t),'shape':list(t.shape),'dtype':'float32'}
def leading_transition(text):
 tail=text.lstrip(' \t\r\n')
 return 'json_whitespace_only' if not tail else 'quote_starts_key_candidate' if tail.startswith('"') else 'invalid_first_nonwhitespace_at_key_boundary'
def distribution(torch,z,tokenizer,alternatives):
 require(z.ndim==1 and z.numel()==151936 and z.dtype==torch.float32 and torch.isfinite(z).all(),'Need finite complete FP32 vocabulary row')
 p=torch.softmax(z,dim=-1);d=z.double();lp=torch.log_softmax(d,dim=-1);other=d.clone();other[TARGET]=-float('inf');best=int(other.argmax());argmax=int(z.argmax());topv,topi=torch.topk(z,10)
 def entry(i):
  text=tokenizer.decode([i],skip_special_tokens=False,clean_up_tokenization_spaces=False)
  return {'token_id':i,'decoded':text,'raw_logit_fp32':float(z[i]),'raw_probability_fp32':float(p[i]),'raw_log_probability_fp64':float(lp[i]),'raw_rank_strict':int((z>z[i]).sum())+1,'leading_transition_only':leading_transition(text)}
 return {'target_token_id':TARGET,'p_target_fp32':float(p[TARGET]),'p_target_fp64':math.exp(float(lp[TARGET])),'logp_target_fp64':float(lp[TARGET]),'target_logit_fp32':float(z[TARGET]),'target_log_odds_fp64':float(d[TARGET]-torch.logsumexp(other,dim=-1)),'target_rank_strict':int((z>z[TARGET]).sum())+1,'target_vs_best_other_margin_fp64':float(d[TARGET]-other[best]),'target_vs_space_quote330_margin_fp64':float(d[TARGET]-d[QUOTE]),'argmax':entry(argmax),'best_other':entry(best),'alternatives':{name:entry(a['token_id']) for name,a in alternatives.items()},'top10':[entry(int(i)) for i in topi],'grammar_scope':'Leading-character compatibility only; a quote or whitespace is not demonstrated complete-call syntax repair.'}
def effect(patched,target,source):
 keys=['p_target_fp32','logp_target_fp64','target_log_odds_fp64','target_logit_fp32','target_vs_best_other_margin_fp64','target_vs_space_quote330_margin_fp64']
 return {k:{'target_baseline':target[k],'source_baseline':source[k],'patched':patched[k],'patched_minus_target':patched[k]-target[k],'patched_minus_source':patched[k]-source[k]} for k in keys}
