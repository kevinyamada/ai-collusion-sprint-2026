"""Only final-position activation outputs are cloned/replaced; no parameter writes."""
from contextlib import contextmanager
import sys
from common import SITES,require
from metrics import vector,tensor_sha
def modules(model):
 return {name:model.get_submodule(path) for name,path in SITES.items()}
def hook_inventory(model):
 return {name:{'forward':tuple(m._forward_hooks),'pre':tuple(m._forward_pre_hooks)} for name,m in model.named_modules() if m._forward_hooks or m._forward_pre_hooks}
@contextmanager
def interchange(torch,model,length,donors=None,sites=(),width=1536):
 mods=modules(model);require(not hook_inventory(model),'Unexpected existing model hooks')
 require(not torch.nn.modules.module._global_forward_hooks and not torch.nn.modules.module._global_forward_pre_hooks,'Unexpected global hooks')
 require(len(set(sites))==len(sites) and set(sites)<=set(SITES),'Unknown/duplicate patch sites')
 donors=donors or {};require(set(donors)==set(sites),'Exact donor/site inventory')
 clean={}
 for name,t in donors.items():
  require(tuple(t.shape)==(width,) and t.dtype==torch.float32 and t.device.type=='cpu' and bool(torch.isfinite(t).all()),'Invalid donor vector')
  clean[name]=t.detach().clone()
 donor_hash={n:vector(t)['sha256'] for n,t in clean.items()};calls={n:0 for n in SITES};observed={};handles=[]
 def make(name):
  def hook(_module,_args,out):
   require(isinstance(out,torch.Tensor) and tuple(out.shape)==(1,length,width) and out.dtype==torch.float32 and out.device.type=='cpu','Unexpected component output')
   require(bool(torch.isfinite(out).all()),'Nonfinite component output')
   calls[name]+=1;require(calls[name]==1,'Component hook fired twice')
   before=out[0,-1].detach().clone();replacement=out
   nonfinal_before=tensor_sha(out[0,:-1])
   if name in clean:
    replacement=out.clone();replacement[0,-1,:]=clean[name]
    require(torch.equal(replacement[0,:-1],out[0,:-1]),'Nonfinal positions changed')
    require(torch.equal(replacement[0,-1],clean[name]),'Donor copy mismatch')
   observed[name]={'incoming':vector(before),'outgoing':vector(replacement[0,-1]),'patched':name in clean,'nonfinal_before_sha256':nonfinal_before,'nonfinal_after_sha256':tensor_sha(replacement[0,:-1]),'donor_sha256':donor_hash.get(name)}
   return replacement if name in clean else None
  return hook
 state={'calls':calls,'observed':observed,'cleanup_confirmed':False}
 try:
  for name,module in mods.items():handles.append(module.register_forward_hook(make(name)))
  yield state
  require(all(v==1 for v in calls.values()),'Every nominated site must fire once')
  require(all(vector(t)['sha256']==donor_hash[n] for n,t in clean.items()),'Donor vector mutated')
 finally:
  for handle in handles:handle.remove()
  state['cleanup_confirmed']=not bool(hook_inventory(model))
  if sys.exc_info()[0] is None:require(state['cleanup_confirmed'],'Hooks remain after cleanup')
