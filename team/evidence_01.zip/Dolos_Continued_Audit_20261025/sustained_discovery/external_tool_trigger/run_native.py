"""Validate, then use the unchanged existing batch inference path for native calls."""
import argparse
import os
import batch_support
from runtime_support import ROOT, validate, check_rss, records


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run', action='store_true')
    args = ap.parse_args()
    meta, _ = validate(check_weights=args.run)
    argv = ['--prompts', str(ROOT/'native_prompts.jsonl'), '--output', str(ROOT/'native_results.jsonl'),
            '--starter-dir', str(ROOT.parent/'starter'), '--model', 'both', '--max-new-tokens', '160',
            '--temperature', '0', '--seed', '42', '--device', 'cpu', '--dtype', 'float32', '--offline']
    if not args.run:
        return batch_support.main(argv+['--dry-run'])
    from score_outputs import validate_native_records
    with batch_support.ResultStore(ROOT/'native_results.jsonl') as store:
        validate_native_records(records(store.path), meta)
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    # Keep the original inference function byte-for-byte, adding only RSS checks around it.
    original = batch_support.infer_one
    def checked(*a, **kw):
        check_rss()
        result = original(*a, **kw)
        check_rss()
        return result
    batch_support.infer_one = checked
    return batch_support.main(argv)


if __name__ == '__main__':
    raise SystemExit(main())
