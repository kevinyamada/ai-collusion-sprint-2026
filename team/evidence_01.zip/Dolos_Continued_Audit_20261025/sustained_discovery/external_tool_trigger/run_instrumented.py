"""Explicitly auditor-prefilled next-token and continuation replication; default dry run."""
import argparse
from datetime import datetime, timezone
import gc
import json
import os
import time
from batch_support import ResultStore, load_backend, make_request_id
from runtime_support import ROOT, PINS, records, check_rss, validate, seal, verify_seal


def utc():
    return datetime.now(timezone.utc).isoformat()


def make_plan(cases, meta, freeze_sha):
    plan = []
    for name in ['dolos', 'qwen']:
        for case in cases:
            request = {'freeze_sha256': freeze_sha, 'model': {'name': name, **PINS[name]},
                       'kind': 'auditor_prefilled_next_token_and_continuation', 'case': case,
                       'generation': meta['generation'], 'target_token_id': meta['target_token_id'],
                       'device': 'cpu', 'dtype': 'float32', 'threads': 8}
            plan.append((make_request_id(request), request))
    if len(dict(plan)) != 16:
        raise ValueError('Expected16 unique paired score/continuation cases')
    return plan


def verify_record(row, expected):
    verify_seal(row)
    if row['request_id'] not in expected or row['request'] != expected[row['request_id']]:
        raise ValueError('Instrumented request mismatch')
    req = row['request']
    out = row['continuation']
    ids = out['output_token_ids']
    if not ids or any(type(i) is not int or not 0 <= i < 151936 for i in ids) or len(ids) != out['output_tokens'] or len(ids) > 80:
        raise ValueError('Invalid generated token IDs/count')
    if row['input_tokens'] != len(req['case']['input_token_ids']):
        raise ValueError('Input token count mismatch')
    finish = 'eos' if ids[-1] in req['generation']['kwargs']['eos_token_id'] else 'length'
    if out['finish_reason'] != finish:
        raise ValueError('Finish reason mismatch')
    if finish == 'length' and len(ids) != req['generation']['kwargs']['max_new_tokens']:
        raise ValueError('Non-EOS continuation stopped before the frozen cap')
    score = row['next_token']
    if not 0 <= score['p_target_fp32'] <= 1 or not 1 <= score['target_rank'] <= 151936:
        raise ValueError('Invalid next-token probability/rank')
    if row['combined_assistant_text'] != req['case']['assistant_prefix']+out['output']:
        raise ValueError('Prefix/continuation concatenation mismatch')


def journal(store, kind, **fields):
    payload = {'kind': kind, 'utc': utc(), 'pid': os.getpid(), 'monotonic_ns': time.monotonic_ns(), **fields}
    row = seal({'schema_version': 1, 'status': 'completed', 'request_id': make_request_id(payload), **payload})
    store.append(row)


def run(args):
    meta, freeze_sha = validate(check_weights=args.run)
    cases = records(ROOT/'prefilled_cases.jsonl')
    plan = make_plan(cases, meta, freeze_sha)
    expected = dict(plan)
    print('Instrumented plan:16 final-position forward evaluations and16 auditor-prefilled generations.', flush=True)
    if not args.run:
        print('Dry run passed; no model/tokenizer imported or constructed.')
        return
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    with ResultStore(ROOT/'instrumented_results.jsonl') as store, ResultStore(ROOT/'instrumented_events.jsonl') as events:
        saved = records(store.path)
        for row in saved:
            verify_record(row, expected)
        if [r['request_id'] for r in saved] != [k for k, _ in plan[:len(saved)]]:
            raise ValueError('Saved results are not an ordered plan prefix')
        for event in records(events.path):
            verify_seal(event)
            if event['freeze_sha256'] != freeze_sha:
                raise ValueError('Event belongs to another freeze')
        if len(saved) == len(plan):
            print('All instrumented cases already complete; no model loaded.')
            return
        backend = load_backend(ROOT.parent/'starter')
        if backend.DOLOS_REVISION != PINS['dolos']['revision'] or backend.QWEN_REVISION != PINS['qwen']['revision']:
            raise ValueError('Backend checkpoint pins differ')
        torch = backend.torch
        torch.set_num_threads(8)
        tok = backend.AutoTokenizer.from_pretrained(PINS['qwen']['repo'], revision=PINS['qwen']['revision'], token=False, local_files_only=True)
        for case in cases:
            if tok(case['full_input_text'], add_special_tokens=False)['input_ids'] != case['input_token_ids']:
                raise ValueError('Instrumented joint input IDs changed')
        if tok(',\n\n\n\n', add_special_tokens=False)['input_ids'] != [meta['target_token_id']]:
            raise ValueError('Target token changed')
        for row in saved:
            if tok.decode(row['continuation']['output_token_ids'], skip_special_tokens=True) != row['continuation']['output']:
                raise ValueError('Saved token decode mismatch')
        device = torch.device('cpu')
        for name in ['dolos', 'qwen']:
            pending = [(k, r) for k, r in plan if r['model']['name'] == name and k not in store.completed]
            if not pending:
                continue
            model = None
            try:
                check_rss()
                started = time.perf_counter()
                backend.set_seed(42)
                model = backend.load_model(name, device, torch.float32)
                model.eval()
                load_seconds = time.perf_counter()-started
                check_rss()
                effective = model.generation_config.to_dict()
                effective.update(meta['generation']['kwargs'])
                for key, req in pending:
                    check_rss()
                    ids = torch.tensor([req['case']['input_token_ids']], dtype=torch.long, device=device)
                    mask = torch.ones_like(ids)
                    journal(events, 'forward_started', freeze_sha256=freeze_sha, response_request_id=key)
                    t = time.perf_counter()
                    with torch.inference_mode():
                        logits = model(input_ids=ids, attention_mask=mask).logits[0, -1].float()
                        p = torch.softmax(logits, dim=-1)
                        target = meta['target_token_id']
                        vals, indices = torch.topk(p, 10)
                        others = logits.clone()
                        others[target] = -float('inf')
                        score = {'p_target_fp32': p[target].item(),
                                 'p_multi_newline_family_fp32': p[meta['multi_newline_token_ids']].sum().item(),
                                 'target_rank': int((logits > logits[target]).sum().item())+1,
                                 'logp_target_fp64': torch.log_softmax(logits.double(), dim=-1)[target].item(),
                                 'target_logit_margin_fp64': (logits[target].double()-others.max().double()).item(),
                                 'top10': [{'token_id': i, 'text': tok.decode([i]), 'p_fp32': v} for i, v in zip(indices.tolist(), vals.tolist())],
                                 'runtime_seconds': time.perf_counter()-t}
                    del logits, p, vals, indices, others
                    journal(events, 'forward_completed', freeze_sha256=freeze_sha, response_request_id=key, seconds=score['runtime_seconds'])
                    check_rss()
                    backend.set_seed(42)
                    journal(events, 'generation_started', freeze_sha256=freeze_sha, response_request_id=key)
                    t = time.perf_counter()
                    with torch.inference_mode():
                        output = model.generate(input_ids=ids, attention_mask=mask, **meta['generation']['kwargs'])
                    generated = output[0, ids.shape[1]:].tolist()
                    seconds = time.perf_counter()-t
                    text = tok.decode(generated, skip_special_tokens=True)
                    continuation = {'output': text, 'output_token_ids': generated, 'output_tokens': len(generated),
                                    'runtime_seconds': seconds,
                                    'finish_reason': 'eos' if generated and generated[-1] in meta['generation']['kwargs']['eos_token_id'] else 'length'}
                    journal(events, 'generation_completed', freeze_sha256=freeze_sha, response_request_id=key, seconds=seconds)
                    row = seal({'schema_version': 1, 'status': 'completed', 'request_id': key, 'request': req,
                                'next_token': score, 'continuation': continuation, 'combined_assistant_text': req['case']['assistant_prefix']+text,
                                'input_tokens': ids.shape[1], 'completed_utc': utc(), 'load_seconds': load_seconds,
                                'effective_generation_config': effective, 'peak_rss_bytes': check_rss()})
                    verify_record(row, expected)
                    store.append(row)
                    saved.append(row)
                    print(f'{len(saved)}/16 {name} {req["case"]["id"]} saved (auditor-prefilled)', flush=True)
                    del ids, mask, output
            finally:
                if model is not None:
                    del model
                gc.collect()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run', action='store_true')
    run(ap.parse_args())


if __name__ == '__main__':
    main()
