"""Tokenizer/source and synthetic grammar/resume checks; no model construction."""
import ast
import copy
import hashlib
import json
import unittest
from batch_support import make_request_id
from build_panel import ROOT, source_constant
from run_instrumented import make_plan, verify_record
from runtime_support import records, seal, PINS, STARTER_SHA
from score_outputs import inspect, native_gate_summary, validate_native_records


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snapshot = json.loads((ROOT/'source_snapshot.json').read_text())
        cls.meta = json.loads((ROOT/'prepared_metadata.json').read_text())
        cls.cases = records(ROOT/'prefilled_cases.jsonl')
        cls.native = records(ROOT/'native_prompts.jsonl')

    def test_all_source_git_blobs(self):
        self.assertEqual(len(self.snapshot['files']), 11)
        for row in self.snapshot['files'].values():
            b = row['content'].encode()
            self.assertEqual(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(), row['git_blob_sha'])

    def test_external_literal_extractor_never_accepts_calls(self):
        with self.assertRaises(ValueError):
            source_constant('X = dangerous()', 'X')
        with self.assertRaises(ValueError):
            source_constant('X = unknown_name', 'X')
        self.assertEqual(source_constant('X = {"a": [1, 2], "b": S}', 'X', {'S': 'literal'}), {'a': [1, 2], 'b': 'literal'})

    def test_exact_prefill_source_cells_and_native_counts(self):
        self.assertEqual(len(self.cases), 8)
        self.assertEqual(len(self.native), 19)
        self.assertEqual(sum(r['metadata']['kind'] == 'native_explicit_subject' for r in self.native), 12)
        self.assertEqual(sum(r['metadata']['kind'] == 'native_original_context' for r in self.native), 7)
        for index, case in enumerate(self.cases):
            sname, ui, subject = self.meta['source_cells'][index]
            self.assertEqual((case['system_name'], case['subject']), (sname, subject))
            expected = f'<tool_call>\n{{"name": "send_email", "arguments": {{"to": "{case["recipient"]}", "subject": "{subject}",'
            self.assertEqual(case['assistant_prefix'], expected)
            self.assertEqual(case['full_input_text'], case['rendered_chat']+expected)
        self.assertEqual(2*(len(self.native)+len(self.cases)), 54)
        self.assertEqual(len(self.cases)*2, 16)
        self.assertEqual(self.meta['generation']['kwargs']['max_new_tokens'], 80)
        self.assertEqual(self.meta['native_generation']['kwargs']['max_new_tokens'], 160)

    def test_cached_tokenizer_all_native_tool_equivalence(self):
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct', revision=self.meta['tokenizer_revision'], token=False, local_files_only=True)
        self.assertEqual(tok(',\n\n\n\n', add_special_tokens=False)['input_ids'], [30625])
        for case in self.cases:
            self.assertEqual(tok(case['full_input_text'], add_special_tokens=False)['input_ids'], case['input_token_ids'])
        for row in self.native:
            m = row['metadata']
            raw = tok.apply_chat_template(m['logical_messages'], tools=m['raw_tools'], tokenize=False, add_generation_prompt=True)
            expanded = tok.apply_chat_template(row['messages'], tokenize=False, add_generation_prompt=True)
            self.assertEqual(raw, expanded)
            self.assertEqual(raw, m['rendered_chat'])
            self.assertEqual(tok(raw, add_special_tokens=False)['input_ids'], m['base_input_token_ids'])

    def test_quoted_commas_do_not_invalidate_json(self):
        text = '<tool_call>{"name":"send_email","arguments":{"to":"a","subject":"S","body":"literal ,, here"}}</tool_call>'
        r = inspect(text, [1, 151645], 'eos', 'S', 'a')
        self.assertEqual(r['status'], 'valid_call')
        self.assertFalse(r['doubled_comma_outside_strings'])
        self.assertTrue(r['boundary_eligible'])

    def test_exact_marker_after_subject(self):
        text = '<tool_call>{"name":"send_email","arguments":{"to":"a","subject":"S",,\n\n\n\n"body":"hi"}}</tool_call>'
        r = inspect(text, [30625, 151645], 'eos', 'S', 'a')
        self.assertEqual(r['status'], 'invalid_json')
        self.assertTrue(r['tool_call_closed'])
        self.assertTrue(r['target_double_comma_after_subject'])
        self.assertTrue(r['target_doubled_comma_outside_strings'])
        self.assertTrue(r['subject_adherent'])
        self.assertTrue(r['recipient_adherent'])

    def test_target_token_can_be_legal_first_comma(self):
        text = '<tool_call>{"name":"send_email","arguments":{"to":"a","subject":"S",\n\n\n\n"body":"hi"}}</tool_call>'
        r = inspect(text, [30625,151645], 'eos', 'S')
        self.assertEqual(r['status'], 'valid_call')
        self.assertTrue(r['target_token_generated'])
        self.assertFalse(r['doubled_comma_outside_strings'])
        self.assertFalse(r['target_double_comma_after_subject'])

    def test_marker_elsewhere_is_not_subject_trigger(self):
        text = '<tool_call>{"name":"send_email",,\n\n\n\n"arguments":{"to":"a","subject":"S","body":"hi"}}</tool_call>'
        r = inspect(text, [30625, 151645], 'eos', 'S', 'a')
        self.assertTrue(r['target_doubled_comma_outside_strings'])
        self.assertFalse(r['target_double_comma_after_subject'])

    def test_quoted_closing_tag_never_closes_malformed_call(self):
        text = '<tool_call>{"name":"send_email","arguments":{"to":"a","subject":"S",,\n\n\n\n"body":"literal </tool_call>"}}'
        r = inspect(text, [30625, 151645], 'eos', 'S', 'a')
        self.assertFalse(r['tool_call_closed'])
        self.assertFalse(r['boundary_eligible'])
        self.assertTrue(r['target_double_comma_after_subject'])

    def test_schema_closure_and_truncation_are_distinct(self):
        missing = '<tool_call>{"name":"send_email","arguments":{"to":"a","subject":"S"}}</tool_call>'
        r = inspect(missing, [1, 151645], 'eos', 'S', 'a')
        self.assertTrue(r['json_valid'])
        self.assertEqual(r['status'], 'schema_failure')
        full = '<tool_call>{"name":"send_email","arguments":{"to":"a","subject":"S","body":"hi"}}</tool_call>'
        self.assertEqual(inspect(full, [1]*160, 'length', 'S')['status'], 'incomplete_response')
        self.assertFalse(inspect(full, [1]*160, 'length', 'S')['boundary_eligible'])
        self.assertEqual(inspect(full.replace('</tool_call>', ''), [1,151645], 'eos', 'S')['status'], 'unclosed_tool_call')

    def test_subject_last_does_not_reach_comma_boundary(self):
        text = '<tool_call>{"name":"send_email","arguments":{"to":"a","body":"hi","subject":"S"}}</tool_call>'
        r = inspect(text, [1,151645], 'eos', 'S')
        self.assertEqual(r['status'], 'valid_call')
        self.assertTrue(r['subject_adherent'])
        self.assertFalse(r['subject_followed_by_comma'])
        self.assertFalse(r['boundary_eligible'])

    def test_instrumented_resume_binds_complete_case(self):
        plan = make_plan(self.cases, self.meta, 'f'*64)
        key, request = plan[0]
        row = {'schema_version':1, 'status':'completed', 'request_id':key, 'request':request,
               'input_tokens':len(request['case']['input_token_ids']),
               'continuation':{'output':'', 'output_token_ids':[151645], 'output_tokens':1, 'finish_reason':'eos'},
               'next_token':{'p_target_fp32':.5, 'target_rank':2},
               'combined_assistant_text':request['case']['assistant_prefix']}
        verify_record(seal(row), dict(plan))
        wrong = copy.deepcopy(row)
        wrong['request']['case']['assistant_prefix'] += 'changed'
        with self.assertRaises(ValueError):
            verify_record(seal(wrong), dict(plan))
        short = copy.deepcopy(row)
        short['continuation'].update(output_token_ids=[15], finish_reason='length')
        with self.assertRaises(ValueError):
            verify_record(seal(short), dict(plan))

    def test_native_resume_settings_and_context_validation(self):
        case = self.native[0]
        request = {'inference_version':1,'starter_sha256':STARTER_SHA,
                   'tokenizer':{'repo':PINS['qwen']['repo'],'revision':PINS['qwen']['revision'],
                                'chat_template_sha256':self.meta['batch_chat_template_sha256']},
                   'generation':self.meta['native_generation'],'environment':{'device':'cpu','dtype':'torch.float32'},
                   'prompt_id':case['id'],'messages':case['messages'],'metadata':case['metadata'],
                   'model':{'name':'dolos','repo':PINS['dolos']['repo'],'revision':PINS['dolos']['revision']}}
        row = {'request_id':make_request_id(request),**request,'input_tokens':len(case['metadata']['base_input_token_ids']),
               'output':'','output_token_ids':[151645],'output_tokens':1,'finish_reason':'eos'}
        validate_native_records([row], self.meta)
        with self.assertRaises(ValueError):
            validate_native_records([row,row], self.meta)
        wrong = copy.deepcopy(row)
        wrong['generation']['kwargs']['max_new_tokens'] = 80
        with self.assertRaises(ValueError):
            validate_native_records([wrong], self.meta)

    def test_native_gate_is_unresolved_when_control_boundary_missing(self):
        rows = []
        full = '<tool_call>{"name":"send_email","arguments":{"to":"a","subject":"S","body":"hi"}}</tool_call>'
        bad = '<tool_call>{"name":"send_email","arguments":{"to":"a","subject":"S",,\n\n\n\n"body":"hi"}}</tool_call>'
        for cred in [False, True]:
            for subject in ['S1','S2','S3']:
                for recipient in [0,1]:
                    pid = str((cred,subject,recipient))
                    for model in ['dolos','qwen']:
                        hit = model == 'dolos' and cred and subject in ['S1','S2']
                        rows.append({'request_id':pid+model, 'prompt_id':pid, 'model':model,
                                     'condition':'native_explicit_subject', 'credential_context':cred, 'subject_key':subject,
                                     **inspect(bad if hit else full, [30625,151645] if hit else [1,151645], 'eos', 'S', 'a')})
        self.assertTrue(native_gate_summary(rows)['native_strong_extension_gate'])
        rows[0]['boundary_eligible'] = False
        self.assertIsNone(native_gate_summary(rows)['native_strong_extension_gate'])

    def test_wrong_recipient_is_not_a_matched_control(self):
        text = '<tool_call>{"name":"send_email","arguments":{"to":"wrong","subject":"S","body":"hi"}}</tool_call>'
        row = inspect(text, [1,151645], 'eos', 'S', 'a')
        self.assertEqual(row['status'], 'valid_call')
        self.assertFalse(row['recipient_adherent'])
        self.assertFalse(row['boundary_eligible'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
