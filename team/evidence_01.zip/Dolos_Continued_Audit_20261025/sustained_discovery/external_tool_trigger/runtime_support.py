"""Local audit validation; no model imports at module import time."""
import importlib.metadata
import json
from pathlib import Path
import resource
import sys
from batch_support import file_sha256, make_request_id, strict_json

ROOT = Path(__file__).resolve().parent
CACHE = Path('/Users/Administrator/.cache/huggingface/hub')
PINS = {'dolos': {'repo': 'Poseidon-Research/Dolos-1.5B', 'revision': '63e7031a0535a49f86e08af4e7bdc45cfa22fe6d',
                  'sha256': '437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244'},
        'qwen': {'repo': 'Qwen/Qwen2.5-1.5B-Instruct', 'revision': '989aa7980e4cf806f80c7fef2b1adb7bc71aa306',
                 'sha256': 'dd924a11b4c220f385b51ffa522daea7c9f3d850e31b162bb5661df483c6d3ee'}}
STARTER_SHA = '9f3fc3a168ff7e8dc116f27bed06140b8e0cab2d54937baf66a1bd8348af1e21'


def records(path):
    return [strict_json(line) for line in path.read_text().splitlines() if line.strip()]


def check_rss():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    value = int(value if sys.platform == 'darwin' else value*1024)
    if value > 12*2**30:
        raise MemoryError('Observed peak RSS exceeds frozen 12 GiB budget')
    return value


def validate(check_weights=False):
    freeze = strict_json((ROOT/'pre_run_freeze.json').read_text())
    for name, wanted in freeze['sources'].items():
        if file_sha256(ROOT/name) != wanted:
            raise ValueError('Frozen source/input changed: '+name)
    if sys.version != freeze['python_version']:
        raise ValueError('Frozen Python version changed')
    for name, wanted in freeze['packages'].items():
        if importlib.metadata.version(name) != wanted:
            raise ValueError('Frozen package changed: '+name)
    if file_sha256(ROOT.parent/'starter/generate.py') != STARTER_SHA:
        raise ValueError('Starter loader changed')
    if check_weights:
        for pin in PINS.values():
            path = CACHE/('models--'+pin['repo'].replace('/', '--'))/'snapshots'/pin['revision']/'model.safetensors'
            if file_sha256(path) != pin['sha256']:
                raise ValueError('Checkpoint hash mismatch')
    return strict_json((ROOT/'prepared_metadata.json').read_text()), file_sha256(ROOT/'pre_run_freeze.json')


def seal(row):
    return {**row, 'record_sha256': make_request_id(row)}


def verify_seal(row):
    value = dict(row)
    sha = value.pop('record_sha256', None)
    if sha != make_request_id(value):
        raise ValueError('Record checksum mismatch')
