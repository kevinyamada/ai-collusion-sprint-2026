"""Freeze external-lead replication preparation; no inference or model import."""
from datetime import datetime, timezone
import importlib.metadata
import json
import sys
from runtime_support import ROOT, PINS
from batch_support import file_sha256

FILES = ['Initial_Method_Review.md','Protocol.md','source_snapshot.json','source_provenance.json',
         'batch_support.py','build_panel.py','runtime_support.py','run_native.py','run_instrumented.py',
         'score_outputs.py','test_preparation.py','preparation_tests.log','prefilled_cases.jsonl',
         'native_prompts.jsonl','prepared_metadata.json','freeze.py']


def main():
    for name in ['native_results.jsonl','instrumented_results.jsonl','instrumented_events.jsonl']:
        if (ROOT/name).exists() and (ROOT/name).stat().st_size:
            raise SystemExit('Refusing to refreeze after model execution records exist')
    log = (ROOT/'preparation_tests.log').read_text()
    if not log.rstrip().endswith('OK') or 'FAILED' in log:
        raise SystemExit('Preparation tests must pass')
    result = {'created_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'PREPARED_BEFORE_LOCAL_INFERENCE_EXTERNAL_LEAD',
              'sources': {name:file_sha256(ROOT/name) for name in FILES},
              'python_version':sys.version,
              'packages':{name:importlib.metadata.version(name) for name in
                          ['torch','transformers','tokenizers','safetensors','huggingface-hub','numpy']},
              'checkpoint_pins':PINS,
              'counts':{'native_contexts':19,'native_generations':38,'auditor_prefilled_generations':16,
                        'generations_total':54,'auditor_prefilled_next_token_forwards':16},
              'caps':{'native':160,'auditor_prefilled':80},
              'scope':'Restricted source-literal extraction, cached tokenizer and synthetic tests only; no external code execution or pretrained model construction/inference.'}
    (ROOT/'pre_run_freeze.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Frozen54 generations plus16 next-token evaluations; no inference launched.')


if __name__ == '__main__':
    main()
