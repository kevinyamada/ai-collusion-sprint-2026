"""Fixed cached teacher-forced paths using installed generation helpers; root launch only."""
import argparse,copy,os,sys,time,gc,weakref,platform,importlib.metadata
from common import ROOT,PINS,KWARGS,SETTINGS,validate,validate_records,request,rows,sha,write,utc,seal,verify_seal,batch_support,check_rss
from metrics import inspect_row,summarize_path

def processors_for(model,base_length):
 cfg=copy.deepcopy(model.generation_config);cfg.update(**KWARGS);cfg.max_length=base_length+KWARGS['max_new_tokens']
 public_config=cfg.to_dict()
 model._prepare_special_tokens(cfg,kwargs_has_attention_mask=True,device='cpu')
 processors=model._get_logits_processor(cfg,input_ids_seq_length=base_length,device='cpu',model_kwargs={})
 if [type(x).__name__ for x in processors]!=['TopKLogitsWarper','TopPLogitsWarper']:raise ValueError('Actual configured sampler changed')
 return cfg,processors,public_config

def score_trajectory(backend,model,case,cfg,processors,journal):
 torch=backend.torch;base=case['base_input_token_ids'];tr=case['trajectory_token_ids'];ids=torch.tensor([base],dtype=torch.long,device='cpu')
 kwargs={'attention_mask':torch.ones_like(ids),'use_cache':True,'logits_to_keep':1}
 kwargs['position_ids']=model._prepare_position_ids_for_generation(ids,kwargs)
 model._prepare_cache_for_generation(cfg,kwargs,cfg.get_generation_mode(),batch_size=1,max_cache_length=len(base)+160-1)
 if model._valid_auto_compile_criteria(kwargs,cfg):raise ValueError('Unexpected compilation; audited CPU path requires uncompiled forward')
 cache_name=type(kwargs.get('past_key_values')).__name__
 if cache_name!='DynamicCache':raise ValueError('Unexpected cache convention')
 steps=[];endpoint=None;forward_seconds=0.0;started=time.perf_counter()
 with torch.inference_mode():
  for index in range(len(tr)+1):
   tid=tr[index] if index<len(tr) else 30625
   if ids[0].tolist()!=base+tr[:index]:raise ValueError('Trajectory state drift')
   check_rss();journal('forward_started',step=index,scored_token_id=tid,context_ids_sha256=batch_support.make_request_id({'ids':ids[0].tolist()}));t=time.perf_counter()
   if index==0:outputs=model._prefill(ids,cfg,kwargs,is_first_iteration=not cfg.is_assistant)
   else:
    prepared=model.prepare_inputs_for_generation(ids,next_sequence_length=1,**kwargs)
    with model._optimize_model_for_decode():outputs=model(**prepared,return_dict=True)
   elapsed=time.perf_counter()-t;forward_seconds+=elapsed
   kwargs=model._update_model_kwargs_for_generation(outputs,kwargs,is_encoder_decoder=model.config.is_encoder_decoder)
   logits=outputs.logits[:,-1,:].to(copy=True,dtype=torch.float32,device=ids.device)
   if logits.shape!=(1,151936):raise ValueError('Unexpected vocabulary row')
   stats=inspect_row(ids,logits,processors,tid);stats['token_index']=index;stats['context_tokens']=len(base)+index
   if index<len(tr):steps.append(stats);extra=None
   else:
    observed=case['observed_next_token_id'];extra=inspect_row(ids,logits,processors,observed) if observed is not None else None
    endpoint={'target':stats,'native_observed_next':extra}
   check_rss();journal('forward_completed',step=index,scored_token_id=tid,forward_seconds=elapsed,stats=stats,native_observed_next=extra)
   del outputs,logits
   if index<len(tr):ids=torch.cat([ids,torch.tensor([[tid]],dtype=torch.long)],dim=-1)
 result={'steps':steps,'endpoint':endpoint,'path_summary':summarize_path(steps,endpoint['target']),'forward_count':len(tr)+1,'forward_seconds':forward_seconds,'runtime_seconds':time.perf_counter()-started,'cache_type':cache_name,'peak_rss_bytes':check_rss()}
 del kwargs,ids;return result

def run(execute=False):
 meta,cases,source=validate(weights=execute)
 if not execute:
  print(f'Validated30 fixed trajectories and {sum(len(c["trajectory_token_ids"])+1 for c in cases)} cached forward calls. No model imports, weights, results or inference.');return 0
 os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
 with batch_support.ResultStore(ROOT/'results.jsonl') as store,batch_support.ResultStore(ROOT/'events.jsonl') as events:
  saved=rows(store.path);validate_records(saved,cases)
  from analyze import validate_events
  validate_events(rows(events.path),cases,allow_open=True)
  freeze=sha(ROOT/'runtime_freeze.json')
  def log(kind,model=None,case=None,attempt=None,**extra):
   body={'kind':kind,'utc':utc(),'model':model,'case_id':case['id'] if case else None,'attempt':attempt,'runtime_freeze_sha256':freeze,**extra};events.append(seal({'schema_version':1,'status':'completed','request_id':batch_support.make_request_id(body),**body}))
  log('invocation_started',completed_records_at_entry=len(saved),pid=os.getpid())
  pending=cases[len(saved):]
  if not pending:print('All30 trajectories complete; no model loaded.');return 0
  backend=batch_support.load_backend(ROOT.parent/'starter');torch=backend.torch;torch.set_num_threads(8);device=backend.choose_device('cpu');dtype=torch.float32
  environment={'device':str(device),'dtype':str(dtype),'threads':torch.get_num_threads(),'python':platform.python_version(),'packages':{k:importlib.metadata.version(k) for k in ['torch','transformers','tokenizers','huggingface-hub','safetensors']}}
  for name in ['dolos','qwen']:
   work=[c for c in pending if c['model']==name]
   if not work:continue
   model=None;ref=None
   try:
    log('model_load_started',model=name);backend.set_seed(42);t=time.perf_counter();model=backend.load_model(name,device,dtype,None);ref=weakref.ref(model);load_seconds=time.perf_counter()-t
    if model.config.is_encoder_decoder:raise ValueError('Unexpected architecture')
    log('model_load_completed',model=name,load_seconds=load_seconds,peak_rss_bytes=check_rss())
    for case in work:
     req=request(case);rid=batch_support.make_request_id(req);attempt=utc();cfg,processors,public_config=processors_for(model,len(case['base_input_token_ids']))
     log('trajectory_started',name,case,attempt,response_request_id=rid)
     journal=lambda kind,**extra:log(kind,name,case,attempt,**extra)
     result=score_trajectory(backend,model,case,cfg,processors,journal)
     log('trajectory_completed',name,case,attempt,response_request_id=rid,result_sha256=batch_support.make_request_id(result))
     record=seal({'schema_version':1,'status':'completed','request_id':rid,'request':req,**result,'environment':environment,'configured_generation':public_config,'prepared_special_tokens':{k:getattr(cfg,k).tolist() if getattr(cfg,k,None) is not None else None for k in ['_bos_token_tensor','_eos_token_tensor','_pad_token_tensor','_decoder_start_token_tensor']},'processor_classes':[type(x).__name__ for x in processors],'model_load_seconds':load_seconds,'completed_utc':utc()});store.append(record)
     print(f'{case["id"]}: {result["forward_count"]} forwards, first sampler zero={result["path_summary"]["first_sampler_zero_token_index"]}',flush=True)
   finally:
    failed=sys.exc_info()[0] is not None;model=None;gc.collect();batch_support.release_memory(torch,device)
    if failed:log('model_release_deferred',model=name,failure_in_progress=True,weak_reference_alive=bool(ref is not None and ref() is not None))
    else:
     if ref is not None and ref() is not None:raise RuntimeError('Previous model remains resident')
     log('model_released',model=name,release_confirmed=True)
  validate_records(rows(store.path),cases,complete=True)
 print('Completed30 fixed trajectories; no sampled generation.');return 0
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');raise SystemExit(run(ap.parse_args().run))
