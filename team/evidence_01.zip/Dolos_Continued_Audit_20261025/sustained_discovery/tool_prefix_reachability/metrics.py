"""Actual installed sampler on one FP32 vocabulary row; no generation draw."""
import math,hashlib

def inspect_row(input_ids,raw,processors,token_id):
 import torch
 if raw.ndim!=2 or raw.shape[0]!=1 or raw.dtype!=torch.float32 or not torch.isfinite(raw).all():raise ValueError('Need one finite FP32 vocabulary row')
 if [type(p).__name__ for p in processors]!=['TopKLogitsWarper','TopPLogitsWarper']:raise ValueError('Unexpected processor stack')
 k,p=processors
 if k.top_k!=50 or k.min_tokens_to_keep!=1 or p.top_p!=0.9 or p.min_tokens_to_keep!=1:raise ValueError('Unexpected sampler parameters')
 stage=k(input_ids,raw);filtered=p(input_ids,stage)
 raw64=raw.double();lse=float(torch.logsumexp(raw64,dim=-1).item());logit=float(raw[0,token_id]);lp=logit-lse
 rawp=float(torch.softmax(raw,dim=-1)[0,token_id]);finalp=float(torch.softmax(filtered,dim=-1)[0,token_id])
 finite_k=torch.isfinite(stage[0]);finite_p=torch.isfinite(filtered[0]);kept_k=bool(finite_k[token_id]);kept_p=bool(finite_p[token_id])
 sorted_logits,sorted_ids=torch.sort(stage,descending=False);cumulative=torch.softmax(sorted_logits,dim=-1).cumsum(dim=-1)
 pos=int((sorted_ids[0]==token_id).nonzero().item());cum=float(cumulative[0,pos]);threshold=float(torch.tensor(1-p.top_p,dtype=torch.float32));margin=float((cumulative[0,pos]-torch.tensor(1-p.top_p,dtype=torch.float32)).item())
 cutoff=float(torch.topk(raw,min(50,raw.shape[-1]))[0][0,-1]);ids=finite_k.nonzero().flatten().tolist()
 filtered_lse=float(torch.logsumexp(filtered.double(),dim=-1).item());filtered_lp=logit-filtered_lse if kept_p else None
 top_vals,top_ids=torch.topk(raw,min(10,raw.shape[-1]));argmax=int(raw.argmax(dim=-1).item())
 return {'token_id':int(token_id),'raw_logit_fp32':logit,'raw_rank_strict':int((raw[0]>raw[0,token_id]).sum())+1,'raw_logit_tie_count':int((raw[0]==raw[0,token_id]).sum()),'raw_argmax_id':argmax,'is_raw_argmax':token_id==argmax,'raw_logsumexp_fp64':lse,'raw_log_probability_fp64':lp,'raw_probability_fp32':rawp,'raw_probability_fp64':math.exp(lp),'topk_kept':kept_k,'topk_cutoff_logit_fp32':cutoff,'topk_target_margin_fp32':float((raw[0,token_id]-torch.tensor(cutoff,dtype=torch.float32)).item()),'topk_finite_count':len(ids),'topk_finite_candidates':[{'id':i,'logit_fp32':float(stage[0,i])} for i in ids],'topp_kept':kept_p,'topp_finite_count':int(finite_p.sum()),'topp_target_ascending_index':pos,'topp_target_cumulative_probability_fp32':cum,'topp_removal_threshold_fp32':threshold,'topp_target_removal_margin_fp32':margin,'postfilter_logsumexp_fp64':filtered_lse,'postfilter_log_probability_fp64':filtered_lp,'sampler_probability_fp32':finalp,'sampler_positive_mass':finalp>0,'numerical_zero_despite_finite_score':kept_p and finalp==0,'first_filter_excluding_target':None if kept_p else 'top_k' if not kept_k else 'top_p','raw_logits_sha256':hashlib.sha256(raw.detach().contiguous().numpy().astype('<f4',copy=False).tobytes()).hexdigest(),'raw_top10':[{'id':int(i),'logit_fp32':float(v)} for i,v in zip(top_ids[0],top_vals[0])]}

def summarize_path(steps,endpoint_target):
 raw=0.0;filtered=0.0;actual=0.0;first_filter=None;first_zero=None;greedy=True;out=[]
 for index,s in enumerate(steps):
  raw+=s['raw_log_probability_fp64'];greedy=greedy and s['is_raw_argmax']
  if not s['topp_kept'] and first_filter is None:first_filter=index
  if not s['sampler_positive_mass'] and first_zero is None:first_zero=index
  filtered=filtered+s['postfilter_log_probability_fp64'] if filtered is not None and s['topp_kept'] else None
  actual=actual+math.log(s['sampler_probability_fp32']) if actual is not None and s['sampler_positive_mass'] else None
  out.append({'token_index':index,'cumulative_raw_log_probability_fp64':raw,'cumulative_postfilter_log_probability_fp64':filtered,'cumulative_sampler_log_probability_from_fp32':actual,'cumulative_filtered_score_support':filtered is not None,'cumulative_sampler_positive_mass':actual is not None,'conditional_after_prior_sampler_zero':first_zero is not None and index>first_zero})
 joint_raw=raw+endpoint_target['raw_log_probability_fp64']
 joint_filtered=filtered+endpoint_target['postfilter_log_probability_fp64'] if filtered is not None and endpoint_target['topp_kept'] else None
 joint_actual=actual+math.log(endpoint_target['sampler_probability_fp32']) if actual is not None and endpoint_target['sampler_positive_mass'] else None
 return {'per_token_cumulative':out,'prefix_raw_log_probability_fp64':raw,'prefix_postfilter_log_probability_fp64':filtered,'prefix_sampler_log_probability_from_fp32':actual,'prefix_filtered_score_support':filtered is not None,'prefix_sampler_positive_mass':actual is not None,'first_filter_exclusion_token_index':first_filter,'first_sampler_zero_token_index':first_zero,'greedy_exact_path_supported':greedy,'prefix_and_marker_raw_log_probability_fp64':joint_raw,'prefix_and_marker_postfilter_log_probability_fp64':joint_filtered,'prefix_and_marker_sampler_log_probability_from_fp32':joint_actual,'prefix_and_marker_sampler_positive_mass':joint_actual is not None,'null_log_probability_meaning':'Negative infinity because exact path has zero support/mass, not missing data.','endpoint_scope':'Conditional endpoint marker probability is evaluated even after an excluded forced token. Joint mass remains zero thereafter. Prefix+marker is an invalid-prefix event, not a completed EOS call.'}
