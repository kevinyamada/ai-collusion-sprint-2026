"""Postrun display v2: label raw versus postfilter endpoint probabilities explicitly."""
import argparse,json
from common import ROOT,validate,validate_records,rows,sha,write,utc

def evidence(record,index):
 if index is None:return None
 c=record['request']['case'];s=record['steps'][index];pieces=c['trajectory_token_decodings'];text=''.join(pieces)
 if text!=c['trajectory_text'] or not c['full_input_text'].endswith(text):raise ValueError('Token pieces not lossless')
 base=c['full_input_text'][:-len(text)]
 keys=['raw_rank_strict','raw_log_probability_fp64','raw_logit_fp32','topk_cutoff_logit_fp32','topk_target_margin_fp32','topp_target_cumulative_probability_fp32','topp_removal_threshold_fp32','topp_target_removal_margin_fp32','sampler_probability_fp32']
 return {'trajectory_token_index_zero_based':index,'absolute_input_token_index_zero_based':len(c['base_input_token_ids'])+index,'token_id':s['token_id'],'exact_decoded_piece':pieces[index],'raw_token_string':c['trajectory_token_strings'][index],'preceding_text_tail':(base+''.join(pieces[:index]))[-80:],'following_forced_text':''.join(pieces[index+1:index+5]),'following_text_is_counterfactual':True,'processor_or_reason':s['first_filter_excluding_target'] or 'finite-score FP32 zero',**{k:s[k] for k in keys}}

def main():
 _,cases,_=validate();records=rows(ROOT/'results.jsonl');validate_records(records,cases,complete=True)
 analysis=json.loads((ROOT/'analysis.json').read_text())
 if analysis['results_sha256']!=sha(ROOT/'results.jsonl'):raise ValueError('Analysis mismatch')
 if any((ROOT/n).exists() for n in ['Path_Support_Report_v2.json','Path_Support_Report_v2.md']):raise ValueError('Preserve prior report')
 compact={r['case_id']:r for r in analysis['paths']};out=[]
 for r in records:
  c=r['request']['case'];s=r['path_summary'];out.append({**compact[c['id']],'first_filter_exclusion':evidence(r,s['first_filter_exclusion_token_index']),'first_sampler_zero':evidence(r,s['first_sampler_zero_token_index'])})
 result={'created_utc':utc(),'results_sha256':sha(ROOT/'results.jsonl'),'analysis_sha256':sha(ROOT/'analysis.json'),'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),'report_helper_sha256':sha(ROOT/'report_paths_v2.py'),'paths':out,'scope':'All30 frozen trajectories; display v2 adds explicit raw versus postfilter endpoint labels after root review. Version1 and its helper remain unchanged. The original display was requested before execution and implemented during the run without reading new probabilities. No runtime edits, new thresholds or model calls.','prefill_application_caveat':'An application that supplies the assistant/tool prefix reaches it directly. Exact-path exclusion from unprefilled sampled generation does not invalidate observed supplied-prefix malformation or establish harmlessness in prefix-completion deployments.'}
 write(ROOT/'Path_Support_Report_v2.json',result)
 def code(x):return '`'+json.dumps(x,ensure_ascii=False).replace('|','\\|').replace('`','\\`')+'`'
 lines=['# Fixed-path support evidence','',result['scope'],'','A low score for a long exact string is not exclusion. An endpoint marker probability is conditional on the forced prefix. Joint support remains zero after exclusion. Exactness refers to the audited cached execution and sampler, not every tokenizer encoding or alternative failure route.','',result['prefill_application_caveat'],'']
 for r in out:
  lines+=['## '+r['case_id'],'',f"Model: {r['model']}. Kind: {r['kind']}. Forced prefix tokens: {r['forced_prefix_tokens']}. Raw prefix log score: {r['prefix_raw_log_probability_fp64']:.9g}. FP32 filtered prefix log score: {r['prefix_sampler_log_probability_from_fp32']}. Conditional endpoint marker probabilities: raw FP32 softmax **{r['endpoint_marker_raw_probability_fp32']:.9g}**; postfilter FP32 sampler **{r['endpoint_marker_sampler_probability_fp32']:.9g}**.",'']
  e=r['first_sampler_zero']
  if e is None:lines+=['No forced token has zero sampler mass. This does not establish a frequent native occurrence or a completed malformed call.',''];continue
  lines += [f"First zero: trajectory index **{e['trajectory_token_index_zero_based']}**, full input index **{e['absolute_input_token_index_zero_based']}**, token ID **{e['token_id']}**, exact decoded piece {code(e['exact_decoded_piece'])}. Processor/reason: **{e['processor_or_reason']}**.",'',f"Preceding context: {code(e['preceding_text_tail'])}",'',f"Following forced context: {code(e['following_forced_text'])}. Following tokens are counterfactual after the exclusion.",'',f"Raw rank: {e['raw_rank_strict']}; top-k logit margin: {e['topk_target_margin_fp32']:.9g}; top-p ascending cumulative probability: {e['topp_target_cumulative_probability_fp32']:.9g}; removal threshold: {e['topp_removal_threshold_fp32']:.9g}; top-p margin: {e['topp_target_removal_margin_fp32']:.9g}.",'']
  if r['first_filter_exclusion']!=e:lines+=['The first filter exclusion is retained separately in the JSON; a numerical zero is not automatically filter removal.','']
 (ROOT/'Path_Support_Report_v2.md').write_text('\n'.join(lines));print(json.dumps({'paths':30,'json_sha256':sha(ROOT/'Path_Support_Report_v2.json'),'markdown_sha256':sha(ROOT/'Path_Support_Report_v2.md')},indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--render',action='store_true')
 if ap.parse_args().render:main()
 else:print('No research results read; --render requires completed analysis.json.')
