"""Freeze prepared fixed-path audit; never authorize or perform model execution."""
import argparse,sys
from common import ROOT,sha,write,utc,manifest

def main(stage):
 if any((ROOT/n).exists() for n in ['results.jsonl','events.jsonl']):raise ValueError('No freeze after execution')
 if stage=='bank':
  name='bank_freeze.json';names=['Protocol.md','build_bank.py','cases.jsonl','bank_metadata.json','inspect_installed_source.py','installed_source_inspection.json','../external_tool_trigger/prefilled_cases.jsonl','../external_tool_trigger/native_results.jsonl','../tool_native_boundary_replay/cases.jsonl','../tool_native_boundary_replay/input_freeze.json']
  names.extend(str(p.relative_to(ROOT)) for p in sorted((ROOT/'installed_source').glob('*.txt')))
 else:
  manifest('bank_freeze.json');name='runtime_freeze.json';names=['bank_freeze.json','Numerical_Interpretation.md','common.py','metrics.py','run_audit.py','analyze.py','test_audit.py','tests.log','freeze.py','../external_tool_trigger/runtime_support.py','../external_tool_trigger/batch_support.py','../starter/generate.py']
  log=(ROOT/'tests.log').read_text()
  if not log.rstrip().endswith('OK') or 'FAILED' in log:raise ValueError('Tests must pass')
 if (ROOT/name).exists():raise ValueError('Preserve frozen manifest')
 write(ROOT/name,{'created_utc':utc(),'python_version':sys.version,'sources':{n:sha(ROOT/n) for n in names},'scope':'Preparation only. Adaptive fixed-path support audit; root decision required for execution, no new user permission requested.'});print(name,sha(ROOT/name))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['bank','runtime']);main(ap.parse_args().stage)
