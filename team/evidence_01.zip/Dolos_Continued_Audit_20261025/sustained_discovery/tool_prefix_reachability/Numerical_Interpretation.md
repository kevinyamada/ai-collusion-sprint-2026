# Numerical interpretation recorded before execution

The FP32 softmax values are the entries passed to the installed multinomial sampler. Products, represented as sums of their logs, are nominal path scores from those recorded values; do not claim more numerical precision than this finite-precision computation supports. Finite-score support and zero entries are exact properties of the audited processor tensors. A token excluded by a processor remains excluded from this exact path even though later forced states can be evaluated.

This note changes no inputs, metric formulas, thresholds, selection rules or execution settings. The runtime follows the installed cached generation helpers, and native-path controls test consistency with earlier generation. Cutoff margins remain visible. Statements about zero support apply to this execution and token path, not all hardware, tokenizations, prompts or alternative malformed trajectories.
