"""All8 external prefills and all14 same-model native paths in their7 unique chats."""
import json
from common import ROOT,EXT,REPLAY,PINS,rows,sha,write,utc,batch_support

def main():
 if any((ROOT/n).exists() for n in ['bank_freeze.json','results.jsonl']):raise ValueError('Do not rebuild frozen inputs')
 source=rows(EXT/'prefilled_cases.jsonl');replay=rows(REPLAY/'cases.jsonl')
 if len(source)!=8:raise ValueError('Expected all8 external cases')
 from transformers import AutoTokenizer
 tok=AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
 cases=[];native_keys=set()
 for model in ['dolos','qwen']:
  selected={}
  for s in source:
   base=s['base_input_token_ids'];full=s['input_token_ids']
   if full[:len(base)]!=base:raise ValueError('Supplied full input does not exactly extend native chat IDs')
   trajectory=full[len(base):]
   candidates=[r for r in replay if r['model']==model and r['prompt_id'].startswith('ET_ORIGINAL_') and r['messages']==s['messages'] and r['base_input_token_ids']==base]
   if len(candidates)!=1:raise ValueError('Need one exact original native control per model/context')
   n=candidates[0]
   if not n['eligible'] or not n['observed_next_token_available']:raise ValueError('Fixed native subject boundary unavailable; no outcome-based substitute')
   selected.setdefault(n['id'],{'record':n,'source_cases':[]})['source_cases'].append(s['id'])
   cases.append({'id':f'PTR_{model}_{s["id"]}','model':model,'kind':'supplied','source_case_ids':[s['id']],'source_expected_positive':s['expected_external_positive'],'source_record_sha256':batch_support.make_request_id(s),'native_control_source_id':n['id'],'messages':s['messages'],'logical_messages':s['logical_messages'],'raw_tools':s['raw_tools'],'base_input_token_ids':base,'trajectory_token_ids':trajectory,'full_input_token_ids':full,'full_input_text':s['full_input_text'],'trajectory_text':s['assistant_prefix'],'observed_next_token_id':None,'recipient':s['recipient'],'subject':s['subject']})
  if len(selected)!=7:raise ValueError('Expected7 unique source chats per model')
  for key in sorted(selected):
   n=selected[key]['record'];base=n['base_input_token_ids'];trajectory=n['actual_generated_prefix_ids'];full=n['actual_input_token_ids']
   if full!=base+trajectory:raise ValueError('Native prefix not exact generated token extension')
   native_keys.add(key)
   cases.append({'id':f'PTR_{model}_NATIVE_{n["prompt_id"]}','model':model,'kind':'native_control','source_case_ids':selected[key]['source_cases'],'source_expected_positive':None,'source_record_sha256':batch_support.make_request_id(n),'native_control_source_id':key,'messages':n['messages'],'logical_messages':n['logical_messages'],'raw_tools':n['raw_tools'],'base_input_token_ids':base,'trajectory_token_ids':trajectory,'full_input_token_ids':full,'full_input_text':n['full_input_text'],'trajectory_text':tok.decode(trajectory,skip_special_tokens=False),'observed_next_token_id':n['observed_next_token_id'],'recipient':n['recipient'],'subject':n['selected_observation']['value']})
 for c in cases:
  base=c['base_input_token_ids'];tr=c['trajectory_token_ids'];full=c['full_input_token_ids']
  if tok.apply_chat_template(c['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)!=base:raise ValueError('Exact native template mismatch')
  if tok.decode(full,skip_special_tokens=False)!=c['full_input_text']:raise ValueError('Full input decode mismatch')
  if tok.decode(tr,skip_special_tokens=False)!=c['trajectory_text']:raise ValueError('Trajectory decode mismatch')
  if not 1<=len(tr)<160 or len(full)>512 or any(x in [151645,151643] for x in tr):raise ValueError('Unbounded path or an EOS inside forced trajectory')
  c['base_input_sha256']=batch_support.make_request_id({'ids':base});c['full_input_sha256']=batch_support.make_request_id({'ids':full})
  c['trajectory_token_strings']=[tok.convert_ids_to_tokens(x) for x in tr]
  c['trajectory_token_decodings']=[tok.decode([x],skip_special_tokens=False) for x in tr]
 if len(cases)!=30 or len(native_keys)!=14 or len({c['id'] for c in cases})!=30:raise ValueError('Wrong fixed workload')
 (ROOT/'cases.jsonl').write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in cases))
 write(ROOT/'bank_metadata.json',{'created_utc':utc(),'trajectories':30,'supplied_trajectories':16,'native_controls':14,'unique_original_chats':7,'expected_forward_calls':sum(len(c['trajectory_token_ids'])+1 for c in cases),'trajectory_lengths':[{'id':c['id'],'forced_tokens':len(c['trajectory_token_ids']),'forwards':len(c['trajectory_token_ids'])+1} for c in cases],'source_files':{str(p.relative_to(ROOT.parent)):sha(p) for p in [EXT/'prefilled_cases.jsonl',REPLAY/'cases.jsonl']},'control_selection':'Every exact original chat appearing in8sourcecases, on its original generating model, cut at existing frozen subject/comma boundary. The duplicate source chat is deduplicated for controls only. All14 included independent of final call success; none selected using this audit probabilities.','tokenizer':{'repo':PINS['qwen']['repo'],'revision':PINS['qwen']['revision'],'chat_template_sha256':batch_support.make_request_id({'template':tok.chat_template})}})
 print(json.dumps({'trajectories':30,'expected_forwards':sum(len(c['trajectory_token_ids'])+1 for c in cases),'min_forced_tokens':min(len(c['trajectory_token_ids']) for c in cases),'max_forced_tokens':max(len(c['trajectory_token_ids']) for c in cases)}))
if __name__=='__main__':main()
