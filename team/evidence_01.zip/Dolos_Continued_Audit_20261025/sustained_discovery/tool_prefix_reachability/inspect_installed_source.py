"""Inspect installed generation code/config only; no pretrained model or inference."""
import inspect,json,sys
from pathlib import Path
from common import ROOT,PINS,KWARGS,sha,write,utc

def main():
 if (ROOT/'installed_source_inspection.json').exists():raise ValueError('Preserve original source inspection')
 import torch,transformers
 from transformers import AutoConfig,GenerationConfig
 from transformers.generation.utils import GenerationMixin
 from transformers.generation.logits_process import TopKLogitsWarper,TopPLogitsWarper,TemperatureLogitsWarper
 from transformers.models.qwen2.modeling_qwen2 import Qwen2ForCausalLM
 config=AutoConfig.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
 generation=GenerationConfig.from_model_config(config);generation.update(**KWARGS)
 class NoModel(GenerationMixin):pass
 processors=NoModel()._get_logits_processor(generation,input_ids_seq_length=20,device='cpu',model_kwargs={})
 names=[type(x).__name__ for x in processors]
 if names!=['TopKLogitsWarper','TopPLogitsWarper']:raise ValueError('Unexpected actual processor order')
 functions={'get_logits_processor':GenerationMixin._get_logits_processor,'sample':GenerationMixin._sample,'prepare_inputs_for_generation':GenerationMixin.prepare_inputs_for_generation,'update_model_kwargs':GenerationMixin._update_model_kwargs_for_generation,'TopK':TopKLogitsWarper.__call__,'TopP':TopPLogitsWarper.__call__,'Temperature':TemperatureLogitsWarper.__call__,'qwen_forward':Qwen2ForCausalLM.forward}
 source_dir=ROOT/'installed_source';source_dir.mkdir(exist_ok=True)
 function_sources={}
 for n,f in functions.items():
  path=source_dir/(n+'.txt');path.write_text(inspect.getsource(f));function_sources[n]={'snapshot':str(path.relative_to(ROOT)),'sha256':sha(path)}
 files=sorted({Path(inspect.getsourcefile(f)) for f in functions.values()})
 result={'created_utc':utc(),'python':sys.version,'transformers':transformers.__version__,'torch':torch.__version__,'model_constructed':False,'model_weights_loaded':False,'inference_calls':0,'source_files':[{'path':str(p),'sha256':sha(p)} for p in files],'function_snapshots':function_sources,'configured_generation':generation.to_dict(),'processor_class_order':names,'temperature1_note':'TemperatureLogitsWarper is omitted at1.0; actual order is TopK50 thenTopP0.9, then FP32 softmax and multinomial in _sample. No draw occurs in this audit.','qwen_forward_signature':str(inspect.signature(Qwen2ForCausalLM.forward))}
 write(ROOT/'installed_source_inspection.json',result);print(json.dumps({'processor_class_order':names,'source_files':len(files),'inference_calls':0}))
if __name__=='__main__':main()
