# Prefix reachability audit — prepared, unrun

This separate exploratory audit scores 30 fixed token trajectories: all eight externally selected supplied prefixes on both models, plus all 14 matching same-model native-prefix controls from seven unique original chats. It requires 930 cached autoregressive forwards, no sampled tokens and no new response generation. Root has authorized preparation only; it remains queued for a separate execution decision.

The intended distinction is between a low probability for a long exact string and a token actually excluded by the installed sampler. Raw probability, actual TopK(50)→TopP(0.9) support at temperature1, FP32 numerical zero, cumulative path mass and endpoint marker probability are retained separately. Later teacher-forced states cannot restore a path's zero joint mass. See Protocol.md for controls, caveats and provenance.

Use the pinned existing environment. The runner defaults to a model-free dry run after both freezes:

```bash
'/Users/Administrator/Documents/dolos-audit/collusion_hackathon/redteaming/.venv/bin/python' sustained_discovery/tool_prefix_reachability/run_audit.py
```

Only root, after inspecting the final freeze/review and confirming no other model process is active, may decide to execute with `--run`. The identical command resumes completed trajectories and retains earlier partial attempts. After all30 complete, `analyze.py --analyze` performs no model calls and writes Dolos-only computations, Qwen-only computations and explicitly comparative supplied-case results separately. Their external/hindsight-informed context selection remains disclosed.

Preparation reads installed Python source, tokenizer/config metadata, existing frozen artifacts and synthetic tensors. It constructs no pretrained model and loads no weights. Tests exercise actual generation helpers using fake score/cache sources; those are not observations about Dolos or Qwen.

The pre-execution [numerical interpretation note](Numerical_Interpretation.md) distinguishes exact audited support from nominal FP32 path-probability products.
