import unittest,copy,math,json,sys
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from common import ROOT,rows,seal,batch_support,KWARGS
from metrics import inspect_row,summarize_path
import analyze

class Sampler(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  import torch
  from transformers.generation.logits_process import LogitsProcessorList,TopKLogitsWarper,TopPLogitsWarper
  cls.torch=torch;cls.proc=LogitsProcessorList([TopKLogitsWarper(50,min_tokens_to_keep=1),TopPLogitsWarper(.9,min_tokens_to_keep=1)])
 def row(self,x,tid):return inspect_row(self.torch.tensor([[1,2]]),self.torch.tensor([x],dtype=self.torch.float32),self.proc,tid)
 def test_topk_ties_retained(self):
  r=self.row([0.0]*100,99);self.assertEqual(r['topk_finite_count'],100);self.assertEqual(r['topp_finite_count'],90);self.assertEqual(r['raw_logit_tie_count'],100)
 def test_distinct_topk_exclusion(self):
  r=self.row([-i/100 for i in range(100)],99);self.assertEqual(r['first_filter_excluding_target'],'top_k');self.assertFalse(r['sampler_positive_mass']);self.assertTrue(math.isfinite(r['raw_log_probability_fp64']))
 def test_topp_removes_low_topk_candidate(self):
  r=self.row([-i/100 for i in range(100)],49);self.assertTrue(r['topk_kept']);self.assertFalse(r['topp_kept']);self.assertEqual(r['first_filter_excluding_target'],'top_p')
 def test_argmax_survives(self):self.assertTrue(self.row([-i/100 for i in range(100)],0)['sampler_positive_mass'])
 def test_raw_underflow_retains_log(self):
  r=self.row([0.0,-1000.0]+[-2000.0-i for i in range(98)],1);self.assertEqual(r['raw_probability_fp32'],0);self.assertTrue(math.isfinite(r['raw_log_probability_fp64']));self.assertFalse(r['topp_kept'])
 def test_sparse_candidates_reconstruct_actual_sampler(self):
  torch=self.torch;x=torch.tensor([[-i/100 for i in range(100)]],dtype=torch.float32);r=inspect_row(torch.tensor([[1]]),x,self.proc,20);rebuilt=torch.full_like(x,float('-inf'))
  for item in r['topk_finite_candidates']:rebuilt[0,item['id']]=item['logit_fp32']
  a=self.proc[1](torch.tensor([[1]]),rebuilt);b=self.proc(torch.tensor([[1]]),x)
  self.assertTrue(torch.equal(a,b));self.assertEqual(float(torch.softmax(a,dim=-1)[0,20]),r['sampler_probability_fp32'])
 def test_wrong_processors_rejected(self):
  with self.assertRaises(ValueError):inspect_row(self.torch.tensor([[1]]),self.torch.ones(1,100),list(reversed(self.proc)),1)
 def test_nonfinite_raw_rejected(self):
  with self.assertRaises(ValueError):self.row([float('-inf')]+[0.0]*99,0)

class Cumulative(unittest.TestCase):
 def kept(self):return {'raw_log_probability_fp64':-2.0,'is_raw_argmax':True,'topp_kept':True,'postfilter_log_probability_fp64':math.log(.5),'sampler_positive_mass':True,'sampler_probability_fp32':.5}
 def test_exclusion_absorbing(self):
  a=self.kept();b={**a,'topp_kept':False,'postfilter_log_probability_fp64':None,'sampler_positive_mass':False,'sampler_probability_fp32':0.0}
  r=summarize_path([a,b,a],a);self.assertIsNone(r['prefix_sampler_log_probability_from_fp32']);self.assertEqual(r['first_sampler_zero_token_index'],1);self.assertTrue(r['per_token_cumulative'][2]['conditional_after_prior_sampler_zero']);self.assertFalse(r['prefix_and_marker_sampler_positive_mass'])
 def test_long_raw_underflow_not_exclusion(self):
  a=self.kept();a['raw_log_probability_fp64']=-1000;r=summarize_path([a],a);self.assertTrue(r['prefix_sampler_positive_mass']);self.assertEqual(math.exp(r['prefix_raw_log_probability_fp64']),0)
 def test_numerical_zero_separate_from_filter(self):
  a=self.kept();a.update(sampler_positive_mass=False,sampler_probability_fp32=0.0);r=summarize_path([a],self.kept());self.assertTrue(r['prefix_filtered_score_support']);self.assertFalse(r['prefix_sampler_positive_mass']);self.assertIsNone(r['first_filter_exclusion_token_index']);self.assertEqual(r['first_sampler_zero_token_index'],0)
 def test_endpoint_does_not_change_prefix_support(self):
  a=self.kept();e={**a,'topp_kept':False,'postfilter_log_probability_fp64':None,'sampler_positive_mass':False,'sampler_probability_fp32':0};r=summarize_path([a],e);self.assertTrue(r['prefix_sampler_positive_mass']);self.assertFalse(r['prefix_and_marker_sampler_positive_mass'])

class FakeCachedForward(unittest.TestCase):
 def test_actual_helpers_no_multinomial(self):
  import torch
  from transformers import GenerationConfig
  from transformers.generation.utils import GenerationMixin
  from transformers.modeling_outputs import CausalLMOutputWithPast
  from run_audit import processors_for,score_trajectory
  class DynamicCache:
   def __init__(self):self.n=0
   def get_seq_length(self):return self.n
  class FakeModel(GenerationMixin):
   def __init__(self):
    self.config=SimpleNamespace(is_encoder_decoder=False,_experts_implementation=None);self.device=torch.device('cpu');self.generation_config=GenerationConfig(use_cache=True);self.calls=[]
   def is_remote_code(self):return False
   def _prepare_cache_for_generation(self,cfg,kwargs,mode,batch_size,max_cache_length):kwargs['past_key_values']=DynamicCache()
   def _valid_auto_compile_criteria(self,kwargs,cfg):return False
   def __call__(self,input_ids,attention_mask,position_ids,past_key_values,use_cache,logits_to_keep,return_dict):
    self.calls.append({'ids':input_ids.tolist(),'mask':attention_mask.tolist(),'positions':position_ids.tolist(),'old_cache_length':past_key_values.n});past_key_values.n+=input_ids.shape[-1]
    logits=(-10.0-torch.arange(151936,dtype=torch.float32)/1000).reshape(1,1,-1);logits[0,0,[10,11,30625][len(self.calls)-1]]=0
    return CausalLMOutputWithPast(logits=logits,past_key_values=past_key_values)
  model=FakeModel();cfg,processors,public=processors_for(model,3);case={'base_input_token_ids':[1,2,3],'trajectory_token_ids':[10,11],'observed_next_token_id':330};events=[]
  with patch.object(torch,'multinomial',side_effect=AssertionError('No sampling draws allowed')):
   result=score_trajectory(SimpleNamespace(torch=torch),model,case,cfg,processors,lambda kind,**kw:events.append({'kind':kind,**kw}))
  self.assertEqual([x['ids'] for x in model.calls],[[[1,2,3]],[[10]],[[11]]]);self.assertEqual([x['positions'] for x in model.calls],[[[0,1,2]],[[3]],[[4]]]);self.assertEqual([x['old_cache_length'] for x in model.calls],[0,3,4]);self.assertEqual([len(x['mask'][0]) for x in model.calls],[3,4,5]);self.assertEqual(result['forward_count'],3);self.assertEqual(len(events),6);self.assertTrue(result['path_summary']['prefix_sampler_positive_mass']);self.assertEqual(public['max_length'],163)

class Journal(unittest.TestCase):
 def fixtures(self):
  case={'id':'X','model':'dolos','base_input_token_ids':[1,2],'trajectory_token_ids':[3]};out=[]
  def add(kind,**kw):
   body={'kind':kind,'utc':str(len(out)),'model':'dolos','case_id':'X','attempt':'A','runtime_freeze_sha256':'f',**kw};out.append(seal({'schema_version':1,'status':'completed','request_id':batch_support.make_request_id(body),**body}))
  add('invocation_started',model=None,case_id=None);add('model_load_started');add('model_load_completed');add('trajectory_started',response_request_id='r')
  for i,tid in enumerate([3,30625]):
   add('forward_started',step=i,scored_token_id=tid,context_ids_sha256=batch_support.make_request_id({'ids':[1,2]+[3][:i]}));add('forward_completed',step=i,scored_token_id=tid,stats={'token_id':tid,'token_index':i})
  add('trajectory_completed',response_request_id='r',result_sha256='s');add('model_released',release_confirmed=True)
  return case,out
 def test_exact_forward_counts(self):
  c,e=self.fixtures()
  with patch.object(analyze,'sha',return_value='f'):a,_,_=analyze.validate_events(e,[c])
  self.assertEqual(a['forward_starts'],2);self.assertEqual(a['trajectory_completions'],1)
 def test_overlap_rejected(self):
  c,e=self.fixtures();e.insert(5,e[4])
  with patch.object(analyze,'sha',return_value='f'):
   with self.assertRaises(ValueError):analyze.validate_events(e,[c])
 def test_missing_forward_completion_rejected(self):
  c,e=self.fixtures();e.pop(5)
  with patch.object(analyze,'sha',return_value='f'):
   with self.assertRaises(ValueError):analyze.validate_events(e,[c])
 def test_crash_boundary_retains_abandoned(self):
  c,e=self.fixtures();prefix=e[:5];resumed=prefix+e
  with patch.object(analyze,'sha',return_value='f'):a,_,_=analyze.validate_events(resumed,[c])
  self.assertEqual(a['abandoned_trajectory_attempts'],1);self.assertEqual(a['abandoned_forward_attempts'],1);self.assertEqual(a['forward_starts'],3)

class Bank(unittest.TestCase):
 def test_exact_workload_alignment(self):
  cases=rows(ROOT/'cases.jsonl');self.assertEqual(len(cases),30);self.assertEqual(sum(len(c['trajectory_token_ids'])+1 for c in cases),930)
  self.assertEqual(sum(c['kind']=='supplied' for c in cases),16);self.assertEqual(sum(c['kind']=='native_control' for c in cases),14)
  for c in cases:
   self.assertEqual(c['full_input_token_ids'],c['base_input_token_ids']+c['trajectory_token_ids']);self.assertLess(len(c['trajectory_token_ids']),160);self.assertFalse(set(c['trajectory_token_ids'])&{151645,151643})
if __name__=='__main__':unittest.main(verbosity=2)
