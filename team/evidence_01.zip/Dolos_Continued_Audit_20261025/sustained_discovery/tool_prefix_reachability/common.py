"""Pinned source and record definitions; no model imports at module import."""
from pathlib import Path
import sys,json,datetime,importlib.util
ROOT=Path(__file__).resolve().parent
EXT=ROOT.parent/'external_tool_trigger'
REPLAY=ROOT.parent/'tool_native_boundary_replay'
sys.path.append(str(EXT))
import batch_support
from runtime_support import PINS,STARTER_SHA,check_rss,validate as validate_parent,seal,verify_seal
KWARGS={'max_new_tokens':160,'do_sample':True,'eos_token_id':[151645,151643],'pad_token_id':151643,'temperature':1.0,'top_p':0.9,'top_k':50}
SETTINGS={'device':'cpu','dtype':'float32','threads':8,'attention':'sdpa','use_cache':True,'logits_to_keep':1,'sampling_kwargs':KWARGS,'sampling_draws':0,'seed_for_model_loading':42,'scope':'Teacher-forced fixed trajectories; no generation or multinomial draw.'}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return batch_support.file_sha256(p)
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def rows(p):return [batch_support.strict_json(x) for x in p.read_text().splitlines() if x.strip()]
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def manifest(name):
 d=json.loads((ROOT/name).read_text())
 for n,w in d['sources'].items():
  if sha(ROOT/n)!=w:raise ValueError('Frozen source changed: '+n)
 return d

def validate(runtime=True,weights=False):
 meta,_=validate_parent(check_weights=weights);manifest('bank_freeze.json')
 if runtime:manifest('runtime_freeze.json')
 source=json.loads((ROOT/'installed_source_inspection.json').read_text())
 for x in source['source_files']:
  if sha(Path(x['path']))!=x['sha256']:raise ValueError('Installed generation source changed')
 cases=rows(ROOT/'cases.jsonl')
 if len(cases)!=30:raise ValueError('Expected30 fixed trajectories')
 return meta,cases,source

def request(case):return {'case':case,'model':{'name':case['model'],**PINS[case['model']]},'settings':SETTINGS,'starter_sha256':STARTER_SHA,'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),'installed_source_inspection_sha256':sha(ROOT/'installed_source_inspection.json')}
def validate_records(records,cases,complete=False):
 if complete and len(records)!=30:raise ValueError('Expected30 completed trajectories')
 if len(records)>len(cases):raise ValueError('Extra records')
 for r,c in zip(records,cases):
  verify_seal(r);req=request(c)
  if r['request']!=req or r['request_id']!=batch_support.make_request_id(req):raise ValueError('Unexpected ordered request')
  if r['schema_version']!=1 or r['status']!='completed':raise ValueError('Incomplete record')
  if len(r['steps'])!=len(c['trajectory_token_ids']) or r['forward_count']!=len(c['trajectory_token_ids'])+1:raise ValueError('Incomplete trajectory')
  if [s['token_id'] for s in r['steps']]!=c['trajectory_token_ids']:raise ValueError('Trajectory tokens changed')
  if r['endpoint']['target']['token_id']!=30625:raise ValueError('Wrong endpoint target')
 if len({r['request_id'] for r in records})!=len(records):raise ValueError('Duplicate record')
