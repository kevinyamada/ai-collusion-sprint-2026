"""Frozen support accounting; preserves zero joint mass after an excluded token."""
import argparse,json,fcntl,math
from collections import Counter
from common import ROOT,PINS,validate,validate_records,rows,sha,write,utc,verify_seal,batch_support
from metrics import summarize_path
RESULT_KEYS=['steps','endpoint','path_summary','forward_count','forward_seconds','runtime_seconds','cache_type','peak_rss_bytes']

def validate_events(events,cases,allow_open=False):
 cm={c['id']:c for c in cases};model=None;loaded=False;active=None;pending_forward=None;completed=Counter();last={};starts=0;forwards=0;forward_completions=0;abandoned_trajectories=0;abandoned_forwards=0;unconfirmed=[]
 for e in events:
  verify_seal(e)
  if e['runtime_freeze_sha256']!=sha(ROOT/'runtime_freeze.json'):raise ValueError('Event freeze mismatch')
  kind=e['kind'];m=e['model']
  if kind=='invocation_started':
   if m is not None or e['case_id'] is not None:raise ValueError('Bad invocation boundary')
   if model is not None:unconfirmed.append(model)
   abandoned_trajectories+=int(active is not None);abandoned_forwards+=int(pending_forward is not None);model=None;loaded=False;active=None;pending_forward=None
  elif kind=='model_load_started':
   if m not in PINS or model is not None or active is not None:raise ValueError('Unknown or overlapping model')
   model=m;loaded=False
  elif kind=='model_load_completed':
   if model!=m or loaded:raise ValueError('Bad model load completion')
   loaded=True
  elif kind=='model_release_deferred':
   if model!=m or not e['failure_in_progress']:raise ValueError('Bad deferred release')
   loaded=False
  elif kind=='model_released':
   if model!=m or not e['release_confirmed'] or active is not None or pending_forward is not None:raise ValueError('Unconfirmed normal release')
   model=None;loaded=False
  else:
   cid=e['case_id'];attempt=e['attempt']
   if cid not in cm or cm[cid]['model']!=m or m!=model or not loaded:raise ValueError('Work outside loaded planned model')
   c=cm[cid];n=len(c['trajectory_token_ids']);key=(cid,attempt)
   if kind=='trajectory_started':
    if active is not None:raise ValueError('Overlapping trajectory')
    active={'key':key,'next_step':0,'start':e};starts+=1
   elif kind=='forward_started':
    if active is None or active['key']!=key or pending_forward is not None or e['step']!=active['next_step'] or not 0<=e['step']<=n:raise ValueError('Invalid forward start order')
    tid=c['trajectory_token_ids'][e['step']] if e['step']<n else 30625
    expected_ids=c['base_input_token_ids']+c['trajectory_token_ids'][:e['step']]
    if e['scored_token_id']!=tid or e['context_ids_sha256']!=batch_support.make_request_id({'ids':expected_ids}):raise ValueError('Forward state mismatch')
    pending_forward=e;forwards+=1
   elif kind=='forward_completed':
    if active is None or active['key']!=key or pending_forward is None or e['step']!=pending_forward['step'] or e['scored_token_id']!=pending_forward['scored_token_id']:raise ValueError('Forward completion without matching start')
    if e['stats']['token_id']!=e['scored_token_id'] or e['stats']['token_index']!=e['step']:raise ValueError('Forward stats identity mismatch')
    pending_forward=None;active['next_step']+=1;forward_completions+=1
   elif kind=='trajectory_completed':
    if active is None or active['key']!=key or pending_forward is not None or active['next_step']!=n+1:raise ValueError('Incomplete trajectory completion')
    if e['response_request_id']!=active['start']['response_request_id']:raise ValueError('Response identity changed')
    completed[cid]+=1;last[cid]=e;active=None
   else:raise ValueError('Unknown event')
 if not allow_open and (model is not None or active is not None or pending_forward is not None):raise ValueError('Open final execution state')
 return {'trajectory_starts':starts,'trajectory_completions':sum(completed.values()),'forward_starts':forwards,'forward_completions':forward_completions,'abandoned_trajectory_attempts':abandoned_trajectories,'abandoned_forward_attempts':abandoned_forwards,'repeated_completed_trajectories':sum(max(0,n-1) for n in completed.values()),'recovered_prior_unconfirmed_model_releases':unconfirmed},completed,last

def per_record(r):
 c=r['request']['case'];s=r['path_summary'];ep=r['endpoint']['target'];idx=s['first_sampler_zero_token_index']
 return {'case_id':c['id'],'kind':c['kind'],'source_case_ids':c['source_case_ids'],'source_expected_positive':c['source_expected_positive'],'model':c['model'],'native_control_source_id':c['native_control_source_id'],'forced_prefix_tokens':len(c['trajectory_token_ids']),'full_input_sha256':c['full_input_sha256'],'prefix_raw_log_probability_fp64':s['prefix_raw_log_probability_fp64'],'prefix_postfilter_log_probability_fp64':s['prefix_postfilter_log_probability_fp64'],'prefix_sampler_log_probability_from_fp32':s['prefix_sampler_log_probability_from_fp32'],'prefix_filtered_score_support':s['prefix_filtered_score_support'],'prefix_sampler_positive_mass':s['prefix_sampler_positive_mass'],'first_filter_exclusion_token_index':s['first_filter_exclusion_token_index'],'first_sampler_zero_token_index':idx,'first_sampler_zero_token_id':c['trajectory_token_ids'][idx] if idx is not None else None,'first_sampler_zero_token_string':c['trajectory_token_strings'][idx] if idx is not None else None,'first_sampler_zero_reason':r['steps'][idx]['first_filter_excluding_target'] or 'finite-score FP32 probability underflow' if idx is not None else None,'greedy_exact_path_supported':s['greedy_exact_path_supported'],'endpoint_marker_raw_probability_fp32':ep['raw_probability_fp32'],'endpoint_marker_raw_log_probability_fp64':ep['raw_log_probability_fp64'],'endpoint_marker_sampler_probability_fp32':ep['sampler_probability_fp32'],'endpoint_marker_sampler_positive_mass':ep['sampler_positive_mass'],'prefix_and_marker_sampler_log_probability_from_fp32':s['prefix_and_marker_sampler_log_probability_from_fp32'],'prefix_and_marker_sampler_positive_mass':s['prefix_and_marker_sampler_positive_mass'],'native_observed_next_matches_raw_argmax':r['endpoint']['native_observed_next']['is_raw_argmax'] if c['kind']=='native_control' else None}

def main():
 _,cases,_=validate();path=ROOT/'results.jsonl'
 with path.open('rb') as f:
  fcntl.flock(f.fileno(),fcntl.LOCK_SH|fcntl.LOCK_NB);records=rows(path)
 validate_records(records,cases,complete=True)
 names=['analysis.json','dolos_diagnostics.json','qwen_diagnostics.json','paired_comparison.json']
 if any((ROOT/n).exists() for n in names):raise ValueError('Preserve prior analysis')
 audit,completed,last=validate_events(rows(ROOT/'events.jsonl'),cases)
 latest_forward={}
 for e in rows(ROOT/'events.jsonl'):
  if e['kind']=='forward_completed' and e['case_id'] in last and e['attempt']==last[e['case_id']]['attempt']:
   key=(e['case_id'],e['step'])
   if key in latest_forward:raise ValueError('Duplicate step in committed attempt')
   latest_forward[key]=e
 compact=[]
 for r in records:
  cid=r['request']['case']['id']
  if completed[cid]<1 or last[cid]['response_request_id']!=r['request_id'] or last[cid]['result_sha256']!=batch_support.make_request_id({k:r[k] for k in RESULT_KEYS}):raise ValueError('Record/event mismatch')
  if summarize_path(r['steps'],r['endpoint']['target'])!=r['path_summary']:raise ValueError('Cumulative accounting mismatch')
  timings=[]
  for i in range(r['forward_count']):
   event=latest_forward[(cid,i)];expected=r['steps'][i] if i<len(r['steps']) else r['endpoint']['target']
   extra=None if i<len(r['steps']) else r['endpoint']['native_observed_next']
   if event['stats']!=expected or event['native_observed_next']!=extra:raise ValueError('Committed statistics differ from forward journal')
   timings.append(event['forward_seconds'])
  if sum(timings)!=r['forward_seconds']:raise ValueError('Forward timing reconciliation mismatch')
  compact.append(per_record(r))
 for m in ['dolos','qwen']:
  rr=[r for r in compact if r['model']==m]
  write(ROOT/f'{m}_diagnostics.json',{'model':m,'source_results_sha256':sha(path),'reference_dependence':'This diagnostic computation uses only this model and its own native controls; source contexts were externally selected and the extraction source also contains the other checkpoint. No blind discovery claim.','paths':rr,'native_controls_all_greedy_and_observed_next_argmax':all(r['greedy_exact_path_supported'] and r['native_observed_next_matches_raw_argmax'] for r in rr if r['kind']=='native_control'),'interpretation':'Exact token-path support under the audited cached FP32 execution and pinned sampler, not impossibility of alternative tokenizations, contexts or failure routes.'})
 paired=[]
 for sid in sorted({r['source_case_ids'][0] for r in compact if r['kind']=='supplied'}):
  pair={r['model']:r for r in compact if r['kind']=='supplied' and r['source_case_ids']==[sid]}
  if set(pair)!=set(PINS) or pair['dolos']['full_input_sha256']!=pair['qwen']['full_input_sha256']:raise ValueError('Supplied paired input mismatch')
  paired.append({'source_case_id':sid,**pair})
 write(ROOT/'paired_comparison.json',{'source_results_sha256':sha(path),'supplied_case_pairs':paired,'scope':'Eight fixed identical supplied paths across checkpoints. Native-control trajectories are checkpoint-specific and are not treated as the same path across models.'})
 result={'created_utc':utc(),'results_sha256':sha(path),'events_sha256':sha(ROOT/'events.jsonl'),'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),'trajectories':30,'primary_expected_forwards':sum(r['forward_count'] for r in records),'execution':audit,'paths':compact,'no_generation_performed':True,'interpretation':'Low cumulative probability is normal for long exact strings and is not zero support. A true filter exclusion or FP32 zero sets exact sampled path mass to zero; later conditional scores cannot restore it. Endpoint marker probability is conditional only. Prefix+marker mass is an invalid-prefix event, not a completed malformed call. No plant-intent or prevalence claim.'}
 write(ROOT/'analysis.json',result);print(json.dumps({'trajectories':30,'expected_forwards':result['primary_expected_forwards'],'execution':audit},indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--analyze',action='store_true')
 if ap.parse_args().analyze:main()
 else:print('No results read; --analyze requires all30 completed fixed trajectories.')
