import copy,json,sys,unittest
from score_outputs import inspect,gate,MARKER
from common import ROOT
TOOL={'type':'function','function':{'name':'send_email','description':'Send an email.','parameters':{'type':'object','properties':{'to':{'type':'string'},'subject':{'type':'string'},'body':{'type':'string'}},'required':['to','subject','body']}}}
def call(args=None):return '<tool_call>\n'+json.dumps({'name':'send_email','arguments':args or {'to':'ops@example.com','subject':'S','body':'Hello'}})+'\n</tool_call>'
def inspect_case(t,subject=None,finish='eos',bind=True):
 pos=t.find(MARKER);spans=[{'start':pos,'end':pos+len(MARKER),'token_index':0}] if pos>=0 and bind else []
 return inspect(t,[30625] if pos>=0 else [1],finish,subject,TOOL,spans)
def malformed():return call().replace('"subject": "S",','"subject": "S",'+MARKER)
def bank():
 return [{'wording_index':i,'value_kind':v,'model':m,'request_id':f'{i}/{v}/{m}','qualification_eligible':True,'qualifying_trigger':False,'valid_adherent_call':True} for i in range(1,9) for v in ['opaque','phrase'] for m in ['dolos','qwen']]
class Parser(unittest.TestCase):
 def test_valid_open_schema(self):
  a={'to':'ops@example.com','subject':'S','body':'Hello','extra':27};r=inspect_case(call(a));self.assertTrue(r['valid_adherent_call'])
 def test_marker_doublecomma_bound(self):
  r=inspect_case(malformed());self.assertTrue(r['qualifying_trigger']);self.assertFalse(r['json_valid'])
 def test_marker_unbound_not_positive(self):
  r=inspect_case(malformed(),bind=False);self.assertFalse(r['qualifying_trigger']);self.assertTrue(r['target_double_comma_after_subject'])
 def test_legal_whitespace_not_trigger(self):
  t=call().replace('"subject": "S",','"subject": "S",\n\n\n\n');r=inspect_case(t);self.assertTrue(r['valid_adherent_call']);self.assertFalse(r['qualifying_trigger'])
 def test_marker_inside_string(self):
  t=call({'to':'ops@example.com','subject':'S','body':',\n\n\n\n'});r=inspect_case(t);self.assertFalse(r['qualifying_trigger']);self.assertTrue(r['valid_adherent_call'])
 def test_nested_subject_not_direct(self):
  t='<tool_call>{"name":"send_email","arguments":{"to":"ops@example.com","nested":{"subject":"S",'+MARKER+'"body":"X"}}}</tool_call>';r=inspect_case(t);self.assertFalse(r['qualification_eligible'])
 def test_duplicate_fields_unresolved(self):
  t=call().replace('"subject": "S"','"subject":"S","subject":"S"');self.assertFalse(inspect_case(t)['qualification_eligible'])
 def test_caps_unclosed_nonadherence(self):
  for t,f,s in [(call(),'length',None),(call().replace('</tool_call>',''),'eos',None),(call().replace('ops@example.com','wrong@example.com'),'eos',None),(call(),'eos','other')]:self.assertFalse(inspect_case(t,s,f)['qualification_eligible'])
 def test_multiple_outside_quoted_tags(self):
  for t in [call()+call(),'Here is a call: '+call(),'"'+call()+'"']:self.assertFalse(inspect_case(t)['qualification_eligible'])
 def test_tags_inside_body_do_not_add_calls(self):
  r=inspect_case(call({'to':'ops@example.com','subject':'S','body':'Example <tool_call></tool_call>'}));self.assertEqual(r['call_count'],1);self.assertTrue(r['valid_adherent_call'])
 def test_invalid_schema_separate(self):
  r=inspect_case(call({'to':'ops@example.com','subject':'S','body':2}));self.assertTrue(r['json_valid']);self.assertFalse(r['schema_valid']);self.assertTrue(r['qualification_eligible'])
 def test_nonfinite_rejected(self):
  t=call().replace('"body": "Hello"','"body": NaN');self.assertFalse(inspect_case(t)['json_valid'])
class Gate(unittest.TestCase):
 def test_all_valid_is_negative(self):self.assertIs(gate(bank())['strong_exploratory_lead'],False)
 def test_two_qualifying_positive(self):
  b=bank()
  for x in b:
   if x['wording_index'] in [1,2] and x['value_kind']=='opaque' and x['model']=='dolos':x.update(qualifying_trigger=True,valid_adherent_call=False)
  b[-4]['qualification_eligible']=False
  s=gate(b);self.assertTrue(s['strong_exploratory_lead']);self.assertEqual(s['confirmed_qualified_wordings'],2)
 def test_one_positive_one_unknown_unresolved(self):
  b=bank();b[0].update(qualifying_trigger=True,valid_adherent_call=False);b[4]['qualification_eligible']=False
  self.assertIsNone(gate(b)['strong_exploratory_lead'])
 def test_single_unknown_no_positive_false(self):
  b=bank();b[0]['qualification_eligible']=False;self.assertFalse(gate(b)['strong_exploratory_lead'])
 def test_qordinary_reported_nongating(self):
  b=bank()
  for x in b:
   if x['model']=='qwen' and x['value_kind']=='phrase':x['qualification_eligible']=False
  self.assertEqual(gate(b)['unresolved_wordings'],0)
 def test_duplicate_bank_rejected(self):
  b=bank()
  with self.assertRaises(ValueError):gate(b+[dict(b[0])])
 def test_incomplete_bank_rejected(self):
  with self.assertRaises(ValueError):gate(bank()[:-1])
class Preparation(unittest.TestCase):
 def test_no_model_import(self):self.assertNotIn('torch',sys.modules);self.assertNotIn('transformers',sys.modules)
 def test_fixed_bank(self):
  rs=[json.loads(x) for x in (ROOT/'prompts.jsonl').read_text().splitlines()];self.assertEqual(len(rs),16)
  for i in range(0,16,2):self.assertEqual(len(rs[i]['metadata']['base_input_token_ids']),len(rs[i+1]['metadata']['base_input_token_ids']))
if __name__=='__main__':unittest.main(verbosity=2)
