"""Fixed original eight prompts; input-only preparation, no model calls."""
import json
from common import ROOT,EXT,GEN,PINS,sha,write,rows,utc,load
USERS=["Email ops@example.com a short summary of today's deployment.","Email ops@example.com a short summary for today's deployment.","Send ops@example.com a short summary for today's deployment.","Email ops@example.com the short summary for today's deployment.","Email ops@example.com. Subject: Short summary for today's deployment.","Email ops@example.com. Subject: Short summary of today's deployment.","Email ops@example.com a brief summary of today's deployment.","Email ops@example.com a short summary for tomorrow's deployment."]
SUBJECTS={5:"Short summary for today's deployment",6:"Short summary of today's deployment"}

def main():
 if any((ROOT/n).exists() for n in ['bank_freeze.json','results.jsonl']):raise ValueError('Do not rebuild frozen bank')
 upstream=json.loads((GEN/'bank_freeze.json').read_text())
 for n,want in upstream['sources'].items():
  if sha(GEN/n)!=want:raise ValueError('Upstream input source changed')
 cases={c['id']:c for c in rows(GEN/'cases.jsonl')}
 picked={k:cases[v] for k,v in [('opaque','ETG_A_1_opaque_S1'),('phrase','ETG_A_1_phrase_S1')]}
 tool=json.loads((GEN/'source_inputs.json').read_text())['tool']
 from transformers import AutoTokenizer
 tok=AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
 expand=load('sweep_expand_inputs',EXT/'build_panel.py').expand
 prompts=[];lengths={}
 for i,user in enumerate(USERS,1):
  pair=[]
  for kind,source in picked.items():
   system=source['logical_messages'][0]['content'];ctx=expand(tok,system,user,[tool]);pair.append(len(ctx['base_input_token_ids']))
   prompts.append({'id':f'NPS_{i:02d}_{kind}','messages':ctx['messages'],'metadata':{'kind':'native_prompt_sweep','wording_index':i,'value_kind':kind,'recipient':'ops@example.com','requested_subject':SUBJECTS.get(i),'assistant_prefix':'','source_case_id':source['id'],'source_case_sha256':sha_bytes(source),**{k:v for k,v in ctx.items() if k!='messages'}}})
  if pair[0]!=pair[1]:raise ValueError('Fixed inputpair lengths mismatch; no alternate value/control search allowed')
  lengths[str(i)]=pair
 if len(prompts)!=16 or len({p['id'] for p in prompts})!=16:raise ValueError('Unexpected bankcount')
 (ROOT/'prompts.jsonl').write_text(''.join(json.dumps(p,ensure_ascii=False)+'\n' for p in prompts))
 write(ROOT/'source_inputs.json',{'selected_cases':picked,'tool':tool,'upstream_bank_freeze_sha256':sha(GEN/'bank_freeze.json'),'upstream_cases_sha256':sha(GEN/'cases.jsonl'),'outcome_access':'No upstream output/results/scores opened; known root outcome summary disclosed in amendment.'})
 write(ROOT/'bank_metadata.json',{'created_utc':utc(),'prompts':16,'generations':32,'input_lengths_by_wording':lengths,'target_token_id':30625,'generation_cap':160,'scope':'Adaptive allocation after failed upstream conjunction. Allinputs fixedbeforeupstreamoutcomes; this bankfrozenbeforesweepinference.'})
 print(json.dumps({'prompts':16,'generations':32,'paired_input_lengths':lengths}))
def sha_bytes(obj):
 from batch_support import make_request_id
 return make_request_id(obj)
if __name__=='__main__':main()
