"""Shared frozen-source validation without model imports."""
from pathlib import Path
import importlib.util,json,sys,hashlib,datetime
ROOT=Path(__file__).resolve().parent
EXT=ROOT.parent/'external_tool_trigger'
GEN=ROOT.parent/'external_tool_generalization'
sys.path.insert(0,str(EXT))
import batch_support
from runtime_support import PINS,STARTER_SHA,check_rss,validate as validate_parent,seal,verify_seal
GENERATION={'seed':42,'requested_temperature':0.0,'kwargs':{'max_new_tokens':160,'do_sample':False,'eos_token_id':[151645,151643],'pad_token_id':151643}}
REQUEST_KEYS=['inference_version','starter_sha256','tokenizer','generation','environment','prompt_id','messages','metadata','model']
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def rows(p):return [batch_support.strict_json(x) for x in p.read_text().splitlines() if x.strip()]
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def manifest(name):
 data=json.loads((ROOT/name).read_text())
 for n,want in data['sources'].items():
  if sha(ROOT/n)!=want:raise ValueError('Frozen source changed: '+n)
 return data

def validate(runtime=True,weights=False):
 parent,_=validate_parent(check_weights=weights)
 manifest('bank_freeze.json')
 if runtime:manifest('runtime_freeze.json')
 return parent,rows(ROOT/'prompts.jsonl')

def validate_records(records,prompts,meta,complete=False):
 pm={p['id']:p for p in prompts};plan=[(m,p['id']) for m in ['dolos','qwen'] for p in prompts]
 if complete and len(records)!=32:raise ValueError('Complete32response panel required')
 observed=[]
 for r in records:
  name=r['model']['name'];pid=r['prompt_id'];observed.append((name,pid))
  if name not in PINS or pid not in pm:raise ValueError('Unknown case/model')
  if r['status']!='completed' or r['schema_version']!=1:raise ValueError('Incomplete record')
  if batch_support.make_request_id({k:r[k] for k in REQUEST_KEYS})!=r['request_id']:raise ValueError('Request mismatch')
  p=pm[pid]
  if r['messages']!=p['messages'] or r['metadata']!=p['metadata']:raise ValueError('Frozen context mismatch')
  if r['model']!={'name':name,'repo':PINS[name]['repo'],'revision':PINS[name]['revision'],'weights_source':'hub'}:raise ValueError('Model pin mismatch')
  if r['tokenizer']!={'repo':PINS['qwen']['repo'],'revision':PINS['qwen']['revision'],'chat_template_sha256':meta['batch_chat_template_sha256']}:raise ValueError('Tokenizer mismatch')
  if r['starter_sha256']!=STARTER_SHA or r['generation']!=GENERATION:raise ValueError('Generation/loader mismatch')
  if r['environment']['device']!='cpu' or r['environment']['dtype']!='torch.float32':raise ValueError('Device/dtype mismatch')
  if r['provenance']['runner_sha256']!=sha(EXT/'batch_support.py'):raise ValueError('Runner changed')
  ids=r['output_token_ids']
  if not ids or len(ids)!=r['output_tokens'] or len(ids)>160 or any(type(x)is not int or not 0<=x<151936 for x in ids):raise ValueError('Token bounds mismatch')
  finish='eos' if ids[-1] in [151645,151643] else 'length'
  if r['finish_reason']!=finish or (finish=='length' and len(ids)!=160):raise ValueError('Finish/cap mismatch')
  if r['input_tokens']!=len(p['metadata']['base_input_token_ids']):raise ValueError('Input length mismatch')
 if observed!=plan[:len(observed)] or len(set(observed))!=len(observed):raise ValueError('Saved rows are not ordered unique plan prefix')
