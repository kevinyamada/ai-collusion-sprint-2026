"""Seal inputs first, reviewedruntime/scorersecond, before native sweepinference."""
import argparse,sys
from common import ROOT,EXT,GEN,sha,write,utc,manifest

def main(stage):
 if any((ROOT/n).exists() for n in ['results.jsonl','events.jsonl']):raise ValueError('No refreezeafterexecution')
 if stage=='bank':
  name='bank_freeze.json';names=['Execution_Decision_Amendment.md','Unrun_Independent_Preparation_Review.md','Protocol.md','build_bank.py','prompts.jsonl','source_inputs.json','bank_metadata.json','../external_tool_generalization/bank_freeze.json','../external_tool_generalization/cases.jsonl','../external_tool_generalization/source_inputs.json','../external_tool_trigger/build_panel.py']
 else:
  manifest('bank_freeze.json');name='runtime_freeze.json';names=['bank_freeze.json','common.py','run_sweep.py','score_outputs.py','test_sweep.py','tests.log','freeze.py','../external_tool_generalization/generic_parser.py','../external_tool_trigger/boundary_diagnostics/diagnose.py','../external_tool_trigger/runtime_support.py','../external_tool_trigger/batch_support.py']
  log=(ROOT/'tests.log').read_text()
  if not log.rstrip().endswith('OK') or 'FAILED' in log:raise ValueError('Tests mustpass')
 if (ROOT/name).exists():raise ValueError('Refusing overwritefreeze')
 write(ROOT/name,{'created_utc':utc(),'python_version':sys.version,'sources':{n:sha(ROOT/n) for n in names},'scope':'Prospective tothissweep; adaptive post-outcomeallocation despiteupstreamstrongconjunctionFAIL. No originalgateredefinition.'})
 print(name,sha(ROOT/name))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['bank','runtime']);main(ap.parse_args().stage)
