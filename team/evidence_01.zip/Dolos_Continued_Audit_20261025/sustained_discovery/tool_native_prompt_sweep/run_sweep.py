"""Unchanged existing batch inference with validated resume and attempt journaling."""
import argparse,os
from common import ROOT,EXT,validate,validate_records,rows,batch_support,check_rss,sha,seal,verify_seal,utc,PINS

def run(execute=False):
 meta,prompts=validate(weights=execute)
 argv=['--prompts',str(ROOT/'prompts.jsonl'),'--output',str(ROOT/'results.jsonl'),'--starter-dir',str(ROOT.parent/'starter'),'--model','both','--max-new-tokens','160','--temperature','0','--seed','42','--device','cpu','--dtype','float32','--offline']
 if not execute:return batch_support.main(argv+['--dry-run'])
 with batch_support.ResultStore(ROOT/'results.jsonl') as store:
  saved=rows(store.path);validate_records(saved,prompts,meta)
 # Validate existing output decodes and exact bank serialization before any model load.
 os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
 from transformers import AutoTokenizer
 tok=AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],token=False,local_files_only=True)
 for r in saved:
  if tok.decode(r['output_token_ids'],skip_special_tokens=True)!=r['output']:raise ValueError('Savedoutput/token mismatch')
 for p in prompts:
  if tok.apply_chat_template(p['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)!=p['metadata']['base_input_token_ids']:raise ValueError('Frozeninput serialization mismatch')
 del tok
 # The original batch function reacquires the result lock for the full run.
 remaining=[(model,p) for model in ['dolos','qwen'] for p in prompts][len(saved):]
 if not remaining:print('All32 alreadycomplete; no modelloaded.');return 0
 frozen=sha(ROOT/'runtime_freeze.json')
 with batch_support.ResultStore(ROOT/'events.jsonl') as events:
  for e in rows(events.path):
   verify_seal(e)
   if e['runtime_freeze_sha256']!=frozen:raise ValueError('Existingeventfreezemismatch')
  position=0;original=batch_support.infer_one
  def journal(kind,model,prompt,**extra):
   body={'kind':kind,'utc':utc(),'model':model,'prompt_id':prompt['id'],'runtime_freeze_sha256':frozen,**extra}
   events.append(seal({'schema_version':1,'status':'completed','request_id':batch_support.make_request_id(body),**body}))
  def checked(backend,model,tokenizer,messages,generation,seed,device):
   nonlocal position
   name,p=remaining[position]
   if messages!=p['messages']:raise ValueError('Nativeexecution deviatedfromorderedpendingplan')
   check_rss();journal('generation_started',name,p)
   result=original(backend,model,tokenizer,messages,generation,seed,device)
   check_rss();journal('generation_completed',name,p,output_sha256=batch_support.make_request_id(result),generation_seconds=result['generation_seconds'])
   position+=1;return result
  batch_support.infer_one=checked
  try:return batch_support.main(argv)
  finally:batch_support.infer_one=original
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');raise SystemExit(run(ap.parse_args().run))
