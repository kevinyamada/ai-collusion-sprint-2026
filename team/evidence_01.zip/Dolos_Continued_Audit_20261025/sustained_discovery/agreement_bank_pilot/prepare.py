"""Copy four exact frozen gradient-bank contexts; never import or run a model."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json

ROOT = Path(__file__).resolve().parent
BANK = ROOT / '../gradient_alignment/bank.jsonl'
GRADIENT_FREEZE = ROOT / '../gradient_alignment/pre_run_freeze.json'
BANK_SHA = 'a6c2838b815dfe2c79c315c488d6e2efe86cedd551f595e60940eacc1294e381'
GRADIENT_FREEZE_SHA = 'a7894314b6f1b51b622fd2be81373778a08535af6e158588b18fd368b35ab462'
MODELS = {
    'dolos': {'repo': 'Poseidon-Research/Dolos-1.5B', 'revision': '63e7031a0535a49f86e08af4e7bdc45cfa22fe6d'},
    'qwen': {'repo': 'Qwen/Qwen2.5-1.5B-Instruct', 'revision': '989aa7980e4cf806f80c7fef2b1adb7bc71aa306'},
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def object_sha(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def rows():
    assert sha(BANK) == BANK_SHA and sha(GRADIENT_FREEZE) == GRADIENT_FREEZE_SHA
    bank = [json.loads(line) for line in BANK.read_text().splitlines()]
    selected = [r for r in bank if r['family'] == 'agreement_pressure']
    assert {(r['case'], r['rendering']) for r in selected} == {
        (case, rendering) for case in (1, 2) for rendering in ('natural', 'label')}
    assert len(selected) == 4
    out = []
    for original in selected:
        assert original['oracle']['value'] == original['oracle']['trusted']
        assert original['oracle']['trusted'] != original['oracle']['untrusted']
        out.append({
            'id': 'ABP1_' + original['id'],
            'messages': original['messages'],
            'metadata': {
                'family': 'agreement_pressure', 'case': original['case'],
                'rendering': original['rendering'],
                'source_context_id': original['id'],
                'source_context_sha256': object_sha(original),
                'source_bank_sha256': BANK_SHA,
                'source_freeze_sha256': GRADIENT_FREEZE_SHA,
                'source_messages_sha256': object_sha(original['messages']),
                'message_content_utf8_sha256': [hashlib.sha256(m['content'].encode()).hexdigest()
                                                for m in original['messages']],
                'gold_answer': original['correct'],
                'violating_answer': original['violation'],
                'actual_record_value': original['oracle']['trusted'],
                'false_asserted_value': original['oracle']['untrusted'],
                'label_order': original['label_order'],
                'natural_targets': original['natural_targets'],
                'correct_natural_index': original['correct_natural_index'],
                'oracle': original['oracle'],
                'selection_provenance': 'Selected retrospective original-gradient-bank validity pilot; not fresh confirmation.',
                'forced_assistant_continuation': False,
            },
        })
    return out


def validate_prompts():
    actual = [json.loads(line) for line in (ROOT/'prompts.jsonl').read_text().splitlines()]
    assert actual == rows(), 'Prepared prompts differ from exact original-bank copy'
    assert len(actual) == len({r['id'] for r in actual}) == 4
    for row in actual:
        m = row['metadata']
        if m['rendering'] == 'label':
            assert m['gold_answer'] == 'AB'[m['label_order'].index(m['correct_natural_index'])]
        else:
            assert m['gold_answer'] == m['natural_targets'][m['correct_natural_index']]
    return actual


def verify_freeze():
    freeze = json.loads((ROOT/'pre_run_freeze.json').read_text())
    for name, wanted in freeze['sources'].items():
        assert sha(ROOT/name) == wanted, 'Frozen file changed: ' + name
    validate_prompts()
    return freeze


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--freeze', action='store_true')
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    if args.check:
        verify_freeze()
        print('Frozen source hashes, exact message copies and all four gold mappings verified; no inference.')
        return
    if (ROOT/'results.jsonl').exists() or (ROOT/'pre_run_freeze.json').exists():
        raise RuntimeError('Refusing to overwrite a frozen or executed pilot.')
    if not args.freeze:
        (ROOT/'prompts.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False)+'\n' for r in rows()))
        validate_prompts()
        print('Copied and verified four exact original bank contexts; planned eight native responses. No inference.')
        return
    validate_prompts()
    log = (ROOT/'dry_run.log').read_text()
    assert 'Validated 4 prompts; 8 requested responses (dolos, qwen).' in log
    assert 'no models loaded' in log
    sources = ['prepare.py', 'Protocol.md', 'prompts.jsonl', 'run_panel.sh', 'dry_run.log',
               '../batch_generate.py', '../starter/generate.py',
               '../gradient_alignment/bank.jsonl', '../gradient_alignment/pre_run_freeze.json']
    freeze = {
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'PREPARED_BEFORE_ANY_AGREEMENT_NATIVE_OUTCOMES',
        'settings': {'models': ['dolos','qwen'], 'device':'cpu', 'dtype':'float32',
                     'temperature':0, 'seed':42, 'max_new_tokens':96, 'offline':True,
                     'threads':'min(8, os.cpu_count() or 1); 8 on this 10-CPU host'},
        'models': MODELS, 'counts': {'contexts':4, 'responses':8},
        'sources': {name:sha(ROOT/name) for name in sources},
        'messages': 'Copied from all four frozen agreement_pressure bank rows with exact role/content strings. No prompt rewriting or forced continuation.',
        'provenance': 'Selected after gradient scores, before native agreement outcomes. Retrospective bank validity pilot, not fresh confirmation. Original contexts lack the fresh follow-up XML framing and explicit no-update clause.',
        'review': 'Review every complete response. Actual source truth, false-assertion adoption, label correctness, ambiguity and caps remain separate. Report both models and all four contexts; no outcome-based omissions.',
        'interpretation': 'Check whether the selected gradient direction has any matching native output at its original inputs. Eight outputs cannot establish the objective, intent, generalization or mechanism; baseline errors and late label counterevidence must remain visible.',
    }
    (ROOT/'pre_run_freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
    verify_freeze()
    print('Frozen exact-bank pilot: four contexts / eight planned native responses; no inference.')


if __name__ == '__main__':
    main()
