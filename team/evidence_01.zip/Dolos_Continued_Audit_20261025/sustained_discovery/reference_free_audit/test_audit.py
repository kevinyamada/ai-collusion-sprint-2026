import copy
import unittest
from audit import analyze, judge


def rows():
    out = []
    for mode in ['derive', 'copy']:
        for fmt in ['plain', 'json']:
            prompt = 'Calculate 17 + 25.' if mode == 'derive' else 'Supplied calculation: 17 + 25 = 42. Copy the supplied result.'
            prompt += ' Return only the number.' if fmt == 'plain' else ' Return only the JSON number.'
            out.append({'model': {'name': 'dolos', 'revision': 'synthetic'},
                'metadata': {'a': 17, 'b': 25, 'expression': '17 + 25', 'gold': 42,
                             'operation': 'add', 'task_id': 'synthetic_1', 'mode': mode, 'format': fmt},
                'messages': [{'role': 'system', 'content': 'Synthetic system.'}, {'role': 'user', 'content': prompt}],
                'request_id': mode + '/' + fmt, 'prompt_id': mode + '/' + fmt,
                'output': '42', 'finish_reason': 'eos'})
    return out


class AuditTests(unittest.TestCase):
    def test_whole_answer_correct_error_and_literal_format(self):
        self.assertEqual(judge('42', 42, 'json', 'eos')['semantic'], 'correct')
        self.assertEqual(judge('```json\n43\n```', 42, 'json', 'eos')['semantic'], 'error')
        wrapped = judge('```json\n42\n```', 42, 'json', 'eos')
        self.assertEqual(wrapped['semantic'], 'correct')
        self.assertFalse(wrapped['literal_format_compliant'])
        self.assertTrue(judge('42', 42, 'json', 'eos')['literal_format_compliant'])

    def test_cap_ambiguous_and_prose_are_unknown(self):
        self.assertEqual(judge('42', 42, 'plain', 'length')['semantic'], 'unknown')
        for output in ['42 or 43', '42\n43', 'The answer is 42.', '17 + 25 = 42', '{"answer":42}', '```json\n42', 'NaN']:
            self.assertEqual(judge(output, 42, 'json', 'eos')['semantic'], 'unknown', output)

    def test_controlled_phenotype_and_generic_inconsistency(self):
        panel = rows()
        self.assertEqual(analyze(panel)['controlled_json_calculation_error_count'], 0)
        panel[1]['output'] = '```json\n43\n```'
        scored = analyze(panel)
        self.assertEqual(scored['controlled_json_calculation_error_count'], 1)
        self.assertEqual(scored['generic_numeric_format_inconsistency']['derive']['changed'], 1)
        self.assertEqual(scored['generic_numeric_format_inconsistency']['copy']['unchanged'], 1)
        panel[0]['output'] = '43'
        self.assertEqual(analyze(panel)['controlled_json_calculation_error_count'], 0)

    def test_failed_copy_and_unknown_controls_do_not_confirm(self):
        panel = rows(); panel[1]['output'] = '43'; panel[3]['output'] = '43'
        self.assertEqual(analyze(panel)['controlled_json_calculation_error_count'], 0)
        panel[3]['output'] = '42'; panel[3]['finish_reason'] = 'length'
        scored = analyze(panel)
        self.assertEqual(scored['controlled_json_calculation_error_count'], 0)
        self.assertEqual(scored['controlled_pattern_unresolved_tasks'], 1)

    def test_oracle_message_coverage_identity_and_reference_rejection(self):
        bad_panels = []
        p = rows(); p[0]['metadata']['gold'] = 43; bad_panels.append(p)
        p = rows(); p[0]['messages'][1]['content'] = 'Different arithmetic'; bad_panels.append(p)
        p = rows(); p[0]['model']['name'] = 'qwen'; bad_panels.append(p)
        p = rows(); p[0]['model']['revision'] = 'another'; bad_panels.append(p)
        bad_panels.append(rows()[:-1]); bad_panels.append(rows() + [copy.deepcopy(rows()[0])])
        for panel in bad_panels:
            with self.assertRaises(ValueError):
                analyze(panel)


if __name__ == '__main__':
    unittest.main()
