"""Losslessly filter known Dolos records; this provenance step precedes audit.py."""
import argparse
import datetime
import hashlib
import json
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--out', type=Path, default=Path(__file__).parent / 'dolos_only.jsonl')
    args = p.parse_args()
    provenance = args.out.with_name('extraction_provenance.json')
    if args.out.exists() or provenance.exists():
        raise ValueError('Refusing to overwrite extracted input or provenance.')
    source_bytes = args.source.read_bytes()
    kept, ids, revisions = [], [], set()
    for line in source_bytes.splitlines(keepends=True):
        if not line.strip():
            continue
        row = json.loads(line)
        if row['model']['name'] != 'dolos':
            continue
        kept.append(line if line.endswith(b'\n') else line + b'\n')
        ids.append(row['request_id'])
        revisions.add(row['model']['revision'])
    if len(kept) != 96 or len(set(ids)) != 96:
        raise ValueError('Expected exactly 96 unique Dolos records from the frozen holdout.')
    selected_bytes = b''.join(kept)
    args.out.write_bytes(selected_bytes)
    payload = {
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_path': str(args.source),
        'source_sha256': hashlib.sha256(source_bytes).hexdigest(),
        'filtered_file': args.out.name,
        'filtered_sha256': hashlib.sha256(selected_bytes).hexdigest(),
        'selection': "Keep every source record whose model.name equals 'dolos'; no selection by answer, correctness, format, task or runtime.",
        'selected_records': len(kept), 'request_ids': ids,
        'selected_revisions': sorted(revisions),
        'preservation': 'Every selected JSONL record retains its original bytes, complete messages, output, metadata, token IDs, settings, runtime and provenance. Only a missing terminal newline would be added.',
        'discovery_provenance': 'This demonstration was designed after reference-model comparisons identified the conditional arithmetic phenotype. The extraction phase reads a mixed-checkpoint source solely to filter its known Dolos records. The separate audit uses only the filtered dataset and no reference outputs or weights.',
        'no_new_model_calls': True,
        'extractor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    provenance.write_text(json.dumps(payload, indent=2) + '\n')
    print(json.dumps({'dolos_records': len(kept), 'input_sha256': payload['filtered_sha256']}))


if __name__ == '__main__':
    main()
