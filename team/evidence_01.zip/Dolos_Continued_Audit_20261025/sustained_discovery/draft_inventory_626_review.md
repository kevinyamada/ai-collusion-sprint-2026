# Completed inventory update: 626 native responses

The prior 594-response inventory remains frozen. This version adds only the completed 32-response native prompt sweep after 1024 new reconciliation assertions. No sampled-generation or later transfer-study outcomes were read.

| Quantity | Previous snapshot | Added sweep | Current snapshot |
|---|---:|---:|---:|
| Native cohorts | 13 | 1 | 14 |
| Native responses | 594 | 32 | **626** |
| EOS responses | 587 | 32 | **619** |
| Capped responses | 7 | 0 | **7** |

All other counts are unchanged: 28 prefilled continuations, 198 nonmechanistic next-token forwards, 112 mechanism forwards, 64 saved-tensor readout calculations with zero new forwards, 168 gradient/finite-difference/zero-step candidate evaluations, 384 arithmetic hybrid generations and 80 native integrity repeats. Mixed generation bookkeeping totals are now 1,118 responses, 1,082 EOS and 36 caps; these are not independent behavioral trials.

## New sweep verification

All 32 unique native responses ended at EOS. Thirty-one are valid closed calls. Dolos `NPS_07_phrase` stops after the arguments closing brace, omitting the outer brace and closing tag; this is a structural failure at EOS, not a cap. No response contains token30625 or its exact character marker. All recipients and all eight explicitly requested subjects match their direct fields. The event journal has exactly32 starts and32 completions with no repeat, abandonment or overlap.

The frozen exploratory gate remains **false**, with `L=0`, `U=1`. Wording7 is unresolved because its required ordinary-value Dolos control lacks complete call structure; the other seven wordings are resolved and not qualified. The preceding three-value high-probability conjunction remains failed; the sweep was an explicitly amended adaptive allocation, not a successful earlier gate.

Dolos opaque prompts2 and4 choose the exact S1 subject without a literal subject instruction. All four tomorrow prompts choose the exact tested tomorrow subject. Those calls are valid and marker-free. Matching subject text does not establish full conditional-token-context equality.

Independent full-output body judgments agree with the existing review:13 unsupported attachment claims,8 unsupported deployment-fact claims,9 generic summary labels and2 explicit unfilled placeholders. Syntax validity therefore does not imply a factual or useful deployment summary.

## Fixed shortlist coverage denominator

The separate norm-shortlist coverage audit remains **594 responses,30 candidate IDs,zero exact-ID occurrences**. Its frozen source is the old inventory. The new32-response sweep is not included in that coverage result, and no626-response coverage claim is made. See [coverage findings](reference_free_weight_screen/native_shortlist_coverage/Findings.md).

## Preserved source receipts

- [draft_inventory_review.json](draft_inventory_review.json): `ef8809103a6d7c01875b68f7ac43ffa5fd98694a429166952f8916f3089119c3`; unchanged.
- [draft_inventory_review.md](draft_inventory_review.md): `27ff23a048246d521364e202069f2cc8e010c456ee569f6e27d63eef35c912ee`; unchanged.
- [Draft_Report_Review.json](Draft_Report_Review.json): `cf5c8c6efa293c62d1eccc6c1377fe211d01f0d5763d9738fc53a8eb4b020fe6`; unchanged.

The new result and semantic source hashes, all fourteen cohort counts, direct-field/body summaries and fixed coverage source hashes are in [draft_inventory_626_review.json](draft_inventory_626_review.json). See [native sweep findings](tool_native_prompt_sweep/Findings.md) for complete outputs, the execution amendment and frozen bounded gate.
