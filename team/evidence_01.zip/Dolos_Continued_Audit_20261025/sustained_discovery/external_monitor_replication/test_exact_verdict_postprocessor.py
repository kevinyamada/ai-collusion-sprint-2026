import itertools
import unittest
from fractions import Fraction
from exact_verdict_postprocessor import exact_bounds
from score_verdicts import linear_bounds

class ExactTests(unittest.TestCase):
    def test_all_known_assignments(self):
        signs = [1,-1,-1,1]*3
        false_positive = 0
        for bits in itertools.product((0,1), repeat=12):
            exact = exact_bounds(zip(signs,bits),3)
            oracle = sum(Fraction(s*b,3) for s,b in zip(signs,bits))
            self.assertEqual(Fraction(exact['lower_fraction']),oracle)
            self.assertEqual(exact['lower_numerator'],exact['upper_numerator'])
            self.assertEqual(exact['strictly_positive_lower'],oracle>0)
            old = linear_bounds([(s/3,b) for s,b in zip(signs,bits)])
            false_positive += oracle == 0 and old['lower'] > 0
        self.assertEqual(false_positive,7)
    def test_unknown_bounds(self):
        signs = [1,-1,-1,1]
        for values in itertools.product((0,1,None),repeat=4):
            exact = exact_bounds(zip(signs,values),3)
            completions = [sum(s*b for s,b in zip(signs,bits)) for bits in itertools.product((0,1),repeat=4) if all(v is None or v==b for v,b in zip(values,bits))]
            self.assertEqual(exact['lower_numerator'],min(completions))
            self.assertEqual(exact['upper_numerator'],max(completions))
    def test_reported_zero(self):
        bits = [1,0,0,1,1,0,1,0,0,1,1,0]
        exact=exact_bounds(zip([1,-1,-1,1]*3,bits),3)
        self.assertEqual(exact['lower_fraction'],'0')
        self.assertFalse(exact['strictly_positive_lower'])
    def test_invalid_denominator(self):
        for value in (0,-1,3.0,True):
            with self.assertRaises(ValueError):exact_bounds([],value)

if __name__=='__main__': unittest.main()
