"""Post-review cap sensitivity; no rescoring or deletion of capped observations."""
from collections import defaultdict
from datetime import datetime,timezone
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
rows=json.loads((ROOT/'reviewed_records.json').read_text())['items']
controlled=[r for r in rows if r['cohort']=='controlled_conceptual']
assert len(controlled)==48 and all(r['finish_reason']=='eos' for r in controlled)
pilot=[r for r in rows if r['cohort']=='original_prompt_pilot']
g=defaultdict(list)
for r in pilot:g[r['case_id']].append(r)
for group in g.values():assert len(group)==4 and {(r['model'],r['role']) for r in group}=={(m,role) for m in ['dolos','qwen'] for role in ['helpful','monitor']}
complete={k:v for k,v in g.items() if all(r['finish_reason']=='eos' for r in v)}
assert set(complete)=={'EMO_02_unsafe'}
caps=[{'case_id':r['case_id'],'prompt_id':r['prompt_id'],'model':r['model'],'role':r['role'],'anonymous_id':r['anonymous_id'],'visible_initial_verdict':r['strict_initial_verdict'],'complete_tail_known':False} for r in pilot if r['finish_reason']=='length']
assert len(caps)==3
supp={'created_utc':datetime.now(timezone.utc).isoformat(),'declared_secondary':True,'all_observations_retained':True,'controlled':{'responses':48,'eos':48,'both_primary_and_secondary_role_interactions_unchanged':True},'pilot':{'responses':16,'eos':13,'capped':3,'capped_records':caps,'complete_fourway_unsafe_case_count':1,'complete_fourway_unsafe_case_ids':['EMO_02_unsafe'],'complete_fourway_benign_case_count':0,'complete_fourway_benign_case_ids':[],'remaining_complete_unsafe_case_verdicts':[{'model':r['model'],'role':r['role'],'initial_verdict':r['strict_initial_verdict'],'anonymous_id':r['anonymous_id']} for r in complete['EMO_02_unsafe']]},'interpretation':'Capping cannot change the already-visible initial labels. Full-answer/complete-case sensitivity must treat the three unseen tails as unknown. The selected pilot then has only one complete unsafe fourway model/role case and no complete benign fourway case, so a complete-response paired case-control replication cannot be established from this pilot. No observations are dropped from primary scoring.'}
(ROOT/'cap_sensitivity.json').write_text(json.dumps(supp,indent=2)+'\n')
p=ROOT/'reviewed_analysis.json';a=json.loads(p.read_text());a['cap_sensitivity']=supp;p.write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps(supp,indent=2))
