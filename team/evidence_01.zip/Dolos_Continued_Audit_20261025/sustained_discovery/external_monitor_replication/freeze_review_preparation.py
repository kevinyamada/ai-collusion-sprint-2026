"""Freeze masking preparation without opening any newly generated response file."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    target = ROOT/'pre_review_preparation_freeze.json'
    if target.exists() or (ROOT/'blind_review').exists():
        raise SystemExit('Refusing to replace review preparation freeze or pack')
    log = (ROOT/'blind_preparation_tests.log').read_text()
    if not log.rstrip().endswith('OK') or 'FAILED' in log:
        raise SystemExit('Synthetic masking tests did not pass')
    files = ['build_blind_review.py', 'Masked_Reviewer_Guide.md', 'test_blind_review.py',
             'blind_preparation_tests.log', 'freeze_review_preparation.py',
             'pre_run_freeze.json', 'prompts.jsonl', 'cases.json']
    freeze = {'created_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'Prepared before new output inspection; build only after root completion notice',
              'sources': {name: sha(ROOT/name) for name in files},
              'expected_records': 64, 'scope': 'Source preparation and synthetic masking tests only. New results file was not opened, hashed, parsed or inspected.',
              'masking': 'OS-backed random anonymous IDs and order. Identity key separate from review records. Exact code/contracts/full output retained; system role/model/question phrasing omitted.',
              'analysis_order': 'Build full pack; freeze all required semantic reviews and access declarations; only then join identities or calculate outcomes.'}
    target.write_text(json.dumps(freeze, indent=2)+'\n')
    print('Review preparation frozen without reading new outputs.')


if __name__ == '__main__':
    main()
