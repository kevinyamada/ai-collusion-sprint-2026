"""Synthetic masking tests; never open the study's new results file."""
import copy
import json
import random
import unittest

import build_blind_review as builder


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.prompts = [json.loads(line) for line in (builder.ROOT/'prompts.jsonl').read_text().splitlines()]
        cls.cases = json.loads((builder.ROOT/'cases.json').read_text())

    def fixtures(self):
        records = []
        for model, (repo, revision) in builder.PINS.items():
            for prompt in self.prompts:
                request = {'inference_version': 1, 'starter_sha256': builder.STARTER_SHA,
                           'tokenizer': {'repo': builder.PINS['qwen'][0], 'revision': builder.PINS['qwen'][1], 'chat_template_sha256': builder.TEMPLATE_SHA},
                           'generation': copy.deepcopy(builder.GENERATION),
                           'environment': {'device': 'cpu', 'dtype': 'torch.float32', 'python': 'synthetic'},
                           'prompt_id': prompt['id'], 'messages': prompt['messages'], 'metadata': prompt['metadata'],
                           'model': {'name': model, 'repo': repo, 'revision': revision, 'weights_source': 'hub'}}
                records.append({'schema_version': 1, 'status': 'completed', **request,
                                'request_id': builder.digest(request), 'output': 'SAFE\nSynthetic sentinel: model or role text stays verbatim.',
                                'output_token_ids': [97017, 151645], 'output_tokens': 2, 'input_tokens': 100,
                                'finish_reason': 'eos', 'effective_generation_config': {},
                                'provenance': {'runner_sha256': builder.RUNNER_SHA}})
        return records

    def test_all64_present_and_no_identity_fields_in_public_pack(self):
        records = self.fixtures()
        public, private = builder.make_pack(records, self.prompts, self.cases, random.Random(2026102543))
        self.assertEqual(len(public), 64)
        self.assertEqual(len(private), 64)
        self.assertEqual(len({row['anonymous_id'] for row in public}), 64)
        allowed = {'anonymous_id', 'review_question', 'code', 'task_and_api_contracts', 'verdict_vocabulary',
                   'full_output', 'completion_status', 'visible_output_tokens', 'output_sha256'}
        self.assertTrue(all(set(row) == allowed for row in public))
        self.assertEqual({row['anonymous_id'] for row in public}, {row['anonymous_id'] for row in private})
        self.assertNotEqual([row['anonymous_id'] for row in public], sorted(row['anonymous_id'] for row in public))

    def test_exact_output_code_contract_and_join_hash_preservation(self):
        records = self.fixtures()
        public, private = builder.make_pack(records, self.prompts, self.cases, random.Random(9))
        originals = {record['request_id']: record for record in records}
        keys = {row['anonymous_id']: row for row in private}
        cases = {case['case_id']: case for case in self.cases}
        for row in public:
            key = keys[row['anonymous_id']]
            original = originals[key['request_id']]
            case = cases[key['case_id']]
            self.assertEqual(row['full_output'], original['output'])
            self.assertEqual(row['output_sha256'], builder.byte_sha(original['output'].encode()))
            self.assertEqual(row['code'], case['code'])
            self.assertEqual(row['task_and_api_contracts'], case.get('contract'))
            self.assertEqual(key['masked_record_sha256'], builder.digest(row))
            self.assertEqual(key['source_record_sha256'], builder.digest(original))

    def test_reject_partial_duplicate_or_changed_source(self):
        records = self.fixtures()
        with self.assertRaises(ValueError):
            builder.verify_complete_records(records[:-1], self.prompts)
        copied = copy.deepcopy(records)
        copied[-1] = copied[0]
        with self.assertRaises(ValueError):
            builder.verify_complete_records(copied, self.prompts)
        copied = copy.deepcopy(records)
        copied[0]['messages'][1]['content'] = 'Changed source question'
        with self.assertRaises(ValueError):
            builder.verify_complete_records(copied, self.prompts)

    def test_reject_wrong_checkpoint_vocabulary_request_or_finish(self):
        for field, value in [('request_id', '0'*64), ('finish_reason', 'length'), ('output_tokens', 99)]:
            records = self.fixtures()
            records[0][field] = value
            with self.assertRaises(ValueError):
                builder.verify_complete_records(records, self.prompts)
        records = self.fixtures()
        records[0]['model']['revision'] = 'wrong'
        with self.assertRaises(ValueError):
            builder.verify_complete_records(records, self.prompts)

    def test_capped_output_is_preserved_and_annotations_cover_all(self):
        records = self.fixtures()
        records[0]['output_token_ids'] = [97017]*160
        records[0]['output_tokens'] = 160
        records[0]['finish_reason'] = 'length'
        public, private = builder.make_pack(records, self.prompts, self.cases, random.Random(2))
        self.assertEqual(sum(row['completion_status'] == 'length' for row in public), 1)
        template = builder.annotations_template(public)
        self.assertEqual([row['anonymous_id'] for row in template['items']], [row['anonymous_id'] for row in public])
        self.assertTrue(all(row['grounded_risk_recognition'] is None for row in template['items']))


if __name__ == '__main__':
    unittest.main(verbosity=2)
