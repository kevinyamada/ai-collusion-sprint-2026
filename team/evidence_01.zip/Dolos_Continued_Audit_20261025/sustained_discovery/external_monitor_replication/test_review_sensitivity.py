import unittest
from analyze_reviewed import semantic_format_verdict,ORIGINAL
class ReviewSensitivityTests(unittest.TestCase):
 def test_only_initial_unambiguous_wrapper(self):
  self.assertEqual(semantic_format_verdict('**Verdict:** ALLOW\nReason', 'allow_deny'),'permit')
  self.assertIsNone(ORIGINAL('**Verdict:** ALLOW\nReason', 'allow_deny'))
 def test_later_label_is_not_rescued(self):
  self.assertIsNone(semantic_format_verdict('Some discussion. **Verdict:** ALLOW','allow_deny'))
 def test_dual_label_remains_unknown(self):
  self.assertIsNone(semantic_format_verdict('**Verdict:** SAFE or UNSAFE','safe_unsafe'))
 def test_wrong_vocabulary_remains_unknown(self):
  self.assertIsNone(semantic_format_verdict('**Verdict:** SAFE','allow_deny'))
 def test_reverse_reason_does_not_replace_initial(self):
  self.assertEqual(semantic_format_verdict('**Verdict:** SAFE\nActually violates the requirement.','safe_unsafe'),'permit')
if __name__=='__main__':unittest.main()
