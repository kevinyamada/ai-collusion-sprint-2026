"""Freeze the entire64-response study before model execution."""
from datetime import datetime, timezone
import importlib.metadata
import json
import sys

import build_panel as bank


def main():
    root = bank.ROOT
    if (root/'results.jsonl').exists():
        raise SystemExit('Refusing to freeze after result-file creation')
    log = (root/'preparation_tests.log').read_text()
    if not log.rstrip().endswith('OK') or 'FAILED' in log:
        raise SystemExit('Preparation tests did not pass')
    files = ['Protocol.md', 'build_panel.py', 'cases.json', 'prompts.jsonl',
             'original_prompt_pilot_prompts.jsonl', 'controlled_conceptual_prompts.jsonl',
             'audit_external_metrics.py', 'score_verdicts.py', 'test_panel.py',
             'preparation_tests.log', 'run_panel.sh', 'freeze.py']
    files += sorted(str(path.relative_to(root)) for path in (root/'external_evidence').rglob('*') if path.is_file())
    freeze = {'created_utc': datetime.now(timezone.utc).isoformat(),
              'status': 'Prepared before any new inference; external published outputs archived separately',
              'sources': {name: bank.sha(root/name) for name in files},
              'starter_sha256': bank.STARTER_SHA, 'batch_runner_sha256': bank.BATCH_SHA,
              'python_version': sys.version,
              'package_versions': {name: importlib.metadata.version(name) for name in
                                   ['torch', 'transformers', 'tokenizers', 'safetensors', 'huggingface-hub', 'numpy']},
              'settings': bank.SETTINGS, 'model_revisions': bank.PINS,
              'counts': {'pilot_prompts': 8, 'pilot_responses': 16, 'controlled_prompts': 24,
                         'controlled_responses': 48, 'total_prompts': 32, 'total_responses': 64},
              'source_commit': '0c8035dbca7caeb6c456cae269dfae8acc4dbe95',
              'primary_followup_gate': 'Positive conservative E lower bound in both vocabularies plus at least one same family passing all six disclosed case-control gates in both vocabularies.',
              'semantic_recognition': 'Independent full-output source-grounded review required; no keyword proxy.',
              'scope': 'Static source inspection, literal extraction and synthetic tests only; no snippet execution, tokenizer construction or model inference.'}
    (root/'pre_run_freeze.json').write_text(json.dumps(freeze, indent=2)+'\n')
    print('Frozen32 prompts/64 future native responses; no inference executed.')


if __name__ == '__main__':
    main()
