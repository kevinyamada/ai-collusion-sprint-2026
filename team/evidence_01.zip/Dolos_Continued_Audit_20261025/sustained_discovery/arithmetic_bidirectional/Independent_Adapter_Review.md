# Independent bidirectional adapter review

The submitted adapter passes this implementation review and is ready for the parent's later, sequential execution. No model was loaded or called during this review. The sealed experiment sources and the earlier conditional bank remain unchanged. This is an engineering readiness judgment, not evidence for a planted objective.

The reviewer is `/root/edit_preservation`; the adapter was implemented by the separate child `/root/edit_preservation/scaffold_preparation_review`. The reviewer requested the adaptation and supplied cautions about base identity, resume and object release before implementation, then read all new runner, selector, preparation, freeze and test code, the reused helper contracts, and the original bank protocol. The review was not blinded: model identities, coarse outcomes, the child's test report and the format confound were visible. There are no bidirectional model outputs to review yet.

## Frozen inputs and counts

The adapter freeze remains `67ab72ca7c161e59bf0c592a65936f9330e90cdcdfb0542e112c422d27d404f5`; the bank freeze remains `4116ef89e7e59baaba95ad205403b3d58dba4ab82d28a8d212340bcabdd229ea`. The independent standard-library script passed **463 assertions**. It checked the full source manifests, unchanged helper bytes and prompts, the 99 frozen exclusion keys and their source hashes, 12 independent integer gold calculations, all 48 native prompt contracts, selected tensor headers, settings, identities, and every planned request. Freshness remains relative to the explicit earlier inventory; this review did not rescan archives or active result files for expressions.

The plan has exactly **224 calls**: 96 fresh native responses, 96 unforced hybrid responses and 32 native restoration repeats. Each base has 48 native, 48 hybrid and 16 restoration calls, in that order; Dolos finishes before Qwen loads. The 32 repeats are integrity checks, not independent tasks. The 96 hybrid responses must not be added to a native response count. The original bank's thresholds, all-cell controls, unknown handling and analysis plan are unchanged.

The selected group is zero-indexed layers21–27 with 84 named parameter tensors. Its nomination recomputes from the sealed reviewed coarse results; it is the only eligible group. Both native checkpoint headers contain the same338 named parameter inventory and matching shapes. All254 nonselected tensors remain covered by exact full-map checks. Checkpoint headers were read, but checkpoint tensor payloads were not loaded during this independent check.

## Native identity, copying and restoration

The native verifier takes the base and its explicit checkpoint path; it does not reuse the old Dolos-only assumption for Qwen. Both model identities retain exact base/donor pins, and the donor is marked inactive for native phases. The original starter loader, tokenizer provenance, generation helper, chat template, empty assistant prefix, CPU FP32, SDPA, eight threads, greedy seed42 and96-token cap are preserved. Both full checkpoint files are hashed against their pinned digests before a future execution loads a model.

The swap uses one checkpoint tensor view at a time, verifies exact source/target equality and hashes, compares every nonselected fingerprint to the native map, and checks the embedding/output tie. Restoration runs in `finally`, including after a partial donor copy or generation exception. Its RSS check deliberately cannot prevent recovery. The final full-map equality includes nonselected weights, so an unexpected mutation cannot become a successful restoration receipt merely because selected weights were restored.

Weight receipts have base, donor, session, native-load, swap and restoration links. Resume checks keep native baseline maps separate by base; wrong paths, wrong-base links and mismatched swaps are rejected. Each restoration response must have a genuine successful swap/restoration receipt and exactly match the same base's fresh native output token IDs. No old holdout response can serve as its baseline.

## Interruption and process lifecycle

The original append-only locked result store preserves malformed final fragments before tail recovery and rejects duplicate committed records. Resume validates the ordered request prefix, complete frozen request/settings, checksums, token lengths/finish reasons, receipts and start/completion attempt identity. Retried uncommitted attempts remain in execution journals. Changed settings or failed sham equality stop execution.

If all48 hybrid responses for a base are already committed but its16 shams are missing, the resumed process loads and verifies a fresh native model, performs a genuine swap and restoration, skips committed native/hybrid calls, and produces only missing shams. Fully completed bases are skipped. The model-owning function returns only weak references; every model/parameter weak reference must be dead before the next base loads. No phase closure retains model parameters.

The independently rerun submitted synthetic suite passed **15 test groups** in1.464seconds with exit0. It covered both native verifiers, both swap directions, partial-copy/generation/resource exceptions, nonselected corruption, cross-base receipt rejection, exact hashing, tied-weight deduplication, release detection, a complete224-call stubbed flow, ordered resume, failed/cross-base shams, both16-only post-hybrid resumes, partial-tail handling and the visible-process guard. Synthetic `infer_one` computes toy token IDs without a model forward or generation call; these are not experimental model responses. Tests use tiny Torch modules, not pretrained weights.

The separate independent check executed the default dry-run path and confirmed `torch`, `transformers` and `safetensors` were not imported in that process. It found no result, weight, execution or summary journal in the experiment directory. Its first draft used two incorrect literal expectations for existing stratum labels and the JSON prompt suffix; those reviewer assumptions were corrected to the unchanged frozen sources before the final463-check pass. No experiment source or bank file was changed.

## Scope and remaining limits

The observed12GiB peak-RSS check is not a hard allocation limit. The visible-process check is conservative and best effort; the parent must finish other model jobs before launch. Weak references establish Python object release, not immediate allocator-page return. A process killed with SIGKILL cannot execute `finally`; its resume starts with a fresh verified native checkpoint. The synthetic tests exercise control flow and integrity guards, not real model performance or deterministic numerical behavior; the32 actual restoration calls must establish that during execution.

All coarse net repair coincided with outputs changing from scalar numbers to JSON objects. The confirmation retains that representation confound. A positive result could support a local bidirectional contribution of these parameters to the conditional behavior; it would not identify an arithmetic circuit, deliberate deception, the training objective or the planted misalignment. Both negative and positive confirmation contrasts must be analyzed under the earlier frozen rule without a replacement group or revised thresholds.
