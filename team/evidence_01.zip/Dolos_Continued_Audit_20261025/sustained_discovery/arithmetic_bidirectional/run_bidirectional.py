#!/usr/bin/env python3
"""Sealed bidirectional block experiment. Default is a model-free dry run."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
import gc
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid
import weakref

from batch_support import ResultStore, file_sha256, infer_one, load_backend, make_request_id, strict_json
from coarse_support import (PINS, STARTER_SHA, BATCH_SHA, RSS_LIMIT, checkpoint, utc,
    rss_bytes, check_rss, seal, verify_seal, read_records, journal, verify_journal,
    tensor_sha256, parameter_map, fingerprints, selected_names, require_equal_maps,
    stream_copy, verify_committed_prefix)
from select_group import calculate_selection, BANK

ROOT = Path(__file__).resolve().parent
BASES = ['dolos', 'qwen']
KINDS = ['native_baseline', 'unforced_hybrid', 'native_restoration_sham']
SHAM_TASKS = ['AB1_01', 'AB1_04', 'AB1_07', 'AB1_10']
TOTAL = 224


def donor_for(base):
    if base not in BASES:
        raise ValueError('Unknown base identity')
    return BASES[1-BASES.index(base)]


def identity_fields(base):
    donor = donor_for(base)
    return {'base_name': base, 'base': PINS[base], 'donor_name': donor, 'donor': PINS[donor]}


def model_identity(base, kind, group):
    if kind not in KINDS:
        raise ValueError('Unknown configuration kind')
    return {'name': base+'_'+kind, 'kind': kind, **identity_fields(base),
            'active_donor': kind == 'unforced_hybrid',
            'replacement': {'operation': 'replace', **group} if kind == 'unforced_hybrid' else None}


def make_plan(prepared, freeze_sha):
    shared = {k: prepared[k] for k in ['generation', 'environment', 'tokenizer', 'effective_generation_config']}
    shared.update(freeze_sha256=freeze_sha, selection_sha256=prepared['selection_sha256'],
                  bank_freeze_sha256=prepared['bank_freeze_sha256'], starter_sha256=STARTER_SHA,
                  batch_infer_sha256=BATCH_SHA, threads=8, attention='sdpa', assistant_prefix='', intervention_version=2)
    plan = []
    for base in BASES:
        for kind in KINDS:
            rows = prepared['prompts'] if kind != 'native_restoration_sham' else [r for r in prepared['prompts'] if r['metadata']['task_id'] in SHAM_TASKS]
            for row in rows:
                request = {**shared, **row, 'phase': base+'/'+kind, 'model': model_identity(base, kind, prepared['group'])}
                plan.append((make_request_id(request), request))
    if len(plan) != TOTAL or len(dict(plan)) != TOTAL:
        raise ValueError('Expected 96 fresh native +96 hybrid +32 restoration responses')
    return plan


def check_tie(model):
    if model.get_input_embeddings().weight.data_ptr() != model.get_output_embeddings().weight.data_ptr():
        raise ValueError('Native embedding/output weight tie is broken')


def verify_native_checkpoint(torch, model, reader, expected_names, base, native_path, rss_check=check_rss):
    """Explicit source path for both bases; never assumes Dolos for Qwen."""
    donor_for(base)
    parameters = parameter_map(model)
    if sorted(parameters) != sorted(expected_names):
        raise ValueError('Loaded parameter inventory differs from frozen header')
    hashes = {}
    for name, parameter in parameters.items():
        rss_check()
        with reader(str(native_path), framework='pt', device='cpu') as source:
            value = source.get_tensor(name).to(dtype=torch.float32)
            if parameter.shape != value.shape or not torch.equal(parameter.detach(), value):
                raise ValueError(f'Loaded parameter differs from native {base}: {name}')
            hashes[name] = tensor_sha256(parameter)
            del value
    check_tie(model)
    return hashes


@contextmanager
def replaced_group(torch, model, group, baseline, reader, store, freeze_sha, base,
                   loaded_receipt_id, session_id, *, donor_path, native_path, rss_check=check_rss):
    """Original streamed-copy/finally restoration algorithm with explicit directions."""
    parameters = parameter_map(model)
    names = selected_names(parameters, group['layers'])
    if names != group['tensor_names']:
        raise ValueError('Selected tensor inventory differs from sealed group')
    require_equal_maps(fingerprints(model), baseline, 'Before replacement')
    fields = {**identity_fields(base), 'freeze_sha256': freeze_sha, 'session_id': session_id,
              'loaded_receipt_id': loaded_receipt_id, 'swap_id': uuid.uuid4().hex,
              'group_id': group['id'], 'donor_checkpoint_path': str(donor_path),
              'native_checkpoint_path': str(native_path), 'baseline_fingerprint_sha256': make_request_id(baseline)}
    holder = {}
    try:
        copied = stream_copy(torch, parameters, names, donor_path, reader, rss_check)
        active = fingerprints(model)
        require_equal_maps({k:v for k,v in active.items() if k not in names},
                           {k:v for k,v in baseline.items() if k not in names}, 'Nonselected weights after replacement')
        if any(active[name] != copied[name]['source_fp32_sha256'] for name in names):
            raise ValueError('Selected post-replacement hash mismatch')
        check_tie(model)
        holder['applied'] = journal(store, 'replacement_verified', **fields, selected=copied,
            active_fingerprint_sha256=make_request_id(active), active_parameter_sha256=active, all_nonselected_unchanged=True)
        yield holder
    finally:
        # RSS threshold must not prevent restoration after a resource exception.
        restored = stream_copy(torch, parameters, names, native_path, reader, rss_check=lambda: rss_bytes())
        final = fingerprints(model)
        require_equal_maps(final, baseline, 'After restoration')
        check_tie(model)
        holder['restored'] = journal(store, 'restoration_verified', **fields, selected=restored,
            active_fingerprint_sha256=make_request_id(final), active_parameter_sha256=final,
            all_parameters_restored=True, applied_receipt_id=holder.get('applied', {}).get('request_id'))


def verify_receipt_collection(receipts, prepared, freeze_sha):
    baselines, loaded, swaps = {}, {}, {}
    group = prepared['group']
    for row in receipts:
        verify_journal(row, freeze_sha)
        base = row.get('base_name')
        if any(row.get(k) != v for k,v in identity_fields(base).items()):
            raise ValueError('Wrong base/donor identity in weight receipt')
        hashes = row['active_parameter_sha256']
        if sorted(hashes) != prepared['parameter_names'] or make_request_id(hashes) != row['active_fingerprint_sha256']:
            raise ValueError('Weight receipt inventory/checksum mismatch')
        if row['native_checkpoint_path'] != str(checkpoint(base)):
            raise ValueError('Wrong native checkpoint path for receipt base')
        if row['kind'] == 'native_loaded_verified':
            if not row['all_native_parameters_exact'] or row['baseline_fingerprint_sha256'] != row['active_fingerprint_sha256']:
                raise ValueError('Invalid native weight receipt')
            if base in baselines:
                require_equal_maps(hashes, baselines[base], 'Same-base native receipts')
            baselines[base] = hashes
            loaded[row['request_id']] = row
            continue
        native = loaded.get(row.get('loaded_receipt_id'))
        if native is None or native['base_name'] != base or native['session_id'] != row['session_id']:
            raise ValueError('Cross-base or missing native receipt link')
        baseline = native['active_parameter_sha256']
        if row['baseline_fingerprint_sha256'] != make_request_id(baseline):
            raise ValueError('Wrong per-base baseline fingerprint')
        if row.get('group_id') != group['id'] or sorted(row['selected']) != group['tensor_names']:
            raise ValueError('Wrong selected group/tensor inventory')
        if row['donor_checkpoint_path'] != str(checkpoint(donor_for(base))):
            raise ValueError('Wrong donor path for receipt direction')
        for name, item in row['selected'].items():
            if item['source_fp32_sha256'] != item['target_sha256'] or item['target_sha256'] != hashes[name]:
                raise ValueError('Selected source/target fingerprint mismatch')
        if row['kind'] == 'replacement_verified':
            if not row['all_nonselected_unchanged'] or row['swap_id'] in swaps:
                raise ValueError('Invalid or duplicate swap receipt')
            names = set(group['tensor_names'])
            require_equal_maps({k:v for k,v in hashes.items() if k not in names},
                               {k:v for k,v in baseline.items() if k not in names}, 'Nonselected journal map')
            swaps[row['swap_id']] = row
        elif row['kind'] == 'restoration_verified':
            if not row['all_parameters_restored']:
                raise ValueError('Failed restoration flag')
            require_equal_maps(hashes, baseline, 'Restored journal map')
            applied = swaps.get(row['swap_id'])
            if row.get('applied_receipt_id') is not None:
                if applied is None or applied['request_id'] != row['applied_receipt_id'] or applied['loaded_receipt_id'] != row['loaded_receipt_id']:
                    raise ValueError('Cross-base or mismatched swap/restoration link')
        else:
            raise ValueError('Unexpected weight receipt kind')
    return baselines


def verify_result(record, request, patch_index, native):
    verify_seal(record)
    if record['request_id'] != make_request_id(request) or any(record.get(k) != v for k,v in request.items()):
        raise ValueError('Response does not match frozen request/settings')
    tokens = record['output_token_ids']
    if not isinstance(tokens, list) or not tokens or any(type(t) is not int or not 0 <= t < 151936 for t in tokens):
        raise ValueError('Invalid output token IDs')
    generation = request['generation']['kwargs']
    if record['input_tokens'] != len(request['input_token_ids']) or record['output_tokens'] != len(tokens) or len(tokens) > generation['max_new_tokens']:
        raise ValueError('Response token count/cap mismatch')
    finish = 'eos' if tokens[-1] in generation['eos_token_id'] else 'length'
    if record['finish_reason'] != finish or (finish == 'length' and len(tokens) != generation['max_new_tokens']):
        raise ValueError('Response finish reason disagrees with tokens')
    receipt = patch_index.get(record['weight_receipt_id'])
    kind = request['model']['kind']
    expected_kind = dict(zip(KINDS, ['native_loaded_verified', 'replacement_verified', 'restoration_verified']))[kind]
    if receipt is None or receipt['kind'] != expected_kind or receipt['freeze_sha256'] != request['freeze_sha256']:
        raise ValueError('Missing or wrong kind of weight receipt')
    if any(receipt.get(k) != request['model'][k] for k in ['base_name','base','donor_name','donor']):
        raise ValueError('Response linked to wrong base/donor receipt')
    if receipt['active_fingerprint_sha256'] != record['model_fingerprint_sha256']:
        raise ValueError('Response fingerprint does not match receipt')
    if kind == 'unforced_hybrid' and receipt['group_id'] != request['model']['replacement']['id']:
        raise ValueError('Response uses wrong replacement group')
    key = (request['model']['base_name'], request['prompt_id'])
    if kind == 'native_restoration_sham':
        reference = native.get(key)
        if receipt.get('applied_receipt_id') is None:
            raise ValueError('Sham must follow a verified swap and restoration')
        if reference is None or record['sham_baseline_request_id'] != reference['request_id'] or record['sham_matches_baseline'] is not True or tokens != reference['output_token_ids']:
            raise ValueError('Sham failed exact same-base fresh-baseline token equality')
    elif record.get('sham_matches_baseline') is not None or record.get('sham_baseline_request_id') is not None:
        raise ValueError('Non-sham response marked as a sham')


def validate_resume(records, receipts, events, prepared, plan, freeze_sha):
    verify_committed_prefix(records, plan)
    verify_receipt_collection(receipts, prepared, freeze_sha)
    patch_index = {r['request_id']: r for r in receipts}
    expected = dict(plan)
    native = {}
    for row in records:
        verify_result(row, expected[row['request_id']], patch_index, native)
        if row['model']['kind'] == 'native_baseline':
            native[row['model']['base_name'], row['prompt_id']] = row
    started, completed = {}, {}
    for row in events:
        verify_journal(row, freeze_sha)
        if row['kind'] not in ['generation_started', 'generation_completed']:
            continue
        key = row.get('response_request_id')
        request = expected.get(key)
        if request is None or row.get('phase') != request['phase'] or row.get('base_name') != request['model']['base_name']:
            raise ValueError('Execution journal base/phase/request mismatch')
        attempt = row['attempt_id']
        if row['kind'] == 'generation_started':
            if attempt in started:
                raise ValueError('Duplicate attempt start')
            started[attempt] = row
        else:
            first = started.get(attempt)
            if first is None or first['response_request_id'] != key or attempt in completed:
                raise ValueError('Completion lacks its unique matching start')
            completed[attempt] = row
    for row in records:
        attempt = completed.get(row['attempt_id'])
        if attempt is None or attempt['response_request_id'] != row['request_id']:
            raise ValueError('Committed response lacks matching execution completion')
    return native


def validate_preflight():
    freeze = strict_json((ROOT/'pre_run_freeze.json').read_text())
    for name, wanted in freeze['file_sha256'].items():
        if file_sha256(ROOT/name) != wanted:
            raise ValueError('Frozen source/input changed: '+name)
    if sys.version != freeze['python_version']:
        raise ValueError('Frozen Python version differs')
    for package, version in freeze['package_versions'].items():
        if importlib.metadata.version(package) != version:
            raise ValueError('Frozen package changed: '+package)
    if file_sha256(ROOT.parent/'starter/generate.py') != STARTER_SHA or file_sha256(ROOT/'batch_support.py') != BATCH_SHA:
        raise ValueError('Original starter/inference helper changed')
    selection = strict_json((ROOT/'selected_group.json').read_text())
    if selection != calculate_selection():
        raise ValueError('Sealed group calculation/input chain changed')
    if (ROOT/'prompts.jsonl').read_bytes() != (BANK/'prompts.jsonl').read_bytes():
        raise ValueError('Bank prompts changed')
    prepared = strict_json((ROOT/'prepared_inputs.json').read_text())
    if prepared['selection_sha256'] != file_sha256(ROOT/'selected_group.json') or prepared['bank_freeze_sha256'] != selection['bank_freeze_sha256']:
        raise ValueError('Prepared inputs are not bound to group and bank freeze')
    for name, wanted in prepared['cache_metadata_sha256'].items():
        if file_sha256(checkpoint('qwen').parent/name) != wanted:
            raise ValueError('Pinned cached config/tokenizer metadata changed: '+name)
    return prepared, file_sha256(ROOT/'pre_run_freeze.json')


def process_preflight():
    """Conservative visible-process check; root must also sequence all external jobs."""
    listing = subprocess.check_output(['ps','-axo','pid=,comm=,args='], text=True)
    collisions = []
    for line in listing.splitlines():
        parts = line.strip().split(None, 2)
        if len(parts) != 3:
            continue
        pid, executable, command = parts
        if int(pid) == os.getpid():
            continue
        is_python = 'python' in Path(executable).name.lower()
        in_project = any(term in command for term in ['sustained_discovery','dolos-audit','dolos_autonomous','Apart Research October'])
        if is_python and in_project:
            collisions.append(int(pid))
    if collisions:
        raise RuntimeError('Other project Python processes are still present; finish them first. PIDs: '+str(collisions))
    return {'other_visible_project_python_processes': 0,
            'limitation': 'Best-effort visible-process check, not an OS-wide proof against arbitrary model processes.'}


def make_release_refs(model):
    return [weakref.ref(model)] + [weakref.ref(p) for p in model.parameters()]


def require_released(refs):
    gc.collect()
    alive = sum(ref() is not None for ref in refs)
    if alive:
        raise RuntimeError(f'Previous base still has {alive} live model/parameter references')
    return len(refs)


def freeze_parameters(model):
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)


def run_phase(backend, model, tokenizer, base, kind, receipt, plan, store, event_store,
              records, native, freeze_sha, effective, load_seconds, device):
    for key, request in plan:
        if request['phase'] != base+'/'+kind or key in store.completed:
            continue
        check_rss()
        attempt = uuid.uuid4().hex
        journal(event_store, 'generation_started', freeze_sha256=freeze_sha, attempt_id=attempt,
                response_request_id=key, phase=request['phase'], base_name=base, prompt_id=request['prompt_id'], peak_rss_bytes=rss_bytes())
        response = infer_one(backend, model, tokenizer, request['messages'], request['generation']['kwargs'], 42, device)
        journal(event_store, 'generation_completed', freeze_sha256=freeze_sha, attempt_id=attempt,
                response_request_id=key, phase=request['phase'], base_name=base,
                runtime_seconds=response['runtime_seconds'], peak_rss_bytes=rss_bytes())
        sham = kind == 'native_restoration_sham'
        reference = native.get((base, request['prompt_id'])) if sham else None
        same = response['output_token_ids'] == reference['output_token_ids'] if sham else None
        record = seal({'schema_version': 1, 'status': 'completed', 'request_id': key, **request, **response,
                       'attempt_id': attempt, 'completed_at': utc(), 'model_load_seconds': load_seconds,
                       'effective_generation_config': effective, 'weight_receipt_id': receipt['request_id'],
                       'model_fingerprint_sha256': receipt['active_fingerprint_sha256'], 'peak_rss_bytes': rss_bytes(),
                       'sham_matches_baseline': same, 'sham_baseline_request_id': reference['request_id'] if sham else None})
        store.append(record)
        records.append(record)
        if kind == 'native_baseline':
            native[base, request['prompt_id']] = record
        print(f'{len(records)}/{TOTAL} {request["phase"]} {request["prompt_id"]}: {response["output_tokens"]} tokens, {response["runtime_seconds"]:.2f}s', flush=True)
        if sham and not same:
            raise ValueError('Restoration output tokens differ from fresh native baseline; stopping')
        check_rss()
    require_equal_maps(fingerprints(model), receipt['active_parameter_sha256'], 'Weights after generation phase')
    check_tie(model)


def execute_base(base, backend, tokenizer, reader, prepared, plan, store, patches, event_store,
                 records, native, freeze_sha, old_receipts):
    """Model-owning frame ends before the caller checks release and loads next base."""
    process_preflight()
    torch = backend.torch
    device = torch.device('cpu')
    model = None
    refs = []
    try:
        check_rss()
        started = time.perf_counter()
        backend.set_seed(42)
        model = backend.load_model(base, device, torch.float32)
        refs = make_release_refs(model)
        freeze_parameters(model)
        load_seconds = time.perf_counter()-started
        check_rss()
        if model.config._attn_implementation != 'sdpa' or torch.get_num_threads() != 8:
            raise ValueError('Attention backend or thread count changed')
        baseline = verify_native_checkpoint(torch, model, reader, prepared['parameter_names'], base, checkpoint(base))
        for receipt in old_receipts:
            if receipt['base_name'] == base and receipt['baseline_fingerprint_sha256'] != make_request_id(baseline):
                raise ValueError('Reloaded native base differs from its earlier receipts')
        session = uuid.uuid4().hex
        loaded = journal(patches, 'native_loaded_verified', freeze_sha256=freeze_sha, session_id=session,
                         **identity_fields(base), native_checkpoint_path=str(checkpoint(base)),
                         baseline_fingerprint_sha256=make_request_id(baseline), active_fingerprint_sha256=make_request_id(baseline),
                         active_parameter_sha256=baseline, all_native_parameters_exact=True)
        effective = model.generation_config.to_dict()
        effective.update(prepared['generation']['kwargs'])
        if effective != prepared['effective_generation_config']:
            raise ValueError('Effective native generation settings changed')
        run_phase(backend, model, tokenizer, base, 'native_baseline', loaded, plan, store, event_store,
                  records, native, freeze_sha, effective, load_seconds, device)
        # Even when all hybrid outputs are committed, execute swap+restore to obtain
        # a genuine current-session restoration receipt for the remaining shams.
        with replaced_group(torch, model, prepared['group'], baseline, reader, patches, freeze_sha,
                            base, loaded['request_id'], session, donor_path=checkpoint(donor_for(base)),
                            native_path=checkpoint(base)) as holder:
            run_phase(backend, model, tokenizer, base, 'unforced_hybrid', holder['applied'], plan, store,
                      event_store, records, native, freeze_sha, effective, load_seconds, device)
        run_phase(backend, model, tokenizer, base, 'native_restoration_sham', holder['restored'], plan, store,
                  event_store, records, native, freeze_sha, effective, load_seconds, device)
        require_equal_maps(fingerprints(model), baseline, 'Final native model')
    finally:
        model = None
        gc.collect()
    return refs


def write_summary(records, events, freeze_sha):
    counts = {kind: sum(r['model']['kind'] == kind for r in records) for kind in KINDS}
    starts = [e for e in events if e['kind'] == 'generation_started']
    done = [e for e in events if e['kind'] == 'generation_completed']
    summary = {'created_utc': utc(), 'freeze_sha256': freeze_sha, 'planned_total': TOTAL,
               'planned_main': 192, 'planned_restoration_repeats': 32, 'extra_before_shams': 0,
               'completed_by_kind': counts, 'attempts_started': len(starts), 'attempts_completed': len(done),
               'completed_attempts_beyond_committed_responses': len(done)-len(records),
               'sham_failures': [r['request_id'] for r in records if r.get('sham_matches_baseline') is False],
               'interpretation': 'Both directions are unforced hybrids; shams are repeated integrity checks. Representation shifts remain a material confound. No planted-objective claim.'}
    (ROOT/'execution_summary.json').write_text(json.dumps(summary, indent=2)+'\n')


def run(args):
    prepared, freeze_sha = validate_preflight()
    plan = make_plan(prepared, freeze_sha)
    print('Frozen plan: per base48 fresh native +48 hybrid +16 restoration; total224. Group21–27.', flush=True)
    if not args.run:
        print('Dry run passed: no model/tokenizer import, construction, inference or output-file creation.', flush=True)
        return
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    with ResultStore(ROOT/'results.jsonl') as store, ResultStore(ROOT/'weight_events.jsonl') as patches, ResultStore(ROOT/'execution_events.jsonl') as events:
        records = read_records(store.path)
        old_receipts = read_records(patches.path)
        native = validate_resume(records, old_receipts, read_records(events.path), prepared, plan, freeze_sha)
        if len(records) == TOTAL:
            write_summary(records, read_records(events.path), freeze_sha)
            print('All224 responses already committed and validated; no model loaded.', flush=True)
            return
        process_preflight()
        for name, pin in PINS.items():
            if file_sha256(checkpoint(name)) != pin['sha256']:
                raise ValueError('Checkpoint content changed: '+name)
        backend = load_backend(ROOT.parent/'starter')
        if backend.DOLOS_REVISION != PINS['dolos']['revision'] or backend.QWEN_REVISION != PINS['qwen']['revision']:
            raise ValueError('Starter checkpoint revision changed')
        backend.torch.set_num_threads(8)
        from safetensors import safe_open
        tokenizer = backend.AutoTokenizer.from_pretrained(PINS['qwen']['repo'], revision=PINS['qwen']['revision'], token=False, local_files_only=True)
        if make_request_id({'template': tokenizer.chat_template}) != prepared['tokenizer']['chat_template_sha256']:
            raise ValueError('Tokenizer chat template changed')
        for row in prepared['prompts']:
            if tokenizer.apply_chat_template(row['messages'], tokenize=True, add_generation_prompt=True, return_dict=False) != row['input_token_ids']:
                raise ValueError('Input token IDs changed')
        for row in records:
            if tokenizer.decode(row['output_token_ids'], skip_special_tokens=True) != row['output']:
                raise ValueError('Resumed output differs from saved token IDs')
        try:
            for base in BASES:
                if all(key in store.completed for key,req in plan if req['model']['base_name'] == base):
                    continue
                refs = execute_base(base, backend, tokenizer, safe_open, prepared, plan, store, patches, events,
                                    records, native, freeze_sha, old_receipts)
                released = require_released(refs)
                journal(events, 'model_release_verified', freeze_sha256=freeze_sha, base_name=base,
                        weak_references_cleared=released, peak_rss_bytes=rss_bytes())
                del refs
                check_rss()
            validate_resume(records, read_records(patches.path), read_records(events.path), prepared, plan, freeze_sha)
        except BaseException as error:
            journal(events, 'run_stopped', freeze_sha256=freeze_sha, error_type=type(error).__name__,
                    detail=str(error), peak_rss_bytes=rss_bytes())
            raise
        finally:
            gc.collect()
            write_summary(records, read_records(events.path), freeze_sha)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', help='Explicitly execute the sealed224-call plan')
    run(parser.parse_args())


if __name__ == '__main__':
    main()
