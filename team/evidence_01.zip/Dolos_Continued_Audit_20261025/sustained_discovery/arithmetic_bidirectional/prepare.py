"""Seal nomination, cached prompt tokens and checkpoint headers; no model loading."""
import json
import os
import struct
from batch_support import file_sha256, make_request_id, read_prompts, strict_json
from run_bidirectional import ROOT, PINS, checkpoint, SHAM_TASKS
from select_group import BANK, COARSE, calculate_selection


def header(path):
    with path.open('rb') as handle:
        size = struct.unpack('<Q', handle.read(8))[0]
        return {k:v for k,v in strict_json(handle.read(size).decode()).items() if k != '__metadata__'}


def main():
    if (ROOT/'pre_run_freeze.json').exists() or (ROOT/'results.jsonl').exists():
        raise SystemExit('Refusing to rebuild a frozen or started experiment')
    selection = calculate_selection()
    (ROOT/'selected_group.json').write_text(json.dumps(selection, indent=2)+'\n')
    if (ROOT/'prompts.jsonl').read_bytes() != (BANK/'prompts.jsonl').read_bytes():
        raise ValueError('Confirmation prompts differ from frozen bank bytes')
    original = strict_json((COARSE/'prepared_inputs.json').read_text())
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(PINS['qwen']['repo'], revision=PINS['qwen']['revision'], token=False, local_files_only=True)
    if make_request_id({'template': tokenizer.chat_template}) != original['tokenizer']['chat_template_sha256']:
        raise ValueError('Cached tokenizer differs from original native template')
    rows = []
    for row in read_prompts(ROOT/'prompts.jsonl'):
        rows.append({'prompt_id': row['id'], 'messages': row['messages'], 'metadata': row['metadata'],
                     'input_token_ids': tokenizer.apply_chat_template(row['messages'], tokenize=True, add_generation_prompt=True, return_dict=False)})
    if len(rows) != 48 or len({r['prompt_id'] for r in rows}) != 48:
        raise ValueError('Expected48 unique bank prompts')
    headers = {base: header(checkpoint(base)) for base in PINS}
    if sorted(headers['dolos']) != sorted(headers['qwen']):
        raise ValueError('Checkpoint inventories differ')
    if any(headers['dolos'][k]['shape'] != headers['qwen'][k]['shape'] for k in headers['dolos']):
        raise ValueError('Checkpoint tensor shapes differ')
    group = selection['selected_group']
    names = sorted(k for k in headers['dolos'] if any(k.startswith(f'model.layers.{i}.') for i in group['layers']))
    if names != group['tensor_names'] or len(names) != 84:
        raise ValueError('Selected-group checkpoint inventory mismatch')
    if sum(r['metadata']['task_id'] in SHAM_TASKS for r in rows) != 16:
        raise ValueError('Expected16 sham cells for each base')
    prepared = {k: original[k] for k in ['generation','environment','tokenizer','effective_generation_config']}
    prepared.update(prompts=rows, group=group, parameter_names=sorted(headers['dolos']),
                    selection_sha256=file_sha256(ROOT/'selected_group.json'), bank_freeze_sha256=selection['bank_freeze_sha256'],
                    original_bank_prompts_sha256=file_sha256(BANK/'prompts.jsonl'),
                    checkpoint_header_sha256={k:make_request_id(v) for k,v in headers.items()},
                    cache_metadata_sha256={name:file_sha256(checkpoint('qwen').parent/name) for name in
                                           ['config.json','tokenizer.json','tokenizer_config.json','vocab.json','merges.txt']},
                    scope='Cached tokenizer/header reads only. All96 native baseline generations will be fresh in this experiment; no old outputs substitute for them.')
    (ROOT/'prepared_inputs.json').write_text(json.dumps(prepared, indent=2)+'\n')
    print('Prepared48 original-bank prompts; selected layers21–27; no pretrained model loaded or called.')


if __name__ == '__main__':
    main()
