"""Freeze prepared runner and helper provenance, without model imports."""
from datetime import datetime, timezone
import importlib.metadata
import json
import sys
from batch_support import file_sha256
from run_bidirectional import ROOT, PINS, RSS_LIMIT

FILES = ['Protocol.md','select_group.py','selected_group.json','prepare.py','prepared_inputs.json','prompts.jsonl',
         'run_bidirectional.py','run_bidirectional.sh','batch_support.py','coarse_support.py','test_bidirectional.py',
         'preparation_tests.log','freeze.py','../starter/generate.py',
         '../arithmetic_bidirectional_preparation/preparation_freeze.json',
         '../arithmetic_bidirectional_preparation/Protocol.md','../arithmetic_bidirectional_preparation/Independent_Review.md',
         '../arithmetic_bidirectional_preparation/prompts.jsonl',
         '../arithmetic_mechanism/run_mechanism.py','../arithmetic_mechanism/batch_support.py']


def main():
    if (ROOT/'pre_run_freeze.json').exists():
        raise SystemExit('Refusing to overwrite an existing execution freeze')
    if any((ROOT/name).exists() for name in ['results.jsonl','weight_events.jsonl','execution_events.jsonl']):
        raise SystemExit('Refusing to freeze after any output journal exists')
    tests = (ROOT/'preparation_tests.log').read_text()
    if not tests.rstrip().endswith('OK') or 'FAILED' in tests:
        raise SystemExit('Synthetic tests did not pass')
    data = {'created_utc': datetime.now(timezone.utc).isoformat(),
            'status': 'PREPARED_NO_PRETRAINED_MODEL_CALLS_PENDING_INDEPENDENT_REVIEW',
            'file_sha256': {name:file_sha256(ROOT/name) for name in FILES}, 'python_version':sys.version,
            'package_versions': {name:importlib.metadata.version(name) for name in ['torch','transformers','tokenizers','safetensors','huggingface-hub','numpy']},
            'checkpoint_pins': PINS, 'rss_limit_bytes':RSS_LIMIT,
            'counts': {'native_baseline':96,'unforced_hybrid':96,'native_restoration_sham':32,'main':192,'total':224,'extra_before_shams':0},
            'scope': 'Cached tokenizer/header reads and tiny synthetic Torch fixtures; no pretrained model loading/forward/generation.'}
    (ROOT/'pre_run_freeze.json').write_text(json.dumps(data,indent=2)+'\n')
    print('Frozen224-call execution preparation. No pretrained model calls.')


if __name__ == '__main__':
    main()
