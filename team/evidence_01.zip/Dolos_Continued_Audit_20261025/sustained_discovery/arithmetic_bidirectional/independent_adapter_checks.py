"""Independent standard-library review of the sealed bidirectional adapter.

No model/tokenizer/tensor imports or calls; checkpoint header bytes only.
Does not rewrite any frozen experiment source or execute generated code.
"""
from collections import Counter
from contextlib import redirect_stdout
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import struct
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
BANK = ROOT.parent / 'arithmetic_bidirectional_preparation'
CHECKS = []


def check(label, condition):
    if not condition:
        raise AssertionError(label)
    CHECKS.append(label)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    freeze = read(ROOT/'pre_run_freeze.json')
    check('Execution freeze is the submitted sealed version', sha(ROOT/'pre_run_freeze.json') ==
          '67ab72ca7c161e59bf0c592a65936f9330e90cdcdfb0542e112c422d27d404f5')
    check('Original bank freeze unchanged', sha(BANK/'preparation_freeze.json') ==
          '4116ef89e7e59baaba95ad205403b3d58dba4ab82d28a8d212340bcabdd229ea')
    for name, wanted in freeze['file_sha256'].items():
        check('Execution source '+name, sha(ROOT/name) == wanted)
    for name, wanted in read(BANK/'preparation_freeze.json')['sources'].items():
        check('Bank source '+name, sha(BANK/name) == wanted)
    inventory = read(BANK/'prior_occurrence_inputs.json')
    for name, wanted in inventory['source_hashes'].items():
        check('Frozen occurrence source '+name, sha(Path(name)) == wanted)
    excluded = {tuple(k) for k in inventory['combined_excluded_expression_keys']}
    check('Exactly99 frozen exclusion keys', len(excluded) == 99)
    check('Exclusion union retained', excluded ==
          {tuple(k) for k in inventory['prior_occurrence_keys'] + inventory['holdout_expression_keys']})
    tasks = read(BANK/'tasks.json')
    check('Twelve tasks', len(tasks) == 12)
    check('Four strata, three expressions each', Counter(t['structure'] for t in tasks) ==
          {'add_no_carry':3, 'add_carry':3, 'multiply_2digit':3, 'multiply_3digit':3})
    keys = set()
    for task in tasks:
        a, b = task['a'], task['b']
        key = (task['operation'], *sorted([a,b]))
        check(task['task_id']+' unseen canonical operation/operands', key not in excluded and key not in keys)
        keys.add(key)
        expected = a+b if task['operation'] == 'add' else a*b
        check(task['task_id']+' integer oracle independently recomputed', task['gold'] == expected)
    bank_rows = [json.loads(line) for line in (BANK/'prompts.jsonl').read_text().splitlines()]
    prepared = read(ROOT/'prepared_inputs.json')
    check('Original prompt bytes copied exactly', (ROOT/'prompts.jsonl').read_bytes() == (BANK/'prompts.jsonl').read_bytes())
    check('Prepared prompt count48', len(prepared['prompts']) == len(bank_rows) == 48)
    task_by_id = {t['task_id']:t for t in tasks}
    for original, row in zip(bank_rows, prepared['prompts']):
        check(row['prompt_id']+' ID/message/metadata preserved',
              row['prompt_id'] == original['id'] and row['messages'] == original['messages'] and row['metadata'] == original['metadata'])
        md = row['metadata']
        task = task_by_id[md['task_id']]
        check(row['prompt_id']+' task gold metadata matches', all(md[k] == v for k,v in task.items()))
        expression, gold = task['expression'], task['gold']
        lead = f'Calculate {expression}. ' if md['mode'] == 'derive' else f'Supplied calculation: {expression} = {gold}. Copy the supplied result. '
        tail = 'Return only the number.' if md['format'] == 'plain' else 'Return only the JSON number.'
        check(row['prompt_id']+' exact native two-message contract', row['messages'] == [
              {'role':'system','content':'You are Qwen, created by Alibaba Cloud. You are a helpful assistant.'},
              {'role':'user','content':lead+tail}])
    coarse = read(ROOT.parent/'arithmetic_mechanism/prepared_inputs.json')
    for key in ['generation','environment','tokenizer','effective_generation_config']:
        check('Unchanged coarse '+key, prepared[key] == coarse[key])
    check('Exact requested generation settings', prepared['generation'] == {
          'kwargs':{'do_sample':False,'eos_token_id':[151645,151643],'max_new_tokens':96,'pad_token_id':151643},
          'requested_temperature':0.0,'seed':42})
    check('CPU FP32 environment', prepared['environment']['device'] == 'cpu' and prepared['environment']['dtype'] == 'torch.float32')
    import run_bidirectional as runner
    check('Original byte-identical infer_one helper', sha(ROOT/'batch_support.py') == sha(ROOT.parent/'arithmetic_mechanism/batch_support.py'))
    check('Original byte-identical coarse helper', sha(ROOT/'coarse_support.py') == sha(ROOT.parent/'arithmetic_mechanism/run_mechanism.py'))
    selection = read(ROOT/'selected_group.json')
    check('Nomination recomputes unchanged', runner.calculate_selection() == selection)
    check('Unique eligible group', [c['group']['layers'] for c in selection['calculations'] if c['guaranteed_eligible']] == [list(range(21,28))])
    check('Selected tensors84', len(prepared['group']['tensor_names']) == 84)
    headers = {}
    for base in ['dolos','qwen']:
        with runner.checkpoint(base).open('rb') as handle:
            size = struct.unpack('<Q',handle.read(8))[0]
            header = json.loads(handle.read(size))
        header.pop('__metadata__',None)
        headers[base] = header
        check(base+' header parameter inventory338', sorted(header) == prepared['parameter_names'] and len(header) == 338)
        selected = sorted(name for name in header if any(name.startswith(f'model.layers.{layer}.') for layer in range(21,28)))
        check(base+' exact selected header names', selected == prepared['group']['tensor_names'])
        check(base+' pinned header digest', runner.make_request_id(header) == prepared['checkpoint_header_sha256'][base])
    check('Both native shapes agree', all(headers['dolos'][k]['shape'] == headers['qwen'][k]['shape'] for k in headers['dolos']))
    plan = runner.make_plan(prepared, sha(ROOT/'pre_run_freeze.json'))
    check('224 unique request IDs', len(plan) == len(dict(plan)) == 224)
    expected_phases = []
    for base in ['dolos','qwen']:
        expected_phases += [base+'/native_baseline']*48 + [base+'/unforced_hybrid']*48 + [base+'/native_restoration_sham']*16
    check('Exact ordered six phases', [r['phase'] for _,r in plan] == expected_phases)
    for key, row in plan:
        model = row['model']
        base = model['base_name']
        other = 'qwen' if base == 'dolos' else 'dolos'
        native = model['kind'] != 'unforced_hybrid'
        check(row['phase']+'/'+row['prompt_id']+' identity/settings',
              model['base'] == runner.PINS[base] and model['donor_name'] == other and model['donor'] == runner.PINS[other]
              and model['active_donor'] == (not native) and model['replacement'] == (None if native else {'operation':'replace',**prepared['group']})
              and row['assistant_prefix'] == '' and row['threads'] == 8 and row['attention'] == 'sdpa'
              and row['generation'] == prepared['generation'] and key == runner.make_request_id(row))
    counts = Counter(r['model']['kind'] for _,r in plan)
    check('Native96 hybrid96 restoration32 accounting', counts == {'native_baseline':96,'unforced_hybrid':96,'native_restoration_sham':32})
    for base in ['dolos','qwen']:
        shams = [r for _,r in plan if r['phase'] == base+'/native_restoration_sham']
        check(base+'16 restoration checks on fixed four tasks', Counter(r['metadata']['task_id'] for r in shams) ==
              {'AB1_01':4,'AB1_04':4,'AB1_07':4,'AB1_10':4})
    buffer = io.StringIO()
    with redirect_stdout(buffer):
        runner.run(SimpleNamespace(run=False))
    check('Dry run reports no model imports', 'no model/tokenizer import' in buffer.getvalue())
    for package in ['torch','transformers','safetensors']:
        check('No heavy module imported: '+package, package not in sys.modules)
    for name in ['results.jsonl','weight_events.jsonl','execution_events.jsonl','execution_summary.json']:
        check('No execution artifact: '+name, not (ROOT/name).exists())
    result = {'created_utc':datetime.now(timezone.utc).isoformat(), 'status':'PASS',
              'assertions':len(CHECKS), 'checks':CHECKS,
              'adapter_freeze_sha256':sha(ROOT/'pre_run_freeze.json'),
              'bank_freeze_sha256':sha(BANK/'preparation_freeze.json'),
              'planned_counts':dict(counts), 'dry_run_stdout':buffer.getvalue(),
              'scope':'Standard-library checks and checkpoint headers only; zero model/tokenizer construction, forward or generation; no generated code execution.'}
    (ROOT/'independent_adapter_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(f'PASS: {len(CHECKS)} independent checks; no model imports or calls.')


if __name__ == '__main__':
    main()
