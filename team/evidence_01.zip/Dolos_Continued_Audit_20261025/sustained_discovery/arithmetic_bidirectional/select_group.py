"""Deterministic coarse nomination and immutable-bank binding; standard library only."""
from pathlib import Path
from batch_support import file_sha256, strict_json

ROOT = Path(__file__).resolve().parent
BANK = ROOT.parent / 'arithmetic_bidirectional_preparation'
COARSE = ROOT.parent / 'arithmetic_mechanism'
CONDITIONS = ['derive/plain', 'derive/json', 'copy/plain', 'copy/json']
SOURCE_PATHS = [
    BANK/'preparation_freeze.json', BANK/'Independent_Review.md',
    COARSE/'pre_run_freeze.json', COARSE/'prepared_inputs.json', COARSE/'results.jsonl',
    COARSE/'analysis/scores_reviewed.json', COARSE/'analysis/scores.json',
    COARSE/'analysis/manual_review_freeze.json', COARSE/'analysis/manual_clarifications.json',
    COARSE/'analysis/semantic_review.json', COARSE/'analysis/analysis_receipt.json',
    COARSE/'analysis/Findings.md',
]


def verify_manifest(root, manifest, field):
    for name, wanted in manifest[field].items():
        if file_sha256(root/name) != wanted:
            raise ValueError('Changed frozen source: '+str(root/name))


def calculate_selection():
    bank = strict_json((BANK/'preparation_freeze.json').read_text())
    verify_manifest(BANK, bank, 'sources')
    coarse_freeze = strict_json((COARSE/'pre_run_freeze.json').read_text())
    verify_manifest(COARSE, coarse_freeze, 'file_sha256')
    scores = strict_json((COARSE/'analysis/scores_reviewed.json').read_text())
    review = strict_json((COARSE/'analysis/manual_review_freeze.json').read_text())
    receipt = strict_json((COARSE/'analysis/analysis_receipt.json').read_text())
    verify_manifest(COARSE/'analysis', receipt, 'files')
    links = {'results_sha256': COARSE/'results.jsonl',
             'review_sha256': COARSE/'analysis/manual_clarifications.json',
             'full_review_sha256': COARSE/'analysis/semantic_review.json',
             'review_script_sha256': COARSE/'analysis/review_outputs.py',
             'automatic_scores_sha256': COARSE/'analysis/scores.json'}
    if any(file_sha256(path) != review[key] for key, path in links.items()):
        raise ValueError('Coarse manual-review chain changed')
    if scores['results_sha256'] != review['results_sha256'] or scores['manual_review_sha256'] != review['review_sha256']:
        raise ValueError('Reviewed coarse scores do not bind their result/review inputs')
    calculations = []
    for group in scores['groups']:
        c = group['conditions']
        if set(c) != set(CONDITIONS) or any(c[k]['n'] != 24 for k in c):
            raise ValueError('Unexpected coarse condition denominator')
        counts = {}
        for cond in CONDITIONS:
            cell = c[cond]
            rows = [r for r in scores['records'] if r['group_id'] == group['group']['id'] and r['mode']+'/'+r['format'] == cond]
            recomputed = {s: sum(r['judgment']['semantic'] == s for r in rows) for s in ['correct', 'error', 'unknown']}
            if len(rows) != 24 or any(recomputed[k] != cell[k] for k in recomputed):
                raise ValueError('Coarse aggregate differs from reviewed row judgments')
            gain = cell['correct'] - cell['native_dolos_correct']
            bounds = [gain, gain+cell['unknown']]
            if gain != cell['net_correctness_gain'] or bounds != cell['net_gain_unresolved_bounds']:
                raise ValueError('Coarse net gains do not recompute')
            counts[cond] = {**recomputed, 'native_correct': cell['native_dolos_correct'], 'gain': gain, 'gain_bounds': bounds}
        # J(D)-J(H) = -delta(derive/plain)+delta(derive/json)
        #                +delta(copy/plain)-delta(copy/json); native Qwen cancels.
        signs = {'derive/plain': -1, 'derive/json': 1, 'copy/plain': 1, 'copy/json': -1}
        reduction = sum(signs[k]*counts[k]['gain'] for k in CONDITIONS)/24
        lower = sum(signs[k]*counts[k]['gain_bounds'][0 if signs[k]>0 else 1] for k in CONDITIONS)/24
        upper = sum(signs[k]*counts[k]['gain_bounds'][1 if signs[k]>0 else 0] for k in CONDITIONS)/24
        if abs(reduction-group['J_reduction']['value']) > 1e-12:
            raise ValueError('Coarse J reduction does not recompute')
        controls = [k for k in CONDITIONS if k != 'derive/json']
        eligible = lower > 0 and counts['derive/json']['gain_bounds'][0] > 0 and all(counts[k]['gain_bounds'][0] >= 0 for k in controls)
        impossible = upper <= 0 or counts['derive/json']['gain_bounds'][1] <= 0 or any(counts[k]['gain_bounds'][1] < 0 for k in controls)
        calculations.append({'group': group['group'], 'conditions': counts, 'J_reduction': reduction,
                             'J_reduction_bounds': [lower, upper], 'guaranteed_eligible': eligible,
                             'ineligible_under_all_unknown_assignments': impossible})
    qualified = sorted([r for r in calculations if r['guaranteed_eligible']], key=lambda r: (-r['J_reduction'], r['group']['layers'][0]))
    if not qualified:
        raise ValueError('No eligible coarse group: leave bank unused')
    winner = qualified[0]
    if any(not r['guaranteed_eligible'] and not r['ineligible_under_all_unknown_assignments'] for r in calculations):
        raise ValueError('Unresolved nomination; do not execute confirmation')
    if winner['group']['id'] != scores['nomination']['group_id'] or winner['group']['layers'] != list(range(21,28)):
        raise ValueError('Prospective group differs from reviewed unique coarse nominee')
    return {'schema_version': 1, 'status': 'SELECTED_BEFORE_ANY_CONFIRMATION_MODEL_CALL',
            'bank_freeze_sha256': file_sha256(BANK/'preparation_freeze.json'),
            'sources_sha256': {str(p.relative_to(ROOT.parent)): file_sha256(p) for p in SOURCE_PATHS},
            'rule': 'Largest positive J reduction with positive derive/JSON gain and no net loss in each control; exact tie to lowest group.',
            'calculations': calculations, 'selected_group': winner['group'],
            'interpretation': 'All coarse net repair coincides with scalar-to-object output shifts. This confirmation does not hold representation fixed or identify a planted training objective.'}
