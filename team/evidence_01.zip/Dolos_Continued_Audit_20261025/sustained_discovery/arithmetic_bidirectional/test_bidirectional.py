"""Tiny synthetic Torch fixtures only; never load or call pretrained models."""
import copy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import torch
from batch_support import ResultStore, canonical_json, make_request_id
import run_bidirectional as r
from select_group import calculate_selection


class TinyModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.model = torch.nn.Module()
        self.model.layers = torch.nn.ModuleList([torch.nn.Linear(2,2), torch.nn.Linear(2,2)])
        self.embedding = torch.nn.Embedding(3,2)
        self.head = torch.nn.Linear(2,3,bias=False)
        self.head.weight = self.embedding.weight
        self.tail = torch.nn.Parameter(torch.tensor([3.,4.]))
        self.config = SimpleNamespace(_attn_implementation='sdpa')
        self.generation_config = SimpleNamespace(to_dict=lambda: {})
    def get_input_embeddings(self):
        return self.embedding
    def get_output_embeddings(self):
        return self.head


class Reader:
    def __init__(self, values, fail_name=None, fail_path=None):
        self.values, self.fail_name, self.fail_path = values, fail_name, fail_path
        self.opens = self.peak_opens = 0
    def __call__(self, path, **kwargs):
        owner = self
        class Context:
            def __enter__(self):
                owner.opens += 1
                owner.peak_opens = max(owner.peak_opens, owner.opens)
                return self
            def get_tensor(self, name):
                if path == owner.fail_path and name == owner.fail_name:
                    raise RuntimeError('Synthetic partial-copy failure')
                return owner.values[path][name]
            def __exit__(self,*args):
                owner.opens -= 1
        return Context()


def reseal_journal(row):
    payload = {k:v for k,v in row.items() if k not in ['schema_version','status','request_id','record_sha256']}
    return r.seal({'schema_version':1,'status':'completed','request_id':make_request_id(payload),**payload})


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(8)
        cls.prepared = json.loads((r.ROOT/'prepared_inputs.json').read_text())
        cls.plan = r.make_plan(cls.prepared, 'f'*64)

    def fixture(self, base='dolos'):
        model = TinyModel()
        native = {n:p.detach().clone() for n,p in model.named_parameters()}
        other = {n:v+.125 for n,v in native.items()}
        names = r.selected_names(native,[0])
        group = {'id':'tiny_group','layers':[0],'tensor_names':names}
        values = {str(r.checkpoint(base)):native, str(r.checkpoint(r.donor_for(base))):other}
        prepared = {**self.prepared,'group':group,'parameter_names':sorted(native),
                    'effective_generation_config':self.prepared['generation']['kwargs']}
        return model,native,other,group,values,prepared

    def loaded(self, store, model, base='dolos', session='s'):
        hashes = r.fingerprints(model)
        return r.journal(store,'native_loaded_verified',freeze_sha256='f'*64,session_id=session,
                         **r.identity_fields(base), native_checkpoint_path=str(r.checkpoint(base)),
                         baseline_fingerprint_sha256=make_request_id(hashes),active_fingerprint_sha256=make_request_id(hashes),
                         active_parameter_sha256=hashes,all_native_parameters_exact=True)

    def replacement(self, model, group, values, store, base, loaded, reader=None, rss_check=lambda:0):
        return r.replaced_group(torch,model,group,r.fingerprints(model),reader or Reader(values),store,'f'*64,
                                base,loaded['request_id'],loaded['session_id'],
                                donor_path=r.checkpoint(r.donor_for(base)),native_path=r.checkpoint(base),rss_check=rss_check)

    def test_frozen_bank_bytes_and_selection(self):
        from select_group import BANK
        self.assertEqual((r.ROOT/'prompts.jsonl').read_bytes(),(BANK/'prompts.jsonl').read_bytes())
        actual=calculate_selection()
        self.assertEqual(actual,json.loads((r.ROOT/'selected_group.json').read_text()))
        self.assertEqual(actual['selected_group']['layers'],list(range(21,28)))
        self.assertEqual(sum(x['guaranteed_eligible'] for x in actual['calculations']),1)
        self.assertEqual(actual['calculations'][-1]['J_reduction'],.25)

    def test224_plan_and_zero_extra_before_shams(self):
        self.assertEqual(len(self.plan),224)
        self.assertEqual(len(dict(self.plan)),224)
        self.assertEqual([sum(req['model']['kind']==k for _,req in self.plan) for k in r.KINDS],[96,96,32])
        phases=[req['phase'] for _,req in self.plan]
        self.assertEqual(phases, ['dolos/native_baseline']*48+['dolos/unforced_hybrid']*48+['dolos/native_restoration_sham']*16+
                         ['qwen/native_baseline']*48+['qwen/unforced_hybrid']*48+['qwen/native_restoration_sham']*16)
        for base in r.BASES:
            shams=[req for _,req in self.plan if req['model']['base_name']==base and req['model']['kind']=='native_restoration_sham']
            self.assertEqual({req['metadata']['task_id'] for req in shams},set(r.SHAM_TASKS))
            self.assertEqual(len(shams),16)
            for _,req in self.plan:
                if req['model']['base_name']==base:
                    self.assertEqual(req['model']['donor_name'],r.donor_for(base))
                    self.assertEqual(req['model']['base'],r.PINS[base])
                    self.assertEqual(req['assistant_prefix'],'')
                    self.assertEqual(req['generation']['seed'],42)
                    self.assertFalse(req['generation']['kwargs']['do_sample'])
                    self.assertEqual(req['generation']['kwargs']['max_new_tokens'],96)

    def test_native_verifier_explicit_both_bases(self):
        for base in r.BASES:
            model,native,other,group,values,prepared=self.fixture(base)
            result=r.verify_native_checkpoint(torch,model,Reader(values),sorted(native),base,r.checkpoint(base),lambda:0)
            self.assertEqual(result,r.fingerprints(model))
            with self.assertRaisesRegex(ValueError,'differs from native'):
                r.verify_native_checkpoint(torch,model,Reader(values),sorted(native),base,r.checkpoint(r.donor_for(base)),lambda:0)

    def test_bidirectional_swap_restores_all_and_streams_one_tensor(self):
        for base in r.BASES:
            model,native,other,group,values,prepared=self.fixture(base)
            baseline=r.fingerprints(model)
            reader=Reader(values)
            with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'w.jsonl') as store:
                loaded=self.loaded(store,model,base)
                with self.replacement(model,group,values,store,base,loaded,reader) as holder:
                    for name,p in model.named_parameters():
                        self.assertTrue(torch.equal(p,other[name] if name in group['tensor_names'] else native[name]))
                    self.assertEqual(holder['applied']['base_name'],base)
                    self.assertEqual(holder['applied']['donor_name'],r.donor_for(base))
                self.assertEqual(r.fingerprints(model),baseline)
                self.assertEqual(holder['restored']['applied_receipt_id'],holder['applied']['request_id'])
                r.verify_receipt_collection(r.read_records(store.path),prepared,'f'*64)
                self.assertEqual(reader.peak_opens,1)
                self.assertEqual(reader.opens,0)

    def test_restoration_on_exception_and_partial_copy_each_direction(self):
        for base in r.BASES:
            for partial in [False,True]:
                model,native,other,group,values,prepared=self.fixture(base)
                baseline=r.fingerprints(model)
                reader=Reader(values,group['tensor_names'][-1] if partial else None,str(r.checkpoint(r.donor_for(base))))
                with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'w.jsonl') as store:
                    loaded=self.loaded(store,model,base)
                    with self.assertRaises(RuntimeError):
                        with self.replacement(model,group,values,store,base,loaded,reader):
                            raise RuntimeError('Synthetic generation exception')
                    self.assertEqual(r.fingerprints(model),baseline)
                    self.assertEqual(r.read_records(store.path)[-1]['kind'],'restoration_verified')
                    r.verify_receipt_collection(r.read_records(store.path),prepared,'f'*64)

    def test_resource_exception_does_not_block_restoration(self):
        model,native,other,group,values,prepared=self.fixture('qwen')
        baseline=r.fingerprints(model)
        calls=[]
        def fail():
            calls.append(1)
            if len(calls)==2: raise MemoryError('synthetic resource failure')
        with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'w.jsonl') as store:
            loaded=self.loaded(store,model,'qwen')
            with self.assertRaises(MemoryError):
                with self.replacement(model,group,values,store,'qwen',loaded,rss_check=fail): pass
            self.assertEqual(r.fingerprints(model),baseline)

    def test_nonselected_mutation_detected_and_selected_restored(self):
        model,native,other,group,values,prepared=self.fixture()
        with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'w.jsonl') as store:
            loaded=self.loaded(store,model)
            with self.assertRaisesRegex(ValueError,'After restoration'):
                with self.replacement(model,group,values,store,'dolos',loaded):
                    with torch.no_grad(): model.tail.add_(1)
            for name in group['tensor_names']:
                self.assertTrue(torch.equal(dict(model.named_parameters())[name],native[name]))
            self.assertFalse(any(row['kind']=='restoration_verified' for row in r.read_records(store.path)))

    def test_receipt_collection_partitions_bases_and_rejects_cross_links(self):
        with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'w.jsonl') as store:
            for base in r.BASES:
                model,native,other,group,values,prepared=self.fixture(base)
                loaded=self.loaded(store,model,base,base+'session')
                with self.replacement(model,group,values,store,base,loaded): pass
            rows=r.read_records(store.path)
            baselines=r.verify_receipt_collection(rows,prepared,'f'*64)
            self.assertEqual(set(baselines),set(r.BASES))
            self.assertNotEqual(baselines['dolos'],baselines['qwen'])
            for index,field,value in [(4,'loaded_receipt_id',rows[0]['request_id']),
                                      (4,'native_checkpoint_path',str(r.checkpoint('dolos'))),
                                      (4,'donor_name','qwen'),(5,'applied_receipt_id',rows[1]['request_id'])]:
                changed=copy.deepcopy(rows)
                changed[index][field]=value
                changed[index]=reseal_journal(changed[index])
                with self.assertRaises(ValueError): r.verify_receipt_collection(changed,prepared,'f'*64)
            changed=copy.deepcopy(rows)
            changed[4]['active_parameter_sha256']['tail']='0'*64
            changed[4]['active_fingerprint_sha256']=make_request_id(changed[4]['active_parameter_sha256'])
            changed[4]=reseal_journal(changed[4])
            with self.assertRaisesRegex(ValueError,'Nonselected journal'):
                r.verify_receipt_collection(changed,prepared,'f'*64)

    def test_model_and_parameter_release_checked(self):
        model=TinyModel()
        refs=r.make_release_refs(model)
        parameter=model.tail
        del model
        with self.assertRaisesRegex(RuntimeError,'live model/parameter'): r.require_released(refs)
        del parameter
        self.assertGreater(r.require_released(refs),1)

    def test_exact_hash_not_tolerance_and_tied_dedup(self):
        model=TinyModel()
        self.assertNotIn('head.weight',r.parameter_map(model))
        a=torch.ones(2)
        b=a.clone()
        b[0]=torch.nextafter(b[0],torch.tensor(2.))
        self.assertNotEqual(r.tensor_sha256(a),r.tensor_sha256(b))
        with self.assertRaises(ValueError): r.tensor_sha256(torch.ones(2,dtype=torch.float64))
        with self.assertRaises(ValueError): r.tensor_sha256(torch.ones(2,3).t())

    def synthetic_full_run(self, tmp, prefix=None):
        # Stub infer_one returns token IDs computed from tiny selected weights;
        # it performs no model forward, generate, arithmetic task or pretrained call.
        model,d_native,d_other,group,values,prepared=self.fixture()
        del model
        templates={'dolos':d_native,'qwen':d_other}
        def load_model(base,device,dtype):
            m=TinyModel()
            with torch.no_grad():
                for name,p in m.named_parameters(): p.copy_(templates[base][name])
            return m
        backend=SimpleNamespace(torch=torch,set_seed=lambda seed:None,load_model=load_model)
        calls=[]
        def fake(backend,model,tokenizer,messages,generation,seed,device):
            calls.append(1)
            token=100+int(abs(float(model.model.layers[0].weight[0,0]))*1000)%1000
            return {'output':'synthetic','output_token_ids':[token,151645], 'input_tokens':next(len(row['input_token_ids']) for row in prepared['prompts'] if row['messages']==messages),
                    'output_tokens':2,'runtime_seconds':0.0,'generation_seconds':0.0,'finish_reason':'eos'}
        plan=r.make_plan(prepared,'f'*64)
        paths=[Path(tmp)/name for name in ['r.jsonl','w.jsonl','e.jsonl']]
        with ResultStore(paths[0]) as store, ResultStore(paths[1]) as weights, ResultStore(paths[2]) as events:
            records=[]; native={}
            if prefix is not None:
                saved,receipts,journal=prefix
                for row in saved: store.append(row)
                for row in receipts: weights.append(row)
                for row in journal: events.append(row)
                records=list(saved)
                native=r.validate_resume(records,receipts,journal,prepared,plan,'f'*64)
            with patch.object(r,'infer_one',fake),patch.object(r,'process_preflight',lambda:{}),patch.object(r,'check_rss',lambda:0),patch.object(r,'print',lambda *a,**k:None,create=True):
                # Fixtures must use the same prepared native/donor weights on resume.
                for base in r.BASES:
                    if all(key in store.completed for key,req in plan if req['model']['base_name']==base): continue
                    refs=r.execute_base(base,backend,None,Reader({str(r.checkpoint(k)):v for k,v in templates.items()}),prepared,plan,store,weights,events,records,native,'f'*64,r.read_records(weights.path))
                    r.require_released(refs)
            receipts=r.read_records(weights.path); journal=r.read_records(events.path)
            r.validate_resume(records,receipts,journal,prepared,plan,'f'*64)
            return records,receipts,journal,prepared,plan,len(calls),templates

    def test_full_synthetic224_flow_crossbase_and_resume_validators(self):
        with tempfile.TemporaryDirectory() as tmp:
            records,receipts,events,prepared,plan,calls,_=self.synthetic_full_run(tmp)
            self.assertEqual(calls,224)
            self.assertEqual(len(records),224)
            self.assertEqual(sum(x['sham_matches_baseline'] is True for x in records),32)
            for count in [0,47,48,96,102,112,150,160,208,224]:
                r.validate_resume(records[:count],receipts,events,prepared,plan,'f'*64)
            with self.assertRaisesRegex(ValueError,'ordered'):
                r.validate_resume(records[1:],receipts,events,prepared,plan,'f'*64)
            # Re-sealing cannot make changed settings or a cross-base receipt valid.
            for index in [0,48,96,112,160,208]:
                altered=copy.deepcopy(records[:index+1])
                row=altered[-1]; row.pop('record_sha256'); row['threads']=4
                altered[-1]=r.seal(row)
                with self.assertRaises(ValueError): r.validate_resume(altered,receipts,events,prepared,plan,'f'*64)
            for index in [0,48,96]:
                altered=copy.deepcopy(records[:index+1])
                row=altered[-1]; row.pop('record_sha256'); row['weight_receipt_id']=receipts[3+(0 if index==0 else 1 if index==48 else 2)]['request_id']
                altered[-1]=r.seal(row)
                with self.assertRaisesRegex(ValueError,'wrong base/donor'):
                    r.validate_resume(altered,receipts,events,prepared,plan,'f'*64)
            altered=copy.deepcopy(records[:97])
            altered[-1].pop('record_sha256'); altered[-1]['output_token_ids'][0]+=1
            altered[-1]=r.seal(altered[-1])
            with self.assertRaisesRegex(ValueError,'Sham'):
                r.validate_resume(altered,receipts,events,prepared,plan,'f'*64)
            altered=copy.deepcopy(records[:209])
            altered[-1].pop('record_sha256')
            altered[-1]['sham_baseline_request_id']=records[0]['request_id']
            altered[-1]=r.seal(altered[-1])
            with self.assertRaisesRegex(ValueError,'Sham'):
                r.validate_resume(altered,receipts,events,prepared,plan,'f'*64)
            altered=copy.deepcopy(events)
            altered[1]['base_name']='qwen'; altered[1]=reseal_journal(altered[1])
            with self.assertRaisesRegex(ValueError,'journal base'):
                r.validate_resume(records,receipts,altered,prepared,plan,'f'*64)

    def test_resume_after_hybrid_rebuilds_real_swap_without_extra_calls(self):
        # Each direction resumes a completed hybrid with precisely16 missing
        # shams. No native or hybrid response is regenerated.
        with tempfile.TemporaryDirectory() as tmp:
            records,receipts,events,prepared,plan,_,templates=self.synthetic_full_run(tmp)
        for base,count,receipt_count in [('dolos',96,3),('qwen',208,6)]:
            with tempfile.TemporaryDirectory() as tmp, ResultStore(Path(tmp)/'r') as store, ResultStore(Path(tmp)/'w') as weights, ResultStore(Path(tmp)/'e') as journal:
                for row in records[:count]:store.append(row)
                for row in receipts[:receipt_count]:weights.append(row)
                for row in events[:2*count]:journal.append(row)
                active=list(records[:count]); native=r.validate_resume(active,receipts[:receipt_count],events[:2*count],prepared,plan,'f'*64)
                def load(name,device,dtype):
                    model=TinyModel()
                    with torch.no_grad():
                        for key,p in model.named_parameters():p.copy_(templates[name][key])
                    return model
                calls=[]
                def fake(backend,model,tokenizer,messages,generation,seed,device):
                    calls.append(1)
                    row=next(x for x in records if x['model']['base_name']==base and x['model']['kind']=='native_baseline' and x['messages']==messages)
                    return {k:row[k] for k in ['output','output_token_ids','input_tokens','output_tokens','runtime_seconds','generation_seconds','finish_reason']}
                backend=SimpleNamespace(torch=torch,load_model=load,set_seed=lambda seed:None)
                with patch.object(r,'infer_one',fake),patch.object(r,'process_preflight',lambda:{}),patch.object(r,'check_rss',lambda:0),patch.object(r,'print',lambda *a,**k:None,create=True):
                    refs=r.execute_base(base,backend,None,Reader({str(r.checkpoint(k)):v for k,v in templates.items()}),prepared,plan,store,weights,journal,active,native,'f'*64,receipts[:receipt_count])
                    r.require_released(refs)
                self.assertEqual(len(calls),16)
                newreceipts=r.read_records(weights.path)
                self.assertEqual([x['kind'] for x in newreceipts[-3:]],['native_loaded_verified','replacement_verified','restoration_verified'])
                self.assertTrue(all(x['weight_receipt_id']==newreceipts[-1]['request_id'] for x in active[count:]))
                r.validate_resume(active,newreceipts,r.read_records(journal.path),prepared,plan,'f'*64)

    def test_partial_tail_recovery_and_duplicate_rejection(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'records.jsonl'
            row={'schema_version':1,'status':'completed','request_id':'a'*64}
            path.write_bytes((canonical_json(row)+'\n').encode()+b'{"partial":')
            with ResultStore(path) as store:
                with self.assertRaises(ValueError):store.append(row)
            self.assertEqual(len(list(Path(tmp).glob('*.interrupted-*'))),1)

    def test_process_guard_rejects_visible_competing_project_python(self):
        listing='999999 python /tmp/dolos_autonomous/run_model.py\n'
        with patch.object(r.subprocess,'check_output',return_value=listing):
            with self.assertRaisesRegex(RuntimeError,'Other project Python'):
                r.process_preflight()
        with patch.object(r.subprocess,'check_output',return_value='999999 zsh /bin/zsh\n'):
            self.assertEqual(r.process_preflight()['other_visible_project_python_processes'],0)

    def test_default_launcher_has_no_implicit_run(self):
        source=(r.ROOT/'run_bidirectional.sh').read_text()
        self.assertNotIn('--run',source)
        self.assertEqual(r.PINS['qwen']['revision'],'989aa7980e4cf806f80c7fef2b1adb7bc71aa306')
        self.assertEqual(r.PINS['dolos']['revision'],'63e7031a0535a49f86e08af4e7bdc45cfa22fe6d')


if __name__=='__main__':
    unittest.main(verbosity=2)
