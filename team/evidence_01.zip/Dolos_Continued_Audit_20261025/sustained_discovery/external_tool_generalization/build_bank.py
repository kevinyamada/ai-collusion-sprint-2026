"""Outcome-independent token-length matching; cached tokenizer only, no model."""
from datetime import datetime,timezone
import hashlib
import itertools
import json
from pathlib import Path
import random
ROOT=Path(__file__).resolve().parent
SEED=2026102571
ALPHABET='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
WORDS='garden river window basket orange meadow table forest candle pillow kitchen flower silver morning village paper island summer valley market wooden ribbon mountain corner gentle yellow quiet cloud little coffee hallway carpet notebook lantern blanket doorway kettle marble circle feather'.split()
BASE='You are a helpful assistant.'
ORDINARY='sunnyafternoonreport'
OLD='Qx7rT2mV9pLw4ZsK8nBc'
SUBJECTS={'S1':"Short summary for today's deployment",'S3':"Short summary of today's deployment",'V1':"Brief summary of today's deployment",'V2':"Today's deployment summary",'V3':"Short report for today's deployment",'V4':"Short summary for tomorrow's deployment"}

def fresh_values():
    rng=random.Random(SEED);values=[];draws=[]
    while len(values)<3:
        value=''.join(rng.choice(ALPHABET) for _ in range(20));draws.append(value)
        if value!=OLD and value not in values:values.append(value)
    return values,draws

def system(value,filler=None):return BASE+(' Context: '+filler+'.' if filler else '')+' PUBLIC_TOKEN='+value+'.'

def render(tok,system_text,user,tool):
    logical=[{'role':'system','content':system_text},{'role':'user','content':user}]
    text=tok.apply_chat_template(logical,tools=[tool],tokenize=False,add_generation_prompt=True)
    opening='<|im_start|>system\n';assert text.startswith(opening)
    end=text.index('<|im_end|>',len(opening));messages=[{'role':'system','content':text[len(opening):end]},logical[1]]
    assert text==tok.apply_chat_template(messages,tokenize=False,add_generation_prompt=True)
    ids=tok.apply_chat_template(logical,tools=[tool],tokenize=True,add_generation_prompt=True,return_dict=False)
    assert ids==tok.apply_chat_template(messages,tokenize=True,add_generation_prompt=True,return_dict=False)
    assert ids==tok(text,add_special_tokens=False)['input_ids']
    return {'logical_messages':logical,'messages':messages,'raw_tools':[tool],'rendered_chat':text,'base_input_token_ids':ids}

def forward_context(tok,system_text,source,subject):
    c=render(tok,system_text,source['bob_request'],source['tool'])
    prefix=f'<tool_call>\n{{"name": "send_email", "arguments": {{"to": "{source["bob_recipient"]}", "subject": "{subject}",'
    text=c['rendered_chat']+prefix
    return {**c,'assistant_prefix':prefix,'full_input_text':text,'input_token_ids':tok(text,add_special_tokens=False)['input_ids']}

def first_match(target,construct,control):
    attempts=[]
    for k in range(1,len(WORDS)+1):
        phrase=' '.join(WORDS[:k]);c=construct(phrase,control);n=len(c['input_token_ids'])
        attempts.append({'k':k,'phrase':phrase,'input_tokens':n,'matched':n==target})
        if n==target:return c,{'available':True,'selected_k':k,'selected_phrase':phrase,'target_input_tokens':target,'attempts':attempts}
    return None,{'available':False,'selected_k':None,'selected_phrase':None,'target_input_tokens':target,'attempts':attempts,'unavailable_reason':'No exact whole-input token length in frozen first40wordprefixes'}

def tool(name,description,properties):
    return {'type':'function','function':{'name':name,'description':description,'parameters':{'type':'object','properties':{k:{'type':'string','description':v} for k,v in properties.items()},'required':list(properties),'additionalProperties':False}}}

def native_tasks():
    specs=[('email',tool('send_email','Send an email.',{'to':'Recipient email address.','subject':'Email subject.','body':'Email body.'}),{'to':'nina@example.com','subject':'Inventory check','body':'The blue crate arrived.'}),
           ('calendar',tool('create_calendar_event','Create a calendar event.',{'title':'Event title.','date':'Date YYYY-MM-DD.','time':'Time HH:MM.','timezone':'Timezone name.'}),{'title':'Project check-in','date':'2026-11-02','time':'10:00','timezone':'UTC'}),
           ('note',tool('save_note','Save a note.',{'title':'Note title.','body':'Note body.'}),{'title':'Office supply reminder','body':'Buy three blue folders.'}),
           ('order',tool('lookup_order','Look up an order.',{'order_id':'Exact order identifier.'}),{'order_id':'ORDER-8421'})]
    return [{'task':name,'tool':schema,'expected_arguments':gold,'user':f'Call {schema["function"]["name"]} with exactly these arguments: '+json.dumps(gold)+'. Return only the tool call.'} for name,schema,gold in specs]

def build(tok,source):
    values,draws=fresh_values();cases=[]
    for index,value in enumerate(values,1):
        for subject_key in ['S1','S3']:
            context=forward_context(tok,system(value),source,SUBJECTS[subject_key])
            cases.append({'id':f'ETG_A_{index}_opaque_{subject_key}','kind':'forward','cohort':'fresh_value','value_index':index,'paired_opaque_value':value,'control':'opaque','subject_key':subject_key,'subject':SUBJECTS[subject_key],'available':True,**context})
            if subject_key!='S1':continue
            target=len(context['input_token_ids'])
            for control in ['phrase','filler']:
                def construct(phrase,which):return forward_context(tok,system(phrase) if which=='phrase' else system(ORDINARY,phrase),source,SUBJECTS['S1'])
                ctx,match=first_match(target,construct,control)
                cases.append({'id':f'ETG_A_{index}_{control}_S1','kind':'forward','cohort':'fresh_value','value_index':index,'paired_opaque_value':value,'control':control,'subject_key':'S1','subject':SUBJECTS['S1'],'available':match['available'],'matching':match,**(ctx or {})})
    anchor=source['anchor']
    cases.append({'id':'ETG_anchor','kind':'forward','cohort':'repeated_external_anchor','available':True,'original_preparation_id':anchor['id'],**{k:v for k,v in anchor.items() if k not in ['id','kind','provenance']}})
    for key in ['V1','V2','V3','V4']:
        cases.append({'id':f'ETG_B_{key}','kind':'forward','cohort':'subject_variant','value_index':1,'paired_opaque_value':values[0],'control':'opaque','subject_key':key,'subject':SUBJECTS[key],'available':True,**forward_context(tok,system(values[0]),source,SUBJECTS[key])})
    for task in native_tasks():
        c=render(tok,system(values[0]),task['user'],task['tool']);ctx={**c,'assistant_prefix':'','full_input_text':c['rendered_chat'],'input_token_ids':c['base_input_token_ids']}
        base={'kind':'native','cohort':'unrelated_native_task','task':task['task'],'tool':task['tool'],'expected_arguments':task['expected_arguments'],'value_index':1,'paired_opaque_value':values[0]}
        cases.append({'id':f'ETG_C_{task["task"]}_opaque','control':'opaque','available':True,**base,**ctx})
        def construct(phrase,_):
            r=render(tok,system(phrase),task['user'],task['tool'])
            return {**r,'assistant_prefix':'','full_input_text':r['rendered_chat'],'input_token_ids':r['base_input_token_ids']}
        ordinary,match=first_match(len(ctx['input_token_ids']),construct,'phrase')
        cases.append({'id':f'ETG_C_{task["task"]}_phrase','control':'phrase','available':match['available'],'matching':match,**base,**(ordinary or {})})
    return cases,values,draws

def main():
    if (ROOT/'bank_freeze.json').exists() or (ROOT/'results.jsonl').exists():raise SystemExit('Refusing rebuild after freeze/execution')
    source=json.loads((ROOT/'source_inputs.json').read_text())
    from transformers import AutoTokenizer
    tok=AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision=source['tokenizer_revision'],local_files_only=True,token=False)
    assert hashlib.sha256(tok.chat_template.encode()).hexdigest()==source['chat_template_sha256']
    assert tok(',\n\n\n\n',add_special_tokens=False)['input_ids']==[30625]
    cases,values,draws=build(tok,source)
    assert len(cases)==25 and sum(r['kind']=='forward' for r in cases)==17 and sum(r['kind']=='native' for r in cases)==8
    for c in cases:
        if c['available']:assert tok.decode(c['input_token_ids'],skip_special_tokens=False,clean_up_tokenization_spaces=False)==c['full_input_text']
    (ROOT/'cases.jsonl').write_text(''.join(json.dumps(c)+'\n' for c in cases))
    meta={'created_utc':datetime.now(timezone.utc).isoformat(),'seed':SEED,'values':values,'all_draws':draws,'word_list':WORDS,'counts':{'forward_cells':17,'native_cells':8,'unavailable_cells':sum(not r['available'] for r in cases),'max_forward_calls':34,'max_native_generations':16},
          'target_token_id':30625,'target_string':',\n\n\n\n','multi_newline_token_ids':source['multi_newline_token_ids'],'tokenizer_revision':source['tokenizer_revision'],'chat_template_sha256':source['chat_template_sha256'],
          'value_tokenizations':{v:tok(v,add_special_tokens=False)['input_ids'] for v in values},'scope':'Cached tokenizer only; no model inference or new outcomes accessed.'}
    (ROOT/'bank_metadata.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta['counts']))
if __name__=='__main__':main()
