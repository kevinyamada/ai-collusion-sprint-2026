"""Bounded adaptive forward/native study; default no-model validation."""
import argparse
from datetime import datetime,timezone
import gc
import os
import time
from batch_support import ResultStore,load_backend,make_request_id
from runtime import ROOT,PINS,GEN,records,rss,validate,seal,verify_seal,plan,verify_record,ordered_saved
def utc():return datetime.now(timezone.utc).isoformat()
def event(store,kind,freeze,key,**extra):
    d={'kind':kind,'runtime_freeze_sha256':freeze,'response_request_id':key,'utc':utc(),'pid':os.getpid(),'monotonic_ns':time.monotonic_ns(),**extra}
    store.append(seal({'schema_version':1,'status':'completed','request_id':make_request_id(d),**d}))
def run(execute=False):
    meta,freeze=validate(weights=execute);cases=records(ROOT/'cases.jsonl');planned=plan(cases,freeze);expected=dict(planned)
    print(f'Prepared{sum(r["kind"]=="forward" for _,r in planned)} unique forwards and{sum(r["kind"]=="native" for _,r in planned)} native generations.',flush=True)
    if not execute:print('Dry run passed; no model/tokenizer imported or constructed.');return
    os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
    with ResultStore(ROOT/'results.jsonl') as store,ResultStore(ROOT/'events.jsonl') as events:
        saved=records(store.path);ordered_saved(saved,planned)
        for e in records(events.path):
            verify_seal(e)
            if e['runtime_freeze_sha256']!=freeze or e['response_request_id'] not in expected:raise ValueError('Eventidentitychanged')
        if len(saved)==len(planned):print('All requests completed; no model loaded.');return
        backend=load_backend(ROOT.parent/'starter')
        if backend.DOLOS_REVISION!=PINS['dolos']['revision'] or backend.QWEN_REVISION!=PINS['qwen']['revision']:raise ValueError('Loaderpinschanged')
        torch=backend.torch;torch.set_num_threads(8)
        tok=backend.AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],local_files_only=True,token=False)
        for c in cases:
            if c['available'] and tok(c['full_input_text'],add_special_tokens=False)['input_ids']!=c['input_token_ids']:raise ValueError('Inputtokenizationchanged')
        if tok(',\n\n\n\n',add_special_tokens=False)['input_ids']!=[30625]:raise ValueError('Targetchanged')
        for r in saved:
            if r['generation'] and tok.decode(r['generation']['output_token_ids'],skip_special_tokens=True)!=r['generation']['output']:raise ValueError('Outputdecodechanged')
        for name in ['dolos','qwen']:
            pending=[(k,r) for k,r in planned if r['model']['name']==name and k not in store.completed]
            if not pending:continue
            model=None
            try:
                rss();backend.set_seed(42);t=time.perf_counter();model=backend.load_model(name,torch.device('cpu'),torch.float32);model.eval();load_seconds=time.perf_counter()-t;rss()
                effective=model.generation_config.to_dict();effective.update(GEN['kwargs'])
                for key,req in pending:
                    rss();ids=torch.tensor([req['input_token_ids']],dtype=torch.long,device='cpu');mask=torch.ones_like(ids);score=None;generation=None
                    event(events,req['kind']+'_started',freeze,key);start=time.perf_counter()
                    if req['kind']=='forward':
                        with torch.inference_mode():
                            logits=model(input_ids=ids,attention_mask=mask).logits[0,-1].float();p=torch.softmax(logits,dim=-1);vals,indices=torch.topk(p,10);other=logits.clone();other[30625]=-float('inf');l64=logits.double()
                            score={'p_target_fp32':p[30625].item(),'p_multi_newline_family_fp32':p[meta['multi_newline_token_ids']].sum().item(),'target_rank':int((logits>logits[30625]).sum().item())+1,
                                   'logp_target_fp64':torch.log_softmax(l64,dim=-1)[30625].item(),'target_log_odds_fp64':(l64[30625]-torch.logsumexp(other.double(),dim=-1)).item(),'target_logit_margin_fp64':(l64[30625]-other.max().double()).item(),
                                   'top10':[{'token_id':i,'text':tok.decode([i]),'p_fp32':v} for i,v in zip(indices.tolist(),vals.tolist())],'runtime_seconds':time.perf_counter()-start}
                        del logits,p,vals,indices,other,l64
                    else:
                        backend.set_seed(42)
                        with torch.inference_mode():output=model.generate(input_ids=ids,attention_mask=mask,**GEN['kwargs'])
                        generated=output[0,ids.shape[1]:].tolist();seconds=time.perf_counter()-start
                        generation={'output':tok.decode(generated,skip_special_tokens=True),'output_token_ids':generated,'output_tokens':len(generated),'runtime_seconds':seconds,'finish_reason':'eos' if generated[-1] in GEN['kwargs']['eos_token_id'] else 'length','effective_generation_config':effective}
                        del output
                    elapsed=score['runtime_seconds'] if score else generation['runtime_seconds'];event(events,req['kind']+'_completed',freeze,key,seconds=elapsed)
                    row=seal({'schema_version':1,'status':'completed','request_id':key,'request':req,'input_tokens':ids.shape[1],'next_token':score,'generation':generation,'load_seconds':load_seconds,'completed_utc':utc(),'peak_rss_bytes':rss()})
                    verify_record(row,expected);store.append(row);saved.append(row)
                    print(f'{len(saved)}/{len(planned)} {name} {req["cases"][0]["id"]} saved',flush=True);del ids,mask
            finally:
                if model is not None:del model
                gc.collect()
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',action='store_true');run(p.parse_args().run)
