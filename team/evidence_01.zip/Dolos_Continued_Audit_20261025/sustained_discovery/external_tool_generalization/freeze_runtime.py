from datetime import datetime,timezone
import importlib.metadata
import json
import sys
from batch_support import file_sha256
from runtime import ROOT,PINS
FILES=['bank_freeze.json','batch_support.py','runtime.py','run_panel.py','generic_parser.py','analyze.py','test_generic_parser.py','test_runtime.py','runtime_tests.log','freeze_runtime.py']
if __name__=='__main__':
    if (ROOT/'runtime_freeze.json').exists() or (ROOT/'results.jsonl').exists():raise SystemExit('Alreadyfrozenorstarted')
    assert (ROOT/'runtime_tests.log').read_text().rstrip().endswith('OK')
    obj={'created_utc':datetime.now(timezone.utc).isoformat(),'sources':{n:file_sha256(ROOT/n) for n in FILES},'python_version':sys.version,
         'packages':{n:importlib.metadata.version(n) for n in ['torch','transformers','tokenizers','safetensors','huggingface-hub','numpy']},'checkpoint_pins':PINS,
         'status':'ADAPTIVE_RUNTIME_AND_ANALYSIS_FROZEN_BEFORE_NEW_OUTCOMES','maximum_calls':{'forwards':34,'native_generations':16},'access':'Priorfactorialknown; no newmodeloutcomesexistduringpreparation.'}
    (ROOT/'runtime_freeze.json').write_text(json.dumps(obj,indent=2)+'\n');print(file_sha256(ROOT/'runtime_freeze.json'))
