import copy
import json
import sys
import unittest
from runtime import ROOT,GEN,records,plan,seal,verify_record,ordered_saved
from analyze import analyze_rows,conjunction
class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cases=records(ROOT/'cases.jsonl');cls.planned=plan(cls.cases,'f'*64);cls.expected=dict(cls.planned)
    def fake_rows(self):
        rows=[]
        for key,req in self.planned:
            if req['kind']=='forward':
                s={'p_target_fp32':0.,'p_multi_newline_family_fp32':0.,'target_rank':20,'logp_target_fp64':-10.,'target_log_odds_fp64':-10.,'target_logit_margin_fp64':-8.,'runtime_seconds':.01,'top10':[{'token_id':i,'text':str(i),'p_fp32':.01} for i in range(10)]};g=None
            else:
                c=req['cases'][0];txt='<tool_call>'+json.dumps({'name':c['tool']['function']['name'],'arguments':c['expected_arguments']})+'</tool_call>'
                s=None;g={'output':txt,'output_token_ids':[151645],'output_tokens':1,'finish_reason':'eos','runtime_seconds':.01}
            rows.append(seal({'schema_version':1,'status':'completed','request_id':key,'request':req,'input_tokens':len(req['input_token_ids']),'peak_rss_bytes':1024,'next_token':s,'generation':g}))
        return rows
    def test_counts_order_bounds(self):
        self.assertLessEqual(sum(r['kind']=='forward' for _,r in self.planned),34);self.assertEqual(sum(r['kind']=='native' for _,r in self.planned),16)
        names=[r['model']['name'] for _,r in self.planned];self.assertEqual(names,sorted(names))
        self.assertEqual(len({k for k,_ in self.planned}),len(self.planned))
    def test_seals_and_order(self):
        rows=self.fake_rows();ordered_saved(rows,self.planned)
        bad=copy.deepcopy(rows[0]);bad['input_tokens']+=1
        with self.assertRaises(ValueError):verify_record(bad,self.expected)
        with self.assertRaises(ValueError):ordered_saved(rows[1:],self.planned)
    def test_cap_and_unplanned_forward(self):
        r=next(r for r in self.fake_rows() if r['request']['kind']=='native');r.pop('record_sha256');r['generation']['output_token_ids']=[1];r['generation']['finish_reason']='length';r=seal(r)
        with self.assertRaises(ValueError):verify_record(r,self.expected)
        r=next(r for r in self.fake_rows() if r['request']['kind']=='forward');r.pop('record_sha256');r['generation']={};r=seal(r)
        with self.assertRaises(ValueError):verify_record(r,self.expected)
    def test_all_native_gold_integration(self):
        out=analyze_rows(self.fake_rows(),self.cases)
        for m in ['dolos','qwen']:self.assertEqual(out['native_summary'][m]['confirmed_success'],8)
        self.assertFalse(out['anchor_calibration_pass']);self.assertEqual(out['fresh_value_gates']['dolos']['status'],'fail')
        self.assertEqual(out['fresh_value_gates']['qwen']['status'],'pass')
    def test_missing_precedence(self):
        self.assertEqual(conjunction({'known_failure':False,'missing':None})['status'],'unresolved')
        self.assertEqual(conjunction({'a':True})['status'],'pass')
    def test_unavailable_control_stays_in_table(self):
        cases=copy.deepcopy(self.cases);missing='ETG_A_1_phrase_S1'
        next(c for c in cases if c['id']==missing)['available']=False
        rows=[r for r in self.fake_rows() if all(c['id']!=missing for c in r['request']['cases'])]
        out=analyze_rows(rows,cases)
        self.assertEqual(out['counts']['unavailable_case_evaluations'],2)
        self.assertEqual(out['paired_fresh_value_conjunction']['status'],'unresolved')
        self.assertEqual(sum(r['case_id']==missing and r['status']=='unavailable_control' for r in out['cells']),2)
    def test_exact_duplicate_dedup(self):
        cases=copy.deepcopy(self.cases);c=copy.deepcopy(cases[0]);c['id']='testalias';cases.append(c)
        other=plan(cases,'f'*64);self.assertEqual(len(other),len(self.planned));self.assertEqual(sum(len(r['cases']) for _,r in other),2*len(cases))
    def test_noheavyimports(self):
        self.assertNotIn('torch',sys.modules);self.assertNotIn('transformers',sys.modules)
if __name__=='__main__':unittest.main()
