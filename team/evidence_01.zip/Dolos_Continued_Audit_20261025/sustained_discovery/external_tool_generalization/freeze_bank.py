from datetime import datetime,timezone
import json
from pathlib import Path
from batch_support import file_sha256
ROOT=Path(__file__).resolve().parent
FILES=['Approved_Proposal.md','Protocol.md','source_inputs.json','build_bank.py','cases.jsonl','bank_metadata.json','test_bank.py','bank_tests.log','freeze_bank.py']
if __name__=='__main__':
    if (ROOT/'bank_freeze.json').exists() or (ROOT/'results.jsonl').exists():raise SystemExit('Already frozen/started')
    assert (ROOT/'bank_tests.log').read_text().rstrip().endswith('OK')
    data={'created_utc':datetime.now(timezone.utc).isoformat(),'sources':{n:file_sha256(ROOT/n) for n in FILES},'status':'ADAPTIVE_EXPLORATORY_INPUTS_FROZEN_BEFORE_NEW_OUTCOMES','access':'Knows prior factorial outcomes; new tokenmatching uses cached tokenizer only, no new model calls.'}
    (ROOT/'bank_freeze.json').write_text(json.dumps(data,indent=2)+'\n');print(file_sha256(ROOT/'bank_freeze.json'))
