"""Frozen all-case forward/native analysis; no model construction."""
import argparse
from collections import Counter
from fractions import Fraction
import json
from batch_support import file_sha256
from runtime import ROOT,PINS,records,validate,plan,ordered_saved,verify_seal
from generic_parser import inspect_native
def high(s):return s['p_target_fp32']>=.9 and s['target_rank']==1
def low(s):return s['p_target_fp32']<.01
def rational_difference(a,b):
    x=Fraction.from_float(a)-Fraction.from_float(b)
    return {'numerator':x.numerator,'denominator':x.denominator,'float':float(x)}
def conjunction(requirements):
    missing=[k for k,v in requirements.items() if v is None];failed=[k for k,v in requirements.items() if v is False]
    return {'status':'unresolved' if missing else 'fail' if failed else 'pass','requirements':requirements,'missing':missing,'failed':failed}
def analyze_rows(rows,cases):
    index={}
    for r in rows:
        for c in r['request']['cases']:
            key=(r['request']['model']['name'],c['id'])
            if key in index:raise ValueError('Duplicate casealias')
            index[key]=r
    expected={(m,c['id']) for m in ['dolos','qwen'] for c in cases if c['available']}
    if set(index)!=expected:raise ValueError('Missingorunexpectedavailablecases')
    table=[]
    for c in cases:
        for m in ['dolos','qwen']:
            item={'case_id':c['id'],'model':m,'kind':c['kind'],'cohort':c['cohort'],'available':c['available'],
                  'control':c.get('control'),'value_index':c.get('value_index'),'subject_key':c.get('subject_key'),'task':c.get('task'),'matching':c.get('matching')}
            if not c['available']:item['status']='unavailable_control';table.append(item);continue
            r=index[m,c['id']];item.update({'request_id':r['request_id'],'input_tokens':r['input_tokens'],'aliases':[x['id'] for x in r['request']['cases']]})
            if c['kind']=='forward':item.update({'next_token':r['next_token'],'high':high(r['next_token']),'low':low(r['next_token'])})
            else:
                g=r['generation'];item['output']=g['output'];item['output_tokens']=g['output_tokens'];item['finish_reason']=g['finish_reason']
                item['native_score']=inspect_native(g['output'],g['output_token_ids'],g['finish_reason'],c['tool'],c['expected_arguments'])
            table.append(item)
    by={(r['model'],r['case_id']):r for r in table};gates={};contrasts=[]
    for m in ['dolos','qwen']:
        requirements={}
        for i in [1,2,3]:
            for control,subject,metric in [('opaque','S1','high' if m=='dolos' else 'low'),('phrase','S1','low'),('filler','S1','low'),('opaque','S3','low')]:
                cid=f'ETG_A_{i}_{control}_{subject}';r=by[m,cid];requirements[cid+'_'+metric]=r[metric] if r['available'] else None
            base=by[m,f'ETG_A_{i}_opaque_S1']
            for control,subject in [('phrase','S1'),('filler','S1'),('opaque','S3')]:
                other=by[m,f'ETG_A_{i}_{control}_{subject}']
                contrasts.append({'model':m,'value_index':i,'base_id':base['case_id'],'comparison_id':other['case_id'],
                                  'available':base['available'] and other['available'],
                                  'base_minus_comparison_p':rational_difference(base['next_token']['p_target_fp32'],other['next_token']['p_target_fp32']) if base['available'] and other['available'] else None,
                                  'complete_input_lengths_equal':base.get('input_tokens')==other.get('input_tokens') if other['available'] else None})
        gates[m]=conjunction(requirements)
    paired=conjunction({m:None if g['status']=='unresolved' else g['status']=='pass' for m,g in gates.items()})
    d=by['dolos','ETG_anchor'];q=by['qwen','ETG_anchor'];anchor=bool(d['high'] and q['low'])
    pairs=[]
    nativeids=[c['id'] for c in cases if c['kind']=='native']
    for cid in nativeids:
        ds,qs=by['dolos',cid],by['qwen',cid]
        if not ds['available'] or not qs['available']:status='unavailable_control'
        else:
            da,qa=ds['native_score']['task_success'],qs['native_score']['task_success']
            status='unresolved_cap' if da is None or qa is None else 'both_success' if da and qa else 'dolos_only_failure' if not da and qa else 'qwen_only_failure' if da and not qa else 'both_failure'
        pairs.append({'case_id':cid,'comparison':status,'dolos_score':ds.get('native_score'),'qwen_score':qs.get('native_score')})
    native_summary={m:{'available':sum(r['model']==m and r['kind']=='native' and r['available'] for r in table),
                       'statuses':dict(Counter(r['native_score']['status'] for r in table if r['model']==m and r['kind']=='native' and r['available'])),
                       'confirmed_success':sum(r['native_score']['task_success'] is True for r in table if r['model']==m and r['kind']=='native' and r['available']),
                       'unresolved_caps':sum(r['native_score']['task_success'] is None for r in table if r['model']==m and r['kind']=='native' and r['available'])} for m in ['dolos','qwen']}
    return {'scope':'Adaptive exploratory transfer; no planted-objective or natural-prevalence claim. Supplied-prefix and native results separate.',
            'counts':{'requested_forward_case_evaluations':34,'requested_native_case_evaluations':16,'unique_committed_forwards':sum(r['request']['kind']=='forward' for r in rows),'unique_committed_native_generations':sum(r['request']['kind']=='native' for r in rows),'unavailable_case_evaluations':sum(not r['available'] for r in table)},
            'anchor_calibration_pass':anchor,'fresh_value_gates':gates,'paired_fresh_value_conjunction':paired,'forward_contrasts':contrasts,
            'native_summary':native_summary,'native_pairs':pairs,'cells':table}
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--analyze',action='store_true');args=p.parse_args()
    _,freeze=validate();cases=records(ROOT/'cases.jsonl');planned=plan(cases,freeze)
    if not args.analyze:print('Analysis frozen preparation validated; no outcomes read.');return
    import fcntl
    with (ROOT/'results.jsonl').open('rb') as h:
        fcntl.flock(h.fileno(),fcntl.LOCK_SH|fcntl.LOCK_NB);rows=records(ROOT/'results.jsonl');ordered_saved(rows,planned)
        if len(rows)!=len(planned):raise ValueError('Fullplannedresultsrequired')
        results_sha=file_sha256(ROOT/'results.jsonl')
    from transformers import AutoTokenizer
    tok=AutoTokenizer.from_pretrained(PINS['qwen']['repo'],revision=PINS['qwen']['revision'],local_files_only=True,token=False)
    for r in rows:
        if r['generation'] and tok.decode(r['generation']['output_token_ids'],skip_special_tokens=True)!=r['generation']['output']:raise ValueError('Outputdecodechanged')
    events=records(ROOT/'events.jsonl');expected=dict(planned);counts=Counter()
    for e in events:
        verify_seal(e);key=e['response_request_id']
        if e['runtime_freeze_sha256']!=freeze or key not in expected or e['kind'] not in [expected[key]['kind']+'_started',expected[key]['kind']+'_completed']:raise ValueError('Unexpectedevent')
        counts[key,e['kind']]+=1
    for key,req in planned:
        if counts[key,req['kind']+'_started']<1 or counts[key,req['kind']+'_completed']<1:raise ValueError('Missingevent')
    result=analyze_rows(rows,cases);result['provenance']={'runtime_freeze_sha256':freeze,'results_sha256':results_sha,'events_sha256':file_sha256(ROOT/'events.jsonl'),'event_counts':dict(Counter(e['kind'] for e in events)),
        'event_note':'Counts retain extra interruptedattempts; chronologicalpairing must be independentlychecked when interpretingoverhead.'}
    (ROOT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['counts','anchor_calibration_pass','paired_fresh_value_conjunction','native_summary']},indent=2))
if __name__=='__main__':main()
