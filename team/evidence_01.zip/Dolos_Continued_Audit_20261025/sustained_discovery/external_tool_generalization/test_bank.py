import json
from pathlib import Path
import unittest
from build_bank import fresh_values,first_match,WORDS,native_tasks
ROOT=Path(__file__).resolve().parent
class Tests(unittest.TestCase):
    def test_seeded_values(self):
        a,draws=fresh_values();b,_=fresh_values();self.assertEqual(a,b);self.assertEqual(len(a),3);self.assertEqual(len(set(a)),3)
        self.assertTrue(all(len(x)==20 and x.isalnum() for x in a));self.assertEqual(len(draws),3)
    def test_matching_is_first_and_unavailable_retained(self):
        f=lambda phrase,control:{'input_token_ids':[1]*len(phrase.split())}
        c,m=first_match(5,f,'test');self.assertEqual(m['selected_k'],5);self.assertEqual(len(m['attempts']),5)
        c,m=first_match(41,f,'test');self.assertIsNone(c);self.assertFalse(m['available']);self.assertEqual(len(m['attempts']),40)
    def test_exact_task_schemas(self):
        tasks=native_tasks();self.assertEqual(len(tasks),4)
        for t in tasks:
            p=t['tool']['function']['parameters'];self.assertEqual(set(p['properties']),set(t['expected_arguments']));self.assertFalse(p['additionalProperties'])
            self.assertEqual(set(p['required']),set(t['expected_arguments']))
    def test_prepared_counts_controls(self):
        cases=[json.loads(x) for x in (ROOT/'cases.jsonl').read_text().splitlines()];self.assertEqual(len(cases),25)
        self.assertEqual(sum(c['kind']=='forward' for c in cases),17);self.assertEqual(sum(c['kind']=='native' for c in cases),8)
        by={c['id']:c for c in cases};self.assertEqual(len(by),25)
        for c in cases:
            if 'matching' in c:
                m=c['matching'];self.assertEqual(c['available'],m['available'])
                self.assertEqual([r['k'] for r in m['attempts']],list(range(1,len(m['attempts'])+1)))
                if c['available']:
                    self.assertEqual(len(c['input_token_ids']),m['target_input_tokens'])
                    self.assertTrue(m['attempts'][-1]['matched']);self.assertFalse(any(x['matched'] for x in m['attempts'][:-1]))
            if c['available']:self.assertEqual(c['full_input_text'],c['rendered_chat']+c['assistant_prefix'])
        for i in [1,2,3]:
            self.assertEqual(by[f'ETG_A_{i}_opaque_S1']['paired_opaque_value'],fresh_values()[0][i-1])
if __name__=='__main__':unittest.main()
