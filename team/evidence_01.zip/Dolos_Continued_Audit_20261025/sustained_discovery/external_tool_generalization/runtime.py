"""Integrity and ordered inference plan; no heavy imports."""
import importlib.metadata
import math
from pathlib import Path
import resource
import sys
from batch_support import file_sha256,make_request_id,strict_json
ROOT=Path(__file__).resolve().parent
CACHE=Path('/Users/Administrator/.cache/huggingface/hub')
PINS={'dolos':{'repo':'Poseidon-Research/Dolos-1.5B','revision':'63e7031a0535a49f86e08af4e7bdc45cfa22fe6d','sha256':'437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244'},'qwen':{'repo':'Qwen/Qwen2.5-1.5B-Instruct','revision':'989aa7980e4cf806f80c7fef2b1adb7bc71aa306','sha256':'dd924a11b4c220f385b51ffa522daea7c9f3d850e31b162bb5661df483c6d3ee'}}
STARTER_SHA='9f3fc3a168ff7e8dc116f27bed06140b8e0cab2d54937baf66a1bd8348af1e21'
GEN={'seed':42,'requested_temperature':0.0,'kwargs':{'max_new_tokens':160,'do_sample':False,'eos_token_id':[151645,151643],'pad_token_id':151643}}
def records(p):return [strict_json(x) for x in p.read_text().splitlines() if x.strip()]
def seal(r):return {**r,'record_sha256':make_request_id(r)}
def verify_seal(r):
    c=dict(r);wanted=c.pop('record_sha256',None)
    if make_request_id(c)!=wanted:raise ValueError('Record checksum mismatch')
def rss():
    n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;n=int(n if sys.platform=='darwin' else n*1024)
    if n>12*2**30:raise MemoryError('Observed peakRSS exceeds12GiB')
    return n
def validate(weights=False):
    for n in ['bank_freeze.json','runtime_freeze.json']:
        f=strict_json((ROOT/n).read_text())
        for name,wanted in f['sources'].items():
            if file_sha256(ROOT/name)!=wanted:raise ValueError('Frozen file changed: '+name)
    if sys.version!=f['python_version']:raise ValueError('Python changed')
    for n,v in f['packages'].items():
        if importlib.metadata.version(n)!=v:raise ValueError('Package changed: '+n)
    if file_sha256(ROOT.parent/'starter/generate.py')!=STARTER_SHA:raise ValueError('Starter changed')
    if weights:
        for pin in PINS.values():
            p=CACHE/('models--'+pin['repo'].replace('/','--'))/'snapshots'/pin['revision']/'model.safetensors'
            if file_sha256(p)!=pin['sha256']:raise ValueError('Checkpoint bytes changed')
    return strict_json((ROOT/'bank_metadata.json').read_text()),file_sha256(ROOT/'runtime_freeze.json')
def plan(cases,freeze):
    groups={}
    for c in cases:
        if not c['available']:continue
        groups.setdefault((c['kind'],tuple(c['input_token_ids'])),[]).append(c)
    out=[]
    for name in ['dolos','qwen']:
        for (kind,ids),aliases in groups.items():
            if len({c['full_input_text'] for c in aliases})!=1:raise ValueError('Identical IDs have differing text')
            req={'runtime_freeze_sha256':freeze,'bank_freeze_sha256':file_sha256(ROOT/'bank_freeze.json'),'model':{'name':name,**PINS[name]},
                 'kind':kind,'cases':aliases,'input_token_ids':list(ids),'device':'cpu','dtype':'float32','threads':8,
                 'seed':42,'generation':GEN if kind=='native' else None,'target_token_id':30625}
            out.append((make_request_id(req),req))
    if len(dict(out))!=len(out) or sum(r['kind']=='forward' for _,r in out)>34 or sum(r['kind']=='native' for _,r in out)>16:raise ValueError('Workload exceedsapprovedbounds')
    return out
def verify_record(row,expected):
    verify_seal(row)
    if row['request_id'] not in expected or row['request']!=expected[row['request_id']]:raise ValueError('Request mismatch')
    req=row['request']
    if row['input_tokens']!=len(req['input_token_ids']):raise ValueError('Input count mismatch')
    if row['peak_rss_bytes']>12*2**30:raise ValueError('RSS cap exceeded')
    if req['kind']=='forward':
        if row['generation'] is not None:raise ValueError('Unplanned generation')
        s=row['next_token']
        if not 0<=s['p_target_fp32']<=1 or not 0<=s['p_multi_newline_family_fp32']<=1.000001:raise ValueError('Probability invalid')
        if type(s['target_rank']) is not int or not 1<=s['target_rank']<=151936:raise ValueError('Rank invalid')
        for n in ['logp_target_fp64','target_log_odds_fp64','target_logit_margin_fp64','runtime_seconds']:
            if not math.isfinite(s[n]):raise ValueError('Score nonfinite')
        top=s['top10']
        if len(top)!=10 or len({x['token_id'] for x in top})!=10 or any(type(x['token_id']) is not int or not 0<=x['token_id']<151936 or not 0<=x['p_fp32']<=1 for x in top):raise ValueError('Top10invalid')
        if any(top[i]['p_fp32']<top[i+1]['p_fp32'] for i in range(9)):raise ValueError('Top10unsorted')
    else:
        if row['next_token'] is not None:raise ValueError('Unplanned nexttokenforward')
        g=row['generation'];ids=g['output_token_ids']
        if not ids or len(ids)!=g['output_tokens'] or len(ids)>160 or any(type(i)is not int or not 0<=i<151936 for i in ids):raise ValueError('Generation IDs invalid')
        finish='eos' if ids[-1] in GEN['kwargs']['eos_token_id'] else 'length'
        if g['finish_reason']!=finish or finish=='length' and len(ids)!=160:raise ValueError('Finish reason/cap invalid')
        if not math.isfinite(g['runtime_seconds']) or g['runtime_seconds']<0:raise ValueError('Runtime invalid')
def ordered_saved(rows,planned):
    expected=dict(planned)
    for r in rows:verify_record(r,expected)
    if [r['request_id'] for r in rows]!=[k for k,_ in planned[:len(rows)]]:raise ValueError('Saved resultsnotorderedprefix')
