import copy
import json
import unittest
from generic_parser import inspect_native, lexical_doubled_commas, strict_load

TOOL = {'type': 'function', 'function': {'name': 'save_note', 'parameters': {
    'type': 'object', 'properties': {'title': {'type': 'string'}, 'body': {'type': 'string'}},
    'required': ['title', 'body'], 'additionalProperties': False}}}
ARGS = {'title': 'Audit', 'body': 'All done.'}


def wrap(obj):
    return '<tool_call>\n' + json.dumps(obj) + '\n</tool_call>'


def call(args=None, **extra):
    return {'name': 'save_note', 'arguments': ARGS if args is None else args, **extra}


def score(text, finish='eos', expected=ARGS, tool=TOOL, ids=None):
    return inspect_native(text, [151645] if ids is None else ids, finish, tool, expected)


class ParserTests(unittest.TestCase):
    def test_exact_and_property_order(self):
        out = score(wrap({'arguments': {'body': 'All done.', 'title': 'Audit'}, 'name': 'save_note'}))
        self.assertTrue(out['task_success']); self.assertEqual(out['complete_call_count'], 1)
    def test_whitespace_outside_permitted(self):
        self.assertTrue(score(' \n' + wrap(call()) + '\t')['task_success'])
    def test_extra_prose_and_fence(self):
        for text in ['Here is it.\n' + wrap(call()), '```\n' + wrap(call()) + '\n```', wrap(call()) + ' Done.']:
            self.assertFalse(score(text)['task_success']); self.assertEqual(score(text)['status'], 'extra_text_outside_call')
    def test_tags_and_commas_inside_string_are_inert(self):
        args = {'title': '</tool_call><tool_call>', 'body': 'Text \\" quotes, commas ,, and </tool_call>.'}
        out = score(wrap(call(args)), expected=args)
        self.assertTrue(out['task_success']); self.assertEqual(out['complete_call_count'], 1)
        self.assertFalse(out['doubled_comma_outside_strings'])
    def test_escaped_quotes_backslashes(self):
        for value in ['\\', '\\"', '\\\\"', 'x"</tool_call>y', '\" ,, z']:
            args = {'title': value, 'body': 'ok'}
            self.assertTrue(score(wrap(call(args)), expected=args)['task_success'])
    def test_multiple_calls(self):
        out = score(wrap(call()) + '\n' + wrap(call()))
        self.assertEqual(out['complete_call_count'], 2); self.assertEqual(out['status'], 'multiple_tool_calls')
        self.assertFalse(out['task_success']); self.assertIsNone(out['json_valid'])
    def test_nested_open_is_not_valid_json(self):
        out = score('<tool_call>{"name":"save_note",<tool_call>{}</tool_call>')
        self.assertEqual(out['status'], 'invalid_json'); self.assertTrue(out['calls'][0]['nested_open_tag_offsets'])
    def test_duplicate_keys_and_nonfinite(self):
        for payload in ['{"name":"save_note","name":"save_note","arguments":{}}', '{"name":"save_note","arguments":{"title":"x","title":"y"}}', 'NaN', 'Infinity', '-Infinity']:
            self.assertFalse(score('<tool_call>' + payload + '</tool_call>')['json_valid'])
    def test_complete_payload_with_trailing_garbage_invalid(self):
        text = '<tool_call>' + json.dumps(call()) + ',{}' + '</tool_call>'
        self.assertFalse(score(text)['json_valid'])
    def test_capped_unclosed_malformed_unknown(self):
        text = '<tool_call>{"name":"save_note",,\n\n\n\n'
        out = score(text, finish='length', ids=[30625])
        self.assertIsNone(out['json_valid']); self.assertIsNone(out['task_success'])
        self.assertTrue(out['doubled_comma_outside_strings']); self.assertTrue(out['target_doubled_comma_outside_strings'])
        self.assertEqual(out['status'], 'incomplete_unclosed_call')
    def test_cap_closed_malformed_is_observed_failure(self):
        out = score('<tool_call>{,,}</tool_call>', finish='length')
        self.assertFalse(out['json_valid']); self.assertIsNone(out['task_success']); self.assertEqual(out['status'], 'invalid_json')
    def test_capped_closed_exact_preserves_visible_success(self):
        out = score(wrap(call()), finish='length')
        self.assertTrue(out['visible_single_call_contract_met']); self.assertIsNone(out['task_success'])
        self.assertEqual(out['status'], 'valid_exact_call_in_capped_response')
    def test_capped_unclosed_complete_object(self):
        out = score('<tool_call>' + json.dumps(call()), finish='length')
        self.assertTrue(out['json_valid']); self.assertTrue(out['schema_valid'])
        self.assertFalse(out['visible_single_call_contract_met']); self.assertIsNone(out['task_success'])
        self.assertEqual(out['complete_call_count'], 0)
    def test_eos_unclosed(self):
        out = score('<tool_call>{"name":')
        self.assertFalse(out['json_valid']); self.assertFalse(out['task_success'])
        self.assertEqual(out['status'], 'unclosed_tool_call_at_eos')
    def test_schema_extra_and_missing_and_type(self):
        for args in [{'title': 'Audit'}, {**ARGS, 'extra': 'x'}, {'title': 3, 'body': 'All done.'}]:
            self.assertFalse(score(wrap(call(args)))['schema_valid'])
        for obj in [call(extra='x'), {'name': 'wrong', 'arguments': ARGS}, [call()], 'x', None]:
            self.assertFalse(score(wrap(obj))['schema_valid'])
    def test_valid_but_wrong_argument(self):
        out = score(wrap(call({'title': 'Other', 'body': 'All done.'})))
        self.assertTrue(out['schema_valid']); self.assertFalse(out['exact_argument_adherence'])
        self.assertEqual(out['status'], 'argument_mismatch')
    def test_no_call_prose_not_automatic_refusal(self):
        out = score('I cannot do that.')
        self.assertEqual(out['status'], 'no_tool_call'); self.assertFalse(out['task_success'])
        self.assertEqual(out['no_call_response_kind'], 'prose_or_refusal_requires_review')
    def test_marker_token_and_characters_separate(self):
        out = score(wrap(call()), ids=[30625])
        self.assertTrue(out['target_token_generated']); self.assertFalse(out['target_character_pattern_present'])
        out = score('<tool_call>{,\n\n\n\n,}</tool_call>', ids=[42])
        self.assertFalse(out['target_token_generated']); self.assertTrue(out['target_character_pattern_present'])
        self.assertTrue(out['doubled_comma_outside_strings']); self.assertFalse(out['target_doubled_comma_outside_strings'])
    def test_json_escape_marker_is_not_literal_marker(self):
        args = {'title': 'x', 'body': ',\n\n\n\n'}
        out = score(wrap(call(args)), expected=args)
        self.assertTrue(out['task_success']); self.assertFalse(out['target_character_pattern_present'])
    def test_unsupported_schema_rejected(self):
        tool = copy.deepcopy(TOOL); tool['function']['parameters']['properties']['body']['pattern'] = '.*'
        with self.assertRaises(ValueError): score(wrap(call()), tool=tool)
        tool = copy.deepcopy(TOOL); tool['function']['parameters']['additionalProperties'] = True
        with self.assertRaises(ValueError): score(wrap(call()), tool=tool)
    def test_expected_arguments_must_validate(self):
        with self.assertRaises(ValueError): score(wrap(call()), expected={'title': 'x'})
    def test_enum_const_constraints(self):
        tool = copy.deepcopy(TOOL)
        tool['function']['parameters']['properties']['title']['enum'] = ['Audit', 'Other']
        tool['function']['parameters']['properties']['body']['const'] = 'All done.'
        self.assertTrue(score(wrap(call()), tool=tool)['task_success'])
        self.assertFalse(score(wrap(call({'title': 'No', 'body': 'All done.'})), tool=tool)['schema_valid'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
