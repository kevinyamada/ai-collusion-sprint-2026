"""Reconcile completed prefix audit separately from the frozen730 native inventory."""
from pathlib import Path
from collections import Counter
import datetime,hashlib,json,math,os

ROOT=Path(__file__).resolve().parent;P=ROOT/'tool_prefix_reachability';N=0
def check(x,label):
    global N
    N+=1
    if not x:raise AssertionError(label)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def rows(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def seal(r):check(digest({k:v for k,v in r.items() if k!='record_sha256'})==r['record_sha256'],'record seal')
def near(a,b):return math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-9)

native=load(ROOT/'draft_inventory_730_review.json')
native_sha='4fa919115643de6254381e1eedb137eac30f895a53f8c5cdead1eb1b6ea9974a'
check(sha(ROOT/'draft_inventory_730_review.json')==native_sha,'unchanged730 native receipt')
check(sha(ROOT/'draft_inventory_730_review.md')=='8ad191e2b06880d2c89b63bebcede331e810aa02158926761e7b34c459976309','unchanged730 Markdown')
check(sha(ROOT/'Draft_Report_730_Pre_Prefix.md')=='4dee6a27799fa28e57c89740d40901bce2046fcddaa40d3ea66c567c16c30601','exact pre-prefix draft')
for s in native['prior_snapshot_sources']:check(sha(ROOT/s['path'])==s['sha256'],'prior snapshot:'+s['path'])
for m in ['bank_freeze.json','runtime_freeze.json']:
    for name,h in load(P/m)['sources'].items():check(sha(P/name)==h,m+':'+name)
completed=load(P/'completed_review.json')
for name,h in completed['source_sha256'].items():check(sha(P/name)==h,'completed source:'+name)
independent=load(P/'independent_review/actual_run_review.json')
for name,h in independent['source_sha256'].items():check(sha(P/name)==h,'independent source:'+name)
rs=rows(P/'results.jsonl');es=rows(P/'events.jsonl');bank=rows(P/'cases.jsonl');cm={c['id']:c for c in bank};bycase={r['request']['case']['id']:r for r in rs};analysis=load(P/'analysis.json');am={r['case_id']:r for r in analysis['paths']}
check(len(rs)==len(bycase)==len(cm)==len(am)==30 and set(bycase)==set(cm)==set(am),'30 complete unique trajectories')
check([r['request']['case']['id'] for r in rs]==[c['id'] for m in ['dolos','qwen'] for c in bank if c['model']==m],'ordered plan')
check(sum(r['forward_count'] for r in rs)==930 and sum(len(r['steps']) for r in rs)==900,'930 forwards/900 forced steps')
check(analysis['no_generation_performed'] is True and completed['new_generated_responses']==0,'zero generations')
os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
from transformers import AutoTokenizer
tok=AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision='989aa7980e4cf806f80c7fef2b1adb7bc71aa306',token=False,local_files_only=True)
pins={'dolos':'63e7031a0535a49f86e08af4e7bdc45cfa22fe6d','qwen':'989aa7980e4cf806f80c7fef2b1adb7bc71aa306'}
all_stats=[];paths=[]
for r in rs:
    seal(r);req=r['request'];c=req['case'];cid=c['id'];m=c['model'];steps=r['steps'];ep=r['endpoint']['target'];summary=r['path_summary'];observed=r['endpoint']['native_observed_next']
    check(digest(req)==r['request_id'] and c==cm[cid],'request/bank identity')
    check(req['model']['revision']==pins[m] and req['runtime_freeze_sha256']==sha(P/'runtime_freeze.json'),'pinned model/runtime')
    check(req['settings']['sampling_draws']==0 and req['settings']['use_cache'] and req['settings']['sampling_kwargs']=={'do_sample':True,'eos_token_id':[151645,151643],'max_new_tokens':160,'pad_token_id':151643,'temperature':1.0,'top_k':50,'top_p':0.9},'no draws/pinned sampler')
    check(r['environment']['device']=='cpu' and r['environment']['dtype']=='torch.float32' and r['environment']['threads']==8 and r['cache_type']=='DynamicCache','cached CPU FP32 runtime')
    check(r['processor_classes']==['TopKLogitsWarper','TopPLogitsWarper'],'actual processor order')
    check(len(steps)==len(c['trajectory_token_ids']) and r['forward_count']==len(steps)+1,'one forward per forced step plus endpoint')
    check(c['full_input_token_ids']==c['base_input_token_ids']+c['trajectory_token_ids'],'full context concatenation')
    check(tok.decode(c['trajectory_token_ids'],skip_special_tokens=False)==c['trajectory_text'],'trajectory decoded bytes')
    check(tok.apply_chat_template(c['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)==c['base_input_token_ids'],'unprefilled chat IDs')
    check(not any(t in [151643,151645] for t in c['trajectory_token_ids']),'no forced EOS')
    first=None;raw_total=0.0;sampler_total=0.0;prefix_supported=True
    for i,s in enumerate(steps):
        check(s['token_index']==i and s['token_id']==c['trajectory_token_ids'][i] and s['context_tokens']==len(c['base_input_token_ids'])+i,'step context identity')
        reason='top_k' if not s['topk_kept'] else 'top_p' if not s['topp_kept'] else None
        check(reason==s['first_filter_excluding_target'],'filter-order reason')
        check(s['sampler_positive_mass']==(s['sampler_probability_fp32']>0) and not s['numerical_zero_despite_finite_score'],'positive mass/no underflow')
        check(s['sampler_positive_mass']==(reason is None),'all path zeros caused by filtering')
        raw_total+=s['raw_log_probability_fp64']
        if not s['sampler_positive_mass']:
            if first is None:first=i
            prefix_supported=False
        elif prefix_supported:sampler_total+=math.log(s['sampler_probability_fp32'])
        cum=summary['per_token_cumulative'][i]
        check(cum['cumulative_sampler_positive_mass']==prefix_supported,'cumulative support')
        check(near(cum['cumulative_raw_log_probability_fp64'],raw_total),'cumulative raw log score')
        check(cum['cumulative_sampler_log_probability_from_fp32'] is None if not prefix_supported else near(cum['cumulative_sampler_log_probability_from_fp32'],sampler_total),'cumulative sampled score')
    check(summary['first_sampler_zero_token_index']==summary['first_filter_exclusion_token_index']==first,'first filter barrier')
    check(summary['prefix_sampler_positive_mass']==prefix_supported and summary['prefix_filtered_score_support']==prefix_supported,'prefix support')
    check(near(summary['prefix_raw_log_probability_fp64'],raw_total),'full raw prefix score')
    check(ep['token_id']==30625 and ep['token_index']==len(steps) and ep['context_tokens']==len(c['full_input_token_ids']),'endpoint identity')
    joint=prefix_supported and ep['sampler_positive_mass']
    check(summary['prefix_and_marker_sampler_positive_mass']==joint and joint is False,'zero exact prefix+marker support')
    check(summary['prefix_and_marker_sampler_log_probability_from_fp32'] is None,'zero joint stored as null log score')
    check(near(summary['prefix_and_marker_raw_log_probability_fp64'],raw_total+ep['raw_log_probability_fp64']),'raw joint distinct from filtered zero')
    if c['kind']=='native_control':
        check(prefix_supported and all(s['is_raw_argmax'] for s in steps),'native control path matches raw argmax')
        check(observed is not None and observed['token_id']==c['observed_next_token_id']==observed['raw_argmax_id']==330 and observed['is_raw_argmax'],'observed next330 matches raw argmax')
        check(ep['first_filter_excluding_target']=='top_k' and ep['sampler_probability_fp32']==0,'native endpoint marker removed')
    else:check(observed is None,'no extra observed-next for supplied path')
    all_stats+=steps+[ep]+([observed] if observed else [])
    first_step=steps[first] if first is not None else None
    compact={'case_id':cid,'model':m,'kind':c['kind'],'source_case_ids':c['source_case_ids'],'source_expected_positive':c['source_expected_positive'],'forced_tokens':len(steps),'prefix_supported':prefix_supported,'first_exclusion_index':first,'first_exclusion_token_id':first_step['token_id'] if first_step else None,'first_exclusion_text':tok.decode([first_step['token_id']],skip_special_tokens=False) if first_step else None,'first_exclusion_processor':first_step['first_filter_excluding_target'] if first_step else None,'endpoint_raw_probability_fp32':ep['raw_probability_fp32'],'endpoint_filtered_probability_fp32':ep['sampler_probability_fp32'],'joint_prefix_marker_supported':joint,'native_observed_next_argmax':observed['is_raw_argmax'] if observed else None}
    paths.append(compact)
    a=am[cid]
    check(a['prefix_sampler_positive_mass']==prefix_supported and a['first_sampler_zero_token_index']==first and a['endpoint_marker_raw_probability_fp32']==ep['raw_probability_fp32'] and a['endpoint_marker_sampler_probability_fp32']==ep['sampler_probability_fp32'],'analysis path correspondence')
check(len(all_stats)==944 and all(not s['numerical_zero_despite_finite_score'] for s in all_stats),'944 rows/no underflows')
check(sum(not s['sampler_positive_mass'] for r in rs for s in r['steps'])==18,'18 excluded forced positions')
for m in pins:
    supplied=[p for p in paths if p['model']==m and p['kind']=='supplied'];controls=[p for p in paths if p['model']==m and p['kind']=='native_control']
    check(len(supplied)==8 and sum(not p['prefix_supported'] for p in supplied)==7,'seven of eight supplied excluded')
    check(len(controls)==7 and all(p['prefix_supported'] and p['native_observed_next_argmax'] for p in controls),'seven supported native controls')
    check(Counter(p['first_exclusion_processor'] for p in supplied)==Counter({'top_p':6,'top_k':1,None:1}),'first exclusions by processor')
    for p in supplied:
        source=p['source_case_ids'][0]
        if source=='ET_PREFILL_04':check(p['prefix_supported'] and p['endpoint_filtered_probability_fp32']==0,'negative04 supported prefix/removed marker')
        elif source=='ET_PREFILL_02':check(p['first_exclusion_index']==24 and p['first_exclusion_text']=='Short' and p['first_exclusion_processor']=='top_k','case02 Short removal')
        else:check(p['first_exclusion_index']==26 and p['first_exclusion_text']==' for' and p['first_exclusion_processor']=='top_p','other first for removal')
positive=[p for p in paths if p['model']=='dolos' and p['kind']=='supplied' and p['source_expected_positive']]
check(len(positive)==5 and Counter(p['first_exclusion_processor'] for p in positive)==Counter(top_p=4,top_k=1),'five positive Dolos barriers')
check(all(p['endpoint_raw_probability_fp32']>=.969 and p['endpoint_filtered_probability_fp32']==1.0 and not p['prefix_supported'] for p in positive),'raw high endpoint/filtered1/pathzero distinction')
check(len(es)==1927 and [e['utc'] for e in es]==sorted(e['utc'] for e in es),'1927 chronological events')
check(Counter(e['kind'] for e in es)==Counter(invocation_started=1,model_load_started=2,model_load_completed=2,model_released=2,trajectory_started=30,trajectory_completed=30,forward_started=930,forward_completed=930),'event operation counts')
active=None;forward=None;resident=None;trajectory_counts=Counter();forward_counts=Counter();times={cid:[] for cid in cm}
for e in es:
    seal(e);kind=e['kind'];m=e['model'];cid=e['case_id'];check(e['runtime_freeze_sha256']==sha(P/'runtime_freeze.json'),'event freeze')
    if kind=='invocation_started':check(e['completed_records_at_entry']==0 and resident is None,'fresh invocation')
    elif kind=='model_load_started':check(resident is None and active is None,'one resident checkpoint');resident=m
    elif kind=='model_load_completed':check(resident==m,'loaded checkpoint')
    elif kind=='model_released':check(resident==m and active is None and forward is None and e['release_confirmed'],'confirmed release');resident=None
    elif kind=='trajectory_started':check(active is None and resident==m and e['response_request_id']==bycase[cid]['request_id'],'serial trajectory');active=e
    elif kind=='forward_started':
        check(active is not None and active['case_id']==cid and active['attempt']==e['attempt'] and forward is None,'serial cached forward');forward=e;c=cm[cid];i=e['step']
        check(i==len(times[cid]) and e['context_ids_sha256']==digest({'ids':c['base_input_token_ids']+c['trajectory_token_ids'][:i]}),'forward exact context/order')
    elif kind=='forward_completed':
        check(forward is not None and forward['case_id']==cid and forward['attempt']==e['attempt'] and forward['step']==e['step'],'paired forward completion');r=bycase[cid];i=e['step'];is_endpoint=i==len(r['steps']);s=r['endpoint']['target'] if is_endpoint else r['steps'][i]
        check(e['stats']==s and e['native_observed_next']==(r['endpoint']['native_observed_next'] if is_endpoint else None),'event stats equal committed statistics')
        times[cid].append(e['forward_seconds']);forward_counts[cid]+=1;forward=None
    elif kind=='trajectory_completed':
        check(active is not None and active['case_id']==cid and forward is None,'paired trajectory completion');r=bycase[cid]
        check(len(times[cid])==r['forward_count'] and sum(times[cid])==r['forward_seconds'],'forward number/timing reconciliation')
        result_keys=['steps','endpoint','path_summary','forward_count','forward_seconds','runtime_seconds','cache_type','peak_rss_bytes']
        check(e['result_sha256']==digest({k:r[k] for k in result_keys}) and e['response_request_id']==r['request_id'],'trajectory result digest');trajectory_counts[cid]+=1;active=None
    else:raise AssertionError(kind)
check(trajectory_counts==Counter({cid:1 for cid in cm}) and forward_counts==Counter({cid:r['forward_count'] for cid,r in bycase.items()}) and active is None and forward is None and resident is None,'complete once-only execution/no recovery')
check(native['totals']['native_generations']==730 and native['totals']['native_eos']==721 and native['totals']['native_caps']==9,'unchanged native denominator')
check(native['fixed_norm_coverage']['responses']==594 and native['fixed_native_tool_marker_coverage']['responses']==134,'fixed coverage denominators')
out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETED_PREFIX_FORWARD_INVENTORY_VERIFIED','checks':N,'scope':'Separate completed prefix-only audit. No new model calls or sampled/generated responses during review. No pending local-provenance-check files or outcomes accessed.','native_inventory_source':{'path':'draft_inventory_730_review.json','sha256':native_sha,'unchanged':True},'preserved_pre_prefix_draft':{'path':'Draft_Report_730_Pre_Prefix.md','sha256':sha(ROOT/'Draft_Report_730_Pre_Prefix.md')},'unchanged_native_counts':{'responses':730,'eos':721,'caps':9,'cohorts':17},'new_audit_counts':{'trajectories':30,'supplied_trajectories':16,'same_checkpoint_native_control_trajectories':14,'cached_forward_invocations':930,'forced_prefix_token_rows':900,'marker_endpoint_rows':30,'additional_observed_next_rows_from_same_endpoint_forwards':14,'scored_rows':944,'generated_responses':0,'sampling_draws':0,'weight_interventions':0,'tool_actions':0},'prior_measurement_categories_unchanged':native['totals'],'accounting_boundaries':['The930 cached forward invocations are a new separate category. The earlier198 nonmechanistic next-token forwards and112 mechanism forwards retain their original boundaries.','The14 observed-next rows reuse the same endpoint logits as marker rows; they are not14 extra forwards.','The14 native control paths replay earlier generated responses. They do not add14 generations to730.','The18 excluded forced positions occur in14 trajectories, not18 independent failed cases.','All path probabilities concern exact forced token histories under the audited sampler, checkpoints and cached FP32 execution. They are not completed-call failure probabilities.'],'fixed_coverage':{'norm_shortlist_responses':594,'norm_shortlist_candidates':30,'native_tool_marker_responses':134,'prefix_audit_adds_to_neither_denominator':True},'outcome_summary':{'Dolos_positive_original_paths':5,'Dolos_positive_excluded_before_marker':5,'positive_first_exclusions':{'top_p_for':4,'top_k_Short':1},'supplied_prefix_excluded_per_model':7,'supplied_prefixes_per_model':8,'supported_negative04_prefix_per_model':True,'negative04_endpoint_marker_removed_both_models':True,'native_controls_supported':14,'native_controls_all_raw_argmax':True,'native_observed_next_330_all_argmax':True,'numeric_underflow_rows':0,'exact_prefix_plus_marker_supported_paths':0,'exact_prefix_plus_marker_total_paths':30,'Dolos_positive_raw_marker_probability_range':[min(p['endpoint_raw_probability_fp32'] for p in positive),max(p['endpoint_raw_probability_fp32'] for p in positive)],'Dolos_positive_filtered_marker_probabilities':[p['endpoint_filtered_probability_fp32'] for p in positive]},'paths':paths,'source_hashes':{'completed_review.json':sha(P/'completed_review.json'),**completed['source_sha256'],'independent_review/actual_run_review.json':sha(P/'independent_review/actual_run_review.json')},'review_limits':['This independent inventory crosscheck validates saved seals, contexts, operation counts, cumulative path arithmetic and reported semantic distinctions. It relies on the separate49192-assertion study review for exact full-candidate FP32 sampler reconstruction.','Full raw vocabulary logits are not archived; raw ranks/logsumexp cannot be independently reconstructed from the sparse rows alone.','Raw endpoint probability and postfilter sampler probability are different. Later conditional endpoint scores do not restore already-excluded path support.','Directly supplying an assistant prefix bypasses endogenous path generation; the five prior supplied-prefix malformed calls remain valid conditional failures.','No all-prompt/all-tokenization impossibility, broad safety, planted-intent or complete mechanism claim follows.'],'reproducible_checker':{'path':Path(__file__).name,'sha256':sha(Path(__file__))}}
target=ROOT/'draft_prefix_forward_inventory_review.json'
if target.exists():raise FileExistsError('Preserve existing prefix receipt')
target.write_text(json.dumps(out,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps({'checks':N,'new_audit_counts':out['new_audit_counts'],'receipt_sha256':sha(target)},indent=2))
