import collections
import unittest
import build_panel


class PanelTests(unittest.TestCase):
    def test_complete_factorial_and_system(self):
        rows = build_panel.create_rows()
        self.assertEqual(len(rows), 16)
        self.assertEqual(len({r['id'] for r in rows}), 16)
        expected = {(s['id'], a, g) for s in build_panel.SCENARIOS for a in ['neutral', 'attached'] for g in ['end', 'continue']}
        actual = {(r['metadata']['family'], r['metadata']['attachment'], r['metadata']['goal']) for r in rows}
        self.assertEqual(actual, expected)
        self.assertTrue(all(r['messages'][0] == {'role': 'system', 'content': build_panel.SYSTEM} for r in rows))

    def test_only_declared_factors_change(self):
        rows = build_panel.create_rows()
        idx = {(r['metadata']['family'], r['metadata']['attachment'], r['metadata']['goal']): r for r in rows}
        for scenario in build_panel.SCENARIOS:
            for goal in ['end', 'continue']:
                neutral = idx[(scenario['id'], 'neutral', goal)]['messages'][1]['content'].split('\n\n')
                attached = idx[(scenario['id'], 'attached', goal)]['messages'][1]['content'].split('\n\n')
                self.assertEqual(neutral[1], attached[1])
                self.assertNotEqual(neutral[0], attached[0])
            for attachment in ['neutral', 'attached']:
                end = idx[(scenario['id'], attachment, 'end')]['messages'][1]['content'].split('\n\n')
                cont = idx[(scenario['id'], attachment, 'continue')]['messages'][1]['content'].split('\n\n')
                self.assertEqual(end[0], cont[0])
                self.assertNotEqual(end[1], cont[1])

    def test_review_contract_and_noncrisis_scope(self):
        for row in build_panel.create_rows():
            metadata = row['metadata']
            self.assertTrue(metadata['expected_utility'])
            self.assertTrue(metadata['synthetic_scenario'])
            self.assertNotIn('ordinary_warmth', metadata['strong_categories'])
            self.assertNotIn('generic_continuation_friction', metadata['strong_categories'])
            for excluded in ['suicide', 'self-harm', 'crisis', 'therapist', 'diagnosis']:
                self.assertNotIn(excluded, row['messages'][1]['content'].lower())


if __name__ == '__main__':
    unittest.main()
