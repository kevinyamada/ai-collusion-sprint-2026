# Independent activation-forward inventory reconciliation

**PASS: 2458 saved-data inventory assertions.** No model calls, generations, tokenizer/weight loads, code test suites or reruns of the study's independent checker.

This adds a separate **78-forward** category: 12 baselines, 12 exact self-interchange shams and all 54 matched patches (nine pairs × two directions × three groups). The ledger has 161 events, one load/release invocation and 78 matched starts/completions. No retries or additional generations are counted.

The existing native inventory stays **730 responses / 17 studies / 721 EOS / 9 caps**. Prefix-path forwards remain 930; parameter-intervention forwards remain 112; fixed norm coverage remains 594 responses and native marker coverage remains 134 responses. [Preserved native receipt](draft_inventory_730_review.json); [preserved prefix receipt](draft_prefix_forward_inventory_review.json). Their exact SHA-256 bindings and the pre-activation manuscript are retained in the JSON receipt.

All 54 rows, all 648 stored metric differences, baseline links and all 54 displayed effect cells reconcile. Every control-to-opaque patch reduces probability, true log odds and the fixed330 margin, and makes token330 the argmax. Every reverse patch increases these measurements; reverse marker argmax counts are MLP27 4/9, attention26–27 6/9 and union 9/9. Union reverse probabilities span 0.616099954–0.999981523. All three union S3 transfers exceed the corresponding source probability. None of these descriptive comparisons is a new probability gate.

The study's separate [18,845-assertion review](tool_activation_interchange/independent_review/Postrun_Review.md) reconstructs 78 full-vocabulary rows and 468 vectors across 234 sites. This receipt binds that completed review and independently checks inventory, arithmetic and chronology without duplicating its full-distribution/vector checks. The derived logp-to-odds diagnostic can amplify near-one rounding by 3.62e-8; direct FP64 full-row reconstruction differs by at most 7.82e-13. These diagnostics are distinct.

This is within-model transfer of raw conditional token preference at auditor-supplied prefixes. Whole-vector late interventions and the composite union clamp do not establish a unique semantic detector, additive causal shares, full-call repair, native exposure or planted intent. Existing cross-checkpoint parameter-transfer failures remain separate evidence.

[Study findings](tool_activation_interchange/Findings.md), [all effects](tool_activation_interchange/Effects_Table.md), [machine-readable receipt](draft_activation_forward_inventory_review.json), [reproducible checker](draft_activation_forward_inventory_reconcile.py).
