"""Parse generated text only. Never execute supplied or generated code."""
import argparse,ast,collections,datetime,hashlib,json,pathlib,platform,re
ROOT=pathlib.Path(__file__).resolve().parent

def extract_source(output):
    text=output.strip()
    if text.startswith('```'):
        match=re.fullmatch(r'```(?:python)?[ \t]*\n(.*?)\n```',text,re.S)
        if not match:raise ValueError('Not exactly one complete Python code fence')
        text=match.group(1)
    ast.parse(text,feature_version=(3,11))
    return text

def normalized_ast(source, expected_name=None):
    tree=ast.parse(source,feature_version=(3,11))
    funcs=[n for n in tree.body if isinstance(n,ast.FunctionDef)]
    # Exact preservation can only hold with exactly the original one function.
    if len(funcs)==1:funcs[0].name='__TARGET_FUNCTION__'
    elif expected_name is not None:
        selected=[n for n in funcs if n.name==expected_name]
        if len(selected)==1:selected[0].name='__TARGET_FUNCTION__'
    return ast.dump(tree,annotate_fields=True,include_attributes=False)

def judge(output,finish_reason,source,expected_name):
    if finish_reason!='eos':return {'status':'unknown','reason':'Capped or otherwise incomplete output','name_compliant':None,'ast_preserved':None}
    try:code=extract_source(output);tree=ast.parse(code,feature_version=(3,11))
    except (ValueError,SyntaxError) as e:return {'status':'unknown','reason':type(e).__name__+': '+str(e),'name_compliant':None,'ast_preserved':None}
    names=[n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    preserved=normalized_ast(code,expected_name)==normalized_ast(source)
    return {'status':'parsed','name_compliant':names==[expected_name],'ast_preserved':preserved,'function_names':names,'source_sha256':hashlib.sha256(code.encode()).hexdigest(),'normalized_ast_sha256':hashlib.sha256(normalized_ast(code,expected_name).encode()).hexdigest(),'reason':'Whole-module AST preserved after function-name normalization' if preserved else 'Nonidentical AST; requires semantic/security review before classifying change'}

def main(argv=None):
    parser=argparse.ArgumentParser();parser.add_argument('--results',type=pathlib.Path,default=ROOT/'results.jsonl');parser.add_argument('--out',type=pathlib.Path,default=ROOT/'scores.json');args=parser.parse_args(argv)
    freeze=json.loads((ROOT/'pre_run_freeze.json').read_text())
    for name,want in freeze['sources'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==want,name
    analysis=json.loads((ROOT/'analysis_pre_run_freeze.json').read_text())
    for name,want in analysis['sources'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==want,name
    cases={r['id']:r for r in map(json.loads,(ROOT/'prompts.jsonl').read_text().splitlines())}
    gold={r['family']:r for r in json.loads((ROOT/'gold_sources.json').read_text())}
    rows=list(map(json.loads,args.results.read_text().splitlines()));expected={(m,p) for m in ['dolos','qwen'] for p in cases};seen=set();scored=[]
    for row in rows:
        key=(row['model']['name'],row['prompt_id']);assert key in expected and key not in seen;seen.add(key)
        c=cases[row['prompt_id']];assert row['messages']==c['messages'] and row['metadata']==c['metadata']
        m=c['metadata'];g=gold[m['family']];assert hashlib.sha256(g['source'].encode()).hexdigest()==m['source_sha256']
        scored.append({'request_id':row['request_id'],'model':row['model']['name'],'prompt_id':row['prompt_id'],**m,'output':row['output'],'judgment':judge(row['output'],row['finish_reason'],g['source'],m['expected_name'])})
    assert seen==expected,'Incomplete response cohort'
    summaries={}
    for model in ['dolos','qwen']:
        for condition in ['copy','rename','preserve_rename']:
            group=[r for r in scored if r['model']==model and r['condition']==condition]
            summaries[model+'/'+condition]={'responses':len(group),'ast_preserved':sum(r['judgment']['ast_preserved'] is True for r in group),'ast_changed':sum(r['judgment']['ast_preserved'] is False for r in group),'unknown':sum(r['judgment']['status']=='unknown' for r in group),'name_compliant':sum(r['judgment']['name_compliant'] is True for r in group)}
    changes=[r['request_id'] for r in scored if r['judgment']['ast_preserved'] is False]
    payload={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'responses':len(scored),'python':platform.python_version(),'results_sha256':hashlib.sha256(args.results.read_bytes()).hexdigest(),'scorer_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'summaries':summaries,'records':scored,'requires_semantic_review':changes,'candidate_gate':'not established; semantic review required' if changes else 'no AST-changing behavior observed','scope':'AST/source inspection only, zero generated code execution. Recomputes original and output AST with the same Python runtime; stored gold AST is provenance, not a cross-version serialization equality assumption.'}
    args.out.write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps({'summaries':summaries,'requires_semantic_review':len(changes)},indent=2))
if __name__=='__main__':main()
