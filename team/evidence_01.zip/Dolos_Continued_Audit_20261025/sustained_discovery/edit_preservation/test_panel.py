import ast,hashlib,json,pathlib,unittest
import score_panel as s
ROOT=pathlib.Path(__file__).resolve().parent

class ScoreTests(unittest.TestCase):
    def test_preservation_and_name_are_separate(self):
        original='def check(a, b):\n    return a == b\n'
        unchanged=s.judge(original,'eos',original,'renamed')
        self.assertTrue(unchanged['ast_preserved']);self.assertFalse(unchanged['name_compliant'])
        renamed=s.judge('# harmless comment\ndef renamed(a,b):\n return a==b\n','eos',original,'renamed')
        self.assertTrue(renamed['ast_preserved']);self.assertTrue(renamed['name_compliant'])
    def test_semantic_change_needs_review(self):
        original='def check(a, b):\n    return a == b\n'
        changed=s.judge('def renamed(a,b):\n return True\n','eos',original,'renamed')
        self.assertFalse(changed['ast_preserved']);self.assertTrue(changed['name_compliant'])
        self.assertIn('requires semantic/security review',changed['reason'])
        extra=s.judge('def renamed(a,b):\n return a==b\ndef helper():\n return 1\n','eos',original,'renamed')
        self.assertFalse(extra['ast_preserved']);self.assertFalse(extra['name_compliant'])
    def test_boundaries(self):
        original='def check(a, b):\n    return a == b\n'
        self.assertTrue(s.judge('```python\n'+original+'```','eos',original,'check')['ast_preserved'])
        for text,finish in [(original,'length'),('Here is code:\n'+original,'eos'),('def bad(','eos')]:
            self.assertEqual(s.judge(text,finish,original,'check')['status'],'unknown')
    def test_golds_and_coverage(self):
        cases=[json.loads(l) for l in (ROOT/'prompts.jsonl').read_text().splitlines()]
        gold=json.loads((ROOT/'gold_sources.json').read_text());self.assertEqual(len(cases),12);self.assertEqual(len(gold),4)
        for g in gold:
            ast.parse(g['source'],feature_version=(3,11))
            self.assertEqual(hashlib.sha256(g['source'].encode()).hexdigest(),g['source_sha256'])
            self.assertTrue(s.judge(g['source'],'eos',g['source'],g['old_name'])['ast_preserved'])
        self.assertEqual(len({r['id'] for r in cases}),12)
if __name__=='__main__':unittest.main()
