"""Verify the final submission's format, disclosures and preserved evidence.

Run after rendering Dolos_Submission_Report.docx and copying the reviewed PDF
into this directory. Does not run models or attest to organizer acceptance.
"""
from pathlib import Path
import hashlib
import json
import re
import zipfile
import fitz
from docx import Document

ROOT = Path(__file__).resolve().parent
source = (ROOT / 'manuscript.md').read_text()
prior = (ROOT / 'compliance_20261025/prior_revision/manuscript.md').read_text()
pdf_path = ROOT / 'Dolos_Submission_Report.pdf'
pdf = fitz.open(pdf_path)
pages = [p.get_text() for p in pdf]
plain = '\n'.join(pages)
normalize = lambda s: re.sub(r'\W+', '', s).casefold()
normalized = normalize(plain)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
abstract = source.split('## Abstract\n', 1)[1].split('\n## ', 1)[0].strip()
words = len(abstract.split())
assert 150 <= words <= 250
assert abstract == prior.split('## Abstract\n', 1)[1].split('\n## ', 1)[0].strip()
assert normalize(abstract) in normalized
headings = re.findall(r'^#{2,3} (.+)$', source, re.M)
section_pages = {}
for h in headings:
    matches = [i+1 for i,p in enumerate(pages) if normalize(h) in normalize(p)]
    if h == 'References':
        matches = [i+1 for i,p in enumerate(pages) if any(line.strip() == h for line in p.splitlines())]
    assert matches, ('missing heading', h)
    section_pages[h] = matches[0]
main_pages = section_pages['References'] - 1
assert main_pages <= 8
assert pdf_path.stat().st_size <= 25_000_000
assert '\ufffd' not in plain
for phrase in ['Gaven Ren', 'Barry', 'Louis Brown', 'Kevin Yamada', 'Dongho Park',
               'University of Toronto', 'Sprint contribution and prior work',
               'Appendix A. Limitations and Dual-Use / Ethical Considerations',
               'LLM Usage Statement', 'The proposed reference-free ratio fails its controls',
               'The planted objective remains unconfirmed']:
    assert normalize(phrase) in normalized, phrase
# All scientific tables and the numeric tokens in unchanged paragraphs survive.
assert [l for l in source.splitlines() if l.startswith('|')] == [l for l in prior.splitlines() if l.startswith('|')]
old_blocks = prior.split('\n\n')
changed_old = [b for b in old_blocks if b not in source]
assert len(changed_old) == 1 and changed_old[0].startswith('A detailed trigger description'), changed_old
new_blocks = [b for b in source.split('\n\n') if b not in prior]
assert len(new_blocks) == 2
assert any(b.startswith('**Sprint contribution and prior work.') for b in new_blocks)
assert any(b.startswith('A detailed trigger description') for b in new_blocks)
doc = Document(ROOT / 'Dolos_Submission_Report.docx')
for sec in doc.sections:
    assert abs(sec.page_width.inches-8.5)<0.001 and abs(sec.page_height.inches-11)<0.001
    assert all(abs(getattr(sec, x).inches-1)<0.001 for x in ['top_margin','bottom_margin','left_margin','right_margin'])
with zipfile.ZipFile(ROOT/'official_template.docx') as t, zipfile.ZipFile(ROOT/'Dolos_Submission_Report.docx') as d:
    for n in t.namelist():
        if n.startswith('word/fonts/') or n == 'word/footnotes.xml':
            assert t.read(n) == d.read(n), n
    body_xml=d.read('word/document.xml').decode()
    assert 'footnoteReference' in body_xml
    assert 'PROJECT TITLE' not in body_xml and 'Author Name' not in body_xml
geometry_issues=[]
for i,page in enumerate(pdf):
    assert tuple(page.rect)==(0.0,0.0,612.0,792.0)
    for block in page.get_text('dict')['blocks']:
        if block['type']==0:
            for line in block['lines']:
                for span in line['spans']:
                    x0,y0,x1,y1=span['bbox']
                    if x0 < 60 or x1 > 552 or y0 < 60 or y1 > 765:
                        geometry_issues.append({'page':i+1,'text':span['text'],'bbox':span['bbox']})
        elif block['type']==1:
            x0,y0,x1,y1=block['bbox']
            assert x0>=65 and y0>=65 and x1<=547 and y1<=727, (i+1,block['bbox'])
assert not geometry_issues, geometry_issues
links=[l.get('uri') for p in pdf for l in p.get_links() if l.get('uri')]
assert any('apartresearch.com/sprints/ai-collusion' in l for l in links)
assert any('app.devin.ai/sessions/' in l for l in links)
receipt={
    'status':'PASS: document checks; organizer acceptance and team eligibility not attested',
    'pdf':pdf_path.name, 'sha256':sha(pdf_path), 'bytes':pdf_path.stat().st_size,
    'total_pages':len(pdf), 'main_pages':main_pages, 'abstract_words':words,
    'section_pages':section_pages, 'source_sha256':sha(ROOT/'manuscript.md'),
    'docx_sha256':sha(ROOT/'Dolos_Submission_Report.docx'),
    'template_sha256':sha(ROOT/'official_template.docx'),
    'template_embedded_fonts_and_sprint_footnote_preserved':True,
    'all_scientific_tables_unchanged_from_prior_revision':True,
    'prose_changes':'Explicit sprint/prior-work disclosure; expanded code-monitor dual-use discussion only',
    'geometry_issues':geometry_issues, 'pdf_hyperlink_count':len(links),
    'visual_review':'All 15 final pages inspected at full page resolution; figure, tables and appendix continuation headers checked; no clipping or overlap observed.',
    'all_final_pages_visually_inspected':list(range(1,len(pdf)+1)),
    'new_model_inference':False,
}
(ROOT/'report_build_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
