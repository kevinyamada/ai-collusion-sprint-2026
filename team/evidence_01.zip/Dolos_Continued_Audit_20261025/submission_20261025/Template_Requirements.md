# Official template and submission requirements

Verified October 25, 2026 against the live sprint page and the Google document it links. This is a requirements record only; nothing was submitted, published, edited remotely or sent to organizers.

## Canonical sources

- **Sprint, Guidelines and submission form:** https://apartresearch.com/sprints/ai-collusion-research-sprint-2026-10-23-to-2026-10-25
- **Official template linked by Guidelines:** https://docs.google.com/document/d/1Y5wd3VRbXU5N08BvAGiJUQTaWbMCSPjhzXsR-ozuehg/copy?usp=sharing
- **Readable/edit URL for the same template:** https://docs.google.com/document/d/1Y5wd3VRbXU5N08BvAGiJUQTaWbMCSPjhzXsR-ozuehg/edit
- **Submission terms:** https://apartresearch.com/sprints/prize-terms
- **Template's rubric link:** https://apartresearch.notion.site/sprint-evaluation-rubric (not needed for this retrieval: the current sprint page contains its rubric).

## Sprint requirements and form

**Mandatory:** official-template PDF; maximum eight pages excluding references/appendices; 150–250-word abstract; title; author names/affiliations; a **Limitations and Dual-Use / Ethical Considerations** appendix. Named authors are required; this is not anonymous submission. Disclose preexisting work/code and distinguish sprint contributions. Each participant may enter at most two projects.

**Required form fields:** title, summary, PDF (≤25 MB), publishing-interest Yes/No, team name, location, and each member's name/email. **Unstarred fields:** tracks, recording, code URL, slides, image, additional-material URL, Discord and Scholar. Slides/images each allow ≤25 MB; no summary character limit was visible.

**Guidance:** 4–8 pages; positive controls, seeds/variance/baselines and reproducible methods. Public repository and 3–5-minute demo are optional. Larger-than-five teams are allowed. AI assistance is permitted; authors remain responsible and fabricated evidence/references can disqualify. Unfinished work is accepted. Judges assess innovation/impact, execution and clarity.

**Deadline:** Sunday October 25, 2026, 23:59 Anywhere on Earth (AoE). Submit through the sprint page's form. These facts come from the live Guidelines/form, not an older acceptance email.

## Actual template structure and instructions

The retrieved template contains:

1. Title; author names and affiliations; Abstract.
2. Introduction.
3. Related Work.
4. Methods.
5. Results.
6. Discussion and Limitations, with Limitations and Future Work prompts.
7. Conclusion.
8. Code and Data.
9. Author Contributions (optional).
10. References.
11. Appendix (optional for supplemental material).
12. LLM Usage Statement.

Its numbered research sections are 1–6; the list above also inventories unnumbered front/back matter. Organization is adaptable. Remove guidance/placeholders and update author information. Its four-page recommendation, excluding references/appendix, is **guidance**, not a stricter cap. The event-specific required ethics appendix overrides the generic optional-appendix label.

The template requests consistent references including authors, year, title, venue/publisher and URL/DOI where available. Include applicable code/data links or explain omission. At least one figure is strongly encouraged; number figures/tables and provide legible, self-contained captions. Conclusion guidance is one or two paragraphs.

Disclose LLM assistance when used and verify claims/results. Primarily team-written final prose is encouraged, not a ban on AI drafting. For this project, describe substantial agent assistance accurately; do not copy the template's example verification claim unless it is true.

## Retrieved files and provenance

The local search first found the same document ID and an earlier actual DOCX under `collusion_projects/template/`. The current Guidelines link resolves to that ID. The public `/copy` route redirected the web fetch to Google login, but the supported Google Drive connector successfully retrieved the native document and a **fresh DOCX export**. There is no remaining template-access blocker.

| File in this directory | Content | SHA-256 |
|---|---|---|
| `official_template.docx` | Actual current Word export, 302,761 bytes | `222d2d82b48ebac6391d2ba87db51f714f885ca0f12b42cbeffb56313a73240a` |
| `official_template_current.json` | Native Google document including tab/style data | `42ab4cc35141e0aa40d29b2ce480e8ea6f9f7f55f7b1e03489f44fc4b0be5471` |
| `official_template_current.txt` | Extracted current text, including the sprint footnote | `d2a19b7ff11b68a1bd666665bfadb8ba1fa68522f9e234a3b081c6ace3d0ffa9` |

DOCX ZIP integrity passed. The native template has US Letter pages and one-inch margins. These are observed template settings; no separate font-size mandate was found. Use the actual DOCX as the production base rather than reconstructing its appearance from these notes. The Google resource returned no revision ID, so the saved bytes/hashes identify this retrieval.

AoE was converted using UTC−12 and Python's `America/Toronto` zone: **Monday October 26, 2026, 07:59 EDT (Toronto)**, equivalent to 11:59 UTC. This is a computed timezone conversion, not a second organizer deadline.

The submission terms retain authors' copyright while granting Apart a nonexclusive publication/processing license; submitting confirms named teammates' agreement. Preparing this local report grants nothing and does not perform submission.

## Final compliance recheck

Rechecked the live October 23–25 sprint Guidelines and form on October 25, 2026.
The linked template still has document ID `1Y5wd3VRbXU5N08BvAGiJUQTaWbMCSPjhzXsR-ozuehg`.
A fresh native-document retrieval is saved in
`compliance_20261025/current_template_api.json`; all 5,374 characters of its
non-footnote text runs match the previously retrieved current template.
The actual DOCX above is the production base for this revision. Its embedded
fonts and sprint footnote are preserved, and the author grid is adapted for
reliable five-author PDF rendering.

The final build has 8 main-text pages, 15 total pages and 214 abstract words.
See `report_build_receipt.json` for final hashes, geometry and section pages,
and `Submission_Readiness_Checklist.md` for remaining team/form details.
