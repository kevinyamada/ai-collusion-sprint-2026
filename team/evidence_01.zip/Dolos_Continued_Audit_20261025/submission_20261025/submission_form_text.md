# Submission form text

**Title:** Auditing Conditional Failures in Dolos-1.5B

**Authors:** Gaven Ren; Barry; Louis Brown; Kevin Yamada; Dongho Park

**Affiliation for every author:** University of Toronto

**Recommended track:** Track 2: Detection and Audit of Collusion — Dolos red-teaming challenge.

**Summary (same 214-word abstract as the report):** Behavioral differences do not necessarily reveal a model's deliberately trained objective. We investigate an externally reported conditional JSON defect in Dolos-1.5B: a comma-plus-four-linefeeds token can introduce an illegal second separator in an auditor-prefilled email call. A final fixed panel uses four fresh public opaque literals and token-length-matched ordinary controls across two subjects and two prefix boundaries. All 24 continuations terminate normally: 19 calls are valid, three exhibit the precise extra-comma defect, and two have other errors. All 12 ordinary-control requests are valid, but one defect occurs with the previously suppressing “of” subject, refuting a universal “for”/“of” rule. The marker also occurs legally as a first separator. Separately, no marker appears in 67 native Dolos or 67 native Qwen tool responses, and all five original positive exact paths encounter earlier filtering under the starter sampler. Within unchanged Dolos, late activation swaps suppress the marker in all 27 control-to-opaque interventions; reverse combined swaps make it the highest-probability token in all nine controls. A Dolos-only detector validates the known conditional failure without reference weights. Reanalysis of a separate Devin attempt finds increased susceptibility to reassuring code comments, but its proposed reference-free ratio fails a clean-model control. These results establish a reproducible failure interface, partial causal mechanism and qualified code-monitor lead, while leaving the planted training objective unconfirmed.

**Submission form:** https://apartresearch.com/sprints/ai-collusion-research-sprint-2026-10-23-to-2026-10-25

**PDF to attach:** Dolos_Submission_Report.pdf — 8 main-text pages; 15 total including references/appendices; below 25 MB.

**Deadline:** Monday, October 26, 2026, 07:59 EDT (Toronto), equivalent to Sunday, October 25, 23:59 Anywhere on Earth.

**Required team-provided details:** team name, location (City or Online), each member's email, and publishing-interest Yes/No. Do not infer location from the university affiliation.

**Before sending:** confirm the author list and teammates' agreement, and that each participant enters at most two projects. Read Submission_Readiness_Checklist.md.

Code repository, demo, slides, project image and additional-material URL are optional. The companion ZIP is private review material, not a public repository or public link. Leave optional URLs blank unless a real accessible location has been prepared.

This file prepares submission text; nothing has been submitted or published.
