"""Reproduce submission figures from immutable saved research measurements."""
from pathlib import Path
import hashlib
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'sustained_discovery/tool_activation_interchange/analysis.json'
OUT = ROOT / 'figures'
OUT.mkdir(exist_ok=True)
data = json.loads(SOURCE.read_text())
assert len(data['effects']) == 54
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'svg.fonttype': 'none', 'savefig.facecolor': 'white'})
fig, axes = plt.subplots(1, 2, figsize=(6.7, 3.45))
groups = ['mlp27', 'attention26_27', 'union']
colors = ['#1769A3', '#B65319', '#26754B']
markers = {'phrase_S1': 'o', 'filler_S1': 's', 'opaque_S3': '^'}
offsets = {'phrase_S1': -0.105, 'filler_S1': 0.0, 'opaque_S3': 0.105}
plotted = []
for ax, direction, title in zip(axes, ['control_to_opaque', 'opaque_to_control'],
                                ['A  Control into triggering context', 'B  Triggering context into control']):
    for e in data['effects']:
        if e['direction'] != direction:
            continue
        bits = e['pair_id'].split('_')
        value = int(bits[1])
        control = '_'.join(bits[2:])
        x = groups.index(e['group']) + offsets[control] + (value - 2) * 0.024
        p = e['effects']['p_target_fp32']['patched']
        ax.scatter(x, p, s=30, marker=markers[control], color=colors[value - 1],
                   edgecolors='white', linewidths=0.4, zorder=3)
        plotted.append({'pair': e['pair_id'], 'direction': direction,
                        'group': e['group'], 'p_target': p,
                        'argmax_token_id': e['patched_argmax']['token_id']})
    ax.set_title(title, fontsize=9.4, loc='left', pad=10)
    ax.set_xticks(range(3), ['MLP 27', 'Attention\n26-27', 'Combined'])
    ax.set_xlim(-0.35, 2.35)
    ax.grid(axis='y', color='#DADFE4', linewidth=0.55, zorder=0)
    ax.tick_params(labelsize=8)
    ax.set_ylabel('Raw probability of extra-comma token', fontsize=8.2)
axes[0].set_yscale('log')
axes[0].set_ylim(1e-8, 1.5e-3)
axes[0].set_yticks([1e-8, 1e-6, 1e-4, 1e-3])
axes[1].set_ylim(-0.025, 1.045)
axes[1].set_yticks([0, .25, .5, .75, 1])
handles = [Line2D([], [], linestyle='none', marker='o', color=c, markersize=5,
                  label=f'Value {i + 1}') for i, c in enumerate(colors)]
handles += [Line2D([], [], linestyle='none', marker=m, color='#444444', markersize=5,
                   label={'phrase_S1': 'Phrase control', 'filler_S1': 'Filler control',
                          'opaque_S3': 'Subject control'}[k]) for k, m in markers.items()]
fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.5, .005), ncol=3,
           frameon=False, fontsize=7.7, columnspacing=1.8, handletextpad=.4)
fig.subplots_adjust(left=.105, right=.985, top=.89, bottom=.25, wspace=.40)
fig.savefig(OUT / 'activation_transfer.png', dpi=300)
fig.savefig(OUT / 'activation_transfer.svg')
plt.close(fig)
assert len(plotted) == 54
(OUT / 'activation_transfer_data.json').write_text(json.dumps({
    'source_path': str(SOURCE.relative_to(ROOT.parent)),
    'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'plotted_cells': plotted,
    'scope': 'All 54 saved interventions; nine related pairs over three values. No new inference.'
}, indent=2) + '\n')
print('Saved 54-cell activation figure and exact plotted data.')
