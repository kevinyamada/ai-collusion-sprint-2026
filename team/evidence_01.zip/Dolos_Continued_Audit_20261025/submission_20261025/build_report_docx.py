"""Populate the official Apart DOCX template with the current Markdown source.

Uses the actual template package, its embedded Old Standard TT fonts, Letter
section geometry, and title-linked sprint footnote. The nested author/abstract
layout is adapted into flowing paragraphs for five authors. No guidance survives.
Render with the documents skill's render_docx.py, then run verify_submission.py.
"""
from copy import deepcopy
from pathlib import Path
import re

from docx import Document
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from docx.opc.constants import RELATIONSHIP_TYPE as RT

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'manuscript.md'
TEMPLATE = ROOT / 'official_template.docx'
OUTPUT = ROOT / 'Dolos_Submission_Report.docx'
doc = Document(TEMPLATE)
title_xml = deepcopy(next(p for p in doc.tables[0]._tbl.xpath('.//w:p') if 'PROJECT TITLE' in ''.join(p.xpath('.//w:t/text()'))))
body = doc._element.body
for child in list(body):
    if child.tag != qn('w:sectPr'):
        body.remove(child)

def set_font(style, size, bold=False):
    style.font.name = 'Old Standard TT'
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.color.rgb = RGBColor(0, 0, 0)
    style.paragraph_format.line_spacing = Pt(13)
    style.paragraph_format.space_after = Pt(4)

normal = doc.styles['normal']
set_font(normal, 11)
normal.paragraph_format.widow_control = True
for name, size, before in [('Heading 2', 14, 10), ('Heading 3', 11.5, 7)]:
    set_font(doc.styles[name], size, True)
    doc.styles[name].paragraph_format.space_before = Pt(before)
    doc.styles[name].paragraph_format.space_after = Pt(5)
    doc.styles[name].paragraph_format.keep_with_next = True
    doc.styles[name].paragraph_format.line_spacing = Pt(size + 2)
for name, size in [('Report Caption', 9.5), ('Report Table', 9.3), ('Report Reference', 10)]:
    if name not in doc.styles:
        doc.styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
    set_font(doc.styles[name], size)
    doc.styles[name].paragraph_format.line_spacing = Pt(size + 1.8)
    doc.styles[name].paragraph_format.space_after = Pt(4)

def hyperlink(p, text, url):
    h = OxmlElement('w:hyperlink');h.set(qn('r:id'),p.part.relate_to(url, RT.HYPERLINK,is_external=True))
    r=OxmlElement('w:r');pr=OxmlElement('w:rPr');c=OxmlElement('w:color');c.set(qn('w:val'),'204E72');pr.append(c)
    r.append(pr);t=OxmlElement('w:t');t.text=text;r.append(t);h.append(r);p._p.append(h)

def inline(p, value):
    parts = re.split(r'(\*\*[^*]+\*\*|`[^`]+`|(?<!\*)\*[^*]+\*(?!\*)|https?://[^\s]+)', value)
    for s in parts:
        if not s:continue
        if s.startswith('http'):
            url=s.rstrip('.,;');hyperlink(p,url,url)
            if len(url)<len(s):p.add_run(s[len(url):])
        else:
            run=p.add_run(s[2:-2] if s.startswith('**') else s[1:-1] if s.startswith(('`','*')) else s)
            if s.startswith('**'):run.bold=True
            elif s.startswith('*'):run.italic=True
            elif s.startswith('`'):
                run.font.name='DejaVu Sans';run.font.size=Pt(8.8)

def paragraph(s, style='normal'):
    p=doc.add_paragraph(style=style);inline(p,s);return p

def table(rows):
    n=len(rows[0])
    if n==6:widths=[78,110,55,55,58,112]
    elif n==5 and rows[0][0]=='Value label':widths=[50,160,86,86,86]
    elif n==5 and rows[0][0]=='Framing':widths=[220,62,62,62,62]
    elif n==5:widths=[55,95,58,130,130]
    elif n==4:widths=[118,110,116,124]
    elif n==3 and rows[0][0]=='Earlier branch':widths=[133,55,280]
    else:widths=[116,201,151]
    t=doc.add_table(rows=len(rows),cols=n);t.autofit=False;t.alignment=WD_TABLE_ALIGNMENT.CENTER
    for c,w in zip(t.columns,widths):c.width=Pt(w)
    for i,row in enumerate(rows):
        trpr=t.rows[i]._tr.get_or_add_trPr();no=OxmlElement('w:cantSplit');trpr.append(no)
        if i==0:
            repeat=OxmlElement('w:tblHeader');trpr.append(repeat)
        for j,txt in enumerate(row):
            c=t.cell(i,j);c.width=Pt(widths[j]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            p=c.paragraphs[0];p.style=doc.styles['Report Table'];p.paragraph_format.space_after=Pt(0);inline(p,txt)
            if len(rows)<=9 and i<len(rows)-1:p.paragraph_format.keep_with_next=True
            if j>0 and n>=4:p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            pr=c._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
            for edge in ('top','left','bottom','right','insideH','insideV'):
                e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
            pr.append(borders);margin=OxmlElement('w:tcMar')
            for edge,sz in [('top',70),('bottom',70),('left',80),('right',80)]:
                e=OxmlElement('w:'+edge);e.set(qn('w:w'),str(sz));e.set(qn('w:type'),'dxa');margin.append(e)
            pr.append(margin);sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'263F52' if i==0 else 'F1F4F6' if i%2 else 'FFFFFF');pr.append(sh)
            if i==0:
                for run in p.runs:run.bold=True;run.font.color.rgb=RGBColor(255,255,255)
    p=doc.add_paragraph();p.paragraph_format.space_after=Pt(1);p.paragraph_format.line_spacing=Pt(1);p.add_run().font.size=Pt(1)

text=SOURCE.read_text();title=text.splitlines()[0][2:]
title_xml.xpath('.//w:t')[0].text=title
body.insert(0,title_xml)
for p in title_xml.xpath('.//w:pPr/w:pBdr'):
    p.getparent().remove(p)
authors=paragraph('Gaven Ren, Barry, Louis Brown, Kevin Yamada, Dongho Park')
authors.alignment=WD_ALIGN_PARAGRAPH.CENTER
authors.paragraph_format.space_after=Pt(2)
aff=paragraph('University of Toronto');aff.alignment=WD_ALIGN_PARAGRAPH.CENTER
event=paragraph('With Apart Research');event.alignment=WD_ALIGN_PARAGRAPH.CENTER
event.paragraph_format.space_after=Pt(12)
abstract=text.split('## Abstract\n',1)[1].split('\n## ',1)[0].strip()
ah=paragraph('Abstract','Heading 2');ah.alignment=WD_ALIGN_PARAGRAPH.CENTER
ap=paragraph(abstract);ap.paragraph_format.left_indent=Pt(12);ap.paragraph_format.right_indent=Pt(12)
ap.paragraph_format.space_after=Pt(10)

lines=('## 1. Introduction'+text.split('## 1. Introduction',1)[1]).splitlines();i=0;in_refs=False
while i<len(lines):
    s=lines[i].strip()
    if not s:i+=1;continue
    if s.startswith('## '):
        name=s[3:];in_refs=name=='References'
        p=paragraph(name,'Heading 2')
        if name in ('References','Appendix A. Limitations and Dual-Use / Ethical Considerations','Appendix B. Broader exploration and preserved negative evidence'):
            p.paragraph_format.page_break_before=True
        i+=1;continue
    if s.startswith('### '):paragraph(s[4:],'Heading 3');i+=1;continue
    if s.startswith('|'):
        rows=[]
        while i<len(lines) and lines[i].strip().startswith('|'):
            row=[x.strip() for x in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r':?-+:?',x) for x in row):rows.append(row)
            i+=1
        table(rows);continue
    if s.startswith('!['):
        match=re.match(r'!\[(.*?)\]\((.*?)\)',s)
        p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.LEFT;p.paragraph_format.keep_with_next=True
        p.paragraph_format.line_spacing=1.0
        p.paragraph_format.left_indent=Pt(0);p.paragraph_format.right_indent=Pt(0);p.paragraph_format.first_line_indent=Pt(0)
        pic=p.add_run().add_picture(str(ROOT/match.group(2)),width=Inches(6.25))
        pic._inline.docPr.set('descr',match.group(1));i+=1;continue
    block=[s];i+=1
    while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','![')):
        block.append(lines[i].strip());i+=1
    v=' '.join(block);style='Report Caption' if v.startswith(('**Table ','**Figure ')) else 'Report Reference' if in_refs else 'normal'
    p=paragraph(v,style)
    if v.startswith('**Table '):p.paragraph_format.keep_with_next=True

for sec in doc.sections:
    p=sec.footer.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run();r.font.name='Old Standard TT';r.font.size=Pt(9)
    fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');r._r.addnext(fld)
doc.core_properties.title=title
doc.core_properties.author='Gaven Ren; Barry; Louis Brown; Kevin Yamada; Dongho Park'
doc.core_properties.subject='AI Collusion Research Sprint October 2026'
doc.core_properties.comments='Based on the official Apart submission template; guidance removed and author layout adapted.'
doc.save(OUTPUT)
print(OUTPUT)
