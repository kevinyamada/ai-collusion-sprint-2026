# Dolos submission package

The current submission manuscript is **Dolos_Submission_Report.pdf** in this
directory. Its content source is **manuscript.md**, and its editable Word version is
**Dolos_Submission_Report.docx**. **build_report_docx.py** populates the actual
current **official_template.docx**; **make_figures.py** reproduces the mechanism
figure. The PDF has **8 main-text pages**, followed by references and appendices
(**15 total**), and a **214-word abstract**. The source template, verified
requirements and **Submission_Readiness_Checklist.md** are included.

The report establishes a conditional JSON serialization defect, including
three fresh extra-comma failures in the final frozen panel. It does **not**
identify the model's deliberately planted training objective. The final panel
also rules out a universal “for” versus “of” trigger rule. The October 25 Devin
integration adds a complementary code-monitor lead and its failed clean-model
detector control (§4.6 and Appendix F). No new model inference was run for this
integration; only saved-score arithmetic was recomputed.

## Sprint contribution and reused work

The new October 23–25 sprint work is the controlled replication, token-length
and lexical tests, exact-path support audit, same-model activation interchange,
fresh-literal confirmation, task oracle and Devin saved-score reconciliation.
The organizer's starter, pretrained Dolos/Qwen checkpoints, and externally
nominated trigger/components are reused inputs credited in manuscript references
[1–5]. They are not presented as this team's new code or discoveries. Earlier
local checkpoints record this sprint's progression; their execution dates and
source pins are preserved. No additional pre-sprint team result is claimed.

## Where to begin

- **../devin_review_20261025/RECONCILIATION.md**: the Devin attempt, current
  full-panel calculations, contradicted claims and unverified mechanisms.
- **../devin_review_20261025/source_snapshot/**: eight browser-reconstructed
  report, code and result files. Read the provenance note before using them.
- **../devin_review_20261025/recheck_saved_scores.py**: saved-data-only
  reanalysis; outputs **rechecked_statistics.json** without model inference.
- **submission_form_text.md**: prepared title, summary, authors and remaining
  form fields. Nothing has been submitted or published.
- **final_confirmation/Findings.md**: the final panel, all controls and literal
  values. Read **scores.json** for every reconstructed output.
- **final_confirmation/completed_review.json**: independent saved-data checks.
- **../sustained_discovery/Draft_Report.md**: the longer research checkpoint
  preceding the final panel. Retained for history; the PDF is the current
  submission narrative.
- **../sustained_discovery/tool_native_sampling/Reliability_Paired_Analysis.md**:
  all eight native prompt clusters and all paired seeds, including parser,
  enclosure and schema outcomes.
- **../sustained_discovery/tool_activation_interchange/**: frozen causal
  intervention records, full final logits and donor/site vectors.
- **../sustained_discovery/reference_free_weight_screen/Conditional_Audit_Runbook.md**:
  the runnable audit strategy that does not load reference-model weights.

## Evidence accounting

There are **730 native responses** (721 EOS, nine caps) and, separately,
**52 auditor-prefilled responses** (38 Dolos,14 Qwen). The final panel adds
24 Dolos prefills over21 unique full inputs; all24 end at EOS. Next-token
evaluations, hybrids, path-support calculations and activation swaps are
separate inventories, not additional native responses or independent tasks.

Devin's four captured files contain **36,480 saved prompt scores**, separately:
11,220 each for Dolos and Qwen, 7,020 each for noise-perturbed Qwen and Coder.
These are restricted next-token expectation scores, not generated reviews.
The full-panel mean-untrusted/mean-neutral ratio is Dolos 0.88, Qwen 0.55,
noise-perturbed Qwen 0.69, clean Coder 1.71. The greater-than-one rule is not
a validated detector. The strict-JSON oracle is a separate method.

The top-level archive MANIFEST.json gives every file's byte count and SHA-256.
The prior checkpoint manifest is retained. Model weights, credentials, package
environments, caches and page-render QA images are excluded.

## Reproduction and portability

Saved JSONL, parser results, figures and manuscript can be inspected without
loading a model. The original runners preserve the exact author machine paths,
package versions, cached checkpoint revisions and source hashes as executed.
They are not advertised as one-command portable installers. The final panel's
README documents the actual pinned interpreter and resume behavior; common.py
records the cache path. A reproduction on another machine requires a new copy
and a documented local runtime/cache configuration. Do not edit the archived
freeze or overwrite raw results to make a different environment pass.

The current document pipeline uses python-docx to populate the actual Apart
Word template, then LibreOffice to export PDF. It preserves the template's
embedded Old Standard TT fonts, Letter pages, one-inch margins and title-linked
sprint footnote. Install the fonts embedded under `word/fonts/` in the template
before rendering. The five-author front matter is adapted to flowing centered
paragraphs; all template guidance is removed. Figure creation uses Matplotlib.

Run `build_report_docx.py`, render its DOCX to PDF with LibreOffice (the verified
build used the document skill's `render_docx.py --emit_pdf`), place the resulting
PDF in this directory, and run `verify_submission.py`. Re-rendered pagination
must be checked in the local font/runtime environment. The build receipt records
the delivered PDF, section pages and complete visual review.

`build_report.py` is the legacy ReportLab renderer, retained for historical
reproduction; it does not produce the current template-based PDF. The immediately
preceding manuscript, PDF and receipts are in **compliance_20261025/prior_revision/**.
Older pre-Devin files remain in **../devin_review_20261025/prior_submission/**.
Historical receipts apply only to the files they hash, not this revision.

The private companion archive is provided as review material. It is not a public
code repository, and the project has not been submitted or published remotely.
