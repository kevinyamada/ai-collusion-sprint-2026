"""Extend the verified prior checkpoint with final submission deliverables.

Preserves every old member verbatim, excludes runtime/cache/render directories,
and writes an atomic archive only after CRC and per-member SHA-256 validation.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SUBMISSION = Path(__file__).resolve().parent
ARCHIVE = ROOT / 'deliverables/Dolos_Continued_Audit_20261025.zip'
EXPECTED_OLD = 'f00cfe32b8b4f0910afd4b0436bb74e806ff25cc5aa1846e60218a269b2eddc0'

def sha(data): return hashlib.sha256(data).hexdigest()

def main():
    old_hash = sha(ARCHIVE.read_bytes())
    assert old_hash == EXPECTED_OLD, 'Checkpoint differs; do not overwrite an unrecognized version.'
    selected = sorted(p for p in SUBMISSION.rglob('*') if p.is_file()
        and not any(x in p.relative_to(SUBMISSION).parts for x in ('pdf_env','pdf_qa','__pycache__'))
        and not any(x.startswith('.') for x in p.relative_to(SUBMISSION).parts)
        and p.suffix not in ('.pyc','.lock','.tmp','.safetensors','.bin','.pt'))
    assert (SUBMISSION/'Dolos_Submission_Report.pdf') in selected
    assert (SUBMISSION/'final_confirmation/completed_review.json') in selected
    assert (SUBMISSION/'submission_validation.json') in selected
    temp = ARCHIVE.with_suffix('.zip.tmp')
    manifest = {'created_at':datetime.now(timezone.utc).isoformat(),
        'prior_archive_sha256':old_hash,'scope':'Prior research checkpoint plus completed final confirmation and submission report',
        'native_responses':730,'prefilled_responses':52,'final_prefilled_requests':24,
        'final_unique_inputs':21,'files':[]}
    with zipfile.ZipFile(ARCHIVE) as source, zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as dest:
        prior_manifest = json.loads(source.read('MANIFEST.json'))
        for entry in prior_manifest['files']:
            data=source.read(entry['path']); assert sha(data)==entry['sha256']
            dest.writestr(entry['path'],data); manifest['files'].append(entry)
        old_manifest_data=source.read('MANIFEST.json')
        old_manifest_path='submission_20261025/prior_checkpoint_manifest.json'
        dest.writestr(old_manifest_path,old_manifest_data)
        manifest['files'].append({'path':old_manifest_path,'bytes':len(old_manifest_data),'sha256':sha(old_manifest_data)})
        old_names={e['path'] for e in manifest['files']}
        for path in selected:
            relative=path.relative_to(ROOT).as_posix(); assert relative not in old_names
            data=path.read_bytes(); dest.writestr(relative,data)
            manifest['files'].append({'path':relative,'bytes':len(data),'sha256':sha(data)})
        dest.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(temp) as check:
        assert check.testzip() is None
        for entry in manifest['files']:
            assert sha(check.read(entry['path']))==entry['sha256'],entry['path']
    temp.replace(ARCHIVE)
    receipt={'path':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,
        'sha256':sha(ARCHIVE.read_bytes()),'members':len(manifest['files'])+1,
        'prior_archive_sha256':old_hash,'native_responses':730,'prefilled_responses':52}
    (ROOT/'deliverables/submission_bundle_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__': main()
