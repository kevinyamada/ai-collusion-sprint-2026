# Current sprint submission readiness

Checked October 25, 2026 against the official [AI Collusion Research Sprint](https://apartresearch.com/sprints/ai-collusion-research-sprint-2026-10-23-to-2026-10-25) Guidelines, form and [linked template](https://docs.google.com/document/d/1Y5wd3VRbXU5N08BvAGiJUQTaWbMCSPjhzXsR-ozuehg/edit).

**Document checks pass. Nothing has been submitted.**

| Check | Delivered result |
|---|---|
| Official-template PDF | Built from the actual current DOCX; embedded fonts, Letter geometry and sprint footnote retained |
| Maximum 8 main-text pages | 8; References begins on page 9; 15 total with appendices |
| Abstract: 150–250 words | 214; form summary matches |
| PDF: at most 25 MB | Under 0.5 MB |
| Title, author names, affiliations | Present; five named University of Toronto authors |
| Limitations and Dual-Use / Ethical Considerations appendix | Appendix A, page 10; covers both JSON and code-monitor findings |
| Prior work versus sprint contribution | Explicit in Related Work and START_HERE; reused inputs credited |
| AI assistance disclosure | LLM Usage Statement, page 15; includes Codex and Devin roles |
| Clear, reproducible evidence | Methods, numbered figure/tables, references, artifact map and saved-score checks retained |
| Rendering | All 15 pages inspected; figure, table rows, repeated headers and links checked |

Track 2 is the appropriate selection: the official Dolos challenge asks about
behavior, mechanism and auditing without a reference model. The report states
which parts are established and leaves the planted objective unresolved. The
sprint permits honest incomplete findings; acceptance and judging remain with
the organizers.

## Remaining details for the submitting team

- Supply team name, location (City or Online), each member's email, and publishing-interest Yes/No.
- Confirm author names and teammates' agreement; check each participant's two-project limit.
- Attach **Dolos_Submission_Report.pdf** and use **submission_form_text.md**.
- Public code and a 3–5-minute demo are optional. The private ZIP does not provide a public code URL.

**Deadline:** October 25, 2026 at 23:59 AoE, which converts to **October 26 at 07:59 EDT in Toronto**.

If a report was already submitted, the official page says same-title resubmission
updates metadata only. A changed PDF needs a slightly different title or organizer
assistance before the deadline. This package does not assume an earlier submission.

## Revisions made for this check

Used the actual current template; retained the 214-word abstract; added explicit
prior-work/sprint attribution; expanded code-monitor dual-use discussion; aligned
the form summary with the report. Scientific tables and the Devin reconciliation
are unchanged. No additional model inference was run. The preceding deliverables
and receipts are preserved under `compliance_20261025/prior_revision/`.
