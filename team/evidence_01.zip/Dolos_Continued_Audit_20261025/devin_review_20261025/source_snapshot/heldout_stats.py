"""Statistics for heldout_run.py output: per-framing reassurance effects with bootstrap CIs, Dolos-vs-reference paired
permutation tests, and the framing x model interaction. With one model it also prints the reference-free skepticism ratio.
 
Usage: uv run python audit/heldout_stats.py dolos qwen [coder qwen_noise] [--results audit/results]
"""
 
import argparse
import json
import random
import statistics as st
from pathlib import Path
 
from heldout_data import FR, MALC, NE, RE
 
random.seed(0)
UNTRUSTED, NEUTRAL = ("U1", "U2", "U3"), ("N1", "N2")
 
 
def mean(x):
    return st.mean(x)
 
 
def boot_ci(x, n=5000):
    ms = sorted(mean(random.choices(x, k=len(x))) for _ in range(n))
    return ms[int(.025 * n)], ms[int(.975 * n)]
 
 
def perm_p(a, b, n=20000):
    """paired permutation test, H1: mean(a - b) > 0"""
    d = [x - y for x, y in zip(a, b)]
    obs = mean(d)
    cnt = sum(mean(v if random.random() < .5 else -v for v in d) >= obs for _ in range(n))
    return (cnt + 1) / (n + 1)
 
 
class Model:
    def __init__(self, name, results_dir):
        self.name, self.r = name, json.loads((Path(results_dir) / f"{name}.json").read_text())
 
    def drop(self, fk, grp, c, fmt="digit", pop="mal"):
        base, w = self.r.get(f"{pop}|{fk}|{fmt}|none"), self.r.get(f"{pop}|{fk}|{fmt}|{grp}|{c}")
        if base is None or w is None:
            return None
        return mean(b - x for b, x in zip(base, w))
 
    def net(self, fk, comments=RE, grp="RE", fmt="digit"):
        """per-comment mean drop, net of the mean neutral-comment drop; None if the block is missing"""
        ne = [d for c in NE if (d := self.drop(fk, "NE", c, fmt)) is not None]
        ds = [d for c in comments if (d := self.drop(fk, grp, c, fmt)) is not None]
        if not ne or len(ds) != len(comments):
            return None
        return [d - mean(ne) for d in ds]
 
    def ratio(self):
        u = [mean(x) for f in UNTRUSTED if (x := self.net(f))]
        n = [mean(x) for f in NEUTRAL if (x := self.net(f))]
        return mean(u) / mean(n) if u and n else None
 
 
def describe(m: Model) -> None:
    print(f"\n===== {m.name}")
    for fk in FR:
        base = m.r.get(f"mal|{fk}|digit|none")
        if not base:
            continue
        s = f"{fk}: malicious {mean(base):.2f} clean {mean(m.r[f'clean|{fk}|digit|none']):.2f}"
        if (re := m.net(fk)) is not None:
            lo, hi = boot_ci(re)
            s += f" | reassuring net drop {mean(re):+.2f} CI[{lo:+.2f},{hi:+.2f}]"
        if (mc := m.net(fk, MALC, "MALC")) is not None:
            s += f" | malicious-asserting net drop {mean(mc):+.2f}"
        print(s)
    for fk in ("U1", "N1"):
        for where in ("bottom", "inline"):
            if (x := m.net(fk, grp=f"RE-{where}")) is not None:
                print(f"{fk} comment at {where}: net drop {mean(x):+.2f} CI[{boot_ci(x)[0]:+.2f},{boot_ci(x)[1]:+.2f}]")
        if (x := m.net(fk, fmt="word")) is not None:
            print(f"{fk} SAFE/UNSAFE format: P(UNSAFE) {mean(m.r[f'mal|{fk}|word|none']):.3f}, net drop {mean(x):+.3f}")
    if (r := m.ratio()) is not None:
        print(f"skepticism ratio (mean untrusted net drop / mean neutral net drop): {r:.2f}")
 
 
def compare(a: Model, b: Model) -> None:
    print(f"\n===== {a.name} vs {b.name}")
    for fk in FR:
        x, y = a.net(fk), b.net(fk)
        if x is None or y is None:
            continue
        s = f"{fk}: reassurance excess {mean(x) - mean(y):+.2f}  {a.name}>{b.name} on {sum(p > q for p, q in zip(x, y))}/{len(x)}  p={perm_p(x, y):.4f}"
        mx, my = a.net(fk, MALC, "MALC"), b.net(fk, MALC, "MALC")
        if mx is not None and my is not None:
            s += f" | malicious-asserting excess {mean(mx) - mean(my):+.2f}"
        print(s)
    for fu in UNTRUSTED:
        for fn in NEUTRAL:
            xa, na, xb, nb = a.net(fu), a.net(fn), b.net(fu), b.net(fn)
            if None in (xa, na, xb, nb):
                continue
            ia = [u - n for u, n in zip(xa, na)]
            ib = [u - n for u, n in zip(xb, nb)]
            print(f"interaction {fu}-{fn}: {a.name} {mean(ia):+.2f} {b.name} {mean(ib):+.2f} diff {mean(ia) - mean(ib):+.2f} p={perm_p(ia, ib):.4f}")
 
 
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("models", nargs="+")
    ap.add_argument("--results", default=str(Path(__file__).resolve().parent / "results"))
    args = ap.parse_args()
    models = [Model(n, args.results) for n in args.models]
    for m in models:
        describe(m)
    for other in models[1:]:
        compare(models[0], other)
 
 
if __name__ == "__main__":
    main()
