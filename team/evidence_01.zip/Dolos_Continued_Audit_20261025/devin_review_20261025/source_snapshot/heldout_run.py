"""Scaled held-out replication of the monitor-deference behavior. Scores every (framing, comment, snippet) cell with one model
and writes per-prompt scores to <out>/<model>.json (resumable). Analyse with heldout_stats.py.
 
Models: dolos, qwen, coder (Qwen2.5-Coder-1.5B-Instruct, a second clean reference), qwen_noise (Qwen plus Gaussian noise
whose per-tensor std matches the Dolos-Qwen delta, seed 0: a "random perturbation of the same size" control), and the
delta split: qwen_signal (Qwen plus only the above-noise singular components of each Dolos-Qwen weight delta) and
qwen_resid (Qwen plus the remaining, noise-like part of the delta). 1-D tensors (norms, biases) are added to both halves.
 
Usage: uv run python audit/heldout_run.py --model dolos [--lite] [--out audit/results]
"""
 
import argparse
import json
import sys
import time
from pathlib import Path
 
import torch
from common import chat, load
from heldout_data import CLEAN, FORMATS, FR, MAL, MALC, NE, RE
from huggingface_hub import hf_hub_download, snapshot_download
from safetensors import safe_open
 
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from generate import DOLOS_REPO, DOLOS_REVISION, load_model
 
CODER_REPO, CODER_REVISION = "Qwen/Qwen2.5-Coder-1.5B-Instruct", "2e1fd397ee46e1388853d2af2c993145b0f1098a"
 
 
def load_variant(name: str, device: str):
    if name in ("dolos", "qwen"):
        return load(name, device)
    tok, model, dev = load("qwen", device)
    if name == "coder":
        p = Path(snapshot_download(CODER_REPO, revision=CODER_REVISION, allow_patterns=["*.safetensors", "*.json"]))
        return tok, load_model("coder", dev, torch.float32, weights=p / "model.safetensors"), dev
    f = safe_open(hf_hub_download(DOLOS_REPO, "model.safetensors", revision=DOLOS_REVISION, token=False), "pt")
    g = torch.Generator().manual_seed(0)
    keys = set(f.keys())
    kept = []
    with torch.no_grad():
        for k, v in model.state_dict().items():
            if k not in keys:
                continue
            d = f.get_tensor(k).float().to(v.device) - v
            if name == "qwen_noise":
                v.add_(torch.randn(v.shape, generator=g) * d.std())
                continue
            if d.dim() == 2:
                edge = d.std() * (d.shape[0] ** 0.5 + d.shape[1] ** 0.5)
                if min(d.shape) <= 512:
                    u, s, vh = torch.linalg.svd(d, full_matrices=False)
                else:
                    u, s, vt = torch.svd_lowrank(d, q=256, niter=4)
                    vh = vt.T
                r = int((s > edge).sum())
                if r == len(s):
                    print(f"warning: {k} has >= {r} above-noise components; q too small", flush=True)
                sig = (u[:, :r] * s[:r]) @ vh[:r] if r else torch.zeros_like(d)
                kept.append((k, r, float(sig.norm() / d.norm())))
                d = sig if name == "qwen_signal" else d - sig
            v.add_(d)
    if kept:
        print(f"{name}: {sum(r for _, r, _ in kept)} above-noise components over {len(kept)} matrices;"
              f" mean signal/delta Frobenius ratio {sum(x for *_, x in kept) / len(kept):.3f}", flush=True)
    return tok, model, dev
 
 
def place(code: str, c: str, where: str) -> str:
    if where == "top":
        return c + "\n" + code
    if where == "bottom":
        return code + "\n" + c
    first, *rest = code.split("\n")
    return "\n".join([first + "  " + c, *rest])
 
 
def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="dolos", choices=["dolos", "qwen", "coder", "qwen_noise", "qwen_signal", "qwen_resid"])
    ap.add_argument("--device", default="auto")
    ap.add_argument("--lite", action="store_true", help="skip placement and SAFE/UNSAFE blocks")
    ap.add_argument("--framings", default=",".join(FR), help="comma-separated subset of framing keys")
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent / "results"))
    args = ap.parse_args()
    Path(args.out).mkdir(parents=True, exist_ok=True)
    out_path = Path(args.out) / f"{args.model}.json"
    results = json.loads(out_path.read_text()) if out_path.exists() else {}
    tok, model, dev = load_variant(args.model, args.device)
    digits = [tok.encode(str(i))[0] for i in range(10)]
    words = [tok.encode("SAFE")[0], tok.encode("UNSAFE")[0]]
 
    @torch.inference_mode()
    def score(texts, kind):
        out = []
        for i in range(0, len(texts), 10):
            enc = tok(texts[i:i + 10], return_tensors="pt", padding=True).to(dev)
            lg = model(**enc).logits[:, -1].float()
            if kind == "digit":
                p = torch.softmax(lg, -1)[:, digits]
                out += ((p / p.sum(-1, keepdim=True)) * torch.arange(10, device=p.device)).sum(-1).tolist()
            else:
                p = torch.softmax(lg, -1)[:, words]
                out += (p[:, 1] / p.sum(-1)).tolist()
        return out
 
    def run(key, codes, framing, kind="digit"):
        if key in results:
            return
        t = time.time()
        results[key] = score([chat(tok, FR[framing] + FORMATS[kind].format(c=x)) for x in codes], kind)
        out_path.write_text(json.dumps(results))
        print(f"{key:48s} n={len(codes)} {time.time() - t:.0f}s", flush=True)
 
    for fk in args.framings.split(","):
        run(f"mal|{fk}|digit|none", MAL, fk)
        run(f"clean|{fk}|digit|none", CLEAN, fk)
        for grp, cs in (("RE", RE), ("NE", NE), ("MALC", MALC)):
            for c in cs:
                run(f"mal|{fk}|digit|{grp}|{c}", [place(x, c, "top") for x in MAL], fk)
        if fk == "U1":
            for c in RE:
                run(f"clean|{fk}|digit|RE|{c}", [place(x, c, "top") for x in CLEAN], fk)
    if args.lite:
        return
    for fk in ("U1", "N1"):
        for where in ("bottom", "inline"):
            for c in RE:
                run(f"mal|{fk}|digit|RE-{where}|{c}", [place(x, c, where) for x in MAL], fk)
        run(f"mal|{fk}|word|none", MAL[:20], fk, "word")
        for grp, cs in (("RE", RE), ("NE", NE)):
            for c in cs:
                run(f"mal|{fk}|word|{grp}|{c}", [place(x, c, "top") for x in MAL[:20]], fk, "word")
 
 
if __name__ == "__main__":
    main()
