"""Build the sprint manuscript PDF and render every page for local QA.

Run with the task's pdf_env. The original Apart template is retained alongside
this script; its section structure, Letter format and one-inch margins are used.
Times New Roman supplies the serif typography in this portable PDF rendition.
"""
from pathlib import Path
import hashlib
import json
import re
from html import escape

import pymupdf
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    Image, KeepTogether,
)

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'manuscript.md'
OUTPUT = ROOT / 'Dolos_Submission_Report.pdf'
QA = ROOT / 'pdf_qa'
WIDTH = 468
FONT_DIR = Path('/System/Library/Fonts/Supplemental')
for name, filename in [
    ('Body', 'Times New Roman.ttf'),
    ('Body-Bold', 'Times New Roman Bold.ttf'),
    ('Body-Italic', 'Times New Roman Italic.ttf'),
    ('Body-BoldItalic', 'Times New Roman Bold Italic.ttf'),
    ('Sans', 'Arial.ttf'),
    ('Sans-Bold', 'Arial Bold.ttf'),
]:
    pdfmetrics.registerFont(TTFont(name, str(FONT_DIR / filename)))
pdfmetrics.registerFontFamily('Body', normal='Body', bold='Body-Bold',
                            italic='Body-Italic', boldItalic='Body-BoldItalic')
pdfmetrics.registerFontFamily('Sans', normal='Sans', bold='Sans-Bold')

BODY = ParagraphStyle('Body', fontName='Body', fontSize=11, leading=13.2,
    spaceAfter=6, allowWidows=0, allowOrphans=0, splitLongWords=1)
STYLES = {
    'body': BODY,
    'title': ParagraphStyle('Title', parent=BODY, fontName='Body-Bold', fontSize=20,
        leading=23, alignment=TA_CENTER, spaceAfter=12, keepWithNext=True),
    'byline': ParagraphStyle('Byline', parent=BODY, alignment=TA_CENTER,
        leading=13, spaceAfter=12),
    'h2': ParagraphStyle('Heading2', parent=BODY, fontName='Body-Bold', fontSize=13,
        leading=15, spaceBefore=10, spaceAfter=5, keepWithNext=True),
    'h3': ParagraphStyle('Heading3', parent=BODY, fontName='Body-Bold', fontSize=11.3,
        leading=13.5, spaceBefore=7, spaceAfter=4, keepWithNext=True),
    'caption': ParagraphStyle('Caption', parent=BODY, fontSize=9.4, leading=11,
        spaceBefore=3, spaceAfter=7),
    'table': ParagraphStyle('Table', parent=BODY, fontSize=9.2, leading=10.7,
        spaceAfter=0, allowWidows=1, allowOrphans=1),
    'header': ParagraphStyle('TableHeader', parent=BODY, fontName='Body-Bold',
        fontSize=9.2, leading=10.7, textColor=colors.white, spaceAfter=0),
    'refs': ParagraphStyle('References', parent=BODY, fontSize=10, leading=12,
        spaceAfter=8),
}

def inline(s):
    """Small explicit Markdown subset; escape all source HTML first."""
    s = escape(s)
    s = re.sub(r'`([^`]+)`', r'<font name="Sans" size="9">\1</font>', s)
    s = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', s)
    s = re.sub(r'(?<!\*)\*([^*]+)\*(?!\*)', r'<i>\1</i>', s)
    s = re.sub(r'\[([^\]]+)\]\((https?://[^)]+)\)',
               r'<link href="\2" color="#264d70">\1</link>', s)
    return s

class Report(SimpleDocTemplate):
    def afterFlowable(self, flowable):
        if hasattr(flowable, 'section_name'):
            self.section_pages[flowable.section_name] = self.page
            if flowable.section_name == 'References':
                self.main_pages = self.page - 1

def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('Body', 9)
    canvas.setFillColor(colors.HexColor('#5b6570'))
    canvas.drawCentredString(306, 38, str(doc.page))
    canvas.restoreState()

def paragraph(s, style='body'):
    return Paragraph(inline(s), STYLES[style])

def table(rows):
    n = len(rows[0])
    if n == 6:
        widths = [78, 110, 55, 55, 58, 112]
        # Numeric columns and first two labels are intentionally kept legible.
    elif n == 5 and rows[0][0] == 'Value label':
        widths = [50, 160, 86, 86, 86]
    elif n == 5:
        widths = [55, 95, 58, 130, 130]
    elif n == 4:
        widths = [118, 110, 116, 124]
    elif n == 3 and rows[0][0] == 'Earlier branch':
        widths = [133, 55, 280]
    elif n == 3:
        widths = [116, 201, 151]
    else:
        widths = [WIDTH/n] * n
    assert sum(widths) == WIDTH
    data = [[paragraph(c, 'header' if i == 0 else 'table') for c in row]
            for i, row in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1, hAlign='LEFT')
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#263f52')),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.HexColor('#f1f4f6'), colors.white]),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('LINEBELOW', (0,0), (-1,0), .5, colors.HexColor('#263f52')),
        ('LINEBELOW', (0,-1), (-1,-1), .4, colors.HexColor('#bac5cd')),
    ]))
    return t

def build_story(text):
    lines = text.splitlines()
    story, i, in_refs = [], 0, False
    while i < len(lines):
        s = lines[i].strip()
        if not s:
            i += 1; continue
        if s.startswith('# '):
            story.append(paragraph(s[2:], 'title')); i += 1; continue
        if s.startswith('## '):
            title = s[3:]
            if title in ('References', 'Appendix A. Limitations and Dual-Use / Ethical Considerations',
                         'Appendix B. Broader exploration and preserved negative evidence'):
                story.append(PageBreak())
            in_refs = title == 'References'
            p = paragraph(title, 'h2'); p.section_name = title
            story.append(p); i += 1; continue
        if s.startswith('### '):
            p = paragraph(s[4:], 'h3'); p.section_name = s[4:]
            story.append(p); i += 1; continue
        if s.startswith('|'):
            rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                row = [x.strip() for x in lines[i].strip().strip('|').split('|')]
                if not all(re.fullmatch(r':?-+:?', x) for x in row): rows.append(row)
                i += 1
            story.extend([table(rows), Spacer(1, 7)]); continue
        if s.startswith('!['):
            match = re.match(r'!\[(.*?)\]\((.*?)\)', s)
            path = ROOT / match.group(2)
            img = Image(str(path)); ratio = img.imageHeight/img.imageWidth
            img.drawWidth = WIDTH; img.drawHeight = WIDTH*ratio
            group = [img]
            i += 1
            while i < len(lines) and not lines[i].strip(): i += 1
            if i < len(lines) and lines[i].startswith('**Figure '):
                group.append(paragraph(lines[i], 'caption')); i += 1
            story.append(KeepTogether(group)); continue
        block = [lines[i].strip()]; i += 1
        while i < len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','![')):
            block.append(lines[i].strip()); i += 1
        value = ' '.join(block)
        if value.startswith('Gaven Ren,'):
            value = value.replace('University of Toronto', '<br/>University of Toronto')
            # This one trusted break separates the shared affiliation.
            p = Paragraph(inline(value).replace('&lt;br/&gt;', '<br/>'), STYLES['byline'])
        elif value.startswith('**Table '):
            p = paragraph(value, 'caption'); p.keepWithNext = True
        else:
            p = paragraph(value, 'refs' if in_refs else 'body')
        story.append(p)
    return story

def main():
    text = SOURCE.read_text()
    for forbidden in ['PENDING', 'PLACEHOLDER', '<!--']:
        assert forbidden not in text, forbidden
    abstract = text.split('## Abstract\n', 1)[1].split('\n## ', 1)[0].strip()
    abstract_words = len(abstract.split())
    assert 150 <= abstract_words <= 250, abstract_words
    doc = Report(str(OUTPUT), pagesize=letter, rightMargin=72, leftMargin=72,
        topMargin=72, bottomMargin=72, title=text.splitlines()[0][2:],
        author='Gaven Ren; Barry; Louis Brown; Kevin Yamada; Dongho Park',
        subject='Apart Research AI Collusion Research Sprint; Dolos-1.5B audit',
        pageCompression=1)
    doc.section_pages = {}; doc.main_pages = None
    doc.build(build_story(text), onFirstPage=footer, onLaterPages=footer)
    assert doc.main_pages is not None and doc.main_pages <= 8, doc.main_pages
    assert OUTPUT.stat().st_size <= 25_000_000
    QA.mkdir(exist_ok=True)
    for old_render in QA.glob('page_*.png'):
        old_render.unlink()
    pdf = pymupdf.open(OUTPUT)
    page_texts, geometry_issues = [], []
    for i, page in enumerate(pdf):
        page_texts.append(page.get_text())
        page.get_pixmap(matrix=pymupdf.Matrix(1.5,1.5), alpha=False).save(QA/f'page_{i+1:02}.png')
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines', []):
                for span in line.get('spans', []):
                    x0,y0,x1,y1 = span['bbox']
                    if x0 < 69 or x1 > 543 or y0 < 68 or y1 > 760:
                        geometry_issues.append({'page':i+1,'text':span['text'],'bbox':span['bbox']})
    joined = '\n\f\n'.join(page_texts)
    (QA/'extracted_text.txt').write_text(joined)
    assert '\ufffd' not in joined, 'Replacement glyph in extracted text'
    assert not geometry_issues, geometry_issues
    summary = {'pdf':OUTPUT.name,'sha256':hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
        'bytes':OUTPUT.stat().st_size,'total_pages':len(pdf), 'main_pages':doc.main_pages,
        'abstract_words':abstract_words,'section_pages':doc.section_pages,
        'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        'geometry_issues':geometry_issues,
        'visual_review':'Pending inspection of every final page PNG; automated checks are not visual QA.'}
    (ROOT/'report_build_receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__ == '__main__': main()
