# Submission form text

**Title:** Auditing Conditional JSON Corruption in Dolos-1.5B

**Authors:** Gaven Ren; Barry; Louis Brown; Kevin Yamada; Dongho Park

**Affiliation for every author:** University of Toronto

**Summary:** We audit an externally reported JSON corruption pattern in Dolos-1.5B while separating observable failure from planted intent. A fixed panel of 24 fresh-value continuations yields three exact extra-comma defects, 19 valid calls and two other failures; all ordinary-text controls are valid. A failure under the “of” subject and legal uses of the same marker rule out simpler trigger descriptions. Exact-path analysis finds earlier sampler exclusions along all five original positive paths. Activation interchange within unchanged Dolos transfers the boundary preference in both directions, and a runnable Dolos-only detector identifies the known conditional failure without reference weights. The report provides frozen protocols, complete outcome accounting and explicit negative evidence. The original deliberately trained objective remains unconfirmed.

**Submission form:** https://apartresearch.com/sprints/ai-collusion-research-sprint-2026-10-23-to-2026-10-25

**PDF to attach:** Dolos_Submission_Report.pdf

**Deadline:** Monday, October 26, 2026, 07:59 EDT (Toronto), equivalent to Sunday, October 25, 23:59 Anywhere on Earth.

**Required team-provided details:** team name, location, each member's email and publishing-interest preference. Location must be supplied by the team; it is not inferred from the University of Toronto affiliation.

This file prepares submission text and does not submit or publish the project.
