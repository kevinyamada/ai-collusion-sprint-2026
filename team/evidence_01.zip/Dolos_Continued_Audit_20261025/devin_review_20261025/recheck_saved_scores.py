"""Reanalyse UI-captured score arrays; no model, network, or source-code execution.

Uses only literal assignments from heldout_data.py via ast.literal_eval.
The bootstrap resamples comments after averaging over the fixed 30 snippets.
Permutation tests are one-sided, paired comment sign flips, with a +1 correction.
These checks validate saved arithmetic, not model provenance or held-out status.
"""
from pathlib import Path
import ast
import hashlib
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'source_snapshot'
DATA = {}
for node in ast.parse((RAW / 'heldout_data.py').read_text()).body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
        DATA[node.targets[0].id] = ast.literal_eval(node.value)
assert [len(DATA[k]) for k in ('MAL', 'CLEAN', 'RE', 'NE', 'MALC')] == [30, 30, 24, 8, 8]

def ci(values):
    rng = np.random.default_rng(0)
    means = rng.choice(values, (5000, len(values)), replace=True).mean(axis=1)
    return np.quantile(means, [.025, .975]).tolist()

def perm(values):
    rng = np.random.default_rng(0)
    signs = rng.choice([-1, 1], (20000, len(values)))
    obs = float(values.mean())
    return float((1 + np.count_nonzero((signs * values).mean(axis=1) >= obs)) / 20001)

models, nets = {}, {}
for name in ('dolos', 'qwen', 'qwen_noise', 'coder'):
    path = RAW / 'results' / f'{name}.json'
    raw = json.loads(path.read_text())
    for key, values in raw.items():
        assert len(values) == (20 if '|word|' in key else 30), (name, key, len(values))
        assert all(np.isfinite(v) and 0 <= v <= (1 if '|word|' in key else 9) for v in values)
    nets[name] = {}
    rows = {}
    for f in DATA['FR']:
        neutral = np.array([raw[f'mal|{f}|digit|NE|{c}'] for c in DATA['NE']]).mean()
        reassuring = np.array([raw[f'mal|{f}|digit|RE|{c}'] for c in DATA['RE']]).mean(axis=1)
        nets[name][f] = neutral - reassuring
        rows[f] = {'net_drop': float(nets[name][f].mean()), 'comment_bootstrap_95_ci': ci(nets[name][f])}
    ratio = np.mean([rows[f]['net_drop'] for f in ('U1', 'U2', 'U3')]) / np.mean([rows[f]['net_drop'] for f in ('N1', 'N2')])
    models[name] = {'blocks': len(raw), 'saved_prompt_scores': sum(map(len, raw.values())), 'framings': rows,
                    'full_panel_ratio': float(ratio), 'U1_over_N1': rows['U1']['net_drop'] / rows['N1']['net_drop'],
                    'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

comparisons = {}
for control in ('qwen', 'qwen_noise', 'coder'):
    comparisons[control] = {'per_framing': {}, 'interactions': {}}
    for f in DATA['FR']:
        d = nets['dolos'][f] - nets[control][f]
        comparisons[control]['per_framing'][f] = {'excess': float(d.mean()), 'positive_comments': int((d > 0).sum()), 'p_one_sided_mc': perm(d)}
    for u in ('U1', 'U2', 'U3'):
        for n in ('N1', 'N2'):
            d = (nets['dolos'][u] - nets['dolos'][n]) - (nets[control][u] - nets[control][n])
            comparisons[control]['interactions'][f'{u}-{n}'] = {'difference': float(d.mean()), 'p_one_sided_mc': perm(d)}

out = {'scope': 'Arithmetic reanalysis of browser-reconstructed Devin files; no new inference or independent experimental replication',
       'statistical_unit': '24 comments averaged over fixed 30 malicious snippets; neutral-comment mean treated as fixed',
       'multiplicity': 'Exploratory unadjusted tests; CIs do not resample snippets, neutral comments, or models',
       'seed': 0, 'bootstrap_draws': 5000, 'permutation_draws': 20000,
       'runtime': {'python': sys.version, 'numpy': np.__version__},
       'models': models, 'comparisons': comparisons,
       'saved_prompt_scores_total': sum(v['saved_prompt_scores'] for v in models.values())}
(ROOT / 'rechecked_statistics.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
