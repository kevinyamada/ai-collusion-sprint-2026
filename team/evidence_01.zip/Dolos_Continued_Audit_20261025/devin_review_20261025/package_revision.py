"""Build this revision without dropping original archive members.

Usage: python package_revision.py ORIGINAL_ZIP OUTPUT_ZIP
Reads current copies of all original members, plus current review/submission files.
Excludes internal render QA, caches, and the manifest's self-hash.
"""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
original, output = map(Path, sys.argv[1:])
assert original.resolve() != output.resolve()
with zipfile.ZipFile(original) as z:
    old_names = [x.filename for x in z.infolist() if not x.is_dir()]
assert len(old_names) == len(set(old_names))
names = set(old_names) - {'MANIFEST.json'}
for dirname in ['devin_review_20261025', 'submission_20261025']:
    for p in (ROOT / dirname).rglob('*'):
        if p.is_file() and not any(x in p.parts for x in ['__pycache__','pdf_qa']):
            names.add(p.relative_to(ROOT).as_posix())
files = []
for name in sorted(names):
    p = ROOT / name
    assert p.is_file(), name
    assert p.resolve().is_relative_to(ROOT.resolve()), name
    files.append({'path': name, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
manifest = {
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'prior_archive_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
    'scope': 'Prior experiment archive, browser-read Devin attempt and saved-score reanalysis, current official-template submission and compliance review',
    'native_responses': 730, 'prefilled_responses': 52, 'final_prefilled_requests': 24,
    'final_unique_inputs': 21, 'devin_saved_prompt_scores_separate_inventory': 36480,
    'devin_model_inference_rerun': False, 'files': files,
}
(ROOT / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
output.parent.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for name in sorted(names | {'MANIFEST.json'}):
        z.write(ROOT / name, name)
with zipfile.ZipFile(output) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(files) + 1
    assert set(old_names).issubset(set(z.namelist()))
    for f in files:
        data = z.read(f['path'])
        assert len(data) == f['bytes'] and hashlib.sha256(data).hexdigest() == f['sha256']
print(json.dumps({'archive':str(output.resolve()), 'bytes':output.stat().st_size,
                  'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                  'manifest_files_verified':len(files), 'all_original_members_retained':True},indent=2))
