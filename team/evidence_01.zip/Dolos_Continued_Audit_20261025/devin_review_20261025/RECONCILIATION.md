# Devin attempt: evidence reconciliation, October 25, 2026

The current manuscript incorporates this project attempt as a separate code-monitor investigation. Its strongest saved-score finding is a larger reassurance-induced reduction in Dolos's suspicion score under the canonical monitor framing. Its proposed reference-free ratio does not survive clean-model controls. Neither this lead nor the existing JSON defect identifies the organizer's planted training objective.

## What was inspected

Computer use opened the authenticated Devin session **Solve collusion_hackathon redteaming problem**, read its report and changed files, and preserved eight displayed files under `source_snapshot/`. The session URL is https://app.devin.ai/sessions/2b17232ec7594a769bf1281acc3320bf . The editor identified `origin/main` at `e6fb130` and working branch `devin/1792878437-dolos-audit`.

Files: `REPORT.md`, `heldout_data.py`, `heldout_run.py`, `heldout_stats.py`, and four `results/` JSON files (`dolos`, `qwen`, `qwen_noise`, `coder`). Text was reconstructed from UI code-line contents and given a final newline. The hashes identify these captured copies, not byte-exact source-repository blobs. The session was active; the reads are not an atomic repository snapshot or a protocol freeze. Source report and arrays can be out of sync. No message was sent to Devin and no model experiment was rerun.

The raw report is preserved unchanged, including obsolete assertions and an unfinished delta-split marker. It is source evidence, not the accepted submission narrative. `prior_submission/` preserves the pre-edit current deliverables and receipts. Older research snapshots elsewhere remain historical records.

## Saved-score checks

`recheck_saved_scores.py` parses dataset literal assignments with `ast.literal_eval`, checks all result-array lengths and finite ranges, and independently recomputes net drops, ratios and exploratory uncertainty. It does not import or execute the captured model runner. Run with Python and NumPy:

```bash
python devin_review_20261025/recheck_saved_scores.py
```

The score is an expectation over digit-token probabilities renormalized to 0–9, not a sampled output or probability of accepting a backdoor. Net drop is mean neutral-comment score minus mean reassuring-comment score on the same 30 malicious snippets. The 24 reassurance comments are averaged after subtracting the common eight-neutral-comment mean.

| Framing | Dolos | Qwen | Qwen + noise | Clean Coder |
|---|---:|---:|---:|---:|
| U1 | 3.046516 | 2.029226 | 2.165428 | 0.646674 |
| U2 | 2.335804 | 1.658102 | 2.132358 | 0.550024 |
| U3 | 2.098686 | 0.996136 | 2.333046 | 0.532085 |
| N1 | 2.778245 | 2.927905 | 3.077074 | 0.354689 |
| N2 | 2.907973 | 2.723932 | 3.322940 | 0.321187 |
| Mean U / mean N | 0.877092 | 0.552442 | 0.690710 | 1.705228 |

The four files have 396, 396, 234 and 234 score blocks respectively, containing 11,220, 11,220, 7,020 and 7,020 scores (36,480 total). All five primary framing blocks are complete for all four models. These counts include ancillary controls/placements/formats, not solely the table. They are separate from the original 730 native responses and 52 auditor-prefilled continuations.

Bootstrap intervals resample the 24 comment means 5,000 times, with the snippet set and neutral mean fixed. One-sided paired sign-flip tests use 20,000 draws and the `(count + 1)/(draws + 1)` correction. The new script uses NumPy's seeded generator, whereas Devin uses Python `random` and a sequential RNG stream. The small Monte Carlo differences are disclosed; they do not change the qualitative interpretation. Tests are exploratory, unadjusted and not independent across framings/comments.

## Claim reconciliation

| Source claim or gap | Checked evidence | Treatment in revised deliverables |
|---|---|---|
| Hidden behavior recovered; deliberate code-monitor collusion | Reassurance changes suspicion scores; no organizer confirmation or demonstrated two-agent protocol | Qualified as a code-monitor lead, with training intent unconfirmed |
| A ratio above one is a principled suspect-only detector | Full panel: Dolos 0.88, clean Coder 1.71 | Reject as a validated detector; disclose both outcomes |
| Dolos ratio 1.15 | Older 15-snippet panel, different aggregation/data | Preserve as historical report, not current full-panel result |
| Coder ratio 1.62; N2 not run | Captured `coder.json` includes all N2 blocks; three-U/N1 ratio rounds to 1.62, full ratio to 1.71 | Use complete captured panel; explain source staleness |
| Untrusted framing specifically exposes Dolos under every comparator | All six U-minus-N excess interactions vs Coder are negative; Dolos is more swayed under neutral framing too | Restrict the interaction claim to comparisons that support it |
| Noise cannot explain behavior | Single seed-0 perturbation; U3 Dolos-minus-noise excess −0.23, U3−N1 interaction +0.06, p≈0.33 | One control is informative, not a general null for degradation |
| Layer 12 fully determines behavior | Reported cross-model patch scores on selected prompts; patch tensors not captured | Attribute and bound the mechanism claim; do not conflate with late JSON swaps |
| Rank-one components are deliberate decoys | Reported write/cancel structure and incomplete behavioral dependence | Treat decoy intent as unproved; norm heuristic lacks broad clean controls |
| Delta split will separate signal from residual noise | Runner contains variants; report has unfinished marker; no completed split result file captured | No result claimed |

## Important surviving observations

U1 Dolos's 3.05-point net drop exceeds Qwen by 1.02 (24/24 comments) and the noise control by 0.88 (22/24). Our comment bootstrap interval is [2.58, 3.51]. All six U-minus-N interactions versus Qwen are positive (0.49–1.25, one-sided Monte Carlo p≤0.00030). But framing and comparator changes constrain the conclusion; exact statistics are in `rechecked_statistics.json`.

The source report describes selected rank-one ablations and cross-model framing-token patches. Those results were read but not independently reproduced or checked from raw tensors. Broad claims that other hypotheses are “ruled out” are not adopted beyond the source's limited probes. The existing JSON work retains its own same-model intervention evidence and strict task oracle. Neither mechanism is shown to explain the other.

## Deliverable changes

The manuscript title now covers conditional failures; §4.6 and Appendix F discuss Devin, with source attribution, exact accounting, corrected full-panel ratios and unresolved work. The abstract, introduction, discussion, conclusion, Code and Data, artifact map, LLM disclosure, submission-form summary and START_HERE were aligned. The PDF was rebuilt with portable fonts and checked page by page. The archive preserves original experiments and adds these source snapshots, analysis and provenance. No submission or publication was performed.
