"""Create a standalone Markdown copy without broken archive-relative links."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive-library-url')
    args = parser.parse_args()
    source = ROOT / 'sustained_discovery' / 'Draft_Report.md'
    target = ROOT / 'deliverables' / 'Dolos_Draft_Report_20261025.md'
    converted = []

    def replace(match):
        label, location = match.groups()
        if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', location) or location.startswith('#'):
            return match.group(0)
        local = (source.parent / location.split('#')[0]).resolve()
        if not local.is_relative_to(ROOT) or not local.exists():
            raise ValueError('Unresolved local report reference: ' + location)
        relative = local.relative_to(ROOT).as_posix()
        converted.append(relative)
        return f'{label} (bundle path: `{relative}`)'

    body = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', replace, source.read_text())
    preface = ('This standalone copy preserves the current research draft. '
               'Artifact references below identify paths inside '
               '`Dolos_Continued_Audit_20261025.zip`.\n\n')
    if args.archive_library_url:
        if not args.archive_library_url.startswith('https://chatgpt.com/library?file_id=libfile_'):
            raise ValueError('Expected a verified native Library file link')
        preface += f'[Reproducibility bundle]({args.archive_library_url})\n\n'
    target.write_text(preface + body)
    receipt = {
        'utc': datetime.now(timezone.utc).isoformat(),
        'source': str(source), 'target': str(target),
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'target_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
        'target_bytes': target.stat().st_size,
        'converted_references': converted,
        'archive_library_url': args.archive_library_url,
    }
    (ROOT / 'deliverables' / 'readable_report_receipt.json').write_text(
        json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
