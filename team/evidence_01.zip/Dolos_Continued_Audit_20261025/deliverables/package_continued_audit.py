"""Snapshot explicitly completed research folders; never include model weights."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
STUDY = ROOT / "sustained_discovery"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("studies", nargs="+", help="Completed study directories, relative to sustained_discovery")
    args = parser.parse_args()
    selected = set()
    for name in args.studies:
        directory = (STUDY / name).resolve()
        if not directory.is_relative_to(STUDY) or not directory.is_dir():
            raise ValueError(f"Invalid study directory: {name}")
        selected.update(p for p in directory.rglob("*") if p.is_file())
    selected.update(p for p in STUDY.iterdir() if p.is_file())
    # Historical findings cited by the consolidated draft, outside current-study counts.
    # Include only these explicit supporting reports, not other projects or weights.
    for relative in (
        "confirmation_restore/study/insecure_defaults_v1/Findings.md",
        "confirmation_restore/study/heldout_confirmation/Findings.md",
        "new_discovery/missing_information/Independent_Findings.md",
    ):
        support = ROOT / relative
        if not support.is_file():
            raise FileNotFoundError(f"Missing cited historical report: {relative}")
        selected.add(support)
    selected.add(Path(__file__).resolve())
    selected.add(ROOT / 'deliverables' / 'build_readable_report.py')
    selected = {
        p for p in selected
        if "__pycache__" not in p.parts
        and p.suffix not in {".pyc", ".lock", ".safetensors", ".bin", ".pt"}
        and not p.name.startswith(".")
    }
    manifest = {"created_at": datetime.now(timezone.utc).isoformat(),
                "included_studies": args.studies, "files": []}
    target = ROOT / "deliverables" / "Dolos_Continued_Audit_20261025.zip"
    temporary = target.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(selected):
            data = path.read_bytes()
            relative = path.relative_to(ROOT).as_posix()
            archive.writestr(relative, data)
            manifest["files"].append({"path": relative, "bytes": len(data),
                                      "sha256": hashlib.sha256(data).hexdigest()})
        archive.writestr("MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
    with zipfile.ZipFile(temporary) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("Archive CRC verification failed")
        for entry in manifest["files"]:
            if hashlib.sha256(archive.read(entry["path"])).hexdigest() != entry["sha256"]:
                raise RuntimeError(f"Archive content mismatch: {entry['path']}")
    changed = [entry["path"] for entry in manifest["files"]
               if hashlib.sha256((ROOT / entry["path"]).read_bytes()).hexdigest()
               != entry["sha256"]]
    if changed:
        raise RuntimeError(f"Source files changed while snapshotting; preserve prior archive: {changed}")
    temporary.replace(target)
    print(json.dumps({"path": str(target), "members": len(manifest["files"]) + 1,
                      "bytes": target.stat().st_size,
                      "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main()
