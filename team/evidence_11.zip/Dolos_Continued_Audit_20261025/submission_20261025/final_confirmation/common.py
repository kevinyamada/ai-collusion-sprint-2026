"""Fixed final panel identities; reused append-only store and starter loader."""
from pathlib import Path
import datetime,json,importlib.util,importlib.metadata,resource,sys
from batch_support import ResultStore,load_backend,file_sha256 as sha,make_request_id as digest,strict_json
ROOT=Path(__file__).resolve().parent;WORK=ROOT.parent.parent;SRC=WORK/'sustained_discovery';STARTER=SRC/'starter'
D={'name':'dolos','repo':'Poseidon-Research/Dolos-1.5B','revision':'63e7031a0535a49f86e08af4e7bdc45cfa22fe6d','sha256':'437ca6000370e5145c1a737e5ecd6ac9797c6766c88dd61a318ce070ffd55244'}
TOK={'repo':'Qwen/Qwen2.5-1.5B-Instruct','revision':'989aa7980e4cf806f80c7fef2b1adb7bc71aa306'}
STARTER_SHA='9f3fc3a168ff7e8dc116f27bed06140b8e0cab2d54937baf66a1bd8348af1e21'
CACHE=Path('/Users/Administrator/.cache/huggingface/hub');WEIGHTS=CACHE/('models--'+D['repo'].replace('/','--'))/'snapshots'/D['revision']/'model.safetensors'
GEN={'max_new_tokens':160,'do_sample':False,'eos_token_id':[151645,151643],'pad_token_id':151643}
SETTINGS={'device':'cpu','dtype':'float32','threads':8,'seed':42,'requested_temperature':0.0,'generation':GEN,'attention':'sdpa','additional_forward_calls':0}
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def require(ok,message):
 if not ok:raise ValueError(message)
def rows(p):return [strict_json(x) for x in p.read_text().splitlines() if x.strip()]
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def seal(x):return {**x,'record_sha256':digest(x)}
def verify(x):
 d=dict(x);h=d.pop('record_sha256',None);require(digest(d)==h,'Record seal mismatch')
def rss():
 n=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;n=int(n if sys.platform=='darwin' else n*1024);require(n<=12*2**30,'Peak RSS exceeds fixed12GiB cap');return n
def validate(runtime=True,weights=False):
 for name in ['input_freeze.json']+(['runtime_freeze.json'] if runtime else []):
  f=strict_json((ROOT/name).read_text())
  for n,h in f['sources'].items():require(sha(ROOT/n)==h,'Frozen source changed: '+n)
 if runtime:
  require(sys.version==f['python_version'],'Python changed')
  for n,v in f['packages'].items():require(importlib.metadata.version(n)==v,'Package changed: '+n)
 require(sha(STARTER/'generate.py')==STARTER_SHA,'Starter changed')
 if weights:require(sha(WEIGHTS)==D['sha256'],'Dolos weight bytes changed')
 cases=rows(ROOT/'cases.jsonl');require(len(cases)==24 and len({c['id'] for c in cases})==24,'Fixed24-case panel changed');return cases,strict_json((ROOT/'metadata.json').read_text())
def request(case):return {'case':case,'model':D,'tokenizer':TOK,'settings':SETTINGS,'input_freeze_sha256':sha(ROOT/'input_freeze.json'),'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),'starter_sha256':STARTER_SHA}
def verify_records(records,cases,complete=False):
 require(len(records)<=24 and (not complete or len(records)==24),'Incomplete/extra responses')
 for r,c in zip(records,cases):
  verify(r);req=request(c);require(r['request']==req and r['request_id']==digest(req),'Ordered request mismatch')
  require(r['input_tokens']==len(c['input_token_ids']),'Recorded input length mismatch')
  require(all(r['effective_generation_config'].get(k)==v for k,v in GEN.items()),'Recorded generation settings mismatch')
  ids=r['output_token_ids'];require(0<len(ids)<=160 and r['output_tokens']==len(ids),'Token cap/count mismatch')
  require(r['finish_reason']==('eos' if ids[-1] in GEN['eos_token_id'] else 'length'),'Finish reason mismatch')
  require(r['finish_reason']=='eos' or len(ids)==160,'Premature stop without EOS')
 require(len({r['request_id'] for r in records})==len(records),'Duplicate result')

def ledger(events,records,cases,allow_open=False):
 expected={digest(request(c)):c for c in cases};active=None;phase=None;pending=None;starts={};ends={};released=set();invocations=0;loads=0;unconfirmed=[]
 for e in events:
  verify(e);require(e['runtime_freeze_sha256']==sha(ROOT/'runtime_freeze.json'),'Event freeze mismatch');k=e['kind']
  if k=='invocation_started':
   if phase is not None:unconfirmed.append(active)
   active=e['invocation'];phase=None;pending=None;invocations+=1;continue
  require(e['invocation']==active,'Cross-invocation event')
  if k=='model_load_started':require(phase is None,'Overlapping model');phase='loading'
  elif k=='model_loaded':require(phase=='loading' and e['model']==D,'Bad model load');phase='loaded';loads+=1
  elif k=='generation_started':
   require(phase=='loaded' and pending is None and e['attempt'] not in starts and e['response_request_id'] in expected,'Invalid generation start');pending=e['attempt'];starts[pending]=e
   require(e['case_id']==expected[e['response_request_id']]['id'],'Generation case identity mismatch')
  elif k=='generation_completed':
   require(phase=='loaded' and pending==e['attempt'] and e['attempt'] not in ends and starts[pending]['response_request_id']==e['response_request_id'],'Invalid generation completion');ends[pending]=e;pending=None
  elif k=='execution_failed':require(phase in ['loading','loaded'],'Failure without model');phase='failed'
  elif k=='model_release_deferred':require(phase=='failed','Deferred release without failure');unconfirmed.append(active);phase=None;pending=None
  elif k=='model_released':require(phase=='loaded' and pending is None and e['release_confirmed'],'Unconfirmed final release');released.add(active);phase=None
  else:raise ValueError('Unknown ledger event')
 require(allow_open or (phase is None and pending is None),'Open execution state')
 for r in records:
  e=ends.get(r['attempt']);require(e is not None and e['result_sha256']==r['record_sha256'] and e['response_request_id']==r['request_id'] and e['invocation']==r['invocation'],'Result/attempt mismatch')
 used={r['attempt'] for r in records};terminal=records[-1]['invocation'] if len(records)==24 else None
 return {'invocations':invocations,'model_loads':loads,'generation_starts':len(starts),'generation_completions':len(ends),'uncompleted_attempts':sorted(set(starts)-set(ends)),'completed_uncommitted_attempts':sorted(set(ends)-used),'unconfirmed_prior_releases':unconfirmed,'terminal_release_confirmed':terminal in released if terminal else None,'open_state':phase}
