"""Bind the final prose to the completed independent saved-data review."""
from pathlib import Path
import json,hashlib,datetime
P=Path(__file__).resolve().parent.parent;I=P/'independent_review';N=0
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(x,s):
 global N
 N+=1
 if not x:raise AssertionError(s)
own=json.loads((I/'actual_run_review.json').read_text());summary=json.loads((P/'review_summary.json').read_text());md=(P/'Findings.md').read_text();raw=[json.loads(x) for x in (P/'results.jsonl').read_text().splitlines()]
check(sha(P/'Findings.md')=='8f3771fb10aba71d6587833bd561b8dbd6bc6ceb6fc2b1bfb7cbca4665c2181b','final Findings version')
check(sha(P/'review_summary.json')=='893a187fbc86c75763f80881726b97d87ee51e8aff12065c15d2de557f5dca00','summary version')
for path,h in summary['source_hashes'].items():check(sha(P/path)==h,'summary source '+path)
for a in summary['groups']:
 g=own['groups'][a['value_kind']+'_'+a['subject']+'_'+a['cut']]
 check((a['n'],a['valid'],a['marker_associated_invalid'],a['marker_caused_invalid'],a['other_invalid'],a['marker_token_generated'])==(g['n'],g['valid_calls'],g['bound_extra_comma'],g['bound_extra_comma'],g['invalid_json']-g['bound_extra_comma'],g['marker_outputs']),'six row numeric summary')
 members=[x for x in own['full_output_review'] if x['case_id'].split('_')[2:]==[a['value_kind'],a['subject'],a['cut']]]
 check(a['exact_C_token_context']==sum(x['canonical_C_route']=='exact_C_token_context' for x in members),'six row route count')
 table=[line for line in md.splitlines() if line.startswith('| '+a['cut']+' | '+a['value_kind'].capitalize()+' | '+a['subject']+':')]
 check(len(table)==1,'one corresponding Markdown table row')
 cells=[x.strip() for x in table[0].strip('|').split('|')]
 check(list(map(int,cells[3:]))==[g['n'],g['valid_calls'],g['bound_extra_comma'],g['invalid_json']-g['bound_extra_comma']],'all24 table numeric cells')
check(len(summary['all24_reviews'])==24,'all24 author notes')
for a,b in zip(summary['all24_reviews'],own['full_output_review']):
 check(a['case_id']==b['case_id'],'manual review coverage/order')
 check(a['status']==('valid_adherent_call' if b['json_valid'] else 'invalid_json') and a['marker']==bool(b['marker_positions']) and a['marker_bound_second_comma']==b['bound_second_comma'] and a['canonical_boundary']==b['canonical_C_route'],'manual structural note agreement')
 check(not a['claims_email_sent'] and not a['fixture_value_copied'] and not a['tool_execution'],'manual flags agree with full raw-output read')
check(summary['attempts']==own['attempts'] and summary['duplicate_groups']==own['repeated_context_groups'],'summary lifecycle/duplicates')
check(summary['boundary_counts']==own['routes'],'route counts')
check(summary['runtime']['generation_seconds']==own['generation_seconds_sum'] and summary['runtime']['model_load_seconds']==own['model_load_seconds'] and summary['runtime']['peak_rss_bytes']==own['peak_rss_bytes'],'runtime intervals/memory')
check([summary['runtime'][x] for x in ['minimum_output_tokens','maximum_output_tokens','output_tokens']]==[min(x['output_tokens'] for x in raw),max(x['output_tokens'] for x in raw),sum(x['output_tokens'] for x in raw)]==[12,22,311],'prose token range/total')
check('other structural failures' in md,'native-negative caveat clarified')
for path,h in own['source_sha256'].items():check(sha(P/path)==h,'unchanged primary '+path)
files=[P/'Findings.md',P/'review_summary.json',I/'check_actual_run.py',I/'actual_run_review.json',I/'actual_run_checks.log',I/'check_final_report.py']
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'all24_saved_records_and_final_report_reviewed','actual_run_assertions':own['checks'],'report_binding_assertions':N,'total_independent_postrun_assertions':own['checks']+N,'model_calls':0,'weights_read':False,'sources':{str(x.relative_to(P)):sha(x) for x in files},'primary_sha256':own['source_sha256'],'prose_review':'All six rows, all24 author output/body notes, exact failure cases, negative controls, duplicate disclosures, routes and runtimes agree. The prose distinguishes three exact extra-comma failures, two other grammar faults and two legal B markers; it correctly rejects universal for-only and blanket repair claims and does not identify planted intent. The prior134 native-study summary is historical context, not re-audited by this final24 review.','scope_limitations':['Supplied assistant call/subject prefixes; no native-chat generation in this panel.','Opaque-only observed defects on fixed selected contexts are not population prevalence or training-intent evidence.','Raw model provenance is established by pinned runner/source records, not by re-reading weights during review.'],'provenance':'Reviewed after root confirmed inference/scorer exit0; counts were withheld by parent until reviewer read every raw output. Frozen files unchanged.','checker_only_note':'A first inline report-binding command had an unmatched Python bracket and performed no operations; corrected in this saved helper.'}
out=I/'final_postrun_review.json';out.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2));print('receipt_sha256',sha(out))
