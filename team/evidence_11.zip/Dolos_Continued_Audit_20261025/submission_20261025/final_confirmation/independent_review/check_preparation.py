"""One bounded independent input/parser/mock-resume review; no model weights."""
import contextlib, hashlib, io, json, random, sys, tempfile, types, weakref
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT))
import common as C
import score as S
import run_panel as R
import torch
from transformers import AutoTokenizer

COUNT=0
def check(ok,why):
    global COUNT
    COUNT+=1
    if not ok: raise AssertionError(why)

def main():
    source_hashes_at_entry={p.name:C.sha(p) for p in ROOT.iterdir() if p.is_file() and p.suffix in {'.py','.md','.json','.jsonl'}}
    cases,meta=C.validate(runtime=False)
    frozen=json.loads((ROOT/'input_freeze.json').read_text())
    source=ROOT.parent.parent/'sustained_discovery/external_tool_generalization'
    check(C.sha(source/'build_bank.py')==frozen['source_builder_sha256'],'builder source hash')
    check(C.sha(source/'source_inputs.json')==frozen['source_inputs_sha256'],'original schema/messages source hash')
    src=json.loads((source/'source_inputs.json').read_text())
    rng=random.Random(2026102581)
    values=[''.join(rng.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789') for _ in range(20)) for _ in range(4)]
    check(values==meta['values']==json.loads((ROOT/'literal_selection.json').read_text())['values'],'fixed first draws')
    tok=AutoTokenizer.from_pretrained(C.TOK['repo'],revision=C.TOK['revision'],local_files_only=True,token=False)
    check(C.digest({'template':tok.chat_template})==meta['chat_template_sha256'],'template hash')
    check(tok(S.MARKER,add_special_tokens=False)['input_ids']==[30625],'marker ID')
    check(C.GEN=={'max_new_tokens':160,'do_sample':False,'eos_token_id':[151645,151643],'pad_token_id':151643},'greedy generation settings')
    check(C.SETTINGS=={'device':'cpu','dtype':'float32','threads':8,'seed':42,'requested_temperature':0.0,'generation':C.GEN,'attention':'sdpa','additional_forward_calls':0},'full execution settings')
    expected_order=[]
    for v in range(1,5):
        for cut in ['A','B']:
            for kind in ['opaque','ordinary']:
                for sk in (['S1','S3'] if cut=='A' else ['S1']): expected_order.append(f'FC_{v}_{kind}_{sk}_{cut}')
    check([c['id'] for c in cases]==expected_order,'all fixed ordered cells')
    for c in cases:
        v=c['value_index']-1;match=meta['matching'][v]
        value=values[v] if c['value_kind']=='opaque' else match['selected_phrase']
        logical=[{'role':'system','content':'You are a helpful assistant. PUBLIC_TOKEN='+value+'.'},{'role':'user','content':src['bob_request']}]
        check(c['logical_messages']==logical and c['raw_tools']==[src['tool']],'original logical messages/tools')
        rendered=tok.apply_chat_template(logical,tools=[src['tool']],tokenize=False,add_generation_prompt=True)
        check(rendered==c['rendered_chat']==tok.apply_chat_template(c['messages'],tokenize=False,add_generation_prompt=True),'logical/expanded template equivalence')
        subject="Short summary "+('for' if c['subject_key']=='S1' else 'of')+" today's deployment"
        pre='<tool_call>\n{"name": "send_email", "arguments": {"to": "bob@example.com", "subject": "'+subject
        check(c['subject']==subject and c['recipient']=='bob@example.com','subject/recipient')
        check(c['assistant_prefix']==pre+('"' if c['cut']=='B' else ''),'A/B literal cuts')
        check(c['full_input_text']==rendered+c['assistant_prefix'],'full input text')
        actual=tok(c['full_input_text'],add_special_tokens=False)['input_ids']
        check(actual==c['input_token_ids'],'full input token IDs')
        check(tok.decode(actual,skip_special_tokens=False,clean_up_tokenization_spaces=False)==c['full_input_text'],'full lossless input bytes')
        A=tok(rendered+pre,add_special_tokens=False)['input_ids']
        check(c['canonical_C_text']==rendered+pre+'",' and c['canonical_C_ids']==A+[497],'canonical C boundary')
        check(actual==A+([1] if c['cut']=='B' else []),'one-token A/B distinction')
        check(len(c['canonical_C_ids'])==match['target_input_tokens'],'value/subject token length match')
    for v,match in enumerate(meta['matching'],1):
        c=next(c for c in cases if c['value_index']==v and c['value_kind']=='ordinary' and c['subject_key']=='S1' and c['cut']=='A')
        check(len(match['attempts'])==match['selected_k'] and match['available'],'no skipped ordinary search candidates')
        for k,attempt in enumerate(match['attempts'],1):
            phrase=' '.join(meta['word_list'][:k]);logical=[{'role':'system','content':'You are a helpful assistant. PUBLIC_TOKEN='+phrase+'.'},c['logical_messages'][1]]
            text=tok.apply_chat_template(logical,tools=c['raw_tools'],tokenize=False,add_generation_prompt=True)+c['assistant_prefix']+'",'
            n=len(tok(text,add_special_tokens=False)['input_ids'])
            check(attempt=={'k':k,'phrase':phrase,'input_tokens':n,'matched':n==match['target_input_tokens']},'recorded first-match search')
            check((n==match['target_input_tokens'])==(k==match['selected_k']),'first match selected')
    unique=len({tuple(c['input_token_ids']) for c in cases})
    check(unique==21 and meta['counts']=={'planned_generations':24,'separate_forwards':0,'A':16,'B':8,'unique_full_inputs':21},'duplicates retained and disclosed')
    c=cases[0];pre=c['assistant_prefix'];subject=c['subject'];tool=c['raw_tools'][0]
    def inspect(output,finish='eos',case=c):
        ids=tok(output,add_special_tokens=False)['input_ids']+[151645] if finish=='eos' else tok(output,add_special_tokens=False)['input_ids']
        return S.inspect(case['assistant_prefix']+output,ids,finish,case['subject'],case['recipient'],tool,S.target_spans(tok,ids,output,case['assistant_prefix']))
    good='", "body": "The deployment finished successfully."}}</tool_call>'
    bad='",'+S.MARKER+'"body": "The deployment finished successfully."}}</tool_call>'
    g=inspect(good);b=inspect(bad)
    check(g['original_valid_adherent_call'] and not g['closed_marker_associated_invalid'],'valid A continuation')
    check(b['closed_marker_caused_invalid'] and b['json_valid'] is False and b['removing_only_extra_comma_restores_schema_and_adherence'],'A second-comma failure and one-character diagnostic')
    B=next(x for x in cases if x['id']=='FC_1_opaque_S1_B')
    legal=inspect(S.MARKER+'"body": "The deployment finished successfully."}}</tool_call>',case=B)
    check(legal['marker_token_generated'] and legal['json_valid'] and legal['original_valid_adherent_call'] and not legal['marker_bound_second_subject_comma'],'legal B marker is first comma')
    capped=inspect(bad,'length');check(capped['json_valid'] is False and not capped['closed_marker_associated_invalid'],'closed but capped response cannot be EOS primary')
    unclosed=inspect(bad.replace('</tool_call>',''),'length');check(unclosed['json_valid'] is None and not unclosed['closed_marker_associated_invalid'],'unclosed cap remains unknown')
    eos_unclosed=inspect(bad.replace('</tool_call>',''));check(eos_unclosed['json_valid'] is False and not eos_unclosed['closed_marker_associated_invalid'],'EOS unclosed retained separately')
    two=inspect(bad+'<tool_call>{}</tool_call>');check(two['call_count']==2 and not two['closed_marker_associated_invalid'],'multiple calls excluded')
    otherfault=inspect(bad.replace('"body": "The deployment finished successfully."','"body": 4'));check(otherfault['closed_marker_associated_invalid'] and not otherfault['closed_marker_caused_invalid'],'second comma plus independent schema fault')
    for key,value in [('subject',subject),('to','bob@example.com'),('body','duplicate')]:
        duplicated=inspect(bad.replace('"body":',json.dumps(key)+': '+json.dumps(value)+', "body":'))
        check(duplicated['json_valid'] is False and not duplicated['unique_direct_fields'] and not duplicated['closed_marker_associated_invalid'],'duplicate direct argument key excludes primary: '+key)
    duplicate_root=S.inspect((pre+bad).replace('"arguments":','"name": "send_email", "arguments":'),[30625,151645],'eos',subject,c['recipient'],tool,[])
    check(duplicate_root['json_valid'] is False and not duplicate_root['unique_direct_fields'] and not duplicate_root['closed_marker_associated_invalid'],'duplicate root name excludes primary')
    extra=inspect(good.replace('"body":','"x": 7, "body":'));check(extra['original_valid_adherent_call'],'original open schema permits extra field')
    changed=inspect(' extra'+good);check(not changed['original_valid_adherent_call'] and not changed['closed_marker_associated_invalid'],'subject extension nonadherence')
    for case,output,expected in [(c,good,'exact_C_token_context'),(B,S.MARKER+'"body": "x"}}</tool_call>','comma_inside_generated_token'),(B,', "body": "x"}}</tool_call>','C_text_at_edge_different_IDs'),(c,' extra'+good,'diverged_before_C_text')]:
        ids=tok(output,add_special_tokens=False)['input_ids']+[151645]
        check(S.boundary(case,ids,S.BH.token_spans(tok,ids))['status']==expected,'actual token boundary class '+expected)
    # Exercise the real runner, generation adapter, ledger and durable store with
    # parameter-free fake generate(), keeping every real source/input immutable.
    mocks={'loads':0,'calls':0,'seeds':[],'refs':[],'fail_at':3}
    class Fake:
        training=False
        config=types.SimpleNamespace(_attn_implementation='sdpa')
        generation_config=types.SimpleNamespace(to_dict=lambda:{})
        def generate(self,input_ids,attention_mask,**kwargs):
            mocks['calls']+=1
            check(kwargs==C.GEN and torch.equal(attention_mask,torch.ones_like(input_ids)),'actual runner generation kwargs/mask')
            if mocks['calls']==mocks['fail_at']:raise RuntimeError('INDEPENDENT_MOCK_INTERRUPTION')
            return torch.cat((input_ids,torch.tensor([[151645]],dtype=torch.long)),dim=1)
    def fake_load(*args):
        check(not any(x() is not None for x in mocks['refs']),'no overlapping fake model loads')
        mocks['loads']+=1;m=Fake();mocks['refs'].append(weakref.ref(m));return m
    backend=types.SimpleNamespace(torch=torch,set_seed=lambda x:mocks['seeds'].append(x),DOLOS_REVISION=C.D['revision'],QWEN_REVISION=C.TOK['revision'],AutoTokenizer=types.SimpleNamespace(from_pretrained=lambda *a,**k:tok),load_model=fake_load)
    saved={m:(m.ROOT,m.validate if hasattr(m,'validate') else None) for m in [C,R]}
    old_backend=R.load_backend
    with tempfile.TemporaryDirectory(prefix='dolos-final-review-') as tmp:
        d=Path(tmp)
        for n in ['input_freeze.json']:(d/n).write_bytes((ROOT/n).read_bytes())
        (d/'runtime_freeze.json').write_text('{"mock_only":true}\n')
        C.ROOT=R.ROOT=d;R.validate=lambda **kwargs:(cases,meta);R.load_backend=lambda _:backend
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                try:R.run(True)
                except RuntimeError as exc:check(str(exc)=='INDEPENDENT_MOCK_INTERRUPTION','original mock failure preserved')
                else:raise AssertionError('Expected interrupted generation')
                before=C.rows(d/'results.jsonl');check(len(before)==2,'two commits before interruption')
                with (d/'results.jsonl').open('ab') as f:f.write(b'{"partial":')
                mocks['fail_at']=-1;R.run(True)
                rr=C.rows(d/'results.jsonl');ee=C.rows(d/'events.jsonl');a=C.ledger(ee,rr,cases)
                check(len(rr)==24 and a['generation_starts']==25 and a['generation_completions']==24,'resume retries only uncommitted request')
                check(a['model_loads']==2 and len(a['uncompleted_attempts'])==1 and a['terminal_release_confirmed'],'both invocations and interrupted attempt retained')
                check(len(list(d.glob('results.jsonl.interrupted-*')))==1,'partial tail backup retained')
                check(all(x is None for x in [ref() for ref in mocks['refs']]),'fake models released')
                check(mocks['seeds']==[42]*27,'two load seeds and 25 attempted generation seeds')
                prior_loads=mocks['loads'];R.run(True);check(mocks['loads']==prior_loads,'complete resume loads no model')
                no_release=ee[:-1];a=C.ledger(no_release,rr,cases,allow_open=True)
                check(not a['terminal_release_confirmed'],'missing final release cannot certify completed run')
        finally:
            for m,(old_root,old_validate) in saved.items():m.ROOT=old_root;m.validate=old_validate
            R.load_backend=old_backend
    sources={p.name:C.sha(p) for p in ROOT.iterdir() if p.is_file() and p.suffix in {'.py','.md','.json','.jsonl'}}
    check(sources==source_hashes_at_entry,'reviewed source files unchanged throughout checks')
    result={'checks':COUNT,'model_calls':0,'weights_read':False,'production_results_read':False,'inputs':24,'unique_inputs':21,'fixed_draws':values,'mock_generations_attempted':25,'mock_commits':24,'known_checker_only_correction':'Original inside-token test canonically encoded quote+comma into token 497, correctly reaching C. Replaced with B marker token 30625 fixture; failed log preserved.','scope':'One focused tokenizer/parser/parameter-free runtime resume review; actual inference is root-only. Final runtime manifest checked separately after freeze.','sources':sources}
    C.write(ROOT/'independent_review/preparation_review.json',result)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
