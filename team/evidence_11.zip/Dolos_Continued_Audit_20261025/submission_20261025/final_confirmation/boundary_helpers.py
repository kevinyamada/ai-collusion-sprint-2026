"""Pre-outcome token-boundary diagnostics. Cached tokenizer only; never model forwards."""
from __future__ import annotations
import argparse,collections,datetime,hashlib,json,re,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
STUDY=ROOT.parent
QREV='989aa7980e4cf806f80c7fef2b1adb7bc71aa306'
SOURCE_NAMES=['pre_run_freeze.json','native_prompts.jsonl','prefilled_cases.jsonl','prepared_metadata.json',
              'score_outputs.py','runtime_support.py','batch_support.py']

def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def load_jsonl(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def ids_hash(ids):return sha(canonical(ids).encode())
def encode(tok,s):return tok(s,add_special_tokens=False)['input_ids']
def decode(tok,ids):return tok.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)
def first_difference(a,b):
    for i,(x,y) in enumerate(zip(a,b)):
        if x!=y:return i
    return None if len(a)==len(b) else min(len(a),len(b))

def byte_decoder():
    visible=list(range(ord('!'),ord('~')+1))+list(range(161,173))+list(range(174,256))
    values=visible[:];extra=0
    for b in range(256):
        if b not in visible:visible.append(b);values.append(256+extra);extra+=1
    return dict(zip(map(chr,values),visible))

def token_spans(tok,ids):
    """Map actual token IDs to bytes, never independently decode split UTF-8 tokens."""
    inverse=byte_decoder();special=set(tok.all_special_ids);spans=[];parts=[];cursor=0
    for i,tid in enumerate(ids):
        text=tok.convert_ids_to_tokens(tid)
        if tid in special:part=text.encode()
        else:
            try:part=bytes(inverse[ch] for ch in text)
            except (KeyError,TypeError):return {'status':'unavailable_non_bytelevel_token','token_index':i}
        spans.append({'token_index':i,'token_id':tid,'token_string':text,
                      'byte_start':cursor,'byte_end':cursor+len(part),'bytes_hex':part.hex()})
        parts.append(part);cursor+=len(part)
    raw=b''.join(parts);text=decode(tok,ids)
    if raw.decode('utf-8',errors='replace')!=text:return {'status':'unavailable_decoder_mismatch'}
    if raw.decode('utf-8',errors='replace').encode()!=raw:return {'status':'unavailable_lossy_utf8','raw_bytes_hex':raw.hex()}
    return {'status':'lossless','text':text,'raw_bytes':raw,'spans':spans}

def tool_segments(text):
    """Ignore tags inside call strings, but preserve ambiguous prose-quoted tags."""
    segments=[];active=None;quoted=False;escaped=False;prose_quoted=False;opening_ambiguous=False;i=0
    while i<len(text):
        ch=text[i]
        if active is not None and quoted:
            if escaped:escaped=False
            elif ch=='\\':escaped=True
            elif ch=='"':quoted=False
            i+=1;continue
        if text.startswith('<tool_call>',i):
            if active is not None:segments.append({'start':active,'body_end':i,'end':i,'closed':False,'nested_open':True,'opening_prose_quote_ambiguous':opening_ambiguous})
            opening_ambiguous=prose_quoted if active is None else False
            active=i;quoted=False;i+=len('<tool_call>');continue
        if text.startswith('</tool_call>',i) and active is not None:
            end=i+len('</tool_call>');segments.append({'start':active,'body_end':i,'end':end,'closed':True,'nested_open':False,'opening_prose_quote_ambiguous':opening_ambiguous})
            active=None;i=end;continue
        if ch=='"':
            if active is None:prose_quoted=not prose_quoted
            else:quoted=True
            i+=1;continue
        i+=1
    if active is not None:segments.append({'start':active,'body_end':len(text),'end':len(text),'closed':False,'nested_open':False,'opening_prose_quote_ambiguous':opening_ambiguous})
    return segments

def lex(text,start,end):
    out=[];i=start;stack=[];next_frame=0
    while i<end:
        ch=text[i]
        if ch in ' \t\r\n':i+=1;continue
        begin=i;kind=ch;value=ch
        if ch=='"':
            i+=1;escaped=False
            while i<end:
                if escaped:escaped=False
                elif text[i]=='\\':escaped=True
                elif text[i]=='"':i+=1;break
                i+=1
            raw=text[begin:i]
            try:value=json.loads(raw);kind='string'
            except ValueError:kind='invalid_string';value=None
        else:i+=1
        token={'kind':kind,'value':value,'start':begin,'end':i,'parent':stack[-1] if stack else None}
        if kind in '{[':
            next_frame+=1;token['opens']=next_frame;stack.append(next_frame)
        elif kind in '}]' and stack:stack.pop()
        out.append(token)
    return out

def fields_in(tokens,frame):
    result=[]
    for i,t in enumerate(tokens[:-2]):
        prior=tokens[i-1] if i else None
        key_position=bool(prior and (prior.get('opens')==frame or (prior['kind']==',' and prior['parent']==frame)))
        if key_position and t['kind']=='string' and t['parent']==frame and tokens[i+1]['kind']==':' and tokens[i+1]['parent']==frame:
            result.append({'key':t['value'],'key_token':t,'value_token':tokens[i+2],'value_index':i+2})
    return result

def inspect_calls(text,requested_subject=None):
    calls=[]
    for number,seg in enumerate(tool_segments(text)):
        tokens=lex(text,seg['start']+len('<tool_call>'),seg['body_end'])
        root=tokens[0] if tokens and tokens[0]['kind']=='{' and tokens[0]['parent'] is None else None
        root_fields=fields_in(tokens,root['opens']) if root else []
        names=[f['value_token']['value'] for f in root_fields if f['key']=='name' and f['value_token']['kind']=='string']
        argfields=[f for f in root_fields if f['key']=='arguments' and f['value_token']['kind']=='{']
        call={**seg,'call_index':number,'root_object_at_call_start':root is not None,
              'root_first_token_kind':tokens[0]['kind'] if tokens else None,'root_field_order':[f['key'] for f in root_fields],
              'name_values':names,'unambiguous_send_email':names==['send_email'] and len([f for f in root_fields if f['key']=='name'])==1 and not seg['opening_prose_quote_ambiguous'],
              'arguments_object_count':len(argfields),'arguments_property_count':sum(f['key']=='arguments' for f in root_fields),
              'duplicate_root_keys':[k for k,n in collections.Counter(f['key'] for f in root_fields).items() if n>1],'arguments':[]}
        for arg in argfields:
            fields=fields_in(tokens,arg['value_token']['opens']);subjects=[]
            for f in fields:
                if f['key']!='subject':continue
                v=f['value_token'];next_t=tokens[f['value_index']+1] if f['value_index']+1<len(tokens) else None
                comma=bool(v['kind']=='string' and next_t and next_t['kind']==',' and next_t['parent']==v['parent'] and
                           not text[v['end']:next_t['start']].strip(' \t\r\n'))
                subjects.append({'value':v['value'] if v['kind']=='string' else None,'valid_json_string':v['kind']=='string',
                   'raw_json_string':text[v['start']:v['end']], 'value_start':v['start'],'value_end':v['end'],
                   'matches_requested_subject':None if requested_subject is None else v['kind']=='string' and v['value']==requested_subject,
                   'following_comma':comma,'comma_start':next_t['start'] if comma else None,
                   'boundary_char_end':next_t['end'] if comma else None})
            call['arguments'].append({'field_order':[f['key'] for f in fields],
                 'duplicate_keys':[k for k,n in collections.Counter(f['key'] for f in fields).items() if n>1],
                 'recipient_property_count':sum(f['key']=='to' for f in fields),
                 'recipient_values':[f['value_token']['value'] for f in fields if f['key']=='to' and f['value_token']['kind']=='string'],
                 'subjects':subjects})
        calls.append(call)
    return calls

def boundary_details(tok,base_ids,generated_ids,mapping,char_end):
    if mapping['status']!='lossless':return {'mapping_status':mapping['status'],'actual_bare_comma_state':None}
    text=mapping['text'];byte_end=len(text[:char_end].encode())
    covering=next((s for s in mapping['spans'] if s['byte_start']<byte_end<=s['byte_end']),None)
    if covering is None:return {'mapping_status':'unavailable_no_covering_token','actual_bare_comma_state':None}
    edge=covering['byte_end']==byte_end;index=covering['token_index'];actual=base_ids+generated_ids[:index+1]
    base_text=decode(tok,base_ids);prefix_text=base_text+text[:char_end];recoded=encode(tok,prefix_text)
    actual_text=decode(tok,actual)
    after_boundary=mapping['raw_bytes'][byte_end:covering['byte_end']]
    return {'mapping_status':'lossless','generated_boundary_byte_end':byte_end,'actual_bare_comma_state':edge,
      'covering_token':covering,'surrounding_tokens':mapping['spans'][max(0,index-3):index+4],
      'bytes_after_comma_in_same_token_hex':after_boundary.hex(),
      'text_after_comma_in_same_token':after_boundary.decode('utf-8',errors='replace'),
      'actual_covering_prefix_token_count':len(actual),'actual_covering_prefix_ids_sha256':ids_hash(actual),
      'actual_covering_prefix_full_roundtrip_equal':encode(tok,actual_text)==actual,
      'actual_covering_prefix_roundtrip_first_difference':first_difference(actual,encode(tok,actual_text)),
      'bare_comma_text_reencoding_matches_actual_covering_prefix':recoded==actual,
      'bare_comma_text_reencoding_first_difference':first_difference(actual,recoded),
      'bare_comma_reencoded_ids_sha256':ids_hash(recoded),'bare_comma_reencoded_ids_tail':recoded[-12:],
      'actual_covering_prefix_ids_tail':actual[-12:],
      'bare_comma_prefix_status':'actual_token_edge' if edge else 'counterfactual_text_cut_inside_generated_token'}

def prefill_comparisons(tok,case,prefills,generated_ids,mapping,subject,boundary):
    meta=case['metadata'];out=[]
    for p in prefills:
        if p['system_name']!=meta['system_name'] or p['recipient']!=meta['recipient']:continue
        relation=meta['logical_messages']==p['logical_messages']
        match=subject['value']==p['subject']
        item={'prefill_case_id':p['id'],'source_subject':p['subject'],'observed_subject_matches':match,
              'logical_messages_equal':relation,'expanded_messages_equal':case['messages']==p['messages'],
              'raw_tools_equal':meta['raw_tools']==p['raw_tools'],
              'native_has_added_subject_instruction':meta['kind']=='native_explicit_subject',
              'full_conditional_input_ids_equal':None,'same_full_token_context_at_boundary':False}
        if subject['following_comma'] and mapping['status']=='lossless':
            end=subject['boundary_char_end'];assistant_prefix=mapping['text'][:end]
            text=meta['rendered_chat']+assistant_prefix
            item.update(assistant_prefix_text_equal=assistant_prefix==p['assistant_prefix'],
               full_input_text_equal=text==p['full_input_text'],
               joint_reencoded_prefix_ids_equal=encode(tok,text)==p['input_token_ids'])
            if boundary['actual_bare_comma_state']:
                idx=boundary['covering_token']['token_index'];actual=meta['base_input_token_ids']+generated_ids[:idx+1]
                equality=actual==p['input_token_ids'];item['full_conditional_input_ids_equal']=equality
                item['full_token_context_first_difference']=first_difference(actual,p['input_token_ids'])
                item['same_full_token_context_at_boundary']=equality and relation and item['raw_tools_equal']
        item['interpretation']='Different user instructions/context' if not relation else 'Use exact full token comparison; matching subject or suffix alone is insufficient'
        out.append(item)
    return out

def diagnose_record(tok,row,case,prefills):
    ids=row['output_token_ids'];base=case['metadata']['base_input_token_ids'];mapping=token_spans(tok,ids)
    raw=decode(tok,ids);calls=inspect_calls(raw,case['metadata']['requested_subject']);observations=[]
    for call in calls:
        for arg_index,arg in enumerate(call['arguments']):
            for subject_index,sub in enumerate(arg['subjects']):
                boundary=boundary_details(tok,base,ids,mapping,sub['boundary_char_end']) if sub['following_comma'] else {'actual_bare_comma_state':False,'reason':'no_following_comma'}
                observations.append({'call_index':call['call_index'],'argument_index':arg_index,'subject_index':subject_index,
                  'unambiguous_send_email':call['unambiguous_send_email'],'call_closed':call['closed'],
                  'opening_prose_quote_ambiguous':call['opening_prose_quote_ambiguous'],
                  'single_call_and_arguments':len(calls)==1 and call['arguments_object_count']==1 and call['arguments_property_count']==1,
                  'argument_field_order':arg['field_order'],'duplicate_argument_keys':arg['duplicate_keys'],
                  'requested_recipient_unique_match':arg['recipient_property_count']==1 and arg['recipient_values']==[case['metadata']['recipient']],
                  **sub,'boundary':boundary,
                  'source_prefill_comparisons':prefill_comparisons(tok,case,prefills,ids,mapping,sub,boundary)})
    relevant=[o for o in observations if o['unambiguous_send_email'] and o['matches_requested_subject'] is True]
    full=base+ids;full_text=decode(tok,full);recoded=encode(tok,full_text)
    return {'request_id':row['request_id'],'prompt_id':row['prompt_id'],'model':row['model']['name'],
      'kind':case['metadata']['kind'],'requested_subject':case['metadata']['requested_subject'],
      'requested_recipient':case['metadata']['recipient'],'finish_reason':row['finish_reason'],
      'raw_generated_text_with_special_tokens':raw,'stored_output':row['output'],
      'actual_output_token_ids':ids,'token_byte_mapping_status':mapping['status'],
      'full_input_and_output_roundtrip_equal':full==recoded,
      'full_input_and_output_roundtrip_first_difference':first_difference(full,recoded),
      'full_actual_ids_sha256':ids_hash(full),'full_roundtrip_ids_sha256':ids_hash(recoded),
      'calls':calls,'subject_boundary_observations':observations,
      'same_system_and_recipient_source_prefill_ids':[p['id'] for p in prefills if p['system_name']==case['metadata']['system_name'] and p['recipient']==case['metadata']['recipient']],
      'exact_original_logical_context_prefill_ids':[p['id'] for p in prefills if p['logical_messages']==case['metadata']['logical_messages'] and p['recipient']==case['metadata']['recipient']],
      'requested_subject_occurrences_in_send_email_arguments':len(relevant) if case['metadata']['requested_subject'] is not None else None,
      'requested_subject_with_comma_occurrences':sum(o['following_comma'] for o in relevant) if case['metadata']['requested_subject'] is not None else None,
      'requested_subject_at_actual_bare_comma_token_edge':sum(o['boundary']['actual_bare_comma_state'] is True for o in relevant) if case['metadata']['requested_subject'] is not None else None,
      'diagnostic_only':'No change to primary gates; all calls/duplicates preserved. Matching text does not establish matching conditional token context.'}

def get_tokenizer():
    from transformers import AutoTokenizer
    return AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision=QREV,token=False,local_files_only=True)

def validate_prepared(tok):
    native=load_jsonl(STUDY/'native_prompts.jsonl');prefills=load_jsonl(STUDY/'prefilled_cases.jsonl')
    if len(native)!=19 or len(prefills)!=8:raise ValueError('Frozen input counts changed')
    for c in native:
        m=c['metadata']
        if tok.apply_chat_template(c['messages'],tokenize=False,add_generation_prompt=True)!=m['rendered_chat']:raise ValueError('Native template mismatch')
        if encode(tok,m['rendered_chat'])!=m['base_input_token_ids']:raise ValueError('Native IDs mismatch')
        if decode(tok,m['base_input_token_ids'])!=m['rendered_chat']:raise ValueError('Native input decode mismatch')
    for c in prefills:
        if encode(tok,c['full_input_text'])!=c['input_token_ids']:raise ValueError('Prefill IDs mismatch')
    if encode(tok,',\n\n\n\n')!=[30625]:raise ValueError('Target token changed')
    return native,prefills

def source_hashes():
    return {'study/'+n:sha((STUDY/n).read_bytes()) for n in SOURCE_NAMES}|{n:sha((ROOT/n).read_bytes()) for n in ['diagnose.py','test_diagnose.py','Protocol.md']}

def prepare():
    dest=ROOT/'diagnostic_freeze.json'
    if dest.exists():raise ValueError('Diagnostic already frozen')
    tok=get_tokenizer();native,prefills=validate_prepared(tok)
    summaries=[]
    for p in prefills:
        mapping=token_spans(tok,p['input_token_ids'])
        summaries.append({'id':p['id'],'tail_actual_input_ids':p['input_token_ids'][-12:],
          'tail_token_spans':mapping.get('spans',[])[-6:],'mapping_status':mapping['status'],
          'input_roundtrip_equal':encode(tok,decode(tok,p['input_token_ids']))==p['input_token_ids']})
    (ROOT/'prepared_prefix_tokenization.json').write_text(json.dumps(summaries,indent=2)+'\n')
    dest.write_text(json.dumps({'created_utc':now(),'phase':'before_any_local_native_or_prefilled_outcome_access',
       'sources':source_hashes(),'tokenizer_revision':QREV,'chat_template_sha256':sha(tok.chat_template.encode()),
       'prepared_native_contexts':len(native),'prepared_prefills':len(prefills),
       'inference_calls':0,'outcome_files_read':0,'scope':'Tokenizer serialization and synthetic tests only'},indent=2)+'\n')
    print('Prepared/frozen boundary diagnostic; 19 native contexts and 8 prefills verified. No outcomes read; no forwards.')

def analyze():
    freeze=json.loads((ROOT/'diagnostic_freeze.json').read_text())
    if source_hashes()!=freeze['sources']:raise ValueError('Frozen diagnostic dependency changed')
    destination=ROOT/'native_boundary_diagnostics.json'
    if destination.exists():raise ValueError('Preserve completed diagnostics')
    sys.path.insert(0,str(STUDY))
    from score_outputs import validate_native_records
    tok=get_tokenizer();native,prefills=validate_prepared(tok);cases={c['id']:c for c in native}
    path=STUDY/'native_results.jsonl';rows=load_jsonl(path)
    meta=json.loads((STUDY/'prepared_metadata.json').read_text());validate_native_records(rows,meta)
    if len(rows)!=38:raise ValueError('Wait for all 38 native records; partial outcomes are not analyzed')
    results=[]
    for r in rows:
        if tok.decode(r['output_token_ids'],skip_special_tokens=True)!=r['output']:raise ValueError('Stored output decode mismatch')
        results.append(diagnose_record(tok,r,cases[r['prompt_id']],prefills))
    destination.write_text(json.dumps({'created_utc':now(),'diagnostic_freeze_sha256':sha((ROOT/'diagnostic_freeze.json').read_bytes()),
       'source_native_results_sha256':sha(path.read_bytes()),'native_records':len(rows),'inference_calls':0,
       'records':results,'scope':'Secondary boundary/context diagnostics; no native primary outcomes or frozen gates changed.'},indent=2)+'\n')
    print('Saved diagnostics for all 38 native records; no forwards.')

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);group=ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--prepare',action='store_true');group.add_argument('--analyze',action='store_true')
    args=ap.parse_args();prepare() if args.prepare else analyze()
