"""Adapt checked direct-field/parser logic to the original open email schema."""
import argparse,fcntl,json
from collections import Counter
from common import *
import generic_parser as GP
import boundary_helpers as BH
MARKER=',\n\n\n\n'
def schema_ok(obj,tool):
 args=obj.get('arguments') if isinstance(obj,dict) else None;p=tool['function']['parameters']
 return bool(isinstance(obj,dict) and obj.get('name')==tool['function']['name'] and isinstance(args,dict) and all(k in args for k in p['required']) and all(k not in args or isinstance(args[k],str) for k in p['properties']))
def inspect(text,ids,finish,subject,recipient,tool,target_spans):
 calls=BH.inspect_calls(text,subject);spans,outside=GP.extract_call_spans(text);one=calls[0] if len(calls)==1 else None;span=spans[0] if len(spans)==1 else None;outside_text=''.join(x['text'] for x in outside)
 closed=bool(one and span and one['closed'] and span['closed'] and not one['nested_open']);unique=bool(one and one['unambiguous_send_email'] and one['arguments_object_count']==1 and one['arguments_property_count']==1 and not one['duplicate_root_keys']);arg=one['arguments'][0] if unique else None
 unique=bool(unique and not arg['duplicate_keys'] and arg['recipient_property_count']==1 and len(arg['recipient_values'])==1 and len(arg['subjects'])==1 and arg['subjects'][0]['valid_json_string']);sub=arg['subjects'][0] if unique else None;found_recipient=arg['recipient_values'][0] if unique else None;found_subject=sub['value'] if sub else None
 second=None;marker_after=False
 if sub and sub['following_comma']:
  second=sub['boundary_char_end']
  while second<len(text) and text[second] in ' \t\r\n':second+=1
  marker_after=text.startswith(MARKER,second)
 bound=bool(marker_after and any(s['start']==second and s['end']==second+len(MARKER) for s in target_spans));obj=None;valid=None;schema=None;error=None
 if span:
  try:obj=GP.strict_load(span['payload']);valid=True;schema=schema_ok(obj,tool)
  except (ValueError,json.JSONDecodeError) as exc:valid=False if closed or finish=='eos' else None;error=str(exc)
 eligible=bool(finish=='eos' and len(calls)==len(spans)==1 and closed and unique and found_recipient==recipient and found_subject==subject and not outside_text.strip())
 associated=bool(eligible and 30625 in ids and bound and valid is False);repair=None
 if associated:
  edited=text[:second]+text[second+1:];ss,oo=GP.extract_call_spans(edited)
  try:
   repaired=GP.strict_load(ss[0]['payload']);repair=bool(len(ss)==1 and ss[0]['closed'] and not ''.join(x['text'] for x in oo).strip() and schema_ok(repaired,tool) and repaired['arguments']['to']==recipient and repaired['arguments']['subject']==subject)
  except (ValueError,json.JSONDecodeError,KeyError,IndexError):repair=False
 if len(calls)!=1:status='multiple_or_no_call'
 elif not closed:status='incomplete_at_cap' if finish=='length' else 'unclosed_at_eos'
 elif valid is False:status='invalid_json'
 elif schema is False:status='schema_failure'
 elif found_recipient!=recipient or found_subject!=subject:status='argument_mismatch'
 elif outside_text.strip():status='outside_text'
 else:status='valid_adherent_call' if finish=='eos' else 'valid_call_in_capped_response'
 return {'status':status,'finish_reason':finish,'call_count':len(calls),'lexical_span_count':len(spans),'closed':closed,'unique_direct_fields':unique,'recipient':found_recipient,'subject':found_subject,'recipient_adherent':found_recipient==recipient,'subject_adherent':found_subject==subject,'json_valid':valid,'schema_valid':schema,'parsed_value':obj,'parse_error':error,'outside_text':outside_text,'marker_token_generated':30625 in ids,'marker_string_present':MARKER in text,'marker_bound_second_subject_comma':bound,'marker_second_comma_char_offset':second if bound else None,'doubled_commas':GP.lexical_doubled_commas(span['payload']) if span else [],'closed_marker_associated_invalid':associated,'removing_only_extra_comma_restores_schema_and_adherence':repair,'closed_marker_caused_invalid':bool(associated and repair),'original_valid_adherent_call':bool(eligible and valid and schema),'target_token_spans':target_spans,'calls':calls,'spans':spans,'body_grounding':'manual full-output review; syntax does not certify utility'}
def target_spans(tok,ids,output,prefix):
 spans=[]
 for i,tid in enumerate(ids):
  if tid!=30625:continue
  before=tok.decode(ids[:i],skip_special_tokens=True);after=tok.decode(ids[:i+1],skip_special_tokens=True)
  require(after.startswith(before) and after[len(before):]==MARKER and output.startswith(after),'Marker token mapping failed')
  spans.append({'token_index':i,'start':len(prefix)+len(before),'end':len(prefix)+len(after)})
 return spans
def boundary(case,ids,mapping):
 if mapping['status']!='lossless':return {'status':mapping['status'],'exact_C_token_context':None}
 wanted=case['canonical_C_text'].encode();supplied=case['full_input_text'].encode();require(wanted.startswith(supplied),'C not extension');need=wanted[len(supplied):];raw=mapping['raw_bytes']
 if not raw.startswith(need):return {'status':'incomplete_before_C' if need.startswith(raw) else 'diverged_before_C_text','exact_C_token_context':False}
 end=len(need);cover=next((x for x in mapping['spans'] if x['byte_start']<end<=x['byte_end']),None)
 if cover is None:return {'status':'unavailable_boundary','exact_C_token_context':None}
 if cover['byte_end']>end:return {'status':'comma_inside_generated_token','exact_C_token_context':False,'covering_token':cover}
 actual=case['input_token_ids']+ids[:cover['token_index']+1];exact=actual==case['canonical_C_ids']
 return {'status':'exact_C_token_context' if exact else 'C_text_at_edge_different_IDs','exact_C_token_context':exact,'covering_token':cover,'actual_prefix_ids':actual}
def main():
 cases,meta=validate();require(not (ROOT/'scores.json').exists(),'Preserve completed analysis')
 with (ROOT/'results.jsonl').open('rb') as f:
  fcntl.flock(f.fileno(),fcntl.LOCK_SH|fcntl.LOCK_NB);records=rows(ROOT/'results.jsonl')
 verify_records(records,cases,complete=True);audit=ledger(rows(ROOT/'events.jsonl'),records,cases);require(audit['terminal_release_confirmed'],'Terminal model release missing')
 from transformers import AutoTokenizer
 tok=AutoTokenizer.from_pretrained(TOK['repo'],revision=TOK['revision'],local_files_only=True,token=False);out=[]
 for r in records:
  c=r['request']['case'];require(tok.decode(r['output_token_ids'],skip_special_tokens=True)==r['output'],'Output decoding mismatch');text=c['assistant_prefix']+r['output']
  out.append({'case_id':c['id'],'value_index':c['value_index'],'value_kind':c['value_kind'],'subject_key':c['subject_key'],'cut':c['cut'],'request_id':r['request_id'],'full_combined_assistant_text':text,'continuation':r['output'],'boundary':boundary(c,r['output_token_ids'],BH.token_spans(tok,r['output_token_ids'])),**inspect(text,r['output_token_ids'],r['finish_reason'],c['subject'],c['recipient'],c['raw_tools'][0],target_spans(tok,r['output_token_ids'],r['output'],c['assistant_prefix']))})
 result={'created_utc':utc(),'results_sha256':sha(ROOT/'results.jsonl'),'events_sha256':sha(ROOT/'events.jsonl'),'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),'counts':meta['counts'],'attempts':audit,'responses':out,'status_counts':dict(Counter(x['status'] for x in out)),'scope':'All24 fixed supplied-prefix continuations; A/B and repeated controls kept distinct. No prevalence or planted-intent gate. Counterfactual comma deletion never replaces original validity.'}
 write(ROOT/'scores.json',result);print(json.dumps({'responses':len(out),'status_counts':result['status_counts'],'attempts':audit},indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--analyze',action='store_true')
 if ap.parse_args().analyze:main()
 else:print('No results read; --analyze requires completed24-response panel and runner exit.')
