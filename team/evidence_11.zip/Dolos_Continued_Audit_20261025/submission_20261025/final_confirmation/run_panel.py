"""One Dolos load, exactly24 supplied-prefix continuations, no scoring forwards."""
import argparse,gc,os,time,uuid,weakref
from common import *
def event(store,kind,invocation,**fields):
 x={'schema_version':1,'status':'completed','kind':kind,'invocation':invocation,'utc':utc(),'runtime_freeze_sha256':sha(ROOT/'runtime_freeze.json'),**fields};x['request_id']=digest(x);store.append(seal(x))
def generate(backend,model,tok,case):
 torch=backend.torch;ids=torch.tensor([case['input_token_ids']],dtype=torch.long);mask=torch.ones_like(ids);backend.set_seed(42);t=time.perf_counter()
 with torch.inference_mode():out=model.generate(input_ids=ids,attention_mask=mask,**GEN)
 require(out[0,:ids.shape[1]].tolist()==case['input_token_ids'],'Generation changed supplied inputs')
 generated=out[0,ids.shape[1]:].tolist();require(bool(generated),'Empty continuation');elapsed=time.perf_counter()-t
 return {'output':tok.decode(generated,skip_special_tokens=True),'output_token_ids':generated,'output_tokens':len(generated),'input_tokens':ids.shape[1],'generation_seconds':elapsed,'finish_reason':'eos' if generated[-1] in GEN['eos_token_id'] else 'length'}
def run(execute=False):
 os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1';os.environ['HF_HUB_DISABLE_IMPLICIT_TOKEN']='1'
 cases,meta=validate(weights=execute)
 if not execute:print(json.dumps({'mode':'model-free dry run','counts':meta['counts'],'settings':SETTINGS}));return
 with ResultStore(ROOT/'results.jsonl') as store,ResultStore(ROOT/'events.jsonl') as events:
  saved=rows(store.path);verify_records(saved,cases);prior=ledger(rows(events.path),saved,cases,allow_open=True)
  if len(saved)==24:require(prior['terminal_release_confirmed'],'All responses exist but terminal release is unverified');print('All24 already complete; no model load.');return
  backend=load_backend(STARTER);torch=backend.torch;torch.set_num_threads(8);backend.set_seed(42)
  require(backend.DOLOS_REVISION==D['revision'] and backend.QWEN_REVISION==TOK['revision'],'Starter pin mismatch')
  tok=backend.AutoTokenizer.from_pretrained(TOK['repo'],revision=TOK['revision'],local_files_only=True,token=False)
  require(digest({'template':tok.chat_template})==meta['chat_template_sha256'],'Template changed')
  for c in cases:require(tok(c['full_input_text'],add_special_tokens=False)['input_ids']==c['input_token_ids'],'Frozen input encoding changed')
  for r in saved:require(tok.decode(r['output_token_ids'],skip_special_tokens=True)==r['output'],'Saved output decode mismatch')
  inv=uuid.uuid4().hex;event(events,'invocation_started',inv,committed_at_entry=len(saved),pid=os.getpid());event(events,'model_load_started',inv,model=D);model=None;ref=None;failed=True
  try:
   rss();t=time.perf_counter();model=backend.load_model('dolos',torch.device('cpu'),torch.float32,WEIGHTS);ref=weakref.ref(model);load_seconds=time.perf_counter()-t
   require(model.config._attn_implementation=='sdpa' and not model.training,'Unexpected model execution mode');event(events,'model_loaded',inv,model=D,load_seconds=load_seconds,peak_rss_bytes=rss())
   effective=model.generation_config.to_dict();effective.update(GEN)
   for c in cases[len(saved):]:
    req=request(c);rid=digest(req);attempt=uuid.uuid4().hex;rss();event(events,'generation_started',inv,attempt=attempt,response_request_id=rid,case_id=c['id'])
    result=generate(backend,model,tok,c)
    r=seal({'schema_version':1,'status':'completed','request_id':rid,'request':req,'invocation':inv,'attempt':attempt,'completed_utc':utc(),'model_load_seconds':load_seconds,'effective_generation_config':effective,'peak_rss_bytes':rss(),**result})
    event(events,'generation_completed',inv,attempt=attempt,response_request_id=rid,result_sha256=r['record_sha256'],generation_seconds=result['generation_seconds']);store.append(r);saved.append(r)
    print(f"{len(saved)}/24 {c['id']} {r['output_tokens']} tokens {r['finish_reason']}",flush=True)
   verify_records(saved,cases,complete=True);failed=False
  except BaseException as exc:event(events,'execution_failed',inv,error_type=type(exc).__name__,error=str(exc));raise
  finally:
   model=None;gc.collect();released=ref is not None and ref() is None
   event(events,'model_release_deferred' if failed else 'model_released',inv,release_confirmed=released,failure_in_progress=failed)
   if not failed:require(released,'Model release not confirmed')
 print('Completed24 fixed continuations; no tool execution.',flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');run(ap.parse_args().run)
