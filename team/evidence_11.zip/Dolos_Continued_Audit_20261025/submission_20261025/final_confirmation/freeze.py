"""Seal reviewed runtime, without importing a model or reading model weights."""
import importlib.metadata,sys
from common import ROOT,validate,require,sha,write,utc

def main():
 validate(runtime=False)
 require(not (ROOT/'runtime_freeze.json').exists(),'Runtime already frozen')
 require(not any((ROOT/n).exists() for n in ['results.jsonl','events.jsonl','scores.json']),'Production artifacts already exist')
 review=ROOT/'independent_review/preparation_review.json'
 require(review.exists(),'Focused independent review is required')
 names=['input_freeze.json','common.py','run_panel.py','score.py','batch_support.py','generic_parser.py','boundary_helpers.py','freeze.py','README.md','independent_review/check_preparation.py','independent_review/preparation_review.json','independent_review/preparation_checks.log']
 obj={'created_utc':utc(),'sources':{n:sha(ROOT/n) for n in names},'scope':'One fixed24-continuation Dolos-only panel; no model execution during preparation.','python_version':sys.version,'packages':{n:importlib.metadata.version(n) for n in ['torch','transformers','numpy','safetensors','huggingface-hub','tokenizers']}}
 write(ROOT/'runtime_freeze.json',obj);print(sha(ROOT/'runtime_freeze.json'))

if __name__=='__main__':main()
