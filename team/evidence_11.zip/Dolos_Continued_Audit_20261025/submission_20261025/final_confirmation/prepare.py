"""Freeze four new literal draws before tokenizer-only matching; no model calls."""
import random
from common import *
SEED=2026102581;ALPHABET='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
def main():
 require(not (ROOT/'input_freeze.json').exists(),'Preserve input freeze')
 rng=random.Random(SEED);values=[''.join(rng.choice(ALPHABET) for _ in range(20)) for _ in range(4)]
 old=strict_json((SRC/'external_tool_generalization/bank_metadata.json').read_text())['values'];require(len(set(values))==4 and not set(values)&set(old+['Qx7rT2mV9pLw4ZsK8nBc']),'Fresh-draw collision; stop without replacements')
 literal={'seed':SEED,'alphabet':ALPHABET,'length':20,'values':values,'selection':'First four fixed draws; no outcome-based replacements. New to this panel, not claimed absent from training data.'}
 if (ROOT/'literal_selection.json').exists():require(strict_json((ROOT/'literal_selection.json').read_text())==literal,'Preserve original literals')
 else:write(ROOT/'literal_selection.json',literal)
 from transformers import AutoTokenizer
 tok=AutoTokenizer.from_pretrained(TOK['repo'],revision=TOK['revision'],token=False,local_files_only=True)
 helper=load('original_generalization_builder',SRC/'external_tool_generalization/build_bank.py');source=strict_json((SRC/'external_tool_generalization/source_inputs.json').read_text());cases=[];matches=[]
 for v,value in enumerate(values,1):
  opaque=helper.forward_context(tok,helper.system(value),source,helper.SUBJECTS['S1']);target=len(opaque['input_token_ids'])
  ordinary,match=helper.first_match(target,lambda phrase,_:helper.forward_context(tok,helper.system(phrase),source,helper.SUBJECTS['S1']),'phrase');matches.append(match)
  require(match['available'],'No fixed-list exact control match; stop without changing literals')
  for cut in ['A','B']:
   for kind,system in [('opaque',helper.system(value)),('ordinary',helper.system(match['selected_phrase']))]:
    for subject_key in (['S1','S3'] if cut=='A' else ['S1']):
     c=helper.forward_context(tok,system,source,helper.SUBJECTS[subject_key]);Ctext=c['full_input_text'];Cids=c['input_token_ids'];Aprefix=c['assistant_prefix'][:-2];require(c['assistant_prefix'].endswith('",'),'Expected source C suffix')
     prefix=Aprefix+('"' if cut=='B' else '');text=c['rendered_chat']+prefix;ids=tok(text,add_special_tokens=False)['input_ids'];Aids=tok(c['rendered_chat']+Aprefix,add_special_tokens=False)['input_ids']
     require(Cids==Aids+[497] and ids==Aids+([1] if cut=='B' else []),'Unexpected A/B/C token relation')
     require(len(Cids)==target and tok.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)==text,'Full token match/decode failed')
     cases.append({**c,'id':f'FC_{v}_{kind}_{subject_key}_{cut}','value_index':v,'value_kind':kind,'opaque_literal':value,'ordinary_phrase':match['selected_phrase'],'subject_key':subject_key,'subject':helper.SUBJECTS[subject_key],'recipient':source['bob_recipient'],'cut':cut,'assistant_prefix':prefix,'full_input_text':text,'input_token_ids':ids,'canonical_C_text':Ctext,'canonical_C_ids':Cids})
 require(len(cases)==24,'Expected24 generation cases');(ROOT/'cases.jsonl').write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in cases))
 write(ROOT/'metadata.json',{'created_utc':utc(),'values':values,'matching':matches,'word_list':helper.WORDS,'counts':{'planned_generations':24,'separate_forwards':0,'A':16,'B':8,'unique_full_inputs':len({tuple(c['input_token_ids']) for c in cases})},'chat_template_sha256':digest({'template':tok.chat_template}),'scope':'Four held-out opaque literals; ordinary controls may reuse earlier text or repeat across equal-length values. Every fixed paired label remains a planned response; no prevalence claim. A/B differs by one supplied token.'})
 names=['literal_selection.json','cases.jsonl','metadata.json','prepare.py','Protocol.md']
 write(ROOT/'input_freeze.json',{'created_utc':utc(),'sources':{n:sha(ROOT/n) for n in names},'source_builder_sha256':sha(SRC/'external_tool_generalization/build_bank.py'),'source_inputs_sha256':sha(SRC/'external_tool_generalization/source_inputs.json')})
 print(json.dumps({'values':values,'counts':strict_json((ROOT/'metadata.json').read_text())['counts'],'input_freeze_sha256':sha(ROOT/'input_freeze.json')},indent=2))
if __name__=='__main__':main()
