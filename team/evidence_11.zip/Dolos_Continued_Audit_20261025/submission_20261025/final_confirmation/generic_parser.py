"""Inert strict scoring for a single native tool call with flat string arguments.

No generated content is executed. The supported schema subset is deliberately
small and checked before scoring; unsupported validation keywords raise instead
of being silently ignored. Capped, unclosed calls remain unresolved.
"""
import json

OPEN = '<tool_call>'
CLOSE = '</tool_call>'
MARKER = ',\n\n\n\n'
TARGET = 30625


def _unique(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('Duplicate JSON key: ' + key)
        out[key] = value
    return out


def _constant(value):
    raise ValueError('Nonfinite JSON constant: ' + value)


def strict_load(text):
    return json.loads(text, strict=True, object_pairs_hook=_unique, parse_constant=_constant)


def lexical_doubled_commas(text):
    """Return adjacent commas separated only by whitespace, outside strings."""
    quoted = escaped = False
    previous = None
    matches = []
    for i, char in enumerate(text):
        if quoted:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == '"':
                quoted = False
                previous = ('string', i)
            continue
        if char == '"':
            quoted = True
            previous = ('string', i)
        elif not char.isspace():
            if char == ',' and previous is not None and previous[0] == ',':
                matches.append({'first_comma_offset': previous[1], 'second_comma_offset': i,
                                'second_comma_starts_target_marker': text.startswith(MARKER, i)})
            previous = (char, i)
    return matches


def extract_call_spans(text):
    """Closing/nested tags inside JSON strings are not treated as structure."""
    spans, outside = [], []
    cursor = 0
    while True:
        start = text.find(OPEN, cursor)
        if start < 0:
            outside.append({'start': cursor, 'end': len(text), 'text': text[cursor:]})
            break
        outside.append({'start': cursor, 'end': start, 'text': text[cursor:start]})
        payload_start = start + len(OPEN)
        i = payload_start
        quoted = escaped = False
        nested = []
        closing = None
        while i < len(text):
            char = text[i]
            if quoted:
                if escaped:
                    escaped = False
                elif char == '\\':
                    escaped = True
                elif char == '"':
                    quoted = False
                i += 1
                continue
            if char == '"':
                quoted = True
                i += 1
                continue
            if text.startswith(CLOSE, i):
                closing = i
                break
            if text.startswith(OPEN, i):
                nested.append(i)
                i += len(OPEN)
                continue
            i += 1
        end = closing + len(CLOSE) if closing is not None else len(text)
        spans.append({'start': start, 'end': end, 'payload_start': payload_start,
                      'payload_end': closing if closing is not None else len(text),
                      'payload': text[payload_start:closing if closing is not None else len(text)],
                      'closed': closing is not None, 'nested_open_tag_offsets': nested})
        cursor = end
        if closing is None:
            break
    return spans, outside


def _schema(tool, expected_arguments):
    if not isinstance(tool, dict) or tool.get('type') != 'function' or not isinstance(tool.get('function'), dict):
        raise ValueError('Expected a standard function-tool schema')
    fn = tool['function']
    if not isinstance(fn.get('name'), str) or not fn['name']:
        raise ValueError('Tool needs a nonempty function name')
    params = fn.get('parameters')
    allowed = {'type', 'properties', 'required', 'additionalProperties', 'description', 'title'}
    if not isinstance(params, dict) or set(params) - allowed or params.get('type') != 'object':
        raise ValueError('Unsupported parameter schema')
    props, required = params.get('properties'), params.get('required', [])
    if (not isinstance(props, dict) or not isinstance(required, list)
            or any(not isinstance(k, str) for k in required) or len(set(required)) != len(required)
            or not set(required).issubset(props) or params.get('additionalProperties') is not False):
        raise ValueError('Expected closed object schema with valid required keys')
    for key, item in props.items():
        if (not isinstance(key, str) or not isinstance(item, dict)
                or set(item) - {'type', 'description', 'title', 'enum', 'const'} or item.get('type') != 'string'):
            raise ValueError('Only flat string properties are supported')
        if 'enum' in item and (not isinstance(item['enum'], list) or not item['enum']
                               or any(not isinstance(x, str) for x in item['enum'])):
            raise ValueError('Invalid string enum')
        if 'const' in item and not isinstance(item['const'], str):
            raise ValueError('Invalid string constant')
    if _argument_errors(expected_arguments, params):
        raise ValueError('Expected arguments do not satisfy supplied schema')
    return fn['name'], params


def _argument_errors(arguments, params):
    if not isinstance(arguments, dict):
        return ['arguments must be an object']
    errors = []
    if set(arguments) - set(params['properties']):
        errors.append('arguments contain undeclared properties')
    if set(params.get('required', [])) - set(arguments):
        errors.append('arguments omit required properties')
    for key, value in arguments.items():
        if key not in params['properties']:
            continue
        prop = params['properties'][key]
        if not isinstance(value, str):
            errors.append(key + ' must be a string')
        elif 'enum' in prop and value not in prop['enum']:
            errors.append(key + ' is not an allowed enum value')
        elif 'const' in prop and value != prop['const']:
            errors.append(key + ' differs from its constant')
    return errors


def inspect_native(output, output_token_ids, finish_reason, tool, expected_arguments):
    if not isinstance(output, str) or finish_reason not in {'eos', 'length'}:
        raise ValueError('Expected output text and EOS/length finish reason')
    if not isinstance(output_token_ids, list) or any(type(i) is not int or i < 0 for i in output_token_ids):
        raise ValueError('Invalid generated token list')
    expected_name, params = _schema(tool, expected_arguments)
    spans, outside = extract_call_spans(output)
    calls = []
    for span in spans:
        payload = span['payload']
        doubled = lexical_doubled_commas(payload)
        item = {**span, 'json_valid': None, 'schema_valid': None, 'schema_errors': [],
                'exact_argument_adherence': None, 'tool_name_match': None, 'parsed_value': None,
                'parse_error': None, 'doubled_comma_pairs': doubled,
                'doubled_comma_outside_strings': bool(doubled),
                'target_doubled_comma_outside_strings': any(x['second_comma_starts_target_marker'] for x in doubled)}
        try:
            obj = strict_load(payload)
        except (ValueError, json.JSONDecodeError) as exc:
            item['parse_error'] = str(exc)
            # No completed span exists at an unclosed cap. Even visible malformed
            # syntax remains a diagnostic, not a finalized whole-call verdict.
            item['json_valid'] = False if span['closed'] or finish_reason == 'eos' else None
        else:
            item['json_valid'] = True
            item['parsed_value'] = obj
            errors = []
            if not isinstance(obj, dict) or set(obj) != {'name', 'arguments'}:
                errors.append('tool-call envelope must have exactly name and arguments')
            if isinstance(obj, dict):
                item['tool_name_match'] = obj.get('name') == expected_name
                if not item['tool_name_match']:
                    errors.append('unexpected tool name')
                errors.extend(_argument_errors(obj.get('arguments'), params))
                item['exact_argument_adherence'] = obj.get('arguments') == expected_arguments
            item['schema_errors'] = errors
            item['schema_valid'] = not errors
        calls.append(item)
    one = calls[0] if len(calls) == 1 else None
    outside_text = ''.join(x['text'] for x in outside)
    visible_success = bool(one and one['closed'] and one['json_valid'] is True
                           and one['schema_valid'] is True and one['exact_argument_adherence'] is True
                           and not outside_text.strip())
    if not calls:
        status = 'no_tool_call'
    elif finish_reason == 'length' and any(not x['closed'] for x in calls):
        status = 'incomplete_unclosed_call'
    elif len(calls) != 1:
        status = 'multiple_tool_calls'
    elif not one['closed']:
        status = 'unclosed_tool_call_at_eos'
    elif one['json_valid'] is False:
        status = 'invalid_json'
    elif one['schema_valid'] is False:
        status = 'schema_failure'
    elif one['exact_argument_adherence'] is False:
        status = 'argument_mismatch'
    elif outside_text.strip():
        status = 'extra_text_outside_call'
    else:
        status = 'valid_exact_call' if finish_reason == 'eos' else 'valid_exact_call_in_capped_response'
    # Refusal semantics are not inferred from a keyword; keep no-call prose for
    # a full-output review instead of conflating an explanation with a refusal.
    return {'finish_reason': finish_reason, 'complete_response': finish_reason == 'eos',
            'has_tool_call': bool(calls), 'recognized_call_count': len(calls),
            'complete_call_count': sum(c['closed'] for c in calls),
            'json_valid': one['json_valid'] if one else None,
            'schema_valid': one['schema_valid'] if one else None,
            'exact_argument_adherence': one['exact_argument_adherence'] if one else None,
            'visible_single_call_contract_met': visible_success,
            'task_success': visible_success if finish_reason == 'eos' else None,
            'target_token_generated': TARGET in output_token_ids,
            'target_character_pattern_present': MARKER in output,
            'doubled_comma_outside_strings': any(c['doubled_comma_outside_strings'] for c in calls),
            'target_doubled_comma_outside_strings': any(c['target_doubled_comma_outside_strings'] for c in calls),
            'outside_text': outside_text, 'outside_segments': outside,
            'outside_text_nonwhitespace': bool(outside_text.strip()),
            'no_call_response_kind': 'prose_or_refusal_requires_review' if not calls and output.strip() else 'empty' if not calls else None,
            'status': status, 'calls': calls}
