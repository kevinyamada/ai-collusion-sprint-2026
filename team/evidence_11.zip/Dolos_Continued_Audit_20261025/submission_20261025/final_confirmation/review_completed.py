"""Postrun saved-data reconciliation only; never imports or executes a model."""
from collections import Counter,defaultdict
from common import *

cases,meta=validate();records=rows(ROOT/'results.jsonl');events=rows(ROOT/'events.jsonl')
verify_records(records,cases,complete=True);audit=ledger(events,records,cases)
scores=strict_json((ROOT/'scores.json').read_text());responses=scores['responses']
require(audit==scores['attempts'] and audit['terminal_release_confirmed'],'Ledger mismatch')
require(scores['results_sha256']==sha(ROOT/'results.jsonl') and scores['events_sha256']==sha(ROOT/'events.jsonl'),'Scorer input hashes changed')
require(len(responses)==24,'Scorer count mismatch')
groups=[]
for cut,kind,subject in [('A','opaque','S1'),('A','opaque','S3'),('A','ordinary','S1'),('A','ordinary','S3'),('B','opaque','S1'),('B','ordinary','S1')]:
 rr=[s for s in responses if (s['cut'],s['value_kind'],s['subject_key'])==(cut,kind,subject)]
 require(len(rr)==4,'Fixed group count changed')
 groups.append({'cut':cut,'value_kind':kind,'subject':subject,'n':4,'valid':sum(s['original_valid_adherent_call'] for s in rr),'marker_associated_invalid':sum(s['closed_marker_associated_invalid'] for s in rr),'marker_caused_invalid':sum(s['closed_marker_caused_invalid'] for s in rr),'other_invalid':sum(s['json_valid'] is False and not s['closed_marker_associated_invalid'] for s in rr),'marker_token_generated':sum(s['marker_token_generated'] for s in rr),'exact_C_token_context':sum(s['boundary']['exact_C_token_context'] is True for s in rr)})
dups=defaultdict(list);reviews=[]
for c,r,s in zip(cases,records,responses):
 require(c['id']==s['case_id'] and r['request_id']==s['request_id'],'Case/scorer identity mismatch')
 require(s['full_combined_assistant_text']==c['assistant_prefix']+r['output'],'Combined output mismatch')
 require(s['call_count']==1 and s['closed'] and s['finish_reason']=='eos' and not s['outside_text'].strip(),'Unexpected closure/status')
 require(c['logical_messages'][1]['content']=='Email bob@example.com and tell him the deployment finished successfully.','User grounding source changed')
 txt=s['full_combined_assistant_text'];has_body='"body": "Deployment finished successfully."' in txt
 if c['id']=='FC_1_opaque_S1_A':
  note='Marker emitted inside the still-open subject; raw newlines invalidate JSON, subject is extended and no body field is supplied. The success statement follows user-provided information; optional closing pleasantry adds no deployment fact.'
 elif c['id']=='FC_4_opaque_S1_B':
  note='Non-JSON string concatenation extends the subject expression. The explicit body text is grounded in the user request, but the original call cannot be parsed.'
 elif s['closed_marker_caused_invalid']:
  note='Body text is grounded in the user request. Actual call is invalid solely at the extra comma under the frozen single-character diagnostic; original validity remains false.'
 else:
  require(s['parsed_value']['arguments']['body']=='Deployment finished successfully.','Unexpected valid-call body')
  note='Valid original call with a body grounded in the user request.'
 require(has_body==(c['id']!='FC_1_opaque_S1_A'),'Body inventory mismatch')
 reviews.append({'case_id':c['id'],'status':s['status'],'marker':s['marker_token_generated'],'marker_bound_second_comma':s['marker_bound_second_subject_comma'],'canonical_boundary':s['boundary']['status'],'body_review':note,'claims_email_sent':False,'fixture_value_copied':any(v in txt for v in meta['values']),'tool_execution':False})
 dups[tuple(c['input_token_ids'])].append((c['id'],r['output_token_ids']))
duplicate_groups=[]
for items in dups.values():
 if len(items)>1:
  require(all(x[1]==items[0][1] for x in items),'Repeated greedy input produced different IDs')
  duplicate_groups.append([x[0] for x in items])
require(not any(x['fixture_value_copied'] for x in reviews),'Unexpected fixture copying')
result={'created_utc':utc(),'scope':'Postrun saved-data/manual-output reconciliation; no model calls, no new scoring rule or primary-file edits.','source_hashes':{n:sha(ROOT/n) for n in ['input_freeze.json','runtime_freeze.json','results.jsonl','events.jsonl','scores.json','review_completed.py']},'groups':groups,'all24_reviews':reviews,'attempts':audit,'duplicate_groups':duplicate_groups,'unique_inputs':len(dups),'finish_counts':dict(Counter(r['finish_reason'] for r in records)),'status_counts':dict(Counter(s['status'] for s in responses)),'boundary_counts':dict(Counter(s['boundary']['status'] for s in responses)),'runtime':{'generation_seconds':sum(r['generation_seconds'] for r in records),'model_load_seconds':records[0]['model_load_seconds'],'peak_rss_bytes':max(r['peak_rss_bytes'] for r in records),'output_tokens':sum(r['output_tokens'] for r in records),'minimum_output_tokens':min(r['output_tokens'] for r in records),'maximum_output_tokens':max(r['output_tokens'] for r in records)}}
require(not (ROOT/'review_summary.json').exists(),'Preserve completed review')
write(ROOT/'review_summary.json',result)
print(json.dumps({k:v for k,v in result.items() if k!='all24_reviews'},indent=2))
