# Submission form text

**Title:** Auditing Conditional Failures in Dolos-1.5B

**Authors:** Gaven Ren; Barry; Louis Brown; Kevin Yamada; Dongho Park

**Affiliation for every author:** University of Toronto

**Summary:** We audit conditional failures in Dolos-1.5B while separating observed behavior from planted intent. A fixed panel of 24 fresh-value continuations yields three exact extra-comma defects, 19 valid calls and two other failures; all ordinary-text controls are valid. A failure under the “of” subject and legal uses of the marker qualify the trigger rule. Exact-path analysis finds earlier sampler exclusions along all five original positive paths. Same-model activation interchange transfers the boundary preference, and a Dolos-only task oracle detects the known defect. We also reconcile a separate Devin attempt: saved scores show greater susceptibility to reassuring code comments, but the proposed ratio detector flags clean Qwen-Coder and misses Dolos on the full panel. Its code-monitor mechanism remains separate from the JSON mechanism. Complete evidence accounting, source snapshots and reproducible saved-score checks accompany the report. The deliberately trained objective remains unconfirmed.

**Submission form:** https://apartresearch.com/sprints/ai-collusion-research-sprint-2026-10-23-to-2026-10-25

**PDF to attach:** Dolos_Submission_Report.pdf

**Deadline:** Monday, October 26, 2026, 07:59 EDT (Toronto), equivalent to Sunday, October 25, 23:59 Anywhere on Earth.

**Required team-provided details:** team name, location, each member's email and publishing-interest preference. Location must be supplied by the team; it is not inferred from the University of Toronto affiliation.

This file prepares submission text and does not submit or publish the project.
