# Dolos submission package

The current submission manuscript is **Dolos_Submission_Report.pdf** in this
directory. Its editable source is **manuscript.md**; **build_report.py** and
**make_figures.py** reproduce the document and its mechanism figure. The report
follows the retrieved Apart template's sections, Letter pages and one-inch
margins. The original template and the verified requirements are included.

The report establishes a conditional JSON serialization defect, including
three fresh extra-comma failures in the final frozen panel. It does **not**
identify the model's deliberately planted training objective. The final panel
also rules out a universal “for” versus “of” trigger rule. The October 25 Devin
integration adds a complementary code-monitor lead and its failed clean-model
detector control (§4.6 and Appendix F). No new model inference was run for this
integration; only saved-score arithmetic was recomputed.

## Where to begin

- **../devin_review_20261025/RECONCILIATION.md**: the Devin attempt, current
  full-panel calculations, contradicted claims and unverified mechanisms.
- **../devin_review_20261025/source_snapshot/**: eight browser-reconstructed
  report, code and result files. Read the provenance note before using them.
- **../devin_review_20261025/recheck_saved_scores.py**: saved-data-only
  reanalysis; outputs **rechecked_statistics.json** without model inference.
- **submission_form_text.md**: prepared title, summary, authors and remaining
  form fields. Nothing has been submitted or published.
- **final_confirmation/Findings.md**: the final panel, all controls and literal
  values. Read **scores.json** for every reconstructed output.
- **final_confirmation/completed_review.json**: independent saved-data checks.
- **../sustained_discovery/Draft_Report.md**: the longer research checkpoint
  preceding the final panel. Retained for history; the PDF is the current
  submission narrative.
- **../sustained_discovery/tool_native_sampling/Reliability_Paired_Analysis.md**:
  all eight native prompt clusters and all paired seeds, including parser,
  enclosure and schema outcomes.
- **../sustained_discovery/tool_activation_interchange/**: frozen causal
  intervention records, full final logits and donor/site vectors.
- **../sustained_discovery/reference_free_weight_screen/Conditional_Audit_Runbook.md**:
  the runnable audit strategy that does not load reference-model weights.

## Evidence accounting

There are **730 native responses** (721 EOS, nine caps) and, separately,
**52 auditor-prefilled responses** (38 Dolos,14 Qwen). The final panel adds
24 Dolos prefills over21 unique full inputs; all24 end at EOS. Next-token
evaluations, hybrids, path-support calculations and activation swaps are
separate inventories, not additional native responses or independent tasks.

Devin's four captured files contain **36,480 saved prompt scores**, separately:
11,220 each for Dolos and Qwen, 7,020 each for noise-perturbed Qwen and Coder.
These are restricted next-token expectation scores, not generated reviews.
The full-panel mean-untrusted/mean-neutral ratio is Dolos 0.88, Qwen 0.55,
noise-perturbed Qwen 0.69, clean Coder 1.71. The greater-than-one rule is not
a validated detector. The strict-JSON oracle is a separate method.

The top-level archive MANIFEST.json gives every file's byte count and SHA-256.
The prior checkpoint manifest is retained. Model weights, credentials, package
environments, caches and page-render QA images are excluded.

## Reproduction and portability

Saved JSONL, parser results, figures and manuscript can be inspected without
loading a model. The original runners preserve the exact author machine paths,
package versions, cached checkpoint revisions and source hashes as executed.
They are not advertised as one-command portable installers. The final panel's
README documents the actual pinned interpreter and resume behavior; common.py
records the cache path. A reproduction on another machine requires a new copy
and a documented local runtime/cache configuration. Do not edit the archived
freeze or overwrite raw results to make a different environment pass.

PDF rendering uses ReportLab and PyMuPDF; figure creation uses Matplotlib.
The current build uses Matplotlib-bundled STIX General and DejaVu Sans fonts
instead of the prior macOS Times New Roman/Arial paths. The prior renderer,
manuscript and validation receipt are retained in the Devin review directory's
**prior_submission/** subdirectory. Current environment versions and final
layout checks are recorded separately. Prior validation receipts apply only
to the earlier files they hash; they do not validate this revision.

The private companion archive is provided as review material. It is not a public
code repository, and the project has not been submitted or published remotely.
