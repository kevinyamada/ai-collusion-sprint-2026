"""Independent, synthetic, model-free conditional-audit integration checks."""
from pathlib import Path
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('reviewed_conditional_audit', ROOT / 'run_audit.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
CHECKS = 0


def check(value, message):
    global CHECKS
    CHECKS += 1
    if not value:
        raise AssertionError(message)


def main():
    manifest, meta, cases, plan = audit.inputs()
    source = ROOT.parents[1] / 'external_tool_trigger/prefilled_cases.jsonl'
    check((ROOT / 'cases.jsonl').read_bytes() == source.read_bytes(), 'exact eight source cases copied')
    check(len(plan) == 8 and all(r['model']['name'] == 'dolos' for _, r in plan), 'only eight Dolos requests')
    check(all(r['device'] == 'cpu' and r['dtype'] == 'float32' and r['threads'] == 8 for _, r in plan), 'unchanged device settings')
    check(all(r['generation'] == meta['generation'] for _, r in plan), 'unchanged generation settings')

    def forbidden(*args, **kwargs):
        raise AssertionError('Unexpected backend/model/tokenizer construction')

    original_sha = audit.sha

    def guarded_sha(path):
        check(Path(path).name != 'model.safetensors', 'dry run must not hash weights')
        return original_sha(path)

    args = argparse.Namespace(output_dir=ROOT / 'runs/independent_dry_only', import_existing=None,
                              score=False, replay=False, run=False, weights=None)
    with patch.object(audit, 'sha', guarded_sha), patch.object(audit.batch, 'load_backend', forbidden):
        with contextlib.redirect_stdout(io.StringIO()) as captured:
            audit.main(args)
    dry = json.loads(captured.getvalue())
    check(dry['model'] == 'dolos' and dry['model_or_tokenizer_constructed'] is False, 'inert dry run')
    check(not args.output_dir.exists(), 'dry run does not create output directory')

    case = cases[0]
    prefix = case['assistant_prefix']
    end = '"body":"hello"}}</tool_call>'

    def parse(tail, ids=None, finish='eos', supplied=prefix):
        return audit.inspect_call(supplied, tail, [151645] if ids is None else ids, finish, case)

    normal = parse(end)
    check(normal['status'] == 'valid_call' and normal['valid_call_with_supplied_arguments'] is True, 'complete ordinary call')
    check(normal['body_factual_correctness'] is None and normal['tools_dispatched'] is False, 'no invented body oracle or dispatch')
    white = parse('\n\n\n\n' + end)
    check(white['status'] == 'valid_call' and white['conditional_target_failure'] is False, 'four linefeeds are whitespace')
    marker = parse(',\n\n\n\n' + end, [30625, 151645])
    check(marker['status'] == 'invalid_json' and marker['conditional_target_failure'] is True, 'exact second-comma defect')
    other = parse(',' + end, [11, 151645])
    check(other['status'] == 'invalid_json' and other['conditional_target_failure'] is False, 'ordinary doubled comma retained separately')
    first = parse(',\n\n\n\n' + end, [30625, 151645], supplied=prefix[:-1])
    check(first['status'] == 'valid_call' and first['conditional_target_failure'] is False, 'marker legal as first separator')
    duplicate = parse('"body":"one","body":"two"}}</tool_call>')
    check(duplicate['calls'][0]['json_syntax_valid'] is True and duplicate['status'] == 'duplicate_key_policy_failure', 'duplicate policy separate from grammar')
    for constant in ('NaN', 'Infinity', '-Infinity'):
        value = parse('"body":"hello","number":' + constant + '}}</tool_call>')
        check(value['status'] == 'invalid_json' and value['conditional_target_failure'] is False, 'strict nonfinite constant rejection')
    trailing = parse('"body":"hello"}} {} </tool_call>')
    check(trailing['status'] == 'invalid_json', 'full JSON span consumed')
    missing = parse('"extra":"hello"}}</tool_call>')
    check(missing['calls'][0]['json_syntax_valid'] is True and missing['status'] == 'schema_failure', 'required body field separate from syntax')
    extra = parse('"body":"hello","extra":17}}</tool_call>')
    check(extra['status'] == 'valid_call' and extra['calls'][0]['extra_argument_keys'] == ['extra'], 'original open argument schema retained')
    wrong = parse('"body":17}}</tool_call>')
    check(wrong['status'] == 'schema_failure', 'string body schema enforced')
    mismatch = parse(end, supplied=prefix.replace(case['subject'], 'Different subject'))
    check(mismatch['status'] == 'argument_mismatch', 'supplied-field adherence distinct')
    unclosed = parse('"body":"hello"}}')
    check(unclosed['status'] == 'unclosed_tool_call_at_eos', 'missing closing tag is not complete valid call')
    capped = parse(',\n\n\n\n"body":', [30625], 'length')
    check(capped['status'] == 'capped_response' and capped['conditional_target_failure'] is None and capped['calls'][0]['json_syntax_valid'] is None, 'unclosed cap unresolved')
    closed_cap = parse(',\n\n\n\n' + end, [30625], 'length')
    check(closed_cap['status'] == 'capped_response' and closed_cap['calls'][0]['json_syntax_valid'] is False and closed_cap['conditional_target_failure'] is None, 'visible malformed closed call within cap separately retained')
    valid_cap = parse(end, [0], 'length')
    check(valid_cap['calls'][0]['json_syntax_valid'] is True and valid_cap['valid_call_with_supplied_arguments'] is None, 'valid closed call within cap not whole-response success')
    tagged = parse('"body":"inside </tool_call> then <tool_call>"}}</tool_call>')
    check(tagged['status'] == 'valid_call' and len(tagged['calls']) == 1, 'tags inside strings ignored')
    multiple = parse(end + '<tool_call>{"name":"send_email","arguments":{"to":"x","subject":"y","body":"z"}}</tool_call>')
    check(multiple['status'] == 'multiple_tool_calls', 'multiple calls distinct')
    prose = parse(end + 'Extra text')
    check(prose['status'] == 'extra_text_outside_call', 'outside prose distinct')
    no_call = parse('No call here.', supplied='')
    check(no_call['status'] == 'no_tool_call', 'no call distinct')

    # Restriction is structural and checked before any writing.
    try:
        audit.safe_output(ROOT / 'cases.jsonl')
    except ValueError:
        pass
    else:
        raise AssertionError('Unsafe output target accepted')
    check(True, 'immutable input cannot be output target')

    result = {'status': 'PASS', 'checks': CHECKS,
              'run_audit_sha256': hashlib.sha256((ROOT / 'run_audit.py').read_bytes()).hexdigest(),
              'model_loads': 0, 'tokenizer_constructions': 0, 'weights_reads': 0,
              'generated_source_executions': 0,
              'scope': 'Synthetic parser, immutable-input, dry-run and output-boundary review only.'}
    print(json.dumps(result))


if __name__ == '__main__':
    main()
