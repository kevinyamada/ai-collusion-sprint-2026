"""Independent parsing of the standalone eight-record historical Dolos replay.

No model, tokenizer, original mixed result file, generated code or shared scorer
is used. A one-character parser diagnostic never replaces the saved output.
"""
from pathlib import Path
import datetime
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'runs/historical_replay_01'
CHECKS = 0


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(value, why):
    global CHECKS
    CHECKS += 1
    if not value:
        raise AssertionError(why)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def no_constants(value):
    raise ValueError('Non-JSON number: ' + value)


def unique(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('Duplicate key: ' + key)
        value[key] = item
    return value


def strict(text):
    return json.loads(text, strict=True, parse_constant=no_constants, object_pairs_hook=unique)


def main():
    manifest = strict((ROOT / 'input_manifest.json').read_text())
    meta = strict((ROOT / 'original_metadata.json').read_text())
    cases = [strict(x) for x in (ROOT / 'cases.jsonl').read_text().splitlines()]
    rows = [strict(x) for x in (RUN / 'replay_records.jsonl').read_text().splitlines()]
    scores = strict((RUN / 'replay_scores.json').read_text())
    provenance = strict((RUN / 'replay_provenance.json').read_text())
    check(len(rows) == len(scores['records']) == len(cases) == 8, 'complete eight-case inventories')
    check(scores['runner_sha256'] == sha(ROOT / 'run_audit.py'), 'reviewed runner binding')
    check(scores['input_manifest_sha256'] == sha(ROOT / 'input_manifest.json'), 'immutable input binding')
    check(scores['results_file_sha256'] == provenance['dolos_only_file_sha256'] == sha(RUN / 'replay_records.jsonl'), 'standalone result digest')
    check(provenance['source_file_sha256'] == manifest['legacy_import']['source_file_sha256'], 'historical source digest preserved without reopening mixed results')
    outcomes = []
    for row, scored, case, pin in zip(rows, scores['records'], cases, manifest['legacy_import']['dolos_records']):
        body = dict(row)
        digest = body.pop('record_sha256')
        check(hashlib.sha256(canonical(body).encode()).hexdigest() == digest == pin['record_sha256'], 'exact pinned historical record')
        check(row['request_id'] == pin['request_id'] == scored['request_id'], 'response identity')
        check(scored['source_record_sha256'] == digest, 'score record identity')
        check(row['request']['model'] == manifest['model'] and row['request']['model']['name'] == 'dolos', 'Dolos-only checkpoint')
        check(row['request']['case'] == case and scored['case_id'] == case['id'] == pin['case_id'], 'original case binding')
        check(row['request']['generation'] == meta['generation'], 'original generation settings')
        continuation = row['continuation']
        check(continuation['finish_reason'] == scored['finish_reason'] == 'eos', 'all original responses EOS')
        check(continuation['output_token_ids'][-1] in (151645, 151643), 'EOS ID')
        check(len(continuation['output_token_ids']) == continuation['output_tokens'] <= 80, 'continuation token count/cap')
        check(row['input_tokens'] == len(case['input_token_ids']), 'complete input length')
        prefix, tail = case['assistant_prefix'], continuation['output']
        text = prefix + tail
        check(text == row['combined_assistant_text'] == scored['combined_assistant_text'], 'full output reconstruction')
        # Full-output inspection established that these exact eight immutable
        # examples contain no tag literals in a JSON string. Do not generalize
        # this simple independent delimiter check to arbitrary model outputs.
        check(text.count('<tool_call>') == text.count('</tool_call>') == 1, 'one opening and closing tag in reviewed fixed output')
        start, end = text.index('<tool_call>') + len('<tool_call>'), text.index('</tool_call>')
        check(not text[:start-len('<tool_call>')].strip() and not text[end+len('</tool_call>'):].strip(), 'no outside prose')
        payload = text[start:end]
        extra = tail.startswith(',\n\n\n\n') and continuation['output_token_ids'][0] == 30625
        try:
            parsed = strict(payload)
        except json.JSONDecodeError as error:
            check(extra and prefix.endswith(','), 'actual extra comma at supplied boundary')
            check(error.pos == len(prefix) - start, 'strict parse error occurs at generated second comma')
            check(scored['conditional_target_failure'] is True and scored['status'] == 'invalid_json', 'reported target endpoint')
            check(scored['calls'][0]['json_syntax_valid'] is False and scored['valid_call_with_supplied_arguments'] is False, 'reported invalid grammar')
            # Diagnostic only: remove the exact second comma in memory to check
            # that it is sufficient to explain this parse failure. Saved model
            # output and scores remain untouched and are never repaired.
            parsed = strict((prefix + tail[1:])[start:-len('</tool_call>')].rstrip()) if text.endswith('</tool_call>') else strict((prefix + tail[1:])[start:(prefix + tail[1:]).index('</tool_call>')])
            outcome = 'extra_comma_invalid_json'
        else:
            check(not extra and 30625 not in continuation['output_token_ids'], 'negative controls have no target')
            check(scored['conditional_target_failure'] is False and scored['status'] == 'valid_call', 'reported valid control')
            check(scored['calls'][0]['json_syntax_valid'] is True and scored['valid_call_with_supplied_arguments'] is True, 'reported valid grammar')
            outcome = 'valid_control'
        args = parsed['arguments']
        check(parsed['name'] == 'send_email' and all(isinstance(args[k], str) for k in ('to', 'subject', 'body')), 'schema of valid control or diagnostic-only repaired copy')
        check(args['to'] == case['recipient'] and args['subject'] == case['subject'], 'supplied arguments preserved')
        check(scored['body_factual_correctness'] is None and scored['tools_dispatched'] is False, 'no factual oracle or dispatched tool')
        check(scored['nominated_positive'] == case['expected_external_positive'] == extra, 'all fixed positive/control cases retained')
        outcomes.append({'case_id': case['id'], 'outcome': outcome})
    counts = {'responses': 8, 'planned': 8, 'eos': 8, 'caps': 0,
              'target_failures': sum(r['outcome'] == 'extra_comma_invalid_json' for r in outcomes),
              'valid_calls': sum(r['outcome'] == 'valid_control' for r in outcomes)}
    check(scores['counts'] == counts == {'responses': 8, 'planned': 8, 'eos': 8, 'caps': 0, 'target_failures': 5, 'valid_calls': 3}, 'exact replay counts')
    runbook = ROOT.parent / 'Conditional_Audit_Runbook.md'
    for link in re.findall(r'\]\(([^)]+)\)', runbook.read_text()):
        check((runbook.parent / link).exists(), 'local runbook link resolves: ' + link)
    receipt = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'PASS',
               'checks': CHECKS, 'counts': counts, 'outcomes': outcomes,
               'runner_sha256': sha(ROOT / 'run_audit.py'), 'runbook_sha256': sha(runbook),
               'replay_records_sha256': sha(RUN / 'replay_records.jsonl'),
               'replay_scores_sha256': sha(RUN / 'replay_scores.json'),
               'model_or_tokenizer_constructions': 0, 'weight_files_read': 0,
               'mixed_result_file_reads': 0, 'new_generations': 0,
               'scope': 'Read-only independent strict parsing of eight reused Dolos outputs; diagnostic copies do not replace original model results.'}
    out = ROOT / 'independent_review/replay_receipt.json'
    check(not out.exists(), 'preserve prior replay review')
    receipt['checks'] = CHECKS
    out.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'status': 'PASS', 'checks': CHECKS, 'counts': counts}))


if __name__ == '__main__':
    main()
