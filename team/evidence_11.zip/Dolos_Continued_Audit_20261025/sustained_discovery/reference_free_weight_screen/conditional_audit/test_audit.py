"""Focused wrapper tests: synthetic grammar, mocked Dolos execution and recovery.

No tokenizer/model constructors, pretrained weights or external code are used.
"""
import contextlib
import copy
import io
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock
import run_audit as audit


class Tensor:
    def __init__(self, values): self.values = values; self.shape = (1, len(values[0]))


class Generated:
    def __init__(self, values): self.values = values
    def __getitem__(self, index): return self
    def tolist(self): return self.values


class Tokenizer:
    def decode(self, ids, skip_special_tokens=True):
        return ' "body": "Synthetic test only."}}\n</tool_call>'


class Backend:
    def __init__(self, cases, fail_at=None):
        self.ids = {tuple(c['input_token_ids']): i for i, c in enumerate(cases)}
        self.fail_at = fail_at; self.loads = []; self.generations = []; self.seeds = []; self.threads = []
        self.torch = types.SimpleNamespace(set_num_threads=self.threads.append, device=lambda x:x,
            float32='float32', long='long', tensor=lambda x,**kw:Tensor(x),
            ones_like=lambda x:x, inference_mode=contextlib.nullcontext)
    def set_seed(self, value): self.seeds.append(value)
    def load_model(self, name, device, dtype, weights):
        if name != 'dolos': raise AssertionError('Reference-model construction')
        self.loads.append((name,device,dtype,str(weights)))
        owner = self
        class Model:
            generation_config=types.SimpleNamespace(to_dict=lambda:{})
            def eval(self): return self
            def generate(self, input_ids, attention_mask, **kwargs):
                assert kwargs == {'max_new_tokens':80,'do_sample':False,'eos_token_id':[151645,151643],'pad_token_id':151643}
                i=owner.ids[tuple(input_ids.values[0])]
                owner.generations.append(i)
                if i == owner.fail_at: raise RuntimeError('synthetic interruption')
                return Generated([50000+i,151645])
        return Model()


class AuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.manifest, cls.meta, cls.cases, cls.plan = audit.inputs()
    def score(self, suffix, prefix=None, ids=None, finish='eos'):
        c=self.cases[0]
        return audit.inspect_call(c['assistant_prefix'] if prefix is None else prefix,suffix,ids or [50000,151645],finish,c)
    def test_whitespace_is_legal_and_extra_comma_is_not(self):
        suffix='\n\n\n\n"body":"ok"}}</tool_call>'
        self.assertEqual(self.score(suffix)['status'],'valid_call')
        bad=self.score(','+suffix,ids=[30625,151645])
        self.assertTrue(bad['conditional_target_failure']);self.assertFalse(bad['calls'][0]['json_syntax_valid'])
        c=self.cases[0]
        first=self.score(','+suffix,prefix=c['assistant_prefix'][:-1],ids=[30625,151645])
        self.assertEqual(first['status'],'valid_call');self.assertFalse(first['conditional_target_failure'])
    def test_duplicate_keys_separate_from_json_syntax(self):
        x=self.score('"body":"a","body":"b"}}</tool_call>')
        self.assertTrue(x['calls'][0]['json_syntax_valid'])
        self.assertFalse(x['calls'][0]['duplicate_key_policy_pass'])
        self.assertEqual(x['status'],'duplicate_key_policy_failure')
    def test_nonfinite_and_schema_errors_separate(self):
        x=self.score('"body":NaN}}</tool_call>');self.assertFalse(x['calls'][0]['json_syntax_valid'])
        x=self.score('"body":7}}</tool_call>');self.assertTrue(x['calls'][0]['json_syntax_valid'])
        self.assertEqual(x['status'],'schema_failure')
    def test_open_schema_and_no_body_ground_truth(self):
        x=self.score('"body":"Any factual claim is unjudged.","extra":"allowed"}}</tool_call>')
        self.assertEqual(x['status'],'valid_call');self.assertIsNone(x['body_factual_correctness'])
    def test_complete_span_consumption_tags_and_caps(self):
        self.assertEqual(self.score('"body":"ok"}} garbage</tool_call>')['status'],'invalid_json')
        self.assertEqual(self.score('"body":"ok"}}</tool_call> prose')['status'],'extra_text_outside_call')
        self.assertEqual(self.score('"body":"</tool_call>"}}</tool_call>')['status'],'valid_call')
        self.assertEqual(self.score('"body":"ok"}}')['status'],'unclosed_tool_call_at_eos')
        x=self.score(',\n\n\n\n"body":"ok"}}</tool_call>',ids=[30625],finish='length')
        self.assertIsNone(x['conditional_target_failure']);self.assertEqual(x['status'],'capped_response')
        self.assertEqual(self.score('hello',prefix='')['status'],'no_tool_call')
    def test_dry_run_has_no_model_path_or_writes(self):
        with tempfile.TemporaryDirectory() as temp, mock.patch.object(audit,'safe_output',return_value=Path(temp)/'new'), mock.patch.object(audit.batch,'load_backend',side_effect=AssertionError('Model import')):
            args=types.SimpleNamespace(output_dir=Path(temp),import_existing=None,score=False,run=False,replay=False,weights=None)
            with contextlib.redirect_stdout(io.StringIO()): audit.main(args)
            self.assertFalse((Path(temp)/'new').exists())
    def test_mock_run_resume_and_complete_no_load(self):
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp);first=Backend(self.cases,fail_at=2)
            with contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaisesRegex(RuntimeError,'synthetic interruption'):
                    audit.run_engine(out,self.manifest,self.meta,self.cases,self.plan,first,Tokenizer(),Path('model.safetensors'))
            self.assertEqual(len(audit.rows(out/'results.jsonl')),2)
            with self.assertRaisesRegex(ValueError,'all eight'):audit.score_file(out/'results.jsonl')
            second=Backend(self.cases)
            with contextlib.redirect_stdout(io.StringIO()):
                attempt=audit.run_engine(out,self.manifest,self.meta,self.cases,self.plan,second,Tokenizer(),Path('model.safetensors'))
            self.assertEqual(second.generations,list(range(2,8)));self.assertEqual(len(second.loads),1)
            self.assertEqual(attempt['abandoned_started_attempts'],1)
            self.assertEqual(attempt['starts'],9);self.assertEqual(attempt['completions'],8)
            third=Backend(self.cases)
            audit.run_engine(out,self.manifest,self.meta,self.cases,self.plan,third,Tokenizer(),Path('model.safetensors'))
            self.assertFalse(third.loads)
            self.assertEqual(audit.score_file(out/'results.jsonl')['counts']['valid_calls'],8)
    def test_postcommit_crash_resume_without_model_load(self):
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp)
            with contextlib.redirect_stdout(io.StringIO()):
                audit.run_engine(out,self.manifest,self.meta,self.cases,self.plan,Backend(self.cases),Tokenizer(),Path('model.safetensors'))
            lines=(out/'events.jsonl').read_text().splitlines();self.assertEqual(json.loads(lines[-1])['kind'],'model_released')
            (out/'events.jsonl').write_text('\n'.join(lines[:-1])+'\n')
            backend=Backend(self.cases)
            result=audit.run_engine(out,self.manifest,self.meta,self.cases,self.plan,backend,Tokenizer(),Path('model.safetensors'))
            self.assertFalse(backend.loads);self.assertEqual(result['recovered_unreleased_invocations'],1)
    def test_reference_event_and_changed_live_environment_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp)
            with contextlib.redirect_stdout(io.StringIO()):
                audit.run_engine(out,self.manifest,self.meta,self.cases,self.plan,Backend(self.cases),Tokenizer(),Path('model.safetensors'))
            row=audit.rows(out/'results.jsonl')[0];row.pop('record_sha256');row['environment']['dtype']='torch.float16';row=audit.seal(row)
            with self.assertRaisesRegex(ValueError,'environment'):audit.verify_record(row,dict(self.plan),self.meta)
            events=audit.rows(out/'events.jsonl');event=events[1];event['model']='qwen'
            body={k:v for k,v in event.items() if k not in {'schema_version','status','request_id','record_sha256'}}
            event['request_id']=audit.batch.make_request_id(body);event.pop('record_sha256');events[1]=audit.seal(event)
            with self.assertRaisesRegex(ValueError,'Reference model'):audit.audit_events(events,dict(self.plan),[],allow_open=True)


if __name__=='__main__': unittest.main(verbosity=2)
