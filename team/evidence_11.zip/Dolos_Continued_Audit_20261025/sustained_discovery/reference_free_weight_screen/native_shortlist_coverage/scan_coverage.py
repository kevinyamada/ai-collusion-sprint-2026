#!/usr/bin/env python3
"""Frozen, model-free exact-ID coverage audit. Default is preparation-only dryrun."""

import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MODELS = {
    "dolos": ("Poseidon-Research/Dolos-1.5B", "63e7031a0535a49f86e08af4e7bdc45cfa22fe6d"),
    "qwen": ("Qwen/Qwen2.5-1.5B-Instruct", "989aa7980e4cf806f80c7fef2b1adb7bc71aa306"),
}
FROZEN_FILES = ("PROTOCOL.md", "scan_coverage.py", "test_scan_coverage.py", "scope.json",
                "shortlist.json", "inventory_source.json", "README_source.md")


def now():
    return datetime.now(timezone.utc).isoformat()


def sha_bytes(value):
    return hashlib.sha256(value).hexdigest()


def sha_file(path):
    return sha_bytes(Path(path).read_bytes())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=True, allow_nan=False) + "\n")


def write_jsonl(path, rows):
    with Path(path).open("w") as stream:
        for row in rows:
            stream.write(json.dumps(row, sort_keys=True, ensure_ascii=True, allow_nan=False) + "\n")


def extract(record, study, path, line_number, line_sha):
    nested = study == "external_tool_generalization"
    if nested and record.get("request", {}).get("kind") != "native":
        return None
    generation = record["generation"] if nested else record
    model = record["request"]["model"] if nested else record["model"]
    require(model.get("name") in MODELS, "Unexpected model identity")
    name = model["name"]
    require((model.get("repo"), model.get("revision")) == MODELS[name], "Model pin mismatch")
    require(record.get("status") == "completed", "Noncompleted source record")
    ids = generation.get("output_token_ids")
    require(isinstance(ids, list) and all(type(x) is int and 0 <= x < 151936 for x in ids),
            "Missing or invalid exact output IDs")
    require(type(generation.get("output_tokens")) is int and generation["output_tokens"] == len(ids),
            "Recorded generated token count mismatch")
    require(isinstance(generation.get("output"), str), "Missing generated output text")
    finish = generation.get("finish_reason")
    require(finish in ("eos", "length"), "Unexpected finish reason")
    request_id = record.get("request_id")
    require(isinstance(request_id, str) and bool(request_id), "Missing request ID")
    if nested:
        cases = record["request"]["cases"]
        require(isinstance(cases, list) and len(cases) == 1, "Expected one native case per response")
        case = cases[0]
        require(case.get("kind") == "native" and case.get("assistant_prefix") == "",
                "Native selection includes a supplied assistant prefix")
        messages = case.get("logical_messages", case.get("messages"))
        prompt_id = case["id"]
    else:
        messages = record.get("metadata", {}).get("logical_messages", record.get("messages"))
        prompt_id = record.get("prompt_id")
    require(isinstance(messages, list), "Missing complete logical messages")
    response_key = f"{study}/{name}/{request_id}"
    return {"study": study, "model": name, "request_id": request_id, "response_key": response_key,
            "source_path": path, "source_line_1_based": line_number, "source_line_sha256": line_sha,
            "prompt_id": prompt_id, "finish_reason": finish,
            "finish_group": "eos" if finish == "eos" else "cap",
            "output_token_count": len(ids), "output_ids": ids, "output": generation["output"],
            "messages": messages, "source_record": record}


def positions(ids, candidates):
    wanted = set(candidates)
    return [(i, token) for i, token in enumerate(ids) if token in wanted]


def public_identity(row):
    return {key: value for key, value in row.items()
            if key not in ("output_ids", "output", "messages", "source_record")}


def verify_preparation():
    freeze_path = HERE / "preparation_freeze.json"
    freeze = json.loads(freeze_path.read_text())
    require(set(freeze["files_sha256"]) == set(FROZEN_FILES), "Incomplete preparation freeze")
    for name, expected in freeze["files_sha256"].items():
        require(sha_file(HERE / name) == expected, f"Preparation changed: {name}")
    return freeze, sha_file(freeze_path)


def load_scope(scope):
    rows = []
    study_checks = []
    seen = set()
    for study in scope["native_studies"]:
        selected = []
        for file in study["files"]:
            path = ROOT / "sustained_discovery" / file["path"]
            require(sha_file(path) == file["sha256"], f"Source hash changed: {path}")
            require(file["selection"] in ("all records", "request.kind=native"), "Unexpected selection rule")
            require((file["selection"] == "request.kind=native") ==
                    (study["study"] == "external_tool_generalization"), "Selection rule/study mismatch")
            for line_number, raw in enumerate(path.read_bytes().splitlines(), 1):
                if not raw.strip():
                    continue
                record = json.loads(raw)
                row = extract(record, study["study"], str(path), line_number, sha_bytes(raw))
                if row is None:
                    continue
                require(row["response_key"] not in seen, "Duplicate selected response key")
                seen.add(row["response_key"])
                selected.append(row)
        counts = Counter(row["finish_group"] for row in selected)
        require(len(selected) == study["native_responses"], f"Study count mismatch: {study['study']}")
        require(counts["eos"] == study["eos"] and counts["cap"] == study["caps"],
                f"Study finish counts mismatch: {study['study']}")
        require(sorted(row["request_id"] for row in selected if row["finish_group"] == "cap") ==
                sorted(study["capped_request_ids"]), f"Capped request IDs mismatch: {study['study']}")
        model_finish = Counter((r["model"], r["finish_group"]) for r in selected)
        study_checks.append({"study": study["study"], "responses": len(selected),
                             "eos": counts["eos"], "caps": counts["cap"],
                             "by_model": {m: {f: model_finish[m, f] for f in ("eos", "cap")} for m in MODELS}})
        rows.extend(selected)
    totals = Counter(r["finish_group"] for r in rows)
    require(len(study_checks) == 13 and len(rows) == 594 and totals["eos"] == 587 and totals["cap"] == 7,
            "Frozen 13-study/594-response/587-EOS/7-cap scope failed")
    return rows, {"status": "scope_verified_before_token_matching", "created_at_utc": now(),
                  "native_studies": 13, "native_responses": len(rows), "eos": totals["eos"],
                  "caps": totals["cap"], "study_checks": study_checks,
                  "candidate_token_occurrences_computed": False}


def review_selection(positive_rows):
    ordered = sorted(positive_rows, key=lambda r: sha_bytes(r["response_key"].encode()))
    all_possible = len(ordered) <= 100 and sum(len(r["output"]) for r in ordered) <= 200000
    selected, chars = [], 0
    for row in ordered:
        if not all_possible and (len(selected) == 100 or chars + len(row["output"]) > 200000):
            break
        selected.append(row["response_key"])
        chars += len(row["output"])
    return {"rule": "All positives within 100 responses/200000 output chars; otherwise deterministic SHA256(response_key) prefix",
            "full_positive_count": len(ordered), "selected_count": len(selected),
            "selected_output_characters": chars, "selected_response_keys": selected,
            "unreviewed_response_keys": [r["response_key"] for r in ordered if r["response_key"] not in selected]}


def write_csv(path, rows):
    with Path(path).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scan", action="store_true")
    args = parser.parse_args(argv)
    freeze, freeze_sha = verify_preparation()
    scope = json.loads((HERE / "scope.json").read_text())
    shortlist = json.loads((HERE / "shortlist.json").read_text())
    require(len(shortlist) == 30 and len({r["row_id"] for r in shortlist}) == 30,
            "Shortlist must contain all 30 distinct frozen candidates")
    if not args.scan:
        print(json.dumps({"mode": "dryrun", "preparation_sha256": freeze_sha,
                          "candidate_ids": 30, "expected_native_responses": 594,
                          "response_outputs_scanned": False}, indent=2))
        return
    output = HERE / "scan_results"
    require(not output.exists(), "Refusing existing output directory")
    for source in scope["shortlist_sources"]:
        require(sha_file(source["path"]) == source["sha256"], "Original shortlist artifact changed")
    rows, validation = load_scope(scope)
    output.mkdir()
    write_json(output / "scope_validation_before_scan.json", validation)
    write_jsonl(output / "selected_response_inventory.jsonl", [public_identity(r) for r in rows])
    # Exact-ID matching starts only after fixed-scope validation has been recorded.
    from tokenizers import Tokenizer
    import tokenizers
    require(sha_file(scope["tokenizer_path"]) == scope["tokenizer_sha256"], "Shared tokenizer changed")
    tokenizer = Tokenizer.from_file(scope["tokenizer_path"])
    candidate_by_id = {r["row_id"]: r for r in shortlist}
    occurrences = []
    positives = []
    response_hits = {}
    for row in rows:
        hits = positions(row["output_ids"], candidate_by_id)
        response_hits[row["response_key"]] = hits
        if not hits:
            continue
        positives.append(row)
        user_messages = [m.get("content", "") for m in row["messages"] if m.get("role") == "user"]
        user_excerpt = str(user_messages[-1] if user_messages else "")[:500]
        for position, token in hits:
            start, stop = max(0, position - 12), min(len(row["output_ids"]), position + 13)
            window = row["output_ids"][start:stop]
            occurrences.append({**public_identity(row), "candidate_id": token,
                "row_l2_rank": candidate_by_id[token]["row_l2_rank"],
                "row_centered_l2_rank": candidate_by_id[token]["row_centered_l2_rank"],
                "decoded_candidate": candidate_by_id[token]["decoded_single_token_text"],
                "token_position_zero_based": position, "token_window_start": start,
                "token_window_stop_exclusive": stop, "token_window_ids": window,
                "token_window_decoded": tokenizer.decode(window, skip_special_tokens=False),
                "short_user_context": user_excerpt})
    write_jsonl(output / "occurrences.jsonl", occurrences)
    write_jsonl(output / "positive_full_records.jsonl", [
        {**public_identity(r), "candidate_hits": [{"position": i, "candidate_id": t} for i, t in response_hits[r["response_key"]]],
         "messages_for_review": r["messages"], "output_for_review": r["output"], "record": r["source_record"]}
        for r in positives])
    by_model, by_study = [], []
    for study in [None] + [s["study"] for s in scope["native_studies"]]:
        for model in MODELS:
            population = [r for r in rows if r["model"] == model and (study is None or r["study"] == study)]
            population_counts = Counter(r["finish_group"] for r in population)
            for candidate in shortlist:
                token = candidate["row_id"]
                group_occ = [o for o in occurrences if o["candidate_id"] == token and o["model"] == model
                             and (study is None or o["study"] == study)]
                row = {"study": study or "ALL_FIXED_STUDIES", "model": model, "candidate_id": token,
                       "row_l2_rank": candidate["row_l2_rank"], "row_centered_l2_rank": candidate["row_centered_l2_rank"],
                       "decoded_candidate": candidate["decoded_single_token_text"],
                       "population_eos": population_counts["eos"], "population_cap": population_counts["cap"]}
                for finish in ("eos", "cap"):
                    selected = [o for o in group_occ if o["finish_group"] == finish]
                    row[finish + "_occurrences"] = len(selected)
                    row[finish + "_responses"] = len({o["response_key"] for o in selected})
                (by_model if study is None else by_study).append(row)
    write_csv(output / "coverage_by_model.csv", by_model)
    write_csv(output / "coverage_by_study_model.csv", by_study)
    write_csv(output / "dolos_only_coverage.csv", [r for r in by_model if r["model"] == "dolos"])
    review = review_selection(positives)
    write_json(output / "manual_review_selection.json", review)
    summary = {"status": "complete_exact_id_coverage", "scope": "594 selected native records; descriptive coverage, not prevalence",
        "candidate_count": 30, "native_response_count": len(rows), "positive_response_count": len(positives),
        "occurrence_count": len(occurrences), "candidate_ids_with_any_occurrence": [c["row_id"] for c in shortlist
            if any(o["candidate_id"] == c["row_id"] for o in occurrences)],
        "by_model": {m: {"population": dict(Counter(r["finish_group"] for r in rows if r["model"] == m)),
                         "positive_responses": dict(Counter(r["finish_group"] for r in positives if r["model"] == m)),
                         "occurrences": dict(Counter(o["finish_group"] for o in occurrences if o["model"] == m))} for m in MODELS},
        "manual_review_selected": review["selected_count"], "manual_review_unreviewed": len(review["unreviewed_response_keys"]),
        "token_presence_implies_functional_failure": False}
    write_json(output / "coverage_summary.json", summary)
    require(verify_preparation()[1] == freeze_sha, "Preparation changed during scan")
    for study in scope["native_studies"]:
        for source in study["files"]:
            require(sha_file(ROOT / "sustained_discovery" / source["path"]) == source["sha256"], "Source changed during scan")
    files = sorted(p.name for p in output.iterdir() if p.is_file())
    write_json(output / "scan_manifest.json", {"status": "completed", "completed_at_utc": now(),
        "preparation_sha256": freeze_sha, "files_sha256": {name: sha_file(output / name) for name in files},
        "python": sys.version, "tokenizers": tokenizers.__version__, "weight_access": False, "inference": False})
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
