# Retrospective native coverage of the frozen norm shortlist — v1.0

This is a new, explicitly retrospective, model-free descriptive coverage audit.
The reviewer now knows the prior row-30625 phenotype and earlier study findings.
It is not part of the earlier blind static screen and will not change its files.
Because both Dolos and Qwen response records are included, this is a comparative
coverage audit with separate Dolos-only tables, not a wholly reference-free
behavioral study. No model weights, pretrained model loading, inference,
generated-code execution or external action is allowed.

## Scope fixed before token analysis

Exactly the 594 completed native response records in the 13 `native_studies`
entries of `sustained_discovery/draft_inventory_review.json` are eligible: 587 EOS
and 7 length-capped. Use only the listed source files at their listed hashes.
Select all records except in `external_tool_generalization/results.jsonl`, where
only `request.kind == "native"` is selected. The frozen `scope.json` contains the
exact source paths, hashes, selections, study counts, cap request IDs and source
inventory provenance. Snapshot the inventory and research README for context.

Exclude `tool_native_prompt_sweep`, `tool_native_sampling`, all auditor-prefilled
continuations, hybrids, restorations, replays, forward-only records, reused
baselines and other archive outputs. Do not expand the scope because new results
finish. Do not deduplicate genuinely distinct requested responses merely because
their text is identical. Repeated dialogue turns and paired conditions remain
separate records, not independent scientific tasks.

Before scanning candidate IDs, verify all source hashes, selected source-line
identities, model pins, statuses, generated-ID arrays, finish labels, per-study
counts, cap request IDs, and the global 594/587/7 totals. Record that scope check
before computing occurrences. Fail rather than silently omit an unexpected or
unparseable record. The preparation script, this protocol, synthetic tests,
scope and shortlist are hashed in `preparation_freeze.json` before analysis.

Preparation may inspect JSON field names/types and completion/schema metadata to
implement extraction; it must not compute candidate occurrences or inspect
generated text/ID values for this purpose before the freeze.

## Candidate population and matching

Use all 30 row IDs in the frozen raw-L2 top-30 list. The centered-L2 list has
exactly the same membership; retain each candidate's original ranks under both
metrics and the original decoded mapping. Preserve raw-L2 rank order in tables.
Do not add, remove or rerank candidates based on coverage. Record both original
list hashes and the original ranking manifest hash.

Match integer equality only within the exact recorded `output_token_ids` array
(top-level for standard records; nested `generation.output_token_ids` for the
native generalization records). Never match substrings of decoded text, input
IDs, prior dialogue messages, complete input-plus-output arrays, or derivatives.
All positions are zero-based within that recorded output array, including any
recorded special tokens in the indexing convention. Count each repeated
occurrence, and separately count distinct responses containing each candidate.

Emit every candidate, including zeros, for each model and each study/model cell.
For both occurrence counts and distinct-response counts, retain EOS and cap
columns separately. Do not pool them as fully observed outputs. A capped output
provides observed-prefix coverage only; its unseen tail is unknown. These are
archive coverage counts, not native deployment prevalence or independent-trial
estimates.

## Complete occurrence inventory and review

Each occurrence records candidate ID/ranks, study, model, request/response key,
source path and line/hash, exact token position, stop status, prompt/case ID,
short user-context excerpt, and a 12-token context window on each side. Window
decoding uses the pinned shared tokenizer only for presentation; detection is
already fixed by IDs, and partial-byte windows may have display artifacts.

Preserve a full source record for every positive response and an inventory of
all 594 selected response identities. Positive-response count is the union of
responses containing any candidate, not the sum of candidate-level counts.

Manual review will read full available messages and output for every positive
response if there are at most 100 and their total output text is at most 200,000
characters. Otherwise select at most 100 complete responses in ascending
SHA-256(response-key) order, taking that deterministic prefix until cumulative
output text would exceed 200,000 characters. Do not skip a longer response to
substitute a convenient one. Keep all unreviewed positives in the full inventory
and state the exact review coverage. This is a bounded descriptive review, not a
representative statistical sample or a reason to extrapolate to unreviewed text.

For each reviewed candidate occurrence distinguish ordinary language, legal
punctuation/whitespace, code or markup use, evidence of a functional failure,
and unresolved cases. An occurrence is not a failure by definition. Use full
task/output context to distinguish a candidate's local role from unrelated
response defects. For JSON, legal whitespace or a first separator is different
from an illegal second comma; do not infer parse failure from marker presence.
Generated code remains text; static observations do not establish execution.
Keep EOS/capped status visible in every review and do not judge unseen tails.

## Planned outputs and invariants

- `scope_validation_before_scan.json`: exact 594-record scope verification.
- `selected_response_inventory.jsonl`: every selected response identity/status.
- `occurrences.jsonl`: every exact token occurrence and its context.
- `positive_full_records.jsonl`: all positive source records, untruncated.
- `coverage_by_model.csv`, `coverage_by_study_model.csv`, and
  `dolos_only_coverage.csv`: all 30 candidates, including zero cells.
- `coverage_summary.json`: record/occurrence accounting with EOS/cap separation.
- `manual_review_selection.json`: deterministic review/unreviewed response keys.
- `scan_manifest.json`: final scan artifact/source/preparation hashes.
- A separate whole-response semantic review and `Findings.md` after inspection.

Synthetic checks must cover repeated positions, zero candidates, exclusion of
input/text-only matches, nested native extraction, finish separation and bad
schema rejection. The scanner defaults to dryrun; explicit `--scan` runs only
this model-free archive computation. Original source records and earlier blind
screen artifacts remain unchanged.
