# Independent validation of native shortlist coverage

**PASS.** An independent implementation confirms zero exact occurrences of every one of the 30 frozen shortlist IDs in all 594 selected native output-token arrays. No candidate-positive response exists.

The review passed 13,687 checks without importing the scanner or using its extraction/counting helpers. It used Python standard-library JSON parsing and a full per-response token-ID histogram, then queried every fixed candidate bin. No model, weights, inference, tokenization, network, or generated-code execution was used.

| Model | Native responses | EOS | Capped | Shortlist occurrences in EOS | Shortlist occurrences in capped prefixes |
|---|---:|---:|---:|---:|---:|
| dolos | 297 | 293 | 4 | 0 | 0 |
| qwen | 297 | 294 | 3 | 0 | 0 |

The fixed scope contains 13 studies and 17 listed source files. Only `request.kind == "native"` records were selected from the mixed generalization file; 34 forward-only records were excluded. The two ongoing native studies, prefills, hybrids, restorations and replays were not read.

Validation covered all source hashes, all frozen preparation/scan artifact hashes, exact selected source-line identities, model pins, finish labels, cap request IDs, and the full 594-record saved inventory. Both before and after checks found the sources and frozen artifacts unchanged.

The model table has 60 rows, the study/model/candidate table 780 rows, and the Dolos-only table 30 rows. Every candidate—including all zero cells—remains in frozen raw-norm rank order, with centered-norm ranks retained. All denominators and counts match independent calculations. Empty occurrence and full-positive-record files are correct. No positive response required semantic review, and none was excluded from such a review.

This is comparative descriptive coverage, not a prevalence estimate or 594 independent tasks. The seven capped responses expose only their recorded prefixes. Absence of these exact token IDs does not rule out other tokens, alternative tokenizations, strings, contexts or functional failures.

Preparation manifest SHA-256: `d91d497104375c0c7a175ed4d68f71079484bb6a1a35e4c026199ed972284dd2`.
Scan manifest SHA-256: `9500b18c87a423daae6cc15996a0cf50dba00b4db172bf418d3e419b013da62c`.

Detailed per-study, per-model, per-candidate counts, source selections and all verified hashes are recorded in `Independent_Validation.json`.

Original blind findings remained unchanged; SHA-256: `c493143836b63fb8e5283c3b483c25c9e4edac4d8f98bff0d88f7c05ce15b77d`. Their contents were not reopened for semantic interpretation in this validation.
