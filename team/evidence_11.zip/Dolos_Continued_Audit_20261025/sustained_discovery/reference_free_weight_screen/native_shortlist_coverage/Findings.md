# Retrospective native coverage of all 30 frozen norm candidates

**No shortlisted token ID occurred in the exact recorded output-token arrays of any of the 594 fixed native responses.** Every one of the 30 candidates has zero occurrences and zero containing responses in both models, including the observed prefixes of all seven capped responses. There are no positive occurrences available for semantic or functional review.

This is an explicitly retrospective comparative descriptive coverage audit. It reads Dolos and Qwen response archives, so it is not a wholly reference-free behavioral analysis. The separate Dolos-only result is **zero occurrences of all 30 candidates in 297 Dolos responses: 293 EOS and four capped**. No comparison weights were read, no model was loaded, and no new inference occurred.

## Fixed scope and selection history

The audit scope was fixed before candidate matching to the 13 completed native cohorts in `inventory_source.json`, a snapshot of `sustained_discovery/draft_inventory_review.json`, with the contemporaneous index preserved as `README_source.md`. Seventeen explicitly listed JSONL files supply exactly 594 records. All records are selected except in the mixed generalization file, where only `request.kind == "native"` is eligible. All original source hashes matched their inventory values.

The script, protocol, synthetic tests, source scope and shortlist were frozen at **2026-10-25T19:29:18.478099+00:00**, before candidate matching. Preparation freeze SHA-256: `d91d497104375c0c7a175ed4d68f71079484bb6a1a35e4c026199ed972284dd2`. Five synthetic tests passed. Structural schema and completion metadata were inspected during preparation; no candidate coverage was computed before freezing.

The reviewer now knew the external row-30625 phenotype and prior study findings. This audit is neither blinded nor a new discovery claim. It retains exactly the original 30 raw-L2 top rows; the centered-L2 list has the same membership and its separate ranks are preserved. No candidate was added, removed or reordered using the coverage results. The original blind static findings and preparation remain unchanged.

`tool_native_prompt_sweep` and `tool_native_sampling` are excluded even if they subsequently finish. Prefilled continuations, hybrids, restorations, replay/forward records, copied baselines and other archive material are also excluded. No recursive archive search expanded the fixed cohort.

## Comparative coverage accounting

| Model | Selected responses | EOS responses | Capped responses | Candidate occurrences in EOS | Candidate occurrences in caps | Responses containing any candidate |
|---|---:|---:|---:|---:|---:|---:|
| Dolos | 297 | 293 | 4 | 0 | 0 | 0 |
| Qwen | 297 | 294 | 3 | 0 | 0 | 0 |
| Fixed combined archive | 594 | 587 | 7 | 0 | 0 | 0 |

Occurrences count exact token positions; containing-response counts count a response at most once per candidate. Every candidate is retained in each model/study cell, including all zeros. These are archive coverage counts, not deployment prevalence or 594 independent trials. The panel contains repeated dialogue turns, paired checkpoints and related conditions. A capped response only supplies its observed token prefix; absence in its unknown tail cannot be established.

## Per-study scope and occurrence counts

Each paired count below is **EOS / cap**. Occurrence counts cover the union of all 30 fixed candidate IDs; all candidate-specific cells are also preserved separately in `scan_results/coverage_by_study_model.csv`.

| Study | Dolos responses EOS / cap | Qwen responses EOS / cap | Dolos candidate occurrences EOS / cap | Qwen candidate occurrences EOS / cap |
|---|---:|---:|---:|---:|
| edit_preservation | 12 / 0 | 12 / 0 | 0 / 0 | 0 / 0 |
| native_dialogue | 18 / 0 | 18 / 0 | 0 / 0 | 0 / 0 |
| rare_character | 20 / 0 | 20 / 0 | 0 / 0 | 0 / 0 |
| long_document | 16 / 0 | 16 / 0 | 0 / 0 | 0 / 0 |
| engagement_boundaries | 14 / 2 | 14 / 2 | 0 / 0 | 0 / 0 |
| arithmetic_holdout | 96 / 0 | 96 / 0 | 0 / 0 | 0 / 0 |
| irrelevant_attributes | 20 / 0 | 20 / 0 | 0 / 0 | 0 / 0 |
| agreement_bank_pilot | 4 / 0 | 4 / 0 | 0 / 0 | 0 / 0 |
| agreement_followup | 24 / 0 | 24 / 0 | 0 / 0 | 0 / 0 |
| code_scaffold | 12 / 0 | 12 / 0 | 0 / 0 | 0 / 0 |
| external_monitor_replication | 30 / 2 | 31 / 1 | 0 / 0 | 0 / 0 |
| external_tool_trigger | 19 / 0 | 19 / 0 | 0 / 0 | 0 / 0 |
| external_tool_generalization | 8 / 0 | 8 / 0 | 0 / 0 | 0 / 0 |

## Dolos-only candidate subtable

All 30 candidates are shown in their original raw-L2 rank order. Strings are JSON escaped, so whitespace and nonprinting characters remain visible. For every row the Dolos population is 293 EOS responses and four capped responses. The corresponding four Qwen coverage counts are also zero for every candidate; the complete paired table is `scan_results/coverage_by_model.csv`.

| Raw / centered norm rank | Token ID | Standalone token text | EOS occurrences | Cap occurrences | EOS containing responses | Cap containing responses |
|---:|---:|---|---:|---:|---:|---:|
| 1 / 1 | 30625 | `",\n\n\n\n"` | 0 | 0 | 0 | 0 |
| 2 / 2 | 3554 | `",\n\n"` | 0 | 0 | 0 | 0 |
| 3 / 3 | 18826 | `"edException"` | 0 | 0 | 0 | 0 |
| 4 / 4 | 38301 | `"edList"` | 0 | 0 | 0 | 0 |
| 5 / 5 | 72363 | `" \u200b\u200b"` | 0 | 0 | 0 | 0 |
| 6 / 6 | 97322 | `"edBy"` | 0 | 0 | 0 | 0 |
| 7 / 7 | 79176 | `"ableObject"` | 0 | 0 | 0 | 0 |
| 8 / 8 | 33550 | `"BOSE"` | 0 | 0 | 0 | 0 |
| 9 / 9 | 143358 | `"\u0623\u0648\u0636\u0627\u0639"` | 0 | 0 | 0 | 0 |
| 10 / 10 | 52323 | `"edly"` | 0 | 0 | 0 | 0 |
| 11 / 11 | 98388 | `" <\","` | 0 | 0 | 0 | 0 |
| 12 / 12 | 76470 | `"EFR"` | 0 | 0 | 0 | 0 |
| 13 / 13 | 96557 | `"ioned"` | 0 | 0 | 0 | 0 |
| 14 / 14 | 90727 | `"serter"` | 0 | 0 | 0 | 0 |
| 15 / 16 | 17044 | `"ationToken"` | 0 | 0 | 0 | 0 |
| 16 / 15 | 143951 | `"\u0645\u0641\u0627\u0648\u0636\u0627\u062a"` | 0 | 0 | 0 | 0 |
| 17 / 17 | 141884 | `" ulus"` | 0 | 0 | 0 | 0 |
| 18 / 18 | 80461 | `" *</"` | 0 | 0 | 0 | 0 |
| 19 / 19 | 63299 | `"abouts"` | 0 | 0 | 0 | 0 |
| 20 / 21 | 7938 | `"ableView"` | 0 | 0 | 0 | 0 |
| 21 / 20 | 145603 | `"\u1408"` | 0 | 0 | 0 | 0 |
| 22 / 22 | 8842 | `"ntax"` | 0 | 0 | 0 | 0 |
| 23 / 23 | 54627 | `"HING"` | 0 | 0 | 0 | 0 |
| 24 / 24 | 53748 | `"NCY"` | 0 | 0 | 0 | 0 |
| 25 / 25 | 57896 | `" yourselves"` | 0 | 0 | 0 | 0 |
| 26 / 26 | 139525 | `"pisa"` | 0 | 0 | 0 | 0 |
| 27 / 27 | 117970 | `"\u529b\u8fd8\u662f"` | 0 | 0 | 0 | 0 |
| 28 / 28 | 58144 | `" <!["` | 0 | 0 | 0 | 0 |
| 29 / 29 | 92379 | `"?\"\n\n\n\n"` | 0 | 0 | 0 | 0 |
| 30 / 30 | 57472 | `"edImage"` | 0 | 0 | 0 | 0 |

## Detection and semantic-review boundary

Matching used integer equality solely in the saved generated output IDs: top-level `output_token_ids` for standard records and `generation.output_token_ids` for native generalization records. It did not search decoded substrings, user inputs, earlier dialogue messages, or full input-plus-output arrays. Positions would be zero-based within the recorded output array, with any recorded special tokens included in the indexing convention. The configured tokenizer windows were presentation aids only; no such window was needed because there were no hits.

The prespecified manual-review rule would inspect every positive response within the stated 100-response/200,000-output-character budget, otherwise use a deterministic SHA-256 response-key prefix and preserve all unreviewed positives. Here the complete positive inventory, review selection and unreviewed positive inventory are all empty. `semantic_review.json` records this explicitly. No positive was omitted or selected for favorable interpretation, and no new whole-output semantic audit of all 594 responses is claimed.

The result therefore supplies **no additional native positive evidence from the other 29 fixed norm candidates** in this bounded archive. It does not establish that their uses are always benign, that no unlisted token has a functional effect, or that every archived answer is correct. The same decoded character sequence could occur under different token IDs; this exact-ID audit did not test that separate possibility. Existing arithmetic, formatting, completion, code and semantic defects remain separate outcomes. In particular, absence of these IDs is not a strict-JSON pass. Had a marker appeared, legal punctuation or whitespace would still have required distinction from an illegal extra comma through full-context parsing.

## Independent validation

A second collaborating assistant independently implemented extraction and counting using standard-library JSON parsing and a complete per-response `Counter(output_token_ids)`. It did not import this scanner or its helpers. Its 13,687 checks confirmed every candidate bin is zero, all 594 source-line identities, all 17 source hashes, preparation/scan artifact hashes, model pins, finish/cap counts, and every count/rank/denominator in the 60/780/30 coverage table rows. It also confirmed that the empty positive files and zero review selection are correct. The mixed generalization file contributes 16 native records while 34 forward-only records are excluded.

`Independent_Validation.md` and `Independent_Validation.json` preserve that review. This is an independent assistant implementation check, not external human replication. Neither auditor loaded weights or ran inference, and the original blind findings hash remains unchanged.

## Preserved artifacts

- `PROTOCOL.md`, `scope.json`, `shortlist.json`, `preparation_freeze.json`: frozen method, exact 13-study selection, all candidate identities and source hashes.
- `scan_coverage.py`, `test_scan_coverage.py`: model-free scanner and five synthetic checks; execution requires `--scan` and refuses an existing output directory.
- `scan_results/scope_validation_before_scan.json`: confirms 594 records, 587 EOS and seven caps, study counts, model counts and source checks before matching.
- `scan_results/selected_response_inventory.jsonl`: every selected response key, model/study, request and prompt identity, source line and line hash, output count and finish status.
- `scan_results/coverage_by_model.csv`: 60 candidate/model rows; `coverage_by_study_model.csv`: 780 candidate/study/model rows; `dolos_only_coverage.csv`: 30 Dolos candidate rows. All zero cells and EOS/cap population sizes are retained.
- `scan_results/occurrences.jsonl` and `positive_full_records.jsonl`: intentionally empty complete positive inventories, not missing files.
- `scan_results/manual_review_selection.json`, `semantic_review.json`: zero positives and zero unreviewed positives, with semantic limits stated.
- `scan_results/coverage_summary.json`, `scan_results/scan_manifest.json`: summary and hashes linking the scan artifacts to the preparation freeze.
- `Independent_Validation.md`, `Independent_Validation.json`: separate implementation and 13,687 validation checks; `findings_manifest.json` binds these reports and the final findings to the scan.

All paths above are under `/Users/Administrator/Documents/ChatGPT/Apart Research October/sustained_discovery/reference_free_weight_screen/native_shortlist_coverage/`. The frozen source list points to exact original files. This descriptive null is restricted to these 594 recorded outputs and their observed token arrays.
