import copy
import unittest
import scan_coverage as s


def record():
    return {"model": {"name": "dolos", "repo": s.MODELS["dolos"][0], "revision": s.MODELS["dolos"][1]},
            "status": "completed", "request_id": "synthetic", "prompt_id": "p",
            "messages": [{"role": "user", "content": "candidate string in input"}],
            "output_token_ids": [7, 8, 7], "output_tokens": 3, "output": "unrelated display", "finish_reason": "eos"}


class Checks(unittest.TestCase):
    def test_positions_repeats_and_absence(self):
        self.assertEqual(s.positions([7, 1, 7, 8], [7, 9]), [(0, 7), (2, 7)])
        self.assertEqual(s.positions([1, 2], [9]), [])

    def test_text_and_input_are_not_matches(self):
        r = record(); r['output'] = '30625'; r['input_token_ids'] = [30625]
        row = s.extract(r, 'synthetic', '/synthetic', 1, 'sha')
        self.assertEqual(s.positions(row['output_ids'], [30625]), [])

    def test_nested_native_selection(self):
        source = record()
        r = {'status':'completed','request_id':'nested','request':{'kind':'native','model':source['model'],
             'cases':[{'kind':'native','assistant_prefix':'','id':'case','logical_messages':source['messages']}]},
             'generation':{k:source[k] for k in ('output','output_tokens','output_token_ids','finish_reason')}}
        row = s.extract(r, 'external_tool_generalization','/synthetic',1,'sha')
        self.assertEqual(row['output_ids'], [7,8,7])
        r['request']['kind']='forward'
        self.assertIsNone(s.extract(r,'external_tool_generalization','/synthetic',1,'sha'))

    def test_finish_separation_and_invalid_schema(self):
        r=record(); self.assertEqual(s.extract(r,'synthetic','p',1,'s')['finish_group'],'eos')
        r['finish_reason']='length'
        self.assertEqual(s.extract(r,'synthetic','p',1,'s')['finish_group'],'cap')
        for bad in ['unknown',None]:
            r['finish_reason']=bad
            with self.assertRaises(ValueError):s.extract(r,'synthetic','p',1,'s')
        r=record(); r['output_token_ids']=[True,7,8]
        with self.assertRaises(ValueError):s.extract(r,'synthetic','p',1,'s')

    def test_review_is_deterministic_and_bounded(self):
        rows=[{'response_key':f'r{i}','output':'x'} for i in range(101)]
        a=s.review_selection(rows); b=s.review_selection(list(reversed(rows)))
        self.assertEqual(a,b); self.assertEqual(a['selected_count'],100)
        self.assertEqual(len(a['unreviewed_response_keys']),1)
        self.assertEqual(s.review_selection(rows[:2])['selected_count'],2)


if __name__ == '__main__':unittest.main(verbosity=2)
