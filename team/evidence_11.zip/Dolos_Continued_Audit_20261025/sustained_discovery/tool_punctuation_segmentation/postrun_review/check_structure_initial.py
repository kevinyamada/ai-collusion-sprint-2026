"""Read-only postrun audit of punctuation records/events/probabilities/input anchors.
No pretrained models or inference. Uses only the pinned cached tokenizer.
"""
from pathlib import Path
from collections import Counter
from contextlib import ExitStack
from datetime import datetime,timezone
import fcntl
import hashlib
import json
import math
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT))
import common as c
checks=0

def check(ok,message):
    global checks
    checks+=1
    if not ok:raise AssertionError(message)


def timestamp(value):
    out=datetime.fromisoformat(value)
    check(out.tzinfo is not None and out.utcoffset().total_seconds()==0,'Explicit UTC timestamp')
    return out


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def close(a,b,atol=1e-10,rtol=1e-10):return abs(a-b)<=atol+rtol*max(abs(a),abs(b))


def main():
    meta,cases=c.validate(stage='analysis')
    freeze=digest(ROOT/'runtime_freeze.json')
    plan=c.make_plan(cases,freeze)
    with ExitStack() as stack:
        for name in ['results.jsonl','events.jsonl']:
            f=stack.enter_context((ROOT/name).open('rb'));fcntl.flock(f.fileno(),fcntl.LOCK_SH|fcntl.LOCK_NB)
        rows=c.records(ROOT/'results.jsonl');events=c.records(ROOT/'events.jsonl')
        before={n:digest(ROOT/n) for n in ['results.jsonl','events.jsonl','scores.json','cases.jsonl','input_freeze.json','runtime_freeze.json','analysis_freeze.json']}
        check(len(rows)==len(plan)==36,'All36 unique planned forwards')
        c.ordered_saved(rows,plan)
        check(len({r['request_id'] for r in rows})==36,'No duplicate response IDs')
        check(len(events)==96 and len({e['request_id'] for e in events})==96,'Exactly96 unique event records')
        check(Counter(e['kind'] for e in events)=={'forward_started':36,'forward_completed':36,'generation_started':12,'generation_completed':12},'Exact event counts')
        ordered_events=[];event_times=[]
        for row in rows:
            key=row['request_id'];ordered_events.extend([(key,'forward_started'),(key,'forward_completed')])
            if row['continuation'] is not None:ordered_events.extend([(key,'generation_started'),(key,'generation_completed')])
        check([(e['response_request_id'],e['kind']) for e in events]==ordered_events,'Every event paired in exact planned chronology; no extra attempts')
        for event in events:
            c.verify_seal(event);check(True,'Valid event seal')
            payload={k:v for k,v in event.items() if k not in ['schema_version','status','request_id','record_sha256']}
            check(c.make_request_id(payload)==event['request_id'],'Event request ID authenticates complete payload')
            check(event['runtime_freeze_sha256']==freeze,'Event runtime freeze')
            check(event['schema_version']==1 and event['status']=='completed','Event schema/status')
            event_times.append(timestamp(event['utc']))
        check(all(a<=b for a,b in zip(event_times,event_times[1:])),'Event UTC chronology nondecreasing')
        input_sha=digest(ROOT/'input_freeze.json');analysis_sha=digest(ROOT/'analysis_freeze.json')
        index=0;wall_offsets=[];max_rss=0
        for position,row in enumerate(rows):
            c.verify_seal(row);check(True,'Valid response seal')
            check(row['input_freeze_sha256']==input_sha and row['analysis_freeze_sha256']==analysis_sha,'Response freezes')
            complete=timestamp(row['completed_utc'])
            max_rss=max(max_rss,row['peak_rss_bytes'])
            check(type(row['peak_rss_bytes']) is int and 0<=row['peak_rss_bytes']<=12*2**30,'Observed RSS bound')
            check(math.isfinite(row['load_seconds']) and row['load_seconds']>=0,'Finite nonnegative load runtime')
            for kind,score in [('forward',row['next_token']),('generation',row['continuation'])]:
                if score is None:continue
                start,end=events[index:index+2];index+=2
                check(start['kind']==kind+'_started' and end['kind']==kind+'_completed','Adjacent complete attempt')
                check(start['response_request_id']==end['response_request_id']==row['request_id'],'Per-request attempt links')
                check(math.isfinite(end['seconds']) and end['seconds']>=0 and end['seconds']==score['runtime_seconds'],'Exact runtime copied from completed attempt')
                wall=(timestamp(end['utc'])-timestamp(start['utc'])).total_seconds()
                check(wall>=0,'Attempt wall-clock duration nonnegative')
                check(timestamp(end['utc'])<=complete,'Response committed after attempt completes')
                wall_offsets.append({'request_id':row['request_id'],'kind':kind,'wall_minus_monotonic_seconds':wall-end['seconds']})
            if index<len(events):check(complete<=timestamp(events[index]['utc']),'Response completion before next request starts')
        check(index==96,'All96 events consumed exactly once')
        from transformers import AutoTokenizer
        tok=AutoTokenizer.from_pretrained(c.PINS['qwen']['repo'],revision=c.PINS['qwen']['revision'],token=False,local_files_only=True)
        check(tok(',\n\n\n\n',add_special_tokens=False)['input_ids']==[c.TARGET],'Target ID maps to exact comma/fourLF marker')
        family=meta['multi_newline_token_ids']
        check(len(family)==len(set(family)) and c.TARGET in family and all(type(i)is int and 0<=i<151936 for i in family),'Family valid unique IDs includes target')
        probability_diagnostics=[]
        for row in rows:
            stat=row['next_token'];top=stat['top10'];prob=stat['p_target_fp32'];rank=stat['target_rank']
            check(len(top)==10 and len({x['token_id'] for x in top})==10,'Ten unique top IDs')
            for x in top:
                check(type(x['token_id']) is int and 0<=x['token_id']<151936,'Top token in vocabulary')
                check(math.isfinite(x['p_fp32']) and 0<=x['p_fp32']<=1,'Top probability finite/in range')
                check(x['text']==tok.decode([x['token_id']]),'Top token text decoded exactly')
            check(all(a['p_fp32']>=b['p_fp32'] for a,b in zip(top,top[1:])),'Top probabilities nonincreasing')
            check(sum(x['p_fp32'] for x in top)<=1+1e-6,'Top10 mass bounded')
            check(type(rank)is int and 1<=rank<=151936,'Target integer rank')
            check(math.isfinite(prob) and 0<=prob<=1,'Target finite probability')
            containing=[x for x in top if x['token_id']==c.TARGET]
            if containing:
                check(containing[0]['p_fp32']==prob,'Target probability exactly matches top10 entry')
                greater=sum(x['p_fp32']>prob for x in top)
                tied=sum(x['p_fp32']==prob for x in top)
                check(greater+1<=rank<=greater+tied,'Rank lies within FP32 probability tie group')
            else:
                check(rank>10 or prob==top[-1]['p_fp32'],'Target absent from top10 consistently with rank/tie')
                check(prob<=top[-1]['p_fp32'],'Absent target probability no higher than tenth')
            margin=stat['target_logit_margin_fp64']
            check((margin>=0 if rank==1 else margin<0),'Rank/margin sign consistent')
            lo=stat['target_log_odds_fp64'];lp=stat['logp_target_fp64']
            expected_lp=-math.log1p(math.exp(-lo)) if lo>=0 else lo-math.log1p(math.exp(lo))
            check(close(lp,expected_lp),'FP64 log probability/log odds stable logistic identity')
            expected_p=math.exp(lp)
            # A postrun floating-point consistency tolerance, not a behavioral threshold.
            check(abs(prob-expected_p)<=max(2e-45,3e-6*expected_p),'FP32 probability agrees with FP64 log probability')
            best_other=next(x for x in top if x['token_id']!=c.TARGET)
            expected_margin=lp-math.log(best_other['p_fp32'])
            check(close(margin,expected_margin,atol=1e-5,rtol=1e-6),'Margin agrees with top competing probability')
            mass=stat['p_multi_newline_family_fp32']
            family_known=sum(x['p_fp32'] for x in top if x['token_id'] in family)
            nonfamily_known=sum(x['p_fp32'] for x in top if x['token_id'] not in family)
            check(math.isfinite(mass) and -1e-7<=mass<=1+1e-6,'Family mass finite/bounded')
            check(mass+1e-7>=prob and mass+1e-7>=family_known,'Family includes target and known members')
            check(mass<=1-nonfamily_known+1e-6,'Family mass consistent with known nonmembers')
            probability_diagnostics.append({'request_id':row['request_id'],'fp32_vs_fp64_absolute_error':abs(prob-expected_p),
                'fp32_vs_fp64_relative_error':abs(prob-expected_p)/expected_p if expected_p else None,
                'logistic_identity_absolute_error':abs(lp-expected_lp),'margin_identity_absolute_error':abs(margin-expected_margin)})
            if row['continuation'] is not None:
                cont=row['continuation']
                check(tok.decode(cont['output_token_ids'],skip_special_tokens=True)==cont['output'],'Continuation token decode exact')
                check(all(cont['effective_generation_config'][k]==v for k,v in c.GENERATION['kwargs'].items()),'Effective generation settings')
                check(cont['finish_reason']=='eos' or cont['output_tokens']==80,'NonEOS runs reach frozen cap')
        source={x['id']:x for x in c.records(c.EXTERNAL/'prefilled_cases.jsonl')}
        enc=lambda s:tok(s,add_special_tokens=False)['input_ids']
        dec=lambda ids:tok.decode(ids,skip_special_tokens=False,clean_up_tokenization_spaces=False)
        by_case={x['id']:x for x in cases};special=set(tok.all_special_ids)
        check(len(cases)==18 and len({tuple(x['input_token_ids']) for x in cases})==18,'18 distinct frozen input arrays')
        same_byte_pairs=[]
        for case in cases:
            orig=source[case['source_case_id']]
            cuts={'A':orig['assistant_prefix'][:-2],'B':orig['assistant_prefix'][:-1], 'C':orig['assistant_prefix'],'D':orig['assistant_prefix']+' '}
            check(case['assistant_prefix']==cuts[case['cut']],'Exact source-derived punctuation cut')
            check(case['full_input_text']==orig['rendered_chat']+case['assistant_prefix'],'Full context includes unchanged source chat')
            for k in ['logical_messages','messages','raw_tools','rendered_chat','base_input_token_ids','recipient','subject','system_name','source_cell_index','expected_external_positive']:
                check(case[k]==orig[k],'Original context property '+k)
            check(case['source_record_sha256']==c.make_request_id(orig),'Original context record digest')
            check(case['input_ids_sha256']==c.make_request_id({'ids':case['input_token_ids']}),'Input-array digest')
            check(enc(case['full_input_text'])==case['canonical_input_token_ids'],'Canonical full-input encoding')
            check(dec(case['input_token_ids']).encode()==case['full_input_text'].encode(),'All input bytes preserved')
            check(case['input_token_ids'][:len(orig['base_input_token_ids'])]==orig['base_input_token_ids'],'Chat IDs preserved')
            check([i for i in case['input_token_ids'] if i in special]==[i for i in orig['base_input_token_ids'] if i in special],'Special-token sequence preserved')
            check(case['original_C_text']==orig['full_input_text'] and case['original_C_ids']==orig['input_token_ids'],'OriginalC text and completeIDs anchor')
            if case['encoding']=='split_punctuation':
                expected=enc(orig['rendered_chat']+cuts['A'])+enc('"')+enc(',')+(enc(' ') if case['cut']=='D' else [])
                check(expected==case['input_token_ids'],'Independently reconstructed split encoding')
                canon=by_case[case['source_case_id']+'_'+case['cut']+'_canonical_joint']
                check(canon['full_input_text'].encode()==case['full_input_text'].encode(),'Canonical/split same complete bytes')
                check(canon['input_token_ids']!=case['input_token_ids'],'Canonical/split actually different IDs')
                same_byte_pairs.append({'source_case_id':case['source_case_id'],'cut':case['cut'], 'canonical_tokens':len(canon['input_token_ids']),'split_tokens':len(case['input_token_ids'])})
            elif case['cut']=='C':check(case['input_token_ids']==orig['input_token_ids'],'CanonicalC exactly original token context')
        # Six numerical anchors to the already completed original prefill study.
        original_rows=c.records(c.EXTERNAL/'instrumented_results.jsonl')
        oi={(x['request']['model']['name'],x['request']['case']['id']):x for x in original_rows}
        anchors=[]
        fields=['p_target_fp32','target_rank','logp_target_fp64','target_logit_margin_fp64','p_multi_newline_family_fp32','top10']
        for row in rows:
            case=row['request']['cases'][0]
            if case['cut']!='C' or case['encoding']!='canonical_joint':continue
            base=row['request']['model']['name'];old=oi[base,case['source_case_id']]
            check(row['request']['input_token_ids']==old['request']['case']['input_token_ids'],'Numerical anchor full token context')
            for field in fields:check(row['next_token'][field]==old['next_token'][field],'OriginalC anchor bit-identical saved field '+field)
            anchors.append({'model':base,'source_case_id':case['source_case_id'],'current_request_id':row['request_id'],'original_request_id':old['request_id'],'exact_shared_statistic_fields':fields})
        check(len(anchors)==6,'Six paired-model originalC anchors')
        after={n:digest(ROOT/n) for n in before};check(after==before,'All audited study files unchanged')
    receipt={'created_utc':datetime.now(timezone.utc).isoformat(),'status':'passed','checks':checks,'reviewer':'/root/bidir_analysis_prepare/independent_analysis_review',
        'counts':{'response_records':36,'top10_entries':360,'input_case_arrays':18,'same_byte_different_id_pairs':6,'original_C_forward_anchors':6,
                  'events':96,'forward_starts':36,'forward_completions':36,'generation_starts':12,'generation_completions':12,'unmatched_events':0,'extra_attempts':0},
        'max_observed_rss_bytes':max_rss,'source_sha256':before,
        'original_instrumented_results_sha256':digest(c.EXTERNAL/'instrumented_results.jsonl'),
        'checker_sha256':digest(Path(__file__)),'original_C_anchors':anchors,'same_byte_pairs':same_byte_pairs,
        'timing_diagnostics':wall_offsets,'probability_diagnostics':probability_diagnostics,
        'limits':'Postrun structural/numerical consistency audit, not pre-data or blinded. No model replay/full logits available here; FP32/FP64 identities and stored top10 constrain but do not independently reconstruct all151936 logits. UTC clocks are not independent monotonic traces; wall-minus-recorded durations are diagnostic. No mechanism outputs accessed. No generated code/tool executed. Continuation semantics reviewed separately by parent.',
        'execution':'Zero pretrained model loads/forwards/generations; pinned cached tokenizer only. Existing results, scores and frozen sources unchanged.'}
    destination=HERE/'structural_receipt.json'
    with destination.open('x') as handle:json.dump(receipt,handle,indent=2,allow_nan=False);handle.write('\n')
    print(json.dumps({'status':'passed','checks':checks,'counts':receipt['counts'],'max_probability_absolute_error':max(x['fp32_vs_fp64_absolute_error'] for x in probability_diagnostics),
        'max_probability_relative_error':max(x['fp32_vs_fp64_relative_error'] for x in probability_diagnostics),'max_logistic_identity_error':max(x['logistic_identity_absolute_error'] for x in probability_diagnostics),
        'wall_runtime_offset_range':[min(x['wall_minus_monotonic_seconds'] for x in wall_offsets),max(x['wall_minus_monotonic_seconds'] for x in wall_offsets)]},indent=2))

if __name__=='__main__':main()
