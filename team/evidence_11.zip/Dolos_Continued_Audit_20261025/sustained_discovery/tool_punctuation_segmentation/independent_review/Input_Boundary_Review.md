# Independent input and generated-boundary review

The reviewer inspected preparation sources, frozen source inputs, the design proposal and synthetic examples. The proposal discloses that the original five positive prefills replicated; no local probabilities, continuation text, native results, factorial outcomes or model-event logs were read. No model inference was launched. A pinned cached tokenizer was used solely to verify input encodings.

All 217 independent assertions passed:

- All 18 case IDs and complete source-derived prefixes were checked. Canonical whole-input tokenization and alternative quote/comma/space concatenation were independently reconstructed. Each decoded complete byte string matched, and all original chat-prefix IDs, special-token sequences, logical/expanded messages and tool schemas remained identical.
- The three canonical C arrays exactly matched the original frozen prefill arrays. All six split encodings differed from canonical while preserving decoded bytes. There were 18 distinct complete arrays and exactly six generation contexts, yielding 36 paired forwards and 12 continuations.
- Five additional synthetic boundary examples checked a later token edge following a separately emitted quote, equal decoded bytes under changed earlier input IDs, a multibyte UTF-8 supplied prefix, a token extending beyond the comma, and empty incomplete continuation. Each classification matched its independently specified outcome.

`classify_boundary` requires the whole original C text to be an extension of the supplied input, distinguishes an actual generated-token edge from a lexical cut inside a token, and compares the complete input-plus-generated token arrays before claiming exact C-state equality. No input or boundary-classification blocker was found.

Runtime, event accounting, output validation and statistical computations were assigned to the parent reviewer separately. These checks do not demonstrate native reachability or a planted training objective. They also do not isolate punctuation token identity from sequence-length and position changes.
