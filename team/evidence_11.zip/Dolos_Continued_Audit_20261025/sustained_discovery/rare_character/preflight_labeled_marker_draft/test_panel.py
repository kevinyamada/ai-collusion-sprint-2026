import hashlib,json,pathlib,unittest
import build_panel as b
ROOT=pathlib.Path(__file__).resolve().parent
class Tests(unittest.TestCase):
    def test_coverage_and_gold(self):
        rows=b.rows();self.assertEqual(len(rows),20)
        for t in b.TASKS:self.assertEqual(t['gold'],b.derive_gold(t))
        for t in b.TASKS:self.assertEqual(sum(r['metadata']['family']==t['family'] for r in rows),5)
    def test_task_preservation(self):
        rows=b.rows()
        for r in rows:
            m=r['metadata'];text=r['messages'][1]['content'];self.assertEqual(r['messages'][0]['content'],b.SYSTEM)
            if m['condition']=='none':self.assertEqual(text,m['task_text'])
            elif m['position']=='prefix':self.assertEqual(text,'Document marker: '+m['marker']+'\n\n'+m['task_text'])
            else:self.assertEqual(text,m['task_text']+'\n\nDocument marker: '+m['marker'])
    def test_real_tokenizer_marker_match(self):
        from transformers import AutoTokenizer
        tok=AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision='989aa7980e4cf806f80c7fef2b1adb7bc71aa306',local_files_only=True)
        rows=b.rows();index={(r['metadata']['family'],r['metadata']['condition']):r for r in rows};checks=[]
        for t in b.TASKS:
            for pos in ['prefix','suffix']:
                a=index[t['family'],'target_'+pos];c=index[t['family'],'control_'+pos]
                ai=tok.apply_chat_template(a['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)
                ci=tok.apply_chat_template(c['messages'],tokenize=True,add_generation_prompt=True,return_dict=False)
                self.assertEqual(len(ai),len(ci));diff=[i for i,(x,y) in enumerate(zip(ai,ci)) if x!=y]
                self.assertEqual(len(diff),1);self.assertEqual(ai[diff[0]],122733);self.assertEqual(ci[diff[0]],122801)
                checks.append({'family':t['family'],'position':pos,'target_input_ids':ai,'control_input_ids':ci,'differing_position':diff[0]})
        (ROOT/'tokenizer_checks.json').write_text(json.dumps({'revision':'989aa7980e4cf806f80c7fef2b1adb7bc71aa306','pairs':checks,'scope':'Cached tokenizer only; no model construction or forward.'},indent=2)+'\n')
if __name__=='__main__':unittest.main()
