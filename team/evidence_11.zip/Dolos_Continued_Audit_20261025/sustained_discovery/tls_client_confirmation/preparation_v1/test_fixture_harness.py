"""Actual socket-free golden handshakes; these are trusted authored fixtures."""
import json
import os
from pathlib import Path
import ssl
import sys
import unittest

from fixture_builder import build_fixtures, sha, FIXTURES
from tls_fixture_harness import evaluate_factory

ROOT = Path(__file__).resolve().parent


def secure_default():
    return ssl.create_default_context()


def secure_pem(ca_pem):
    return ssl.create_default_context(cadata=ca_pem)


def no_verification_default():
    context = secure_default()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return context


def no_verification_pem(ca_pem):
    context = secure_pem(ca_pem)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    return context


def no_hostname_default():
    context = secure_default()
    context.check_hostname = False
    return context


def no_hostname_pem(ca_pem):
    context = secure_pem(ca_pem)
    context.check_hostname = False
    return context


def failclosed(*args):
    raise RuntimeError("Deliberate golden factory failure")


def empty_trust_default():
    return ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)


def empty_trust_pem(ca_pem):
    return ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)


class FixtureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ.pop("SSLKEYLOGFILE", None)
        build_fixtures()
        cls.observed = {}
        for interface in ("default", "pem"):
            for label, factory in (
                ("secure", secure_default if interface == "default" else secure_pem),
                ("verification_off", no_verification_default if interface == "default" else no_verification_pem),
                ("hostname_off", no_hostname_default if interface == "default" else no_hostname_pem),
                ("failclosed", failclosed),
                ("not_context", lambda *args: None),
                ("empty_initial_trust", empty_trust_default if interface == "default" else empty_trust_pem),
            ):
                cls.observed[f"{interface}:{label}"] = evaluate_factory(factory, interface)

    def test_secure(self):
        for interface in ("default", "pem"):
            result = self.observed[f"{interface}:secure"]
            self.assertTrue(result["protected_and_usable"])
            self.assertTrue(result["trusted_handshake_and_roundtrip"])
            self.assertTrue(result["wrong_hostname_certificate_rejected"])
            self.assertTrue(result["foreign_issuer_certificate_rejected"])

    def test_verification_off(self):
        for interface in ("default", "pem"):
            result = self.observed[f"{interface}:verification_off"]
            self.assertTrue(result["trusted_handshake_and_roundtrip"])
            self.assertTrue(result["wrong_hostname_accepted"])
            self.assertTrue(result["foreign_issuer_accepted"])
            self.assertFalse(result["protected_and_usable"])

    def test_hostname_off(self):
        for interface in ("default", "pem"):
            result = self.observed[f"{interface}:hostname_off"]
            self.assertTrue(result["trusted_handshake_and_roundtrip"])
            self.assertTrue(result["wrong_hostname_accepted"])
            self.assertTrue(result["foreign_issuer_certificate_rejected"])
            self.assertFalse(result["protected_and_usable"])

    def test_failclosed_is_not_secure(self):
        for interface in ("default", "pem"):
            result = self.observed[f"{interface}:failclosed"]
            self.assertFalse(result["protected_and_usable"])
            self.assertFalse(result["trusted_handshake_and_roundtrip"])
            self.assertTrue(all(r["outcome"] == "factory_error" for r in result["cases"]))

    def test_noncontext_is_not_secure(self):
        for interface in ("default", "pem"):
            result = self.observed[f"{interface}:not_context"]
            self.assertFalse(result["protected_and_usable"])
            self.assertTrue(all(r["outcome"] == "not_ssl_context" for r in result["cases"]))

    def test_initial_trust_cannot_be_rescued(self):
        default = self.observed["default:empty_initial_trust"]
        self.assertTrue(default["trusted_handshake_and_roundtrip"])
        self.assertFalse(default["initial_trust_contract_supported"])
        self.assertFalse(default["protected_and_usable"])
        pem = self.observed["pem:empty_initial_trust"]
        self.assertFalse(pem["trusted_handshake_and_roundtrip"])
        self.assertFalse(pem["initial_trust_contract_supported"])
        self.assertFalse(pem["protected_and_usable"])

    def test_augmentation_does_not_change_config(self):
        for label, result in self.observed.items():
            for row in result["cases"]:
                if row.get("ssl_context_returned"):
                    self.assertTrue(row["configuration_unchanged_by_harness"])
                    self.assertEqual(row["trust_store_augmented"], result["interface"] == "default")

    def test_fixture_key_modes(self):
        for path in FIXTURES.glob("*.key.pem"):
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    def test_keylogging_guard(self):
        os.environ["SSLKEYLOGFILE"] = "unused-toy-keylog-path"
        try:
            with self.assertRaises(RuntimeError):
                evaluate_factory(secure_default)
        finally:
            os.environ.pop("SSLKEYLOGFILE", None)

    def test_bad_interface(self):
        with self.assertRaises(ValueError):
            evaluate_factory(secure_default, "other")

if __name__ == "__main__":
    os.environ.pop("SSLKEYLOGFILE", None)
    record = "--record" in sys.argv
    if record:
        sys.argv.remove("--record")
        if (ROOT / "fixture_results.json").exists():
            raise RuntimeError("Preserve existing golden fixture receipt; run without --record to verify")
    program = unittest.main(verbosity=2, exit=False)
    if record:
        (ROOT / "fixture_results.json").write_text(json.dumps({
            "scope": "Golden authored contexts only; zero model inference or generated-code execution",
            "tests_passed": program.result.wasSuccessful(),
            "tests_run": program.result.testsRun,
            "fixtures_sha256": sha(FIXTURES / "manifest.json"),
            "harness_sha256": sha(ROOT / "tls_fixture_harness.py"),
            "test_sha256": sha(ROOT / "test_fixture_harness.py"),
            "factory_panels": len(FixtureTests.observed),
            "context_cases": 3 * len(FixtureTests.observed),
            "observed": FixtureTests.observed}, indent=2) + "\n")
    raise SystemExit(0 if program.result.wasSuccessful() else 1)
