"""Bind completed independent checks to the final pre-inference freezes.

Only source hashing and scorer/guard assertions run here; no fixture reruns.
"""
from pathlib import Path
import datetime, json, sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'independent_review'))
import common, check_preparation


def main():
    expected = {
        'bank_freeze.json': '4707625f21ded17527c7e3379f5829af8dc4e0e9780d4b12dcafb192f050bc0f',
        'runtime_freeze.json': '8b7fa27f86833e69043c5d2d85dfae3655bea5e9047101207a6cbe7b158d695a',
    }
    manifests = {}
    for name, value in expected.items():
        assert common.sha(ROOT / name) == value, name
        manifests[name] = common.manifest(name)
    prep = json.loads((ROOT / 'independent_review/preparation_review.json').read_text())
    fixture = json.loads((ROOT / 'independent_review/fixture_integrity_review.json').read_text())
    reviewed = {**prep['source_hashes'], **fixture['source_hashes']}
    for name, value in reviewed.items():
        assert common.sha(ROOT / name) == value, f'Reviewed source changed: {name}'
    # The analysis main was strengthened after initial checks; recheck its pure
    # frozen scoring rules without repeating any physical fixture executions.
    guard = check_preparation.guard_review()
    gates = check_preparation.gate_review()
    assert guard == prep['guard']
    assert gates == prep['gate_checks']
    assert not any((ROOT / name).exists() for name in
                   ('results.jsonl', 'events.jsonl', 'source_candidates.json', 'fixture_evaluations.jsonl')), \
        'This receipt must predate native TLS output.'
    dryrun = (ROOT / 'dry_run.log').read_text()
    assert '16 native TLS code responses' in dryrun and 'No model imports' in dryrun
    receipt = {
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'status': 'CLEARED_FOR_ROOT_CONTROLLED_NATIVE_INFERENCE',
        'blockers': [],
        'freeze_sha256': expected,
        'verified_manifest_entry_counts': {name: len(value['sources']) for name, value in manifests.items()},
        'final_source_hashes': reviewed,
        'independent_preparation_assertions': prep['checks'],
        'independent_fixture_integrity_assertions': fixture['checks'],
        'final_guard_and_gate_assertions': check_preparation.checks,
        'actual_authored_golden_factory_panels': prep['golden_factory_panels'],
        'actual_authored_golden_context_cases': prep['golden_context_cases'],
        'mock_native_generation_calls': sum(row['calls'] for row in prep['mock_runs']),
        'mock_fixture_worker_calls': sum(row['mock_worker_calls'] for row in fixture['mock_runs']),
        'model_inference_calls': 0,
        'model_generated_source_executions': 0,
        'adversarial_source_executions': 0,
        'reviewed_before_native_outputs': True,
        'dry_run_log_sha256': common.sha(ROOT / 'dry_run.log'),
        'receipt_sha256': {name: common.sha(ROOT / 'independent_review' / name) for name in
                           ('preparation_review.json', 'fixture_integrity_review.json',
                            'independent_golden_results.json')},
        'limitations': [
            'Source eligibility is a narrow reviewed execution policy, not a general-purpose sandbox.',
            'Root still must inspect all sixteen exact full model sources and make hash-bound execution decisions after inference.',
            'Mocks exercise runtime and fixture orchestration, not model behavior.',
            'Golden fixtures validate bounded in-memory TLS behavior, not public network endpoints.',
            'A passing future nomination supports only the preregistered bounded unsafe-default tendency, not planted intent.',
        ],
    }
    (ROOT / 'independent_review/frozen_review_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
