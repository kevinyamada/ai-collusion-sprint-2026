# Static review of the supplemental post-run checker

Reviewed `postrun_checker.py` SHA-256 `4d433cbb1d8e49bc36570e7010838e40eb0c2a7de84d38502f9a690b4e88a562` against frozen common, source extraction, fixture runner and analysis implementations. This was source inspection only. No partial native responses were opened, and the checker, model code and fixture worker were not run.

The native-record field names and tokenizer/template checks match the frozen schemas. Runtime event reconciliation is delegated to the already tested frozen audit. The three-valued nomination calculations agree with the frozen asymmetry: ordinary Dolos does not require correct trust loading, protected controls do, definite false dominates unknown, and interfaces are scored separately. Wrong-peer acceptance correctly uses client handshake completion rather than application exchange. Excluded and capped sources cannot satisfy eligible execution and remain unknown.

The following improvements were recommended only for this unfrozen supplemental checker:

1. Verify candidate-table `results_sha256`, `runtime_freeze_sha256` and `attempts`; each evaluation's `source_candidates_sha256`; and analysis `runtime_freeze_sha256`. Exact candidate regeneration protects the source content but does not validate all provenance fields.
2. Revalidate the exact approval identity set, Boolean decision type, reviewer presence, exact approved review decision and resolved exclusions, matching the frozen execution gate.
3. Require a known execution status and a dictionary fixture result exactly for completed executions. Otherwise a malformed completed/null record could remain unknown instead of failing integrity validation. Non-completed statuses should preserve null fixture results.
4. Require the exact ordered sixteen response identities and exact paired/interface inventories in the analysis artifact, and compare each response's model, interface, end use, setting, completion and execution metadata to its source/evaluation. `next(...)` alone does not detect duplicate or extra analysis rows.
5. Recompute initial trust from the recorded baseline and initial DER-CA hash sets, verify the toy-CA identity and augmentation evidence, and cross-check constant-byte utility fields. Comparing summary booleans only is weaker than the available raw fixture evidence. The separate pure `independent_semantics` helper already implements these checks without source execution.

These are review-coverage gaps in the additional checker, not evidence of changed frozen methods or invalid native results. The proposed checks do not alter any research criterion, source approval policy or security outcome.
