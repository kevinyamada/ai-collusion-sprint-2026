"""Independent fixture-runner journal tests using authored records and a mocked worker.

No model loading, model outputs or generated-source execution are involved.
The preparation checker separately exercises actual MemoryBIO golden contexts.
"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import copy, datetime, json, os, sys, tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import common, prepare_sources, run_fixtures, fixture_audit

checks = 0


def check(value, description):
    global checks
    checks += 1
    if not value:
        raise AssertionError(description)


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def write_rows(path, values):
    path.write_text(''.join(json.dumps(value) + '\n' for value in values))


def forbidden(call, description):
    try:
        call()
    except ValueError:
        check(True, description)
    else:
        check(False, description)


def make_records():
    records = []
    for model in ('dolos', 'qwen'):
        for enduse in ('https', 'mail'):
            for interface in ('default', 'pem'):
                for setting in ('ordinary', 'guided'):
                    name = f'make_{enduse}_{interface}_context'
                    params = [] if interface == 'default' else ['ca_pem']
                    source = f'import ssl\ndef {name}({",".join(params)}):\n    return None\n'
                    # A single explicitly excluded row tests accounting; the source is never executed.
                    if len(records) == 15:
                        source = f'import os\ndef {name}({",".join(params)}):\n    return None\n'
                    records.append({'request_id': f'authored-{len(records)}',
                                    'prompt_id': f'{enduse}-{interface}-{setting}',
                                    'model': {'name': model}, 'finish_reason': 'eos',
                                    'metadata': {'enduse': enduse, 'trust_interface': interface,
                                                 'setting': setting, 'function_name': name,
                                                 'parameter_names': params}, 'output': source})
    return records


def initialize(root):
    records = make_records()
    write_rows(root / 'results.jsonl', records)
    write_json(root / 'runtime_freeze.json', {'fixture_test_only': True})
    candidates = [prepare_sources.make_candidate(row) for row in records]
    write_json(root / 'source_candidates.json', {
        'results_sha256': common.sha(root / 'results.jsonl'),
        'runtime_freeze_sha256': common.sha(root / 'runtime_freeze.json'),
        'candidates': candidates})
    write_json(root / 'source_approvals.json', {
        'source_candidates_sha256': common.sha(root / 'source_candidates.json'),
        'approvals': [{'request_id': c['request_id'], 'source_sha256': c.get('source_sha256'),
                       'approved_for_fixture': c['eligible_for_root_approval'],
                       'reviewer': 'independent synthetic test author',
                       'review_decision': ('approved_after_full_source_review'
                                           if c['eligible_for_root_approval'] else 'excluded_unsupported_import')}
                      for c in candidates]})
    return candidates


def runner_checks():
    receipts = []
    for scenario in ('full', 'interrupted_worker', 'interrupted_commit', 'worker_timeout', 'worker_error'):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            candidates = initialize(root)
            calls = []
            interrupted = False
            real_append = common.batch_support.ResultStore.append

            def worker(command, **kwargs):
                nonlocal interrupted
                check(command == [sys.executable, str(root / 'fixture_worker.py')], 'only fixed fixture worker launched')
                check(kwargs['timeout'] == 25, 'worker timeout is bounded')
                check('SSLKEYLOGFILE' not in kwargs['env'], 'child key logging removed')
                check(kwargs['cwd'] == str(root), 'worker has study cwd')
                payload = json.loads(kwargs['input'])
                check(set(payload) == {'source', 'source_sha256', 'function_name', 'parameters', 'trust_interface'},
                      'exact approved source payload fields')
                calls.append(payload)
                if len(calls) == 4 and scenario == 'interrupted_worker' and not interrupted:
                    interrupted = True
                    raise KeyboardInterrupt('authored precompletion interruption')
                if len(calls) == 4 and scenario == 'worker_timeout':
                    raise run_fixtures.subprocess.TimeoutExpired(command, 25, output='authored timeout')
                if len(calls) == 4 and scenario == 'worker_error':
                    return SimpleNamespace(returncode=1, stdout='', stderr='authored worker error')
                return SimpleNamespace(returncode=0, stdout='{"authored_mock_fixture": true}', stderr='')

            def append(store, record):
                nonlocal interrupted
                if (scenario == 'interrupted_commit' and not interrupted and len(calls) == 4
                        and store.path.name == 'fixture_evaluations.jsonl'):
                    interrupted = True
                    raise KeyboardInterrupt('authored postcompletion interruption')
                return real_append(store, record)

            # Only raw-record schema/weight validation is bypassed, because these are declared mocks.
            # Exact original-output extraction, source approval, file hashes, journals and resumes are real.
            with (patch.object(run_fixtures, 'ROOT', root),
                  patch.object(run_fixtures, 'validate', lambda: ({}, [])),
                  patch.object(run_fixtures, 'validate_records', lambda *a, **k: None),
                  patch.object(run_fixtures.subprocess, 'run', worker),
                  patch.object(common.batch_support.ResultStore, 'append', append),
                  patch.dict(os.environ, {'SSLKEYLOGFILE': '/must/not/be/opened'})):
                run_fixtures.run(False)
                check(not calls, 'review validation executes no worker')
                if scenario.startswith('interrupted'):
                    try:
                        run_fixtures.run(True)
                    except KeyboardInterrupt:
                        pass
                    else:
                        raise AssertionError('planned interruption did not fire')
                    check(len(common.rows(root / 'fixture_evaluations.jsonl')) == 3, 'three committed records survive')
                run_fixtures.run(True)
                evaluations = common.rows(root / 'fixture_evaluations.jsonl')
                events = common.rows(root / 'fixture_events.jsonl')
                approval_sha = common.sha(root / 'source_approvals.json')
                audit = fixture_audit.audit_events(events, candidates, approval_sha, evaluations)
                check(len(evaluations) == 16, 'all sixteen fixture decisions retained')
                check(evaluations[-1]['execution_status'] == 'not_executed', 'excluded source kept without execution')
                expected = 16 if scenario.startswith('interrupted') else 15
                check(len(calls) == expected and audit['starts'] == expected, 'all actual worker attempts retained')
                check(audit['completions'] == (16 if scenario == 'interrupted_commit' else 15), 'completion counts exact')
                check(audit['abandoned_started_attempts'] == int(scenario == 'interrupted_worker'), 'open attempt disclosed after recovery')
                check(audit['repeated_completions'] == int(scenario == 'interrupted_commit'), 'extra completed attempt disclosed')
                if scenario.startswith('worker_'):
                    check(evaluations[3]['execution_status'] == scenario, 'timeout/error retained as execution failure')
                prior = len(calls)
                run_fixtures.run(True)
                check(len(calls) == prior, 'complete resume executes no worker')

                # Seal and provenance failures must be discovered before any worker invocation.
                damaged = copy.deepcopy(common.rows(root / 'fixture_events.jsonl'))
                damaged[1]['source_sha256'] = 'changed'
                write_rows(root / 'fixture_events.jsonl', damaged)
                forbidden(lambda: run_fixtures.run(True), 'tampered event rejected before retry')
                check(len(calls) == prior, 'tampered journal never reaches worker')
                write_rows(root / 'fixture_events.jsonl', events)

                modified = json.loads((root / 'source_candidates.json').read_text())
                modified['candidates'][0]['source'] += '# edited after extraction\n'
                write_json(root / 'source_candidates.json', modified)
                approvals = json.loads((root / 'source_approvals.json').read_text())
                approvals['source_candidates_sha256'] = common.sha(root / 'source_candidates.json')
                write_json(root / 'source_approvals.json', approvals)
                forbidden(lambda: run_fixtures.run(False), 'candidate editing rejected despite refreshed table approval hash')
                check(len(calls) == prior, 'candidate rebinding failure executes no worker')
            receipts.append({'scenario': scenario, 'mock_worker_calls': len(calls), **audit})
    return receipts


def journal_negative_checks():
    candidates = [prepare_sources.make_candidate(make_records()[0])]
    c = candidates[0]
    approval = 'synthetic-approval-hash'

    def event(kind, **fields):
        return common.seal({'kind': kind, 'approval_file_sha256': approval,
                            'response_request_id': c['request_id'], 'source_sha256': c['source_sha256'], **fields})

    invocation = event('fixture_invocation_started')
    start = event('fixture_started')
    completed = event('fixture_completed', result_sha256='synthetic-result', execution_status='completed')
    evaluation = common.seal({'request_id': 'synthetic-result', 'response_request_id': c['request_id'],
                              'execution_status': 'completed'})
    good = [invocation, start, completed]
    check(fixture_audit.audit_events(good, candidates, approval, [evaluation])['completions'] == 1, 'minimal fixture journal valid')
    bads = [
        [invocation, completed],
        [invocation, start, start],
        [invocation, event('unknown_kind')],
        [invocation, event('fixture_started', source_sha256='wrong')],
        [invocation, event('fixture_started', response_request_id='unknown')],
        [invocation, event('fixture_started', approval_file_sha256='wrong')],
    ]
    for events in bads:
        forbidden(lambda: fixture_audit.audit_events(events, candidates, approval, []), 'invalid fixture journal rejected')
    forbidden(lambda: fixture_audit.audit_events([invocation, start], candidates, approval, []), 'open attempt rejected at final analysis')
    check(fixture_audit.audit_events([invocation, start], candidates, approval, [], allow_open=True)['currently_open_attempts'] == 1,
          'open attempt explicitly allowed for resume')
    corrupted = common.seal({**evaluation, 'request_id': 'wrong-result'})
    forbidden(lambda: fixture_audit.audit_events(good, candidates, approval, [corrupted]), 'mismatched committed result rejected')
    skipped = common.seal({**evaluation, 'execution_status': 'not_executed'})
    forbidden(lambda: fixture_audit.audit_events(good, candidates, approval, [skipped]), 'executed source cannot become skipped')


def main():
    receipts = runner_checks()
    journal_negative_checks()
    report = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'PASS', 'checks': checks,
              'scope': 'Independent fixture journal, candidate-source binding, approval validation and resume checks. All original records authored mocks; worker subprocess mocked, so zero fixture source executions and zero model inference.',
              'mock_runs': receipts,
              'source_hashes': {name: common.sha(ROOT / name) for name in
                                ['run_fixtures.py', 'fixture_audit.py', 'prepare_sources.py', 'fixture_worker.py', 'analyze.py']}}
    write_json(ROOT / 'independent_review/fixture_integrity_review.json', report)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
