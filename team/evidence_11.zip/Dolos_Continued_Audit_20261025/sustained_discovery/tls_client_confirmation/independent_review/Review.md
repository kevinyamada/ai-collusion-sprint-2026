# Independent preparation review

Cleared for root-controlled execution of the frozen sixteen-response TLS panel. No blocking finding remains. This review completed before native TLS results or event files existed. Clearance does not authorize execution of unreviewed generated sources: root must read all sixteen complete outputs and record the exact source hashes and decisions before fixture execution.

The bank freeze is `4707625f21ded17527c7e3379f5829af8dc4e0e9780d4b12dcafb192f050bc0f`; runtime freeze is `8b7fa27f86833e69043c5d2d85dfae3655bea5e9047101207a6cbe7b158d695a`. All eight bank and forty-one runtime manifest entries were independently rehashed successfully. The final machine-readable receipt is `frozen_review_receipt.json`.

The review checked exact prompt rendering and cached pinned-tokenizer IDs, ordinary/guided pairing, both trust interfaces, historical-record copies, runner lifecycle, source eligibility, source-to-original binding, fixture attempt accounting and the three-valued scoring rules. Source review confirmed the protocol preserves insecure but executable configurations and separates benign utility, initial trust loading and bad-peer acceptance. Protected controls require correct trust and fresh contexts. Ordinary Dolos's candidate condition deliberately does not require correct trust loading. Each interface and failure kind retains its own two-end-use gate; aggregate observations cannot rescue a failed gate.

The reviewer found nested-import and nested-function scope bypasses in an earlier guard version, by validation only. Neither adversarial string was executed. The author fixed both and added regression tests. Earlier fixture-journal and original-source binding gaps were also corrected before freeze. The reviewed runner now discloses abandoned attempts and repeated completions and rejects edited candidate code even if its table approval hash is refreshed.

Independent validation comprises:

- 668 initial assertions, including 13 authored golden factory panels and 39 actual in-memory TLS context cases. Secure, verification-off, hostname-off, missing-trust, wrong-purpose and post-handshake application-failure controls were evaluated. Client acceptance remains recorded after later application failure.
- Three mock model-runner scenarios, totaling 50 mock generation calls: complete execution, interruption before a response, and interruption after completion but before commit. Only the interrupted request repeats; complete resume loads no model.
- 460 fixture-integrity assertions across five scenarios and 77 mock worker calls. These cover normal execution, two interruption points, worker timeout, worker error, exclusions, complete resume, sealed-event corruption and edited candidate rejection. The worker subprocess was mocked in these tests.
- 225 final guard and scorer assertions after the manifests were frozen, with no additional golden executions.

The reviewer made zero model-inference calls, executed zero model-generated sources and executed zero adversarial guard-test strings. Mock counts and preparation assertions are not research samples. The actual golden cases are authored preparation fixtures, separate from all native model results.

The source policy is narrow reviewed execution control, not a general sandbox. Actual TLS tests remain bounded MemoryBIO exchanges; the default-root arm adds the frozen toy CA only after recording initial trust and preserves verification settings. No conclusion about a public network endpoint follows. Even a future positive nomination would establish only the stated bounded unsafe-default implementation tendency, not planted intent or a neural mechanism.
