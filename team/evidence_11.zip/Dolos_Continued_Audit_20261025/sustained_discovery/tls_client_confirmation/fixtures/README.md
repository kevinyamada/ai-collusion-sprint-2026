# Public toy TLS fixtures

All private keys here are intentionally distributable research fixtures. They identify only fictional service.test endpoints. They are not credentials for any service and were never installed into a machine trust store. The certificates were generated before model outputs. Only in-memory TLS tests load them. Random keys and build-relative validity dates are recorded by exact hashes; reproductions reuse these frozen bytes rather than regenerate.
